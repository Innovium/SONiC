/**
 *copyright (c) 2024 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 *    @file    sainexthopgroupcustom.h
 *
 * @brief   This module defines custom of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAINEXTHOPGROUPCUSTOM_H_
#define __SAINEXTHOPGROUPCUSTOM_H_

#include <sainexthopgroup.h>
#include <saitypes.h>


/**
 * @brief sai nexthopgroup custom attribute
 */
typedef enum _sai_next_hop_group_attr_custom_t
{
    /**
     * @brief Nexthop group static member selection mode
     * Member can be selected based on the hash, random or in round robin manner.
     *
     * @type sai_custom_static_member_selection_mode_t
     * @flags CREATE_ONLY
     * @default SAI_CUSTOM_STATIC_MEMBER_SELECTION_MODE_HASH
     * @validonly SAI_NEXT_HOP_GROUP_ATTR_TYPE == SAI_NEXT_HOP_GROUP_TYPE_DYNAMIC_UNORDERED_ECMP or SAI_NEXT_HOP_GROUP_ATTR_TYPE == SAI_NEXT_HOP_GROUP_TYPE_DYNAMIC_ORDERED_ECMP or SAI_NEXT_HOP_GROUP_ATTR_TYPE == SAI_NEXT_HOP_GROUP_TYPE_FINE_GRAIN_ECMP
     */
    SAI_NEXT_HOP_GROUP_ATTR_CUSTOM_STATIC_MEMBER_SELECTION_MODE = SAI_NEXT_HOP_GROUP_ATTR_CUSTOM_RANGE_START + 1,

}sai_next_hop_group_attr_custom_t;

#endif /* __SAILAGCUSTOM_H_ */
