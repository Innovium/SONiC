
#-------------------------------------------------------------------------------
# * Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

from ctypes import *
from utils.compat_util import *
from verbosity import log, log_dbg, log_err
from ifcs_cmds.extended_field_list import *
from print_table import PrintTable
import sys
ifcs_ctypes=sys.modules['ifcs_ctypes']


extended_field_list_enums = [
   'mac_da',
   'mac_sa',
   'svid',
   'cvid',
   'ethertype',
   'ipv4_destination_ip',
   'ipv4_source_ip',
   'ipv4_protocol',
   'ipv6_destination_ip',
   'ipv6_source_ip',
   'ipv6_nextheader',
   'ipv6_flow_label',
   'tcp_udp_sport',
   'tcp_udp_dport',
   'gre_protocol',
   'gre_key',
   'source_sysport',
   'rdma_bth_opcode',
   'rdma_bth_dest_qp',
   'fpf_field1',
   'fpf_field2',
   'fpf_field3',
   'fpf_field4',
   'fpf_field5',
   'fpf_field6',
   'fpf_field7',
   'fpf_field8',
   'fpf_tunnel_payload_field1',
   'fpf_tunnel_payload_field2',
   'fpf_tunnel_payload_field3',
   'fpf_tunnel_payload_field4',
   'fpf_tunnel_payload_field5',
   'fpf_tunnel_payload_field6',
   'fpf_tunnel_payload_field7',
   'fpf_tunnel_payload_field8',
]

def show_extended_field_list_extension_brief(args, extended_field_list):
    log_dbg(1, " Inside extended_field_list extension brief show")

    try:
        rc, all_extended_field_list = extended_field_list.bulk_get_all_extended_field_list_keys()
    except BaseException:
        log_err(" Failed to get all extended_field_list")
        return

    table = PrintTable()
    field_names = []
    field_names.append('extended_field_list')

    field_names.append('elements')
    table.add_row(field_names)
    all_extended_field_list = sorted(all_extended_field_list)

    log("Total extended_field_list count: {0} ".format(len(all_extended_field_list)))
    count = 0
    for efl in all_extended_field_list:
        attr_row = []
        attr_row.append(extended_field_list.handle_to_str(efl))

        try:
            elements = extended_field_list.getElements(efl, True)
        except KeyError:
            einfo = "{}".format(sys.exc_info())
            log_dbg(
                1,
                "KeyError in show extended_field_list extension brief. extended_field_list: {} ({}), error: {}"
                .format(efl, extended_field_list.handle_to_str(efl), einfo))
            if extended_field_list.not_found_exc_msg.format(
                    ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                # Skip the instance as the object is not found.
                continue
            # Re-raise other exceptions for handling.
            raise

        ext_flds = []
        for e in elements:
            ext_flds.append(extended_field_list_enums[e])

        attr_row.append(str(ext_flds))

        table.add_row(attr_row)
        count += 1

    table.print_table(brief=True)
    table.reset_table()
    log("Total extended_field_list count: {0} \n".format(count))
    return


def show_extended_field_list_extension_attrs(args,
                                             extended_field_list,
                                             ignore_notfound_err=False,
                                             display_count=False,
                                             count_val=0,
                                             group=None):
    log_dbg(1, " Inside extended_field_list extension attrs show")

    if not extended_field_list:
        return

    attrCount = ifcs_ctypes.IFCS_EXTENDED_FIELD_LIST_ATTR_COUNT_GET_ALL
    attr = (ifcs_ctypes.ifcs_attr_t * attrCount)()
    attr_p = compat_pointer(attr, ifcs_ctypes.ifcs_attr_t)

    valid_im_attrs = 0

    if group == 'im':
        im_attr_count = len(extended_field_list.im_attrlist)
        im_attr = (ifcs_ctypes.ifcs_attr_t * im_attr_count)()
        im_attr_p = compat_pointer(im_attr, ifcs_ctypes.ifcs_attr_t)
        idx = 0
        for im_attr_id in extended_field_list.im_attrlist.keys():
            im_attr[idx].id = int(im_attr_id)
            idx += 1
    try:
        actual_count = extended_field_list.getAttr(
            ifcs_ctypes.IFCS_HANDLE_EXTENDED_FIELD_LIST(int(args)), attr,
            attr_p, attrCount, ignore_notfound_err)
        if group == 'im':
            extended_field_list.getIMAttr(im_attr, im_attr_p, im_attr_count, ignore_notfound_err)
    except KeyError:
        einfo = "{}".format(sys.exc_info())
        log_dbg(
            1,
            "KeyError in show extended_field_list extension attrs. extended_field_list: {}, error: {}"
            .format(args, einfo))
        if ignore_notfound_err and extended_field_list.not_found_exc_msg.format(
                ifcs_ctypes.IFCS_NOTFOUND) in einfo:
            # Don't display error message for expected exception.
            # Re-raise for handling.
            raise
        log_err("Failed to get attributes for extended_field_list ")
        raise
    except:
        log_dbg(
            1,
            "OtherError in show extended_field_list extension attrs. extended_field_list: {}, error: {}"
            .format(args, sys.exc_info()))
        log_err("Failed to get attributes for extended_field_list ")
        raise KeyError

    if display_count:
        log("ExtendedFieldList count: {0} ".format(count_val))

    table = PrintTable()
    table.add_row(['Identifier',extended_field_list.handle_to_str(ifcs_ctypes.IFCS_HANDLE_EXTENDED_FIELD_LIST(int(args)), True)])

    for j in range(actual_count.value):
        attr_name, attr_type, attr_value, attr_valid = extended_field_list.get_attr_name_value(attr[j])
        if not attr_valid:
            continue
        if attr_value == '[ ]':
            table.add_row([attr_name, attr_value])
            continue
        if attr_name == 'elements':
            elements = []
            for i in range(len(attr_value)):
                elements.append(extended_field_list_enums[attr_value[i]])
            table.add_row([attr_name,elements])
        elif attr_name == 'ref_count':
            table.add_row([attr_name,attr_value])
        elif attr_name == 'elements_mask':
            mask_arr=[]
            for i in range(len(attr_value)):
                mask_val = ((1 << attr_value[i].size) - 1) << attr_value[i].offset
                mask_arr.append(f"0x{mask_val:X}")
            table.add_row([attr_name, mask_arr])
        elif attr_name == 'elements_sequence_id':
            elements_sequence = []
            for seq_id in attr_value:
                elements_sequence.append(seq_id)
            table.add_row([attr_name, elements_sequence])

    if group == 'im':
        for j in range(im_attr_count):
            attr_name, attr_type, attr_value, attr_valid, valid_im_attrs = extended_field_list.get_im_attr_name_value(im_attr[j], valid_im_attrs)
            if not attr_valid:
                continue
            elements = []
            if isinstance(attr_value, list):
                for i in range(len(attr_value)):
                    elements.append(extended_field_list_enums[attr_value[i]])
            else:
                elements = attr_value
            table.add_row([attr_name,elements])

    if valid_im_attrs:
        table.set_footer_size(valid_im_attrs)
    table.print_table()
    table.reset_table()
    return
