#-------------------------------------------------------------------------------
# * Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import socket
import struct
from shlex import *
from argparse import *
from ctypes import *
from time import *
import sys
try:
    ifcs_ctypes = sys.modules["ifcs_ctypes"]
except KeyError:
    import ifcs_ctypes
from utils.ifcs_types_util import *
from collections import OrderedDict
from utils.common_util import build_ipaddr_attr
from utils.common_util import build_fwd_policy_attr_value
from utils.common_util import getHandlesFromIfcsHandleList
from utils.mac_util import mac_addr_to_str
from utils.mac_util import get_ctype_arr
from utils.mac_util import convertMacstrtoarr

def convert_error_code_to_string(error_code):
    error_to_string = {
            0 : "IFCS_SUCCESS (Success)",
            1 : "IFCS_UNINIT (IFCS Uninitialized)",
            2 : "IFCS_BUSY (Resource in use)",
            3 : "IFCS_CONFIG (Invalid configuration)",
            4 : "IFCS_MEMORY (Out of memory)",
            5 : "IFCS_PARAM (Invalid parameter)",
            6 : "IFCS_EXIST (Entry already exists)",
            7 : "IFCS_MULTI_EXIST (Multiple entries already exist)",
            8 : "IFCS_ENTRY_REPLACED (Entry replaced)",
            9 : "IFCS_LENGTH_MISMATCH (Entry length mismatch)",
            10 : "IFCS_NOTFOUND (Entry not found in device)",
            11 : "IFCS_INVAL (Invalid argument)",
            12 : "IFCS_UNSUPPORTED (Unsupported API or configuration)",
            13 : "IFCS_RESOURCE_FULL (Resource full condition)",
            14 : "IFCS_TIMEOUT (Timeout error condition)",
            15 : "IFCS_DEVICE_ACCESS_ERROR (Device access error)",
            16 : "IFCS_DRIVER_ERROR (Driver error)"
    }
    return error_to_string[error_code]

def get_sub_fields_from_attr(attr_name, attr_val):
    sub_fields = {}
    if attr_name == 'pkt_policy':
        sub_fields['ctc_action'] = attr_val.ctc_policy.ctc_action
        sub_fields['trap_handle'] = attr_val.ctc_policy.trap_handle
        sub_fields['fwd_action'] = attr_val.fwd_action
        sub_fields['traffic_monitor_action'] = attr_val.traffic_monitor_policy.traffic_monitor_action
        sub_fields['collector_set'] = attr_val.traffic_monitor_policy.collector_set
        sub_fields['traffic_monitor_container'] = attr_val.traffic_monitor_policy.traffic_monitor_container
        sub_fields['sampling_rate'] = attr_val.traffic_monitor_policy.sampling_rate
    elif attr_type == 'ip_addr':
        if attr_val.addr_family == ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6:
            sub_fields['addr_family'] = "IPV6"
            sub_fields['ip_addr'] = socket.inet_ntop(socket.AF_INET6,attr_val.ip_addr.ipv6)
        if attr_val.addr_family == ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4:
            sub_fields['addr_family'] = "IPV4"
            sub_fields['ip_addr'] = socket.inet_ntoa(struct.pack('!L',attr_val.ip_addr.ipv4))
    return sub_fields
