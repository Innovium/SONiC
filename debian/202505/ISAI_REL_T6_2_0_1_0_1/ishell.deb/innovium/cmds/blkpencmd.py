#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import shlex
import argparse
import time

from utils.compat_util import *
from verbosity import *
from cmdmgr import Command
from ctypes import *
import sys
try:
    ifcs_ctypes = sys.modules["ifcs_ctypes"]
except KeyError:
    import ifcs_ctypes
if COMPAT_PY2:
    from exceptions import IOError

# to backtrace on breakage
import traceback

# pen = TIERB_L3QOS_MAP
# field =  DATA_DSCP_F
# fieldtype= TENTRY_FLD_TYPE_UINT32

def cli_write(args):
    node_id = 0
    pen = eval('ifcs_ctypes.' + args.pen.upper())
    if args.field[-2:].upper() != '_F':
        field = eval('ifcs_ctypes.' + args.field.upper() + '_F')
    else:
        field = eval('ifcs_ctypes.' + args.field.upper())
    fieldtype = eval('ifcs_ctypes.' + args.fieldtype.upper())
    num_entries = args.num_entries
    value = args.value
    index = args.index

    w_entry = ifcs_ctypes.bentry_new(node_id, pen, num_entries)
    ifcs_ctypes.bentry_alloc(node_id, w_entry)

    w_entry_2 = ifcs_ctypes.bentry_new(node_id, pen, num_entries)
    ifcs_ctypes.bentry_alloc(node_id, w_entry_2)

    for i in range (0, args.num_entries):
        wr_val = c_uint32()
        wr_val.value = value + i * args.increment
        ifcs_ctypes.bentry_set_item(node_id, pen, i, field, fieldtype, w_entry, pointer(wr_val))
        wr_val.value = 0
        ifcs_ctypes.bentry_set_item(node_id, pen, i, field, fieldtype, w_entry_2, pointer(wr_val))

    for _ in range(args.repeat):
        rc = ifcs_ctypes.node_isn_pen_block_write(node_id, 0, pen, index, num_entries, 0, w_entry)
        if args.repeat > 1:
            rc = ifcs_ctypes.node_isn_pen_block_write(node_id, 0, pen, index, num_entries, 0, w_entry_2)

    if (rc != ifcs_ctypes.IFCS_SUCCESS):
        log("pen block write FAILED with rc = " + str(rc))
    ifcs_ctypes.bentry_st_free(w_entry)

def cli_read(args):
    node_id = 0
    pen = eval('ifcs_ctypes.' + args.pen.upper())
    if args.field[-2:].upper() != '_F':
        field = eval('ifcs_ctypes.' + args.field.upper() + '_F')
    else:
        field = eval('ifcs_ctypes.' + args.field.upper())
    fieldtype = eval('ifcs_ctypes.' + args.fieldtype.upper())
    index = args.index
    num_entries = args.num_entries

    r_entry = ifcs_ctypes.bentry_new(node_id, pen, num_entries)
    rd_val = c_int(0)
    ifcs_ctypes.bentry_alloc(node_id, r_entry)

    rc = ifcs_ctypes.node_isn_pen_block_read(node_id, 0, pen, index, num_entries, 0, r_entry)
    if (rc != ifcs_ctypes.IFCS_SUCCESS):
        log("pen read FAILED with rc = " + str(rc))
    else:
        for i in range (0, num_entries):
            ifcs_ctypes.bentry_get_item(node_id, pen, i, field, fieldtype, r_entry, pointer(rd_val))
            log("%s[%d]: 0x%x" % (args.pen, index + i, rd_val.value))

    ifcs_ctypes.bentry_st_free(r_entry)

class Blkpen(Command):
    def __init__(self, cli):
        self.cli = cli
        super(Blkpen, self).__init__()

    def run_cmd(self, fullargs):
        try:
            arglist = shlex.split(fullargs)
            parser = argparse.ArgumentParser(prog='blkpen')
            subparsers = parser.add_subparsers()
            parser_read = subparsers.add_parser('read', help='block read')
            parser_read.add_argument('pen')
            parser_read.add_argument('field')
            parser_read.add_argument('index', type=int)
            parser_read.add_argument('--fieldtype', '-t', default='TENTRY_FLD_TYPE_UINT32')
            parser_read.add_argument('--num_entries', '-n', type=int, default=1)

            parser_read.set_defaults(func=cli_read)

            parser_write = subparsers.add_parser('write', help='block write')
            parser_write.add_argument('pen')
            parser_write.add_argument('field')
            parser_write.add_argument('index', type=int)
            parser_write.add_argument('value', type=int)
            parser_write.add_argument('--fieldtype', '-t', default='TENTRY_FLD_TYPE_UINT32')
            parser_write.add_argument('--num_entries', '-n', type=int, default=1)
            parser_write.add_argument('--increment', '-i', action='store_true')
            parser_write.add_argument('--repeat', '-r', type=int, default=1)
            parser_write.set_defaults(func=cli_write)

            args = parser.parse_args(arglist[1:])
            args.func(args)

        except Exception as ex:
            traceback.print_exc(file=sys.stdout)
            log("run cmd: ", type(ex).__name__, ex.args)

    def subcomplete(self, text, remline):
        return None
