
#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import shlex
import argparse
import random
import time
import datetime
import math
import sys

from testutil.pkt import get_dtm_discard_count

from testutil.util import hexdump
from utils.compat_util import *
from verbosity import *
from cmdmgr import Command
from ctypes import *
import struct
import array
import traceback

try:
    ifcs_ctypes = sys.modules["ifcs_ctypes"]
except KeyError:
    import ifcs_ctypes

LDH_LEN = 12
expected_packets = [[[] for i in range(49)] for j in range(7)]
tx_count = 0
rx_count = 0
rx_bytes = 0
rx_skip_count = 0
rx_q_skip_count = [0 for i in range(49)]
sent_packets = []

def ldh_vf0_v0(self, ib, ib_port, ssp, queue):
    slp = (ib << 6) | ib_port
    return struct.pack("!8BL", 1 << 1, 0,
                       slp >> 5, (slp & 0x1f) << 3,
                       (ssp >> 3), (ssp & 0x07) << 5, 0, queue << 1, 0)

def ldh_vf2_v0(self, ib, ib_port, queue):
    dlp = (ib << 6) | ib_port
    return struct.pack("!6BLH", 1 << 1, 2,
                       dlp >> 5, (dlp & 0x1f) << 3, (queue << 4), 0, 0, 0)

def ldh_vf0_v1(self, ib, ib_port, ssp, queue):
    slp = (ib << 7) | ib_port
    return struct.pack("!8BL", 1 << 1, 0,
                       slp >> 6, (slp & 0x3f) << 2,
                       (ssp >> 3), (ssp & 0x07) << 5, 0, queue << 1,
                       0)

def ldh_vf2_v1(self, ib, ib_port, queue):
    dlp = (ib << 7) | ib_port
    return struct.pack("!6BLH", 1 << 1, 2,
                       dlp >> 6, (dlp & 0x3f) << 2, (queue << 4), 0, 0, 0)

def ldh_vf0(ib, ib_port, ssp, queue):
    cpu_port = ifcs_ctypes.IFCS_CPU_PORT_NUM(0)
    if cpu_port == 33:
        return ldh_vf0_v0(ib, ib_port, ssp, queue)
    elif cpu_port == 65:
        return ldh_vf0_v1(ib, ib_port, ssp, queue)
    else:
        return None

def ldh_vf2(ib, ib_port, queue):
    cpu_port = ifcs_ctypes.IFCS_CPU_PORT_NUM(0)
    if cpu_port == 33:
        return ldh_vf2_v0(ib, ib_port, queue)
    elif cpu_port == 65:
        return ldh_vf2_v1(ib, ib_port, queue)
    else:
        return None

def rx_verify(nodeId, user_data, packet):
    global tx_count
    global rx_count
    global rx_bytes
    global rx_skip_count
    global rx_q_skip_count
    global expected_packets

    buf_len = packet.contents.pkt_buf_len
    buf = c_char_p(packet.contents.pkt_buf)
    rx_queue = packet.contents.queue_num
    packet_data = cast(buf, POINTER(c_char))
    packet_data = packet_data[:buf_len]
    #log("Rx packet:")
    #hexdump(packet_data)
    tx_ring = ord(packet_data[0])
    #tx_ring = ord(packet_data[12]) # skip the DMAC-SMAC

    if not(expected_packets[tx_ring][rx_queue]):
        log("Unexpected packet: len:0x%04x tx_r:%d rx_q:%d rx_count:%d tx_count:%d"
              % (buf_len, tx_ring, rx_queue, rx_count, tx_count))
        #hexdump(packet_data)
        #trigger(0, 1)
        return
    # cur_pkt_idx = ((ord(packet_data[1]) << 16) + (ord(packet_data[2]) << 8) + ord(packet_data[3]))
    # log("RX rx:%d drop:%d tx:%d q_cnt:0x%06x len:0x%04x tx_r:0x%02x rx_q:0x%02x"
    #       % (rx_count, rx_skip_count, tx_count, cur_pkt_idx, buf_len, tx_ring, rx_queue))
    # hexdump(packet_data[:16]) # [-16:] [:16]

    expected = expected_packets[tx_ring][rx_queue].pop(0)
    if (packet_data != expected[24:]):
        # We failed to match, so run down the Q expected packets in case of DTM drop
        num_skipped = 0
        test_expected = expected
        while True:
            if (packet_data == test_expected[24:]):
                #log('After %d, skipped %d' % (rx_count + rx_skip_count - num_skipped, num_skipped))
                #if rx_skip_count > 50000:
                #    trigger(0, 0)
                break

            if not(expected_packets[tx_ring][rx_queue]):
                #trigger(0, 0)
                log('after skipping %d packets on rx' % num_skipped)
                log("Bad Match rx_count:%d rx_skip:%d tx_r:%d rx_q:%d tx_count:%d len:0x%04x"
                      % (rx_count, rx_skip_count, tx_count, tx_ring, rx_queue, buf_len))
                #hexdump(packet_data)
                #log("Expected packet:")
                #hexdump(expected[24:])
                #log("Last packet seen:")
                #hexdump(test_expected[24:])
                #trigger(0, 1)
                break

            rx_skip_count += 1
            rx_q_skip_count[rx_queue] += 1
            num_skipped += 1
            test_expected = expected_packets[tx_ring][rx_queue].pop(0)
    rx_count += 1
    rx_bytes += buf_len + LDH_LEN
    if (rx_count % 10000 == 0):
        #trigger(0,0)
        #log("RX rx:%d drop:%d" % (rx_count, rx_skip_count))
        sys.stdout.write('.')
        sys.stdout.flush()

        pass

    return

# Class implements Pkt related command
class Pkt(Command):

    def __init__(self, cli):
        self.sub_cmds = {'send'        : self.send,
                       # 'sendbob'     : self.sendbob,
                       # 'recv'        : self.recv,
                       # 'l2setup'     : self.l2setup,
                         'help'        : self.help,
                         '?'           : self.help
                        }
        self.cli = cli
        self.arg_list = []
        self.cbfn = None
        super(Pkt, self).__init__()

    def run_cmd(self, args):
        log_dbg(1, "in Pkt run")
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        try:
            return self.sub_cmds[self.arg_list[1]](args)
        except Exception as ex:
            log_dbg(
                1, "Exception in pkt [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            traceback.print_exc(file=sys.stdout)
            log("run cmd: ", type(ex).__name__, ex.args)
            self.cli.error()
            self.help(args)
            return
        except (KeyError):
            log_dbg(
                1, "KeyError in pkt [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
        except (ValueError):
            log_dbg(
                1, "ValueError in pkt [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
        except:
            log_dbg(
                1, "OtherError in pkt [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
        return

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def register_rx_cb(self, fn):
        self.cbfn = ifcs_ctypes.ifcs_hostif_packet_notify_t(fn)
        ifcs_ctypes.ifcs_hostif_register_rx_packet_notify(0, None, self.cbfn)

    def sendbob(self, args):
        global expected_packets
        global tx_count
        global rx_count
        global rx_bytes
        global rx_skip_count
        global rx_q_skip_count

        self.arg_list.pop(0)
        self.arg_list.pop(0)
        ib = 0
        ring = int(self.arg_list.pop(0))
        ibp = int(self.arg_list.pop(0))
        count = int(self.arg_list.pop(0))

        fixed_bytes = None
        if (len(self.arg_list) > 0):
            arg = self.arg_list.pop(0)
            try:
                test_size = int(arg)
            except ValueError:
                f = open(arg, 'r')
                a = (f.read()).split();
                test_size = len(a)
                fixed_bytes = reduce(lambda x, y: x + chr(int(y, 16)), a, "")
                f.close()
        else:
            test_size = 0

        nodeId = 0

        # Set up the listener
        cbfn = ifcs_ctypes.ifcs_hostif_packet_notify_t(rx_verify)
        ifcs_ctypes.ifcs_hostif_register_rx_packet_notify(nodeId, None, cbfn)

        # create the trap
        attr_count = 1
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()

        attr[0].id = ifcs_ctypes.IFCS_HOSTIF_TRAP_ATTR_ENABLE
        attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_TRUE

        # Any handle
        trap_handle = ifcs_ctypes.ifcs_handle_t()
        trap_handle.value = ifcs_ctypes.IFCS_HANDLE_HOSTIF_TRAP(ifcs_ctypes.IFCS_HOSTIF_TRAP_SWITCH_TO_CPU)
        rc = ifcs_ctypes.ifcs_hostif_trap_attr_set(nodeId, trap_handle,
                                       attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert (rc == ifcs_ctypes.IFCS_SUCCESS or rc == ifcs_ctypes.IFCS_EXIST), "STC Trap enable failed: rc = [" + str(rc) + "]"

        # Setup test
        if (test_size == 0):
            log("Testing count:" +str(count) + " length: rnd")
        else:
            log("Testing count:" +str(count) + " length:" + str(test_size))

        tx_q_count = [0 for i in range(49)]
        start_drop_count = get_dtm_discard_count()
        tx_count = 0
        rx_count = 0
        tx_bytes = 0
        rx_bytes = 0
        rx_skip_count = 0
        rx_q_skip_count = [0 for i in range(49)]
        drop_count = 0
        dtm_drop_count = 0
        start_time = time.time()
        # test_size = 63
        for i in range(count):
            # if (i % 2048 == 0):
            #     test_size += 1

            # min length is 64 with inner header, max is 9228 with all headers
            if (test_size == 0):
                length = random.randint(0x4c-12, 9228-24)
            else:
                length = test_size

            tx_busy_count = 0
            startByte = random.randint(0, 255)
            startByte = tx_count % 256
            #tx_ring = tx_count % 4 #random.randint(0, 3)
            tx_ring = tx_count % 4 #random.randint(0, 3)
            #tx_ring = ring
            rx_queue = tx_ring #random.randint(0, 7) # Bob only can use Q 0-7

            if fixed_bytes == None:
                curByte = startByte
                # Start with some special bytes to ID the packet
                payload =  chr(tx_ring)
                payload += chr((tx_q_count[rx_queue] >> 16) & 0xff)
                payload += chr((tx_q_count[rx_queue] >> 8) & 0xff)
                payload += chr(tx_q_count[rx_queue] & 0xff)
                payload += chr(rx_queue)
                payload += chr(length >> 8)
                payload += chr(length & 0xff)
                for j in range(length - 7):
                    payload += chr(curByte)
                    curByte = (curByte + 1) & 0xff
            else:
                payload = fixed_bytes

            pkt_hdr = ''

            if (ibp == ifcs_ctypes.IFCS_CPU_PORT_NUM(0)):
                # to-CPU packet: add a bogus vf0 on the front so it looks like a regular received packet
                pkt_hdr = ldh_vf0(ib, ifcs_ctypes.IFCS_CPU_PORT_NUM(0), 1, rx_queue)

            # add the VF2 (BOB) header on the front:
            pkt_hdr = ldh_vf2(ib, ibp, rx_queue) + pkt_hdr

            packet = pkt_hdr + payload

            if (ibp == ifcs_ctypes.IFCS_CPU_PORT_NUM(0)):
                expected_packets[tx_ring][rx_queue].append(packet)

            # log("TX tx:%d q_cnt:0x%06x len:0x%04x 1st:0x%02x last:0x%02x rx_q:0x%02x tx_r:0x%02x"
            #       % (tx_count, tx_q_count[rx_queue], length, startByte, curByte, rx_queue, tx_ring))
            #log("Tx packet:")
            #hexdump(packet)

            p = cast(packet, c_void_p);
            while (1):
                rc = ifcs_ctypes.im_hostif_send_packet_zcopy(nodeId, tx_ring, p, len(packet))
                if (rc == ifcs_ctypes.IFCS_SUCCESS):
                    break
                if (rc != ifcs_ctypes.IFCS_BUSY):
                    log_err('Packet send to pcie failed')
                    attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE
                    rc = ifcs_ctypes.ifcs_hostif_trap_attr_set(nodeId, trap_handle,
                                                   attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
                    assert rc == ifcs_ctypes.IFCS_SUCCESS, "STC Trap disable failed: rc = [" + str(rc) + "]"
                    ifcs_ctypes.ifcs_hostif_unregister_rx_packet_notify(nodeId)
                    return
                tx_busy_count += 1
                time.sleep(0.001)

            tx_count += 1
            tx_q_count[rx_queue] += 1
            tx_bytes += len(packet)

        # trigger(0, 0)

        myflag = 0;
        if (ibp == ifcs_ctypes.IFCS_CPU_PORT_NUM(0)):
            old_recv_count = rx_count - 1  # prevent the print from firing the first time through
            dtm_drop_count = get_dtm_discard_count() - start_drop_count
            while (tx_count != (rx_count + dtm_drop_count)):
                if (old_recv_count == rx_count):
                    log("Waiting for rx:%d rx_skip:%d dtm_drop:%d"
                           % (tx_count - rx_count, rx_skip_count, dtm_drop_count))
                    for i in range(7):
                        for j in range(49):
                            if len(expected_packets[i][j]) != 0:
                                log("TX_R:%d RX_Q:%d pending:%d" % (i, j, len(expected_packets[i][j])))
                old_recv_count = rx_count

                time.sleep(0.1)
                dtm_drop_count = get_dtm_discard_count() - start_drop_count
                if(myflag == 3):
                    break
            # flush any remaining "expected" packets and account for them
            for i in range(7):
                for j in range(49):
                    rx_skip_count += len(expected_packets[i][j])
                    expected_packets[i][j] = []

        stop_time = time.time()

        # clear traps & handlers
        attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE
        rc = ifcs_ctypes.ifcs_hostif_trap_attr_set(nodeId, trap_handle,
                                       attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "STC Trap disable failed: rc = [" + str(rc) + "]"

        ifcs_ctypes.ifcs_hostif_unregister_rx_packet_notify(nodeId)
        log("")
        if (start_time == stop_time):
            log("Done elapsed:%0.2fs packets per second: (run too short)" % (stop_time - start_time))
        else:
            log("Done elapsed:%0.2fs packets per second:%0.2f"
                   % ((stop_time - start_time), ((tx_count + rx_count) / (stop_time - start_time))))
        log("  Sent:%d tx_busy:%d Rx:%d RxSkip:%d DTM_drop:%d"
              % (tx_count, tx_busy_count, rx_count, rx_skip_count, dtm_drop_count))

        scaling_factor = 1.0
        txbw_mbps = scaling_factor * tx_bytes / (stop_time - start_time) * 8 / 1000000
        rxbw_mbps = scaling_factor * rx_bytes / (stop_time - start_time) * 8 / 1000000
        log("  Scaled BW  Tx: %.2f Mbps  Rx: %.2f Mbps"
              % (txbw_mbps, rxbw_mbps))
        #log("  Per-Q Skips: ", rx_q_skip_count)
        return

    #pkt send -d <dest> -n <pkt_count> -f <name>
    def send(self, args):
        log_dbg(1, "In Pkt Send")
        try:
            self.arg_list.pop(0)
            self.arg_list.pop(0)
            parser = argparse.ArgumentParser(description='Transmit Packet via CPU')
            parser.add_argument('-s', type=int, default=-1, help='Fake source port if present')
            #parser.add_argument('-o', type=int, default=0, help='Transmit Type (0=normal, 1=BOB)')
            parser.add_argument('-f', type=str, help='Packet filename')
            parser.add_argument('-d', type=int, default=-1, help='Destination port if present')
            parser.add_argument('-n', type=int, default=1, help='Number of packets to send')
            res = parser.parse_args(self.arg_list)
            fname = res.f  # could use type=argparse.FileType('r') instead above...
            tx_opt = ifcs_ctypes.IFCS_HOSTIF_TX_TYPE_PIPELINE_BYPASS
            src = res.s
            dest = res.d
            count = res.n
        except Exception as e:
            log("exc", e)
            self.help(args)
            return
        #Open File and retrive contents
        f = open(fname, 'r')
        a = (f.read()).split();
        data = (c_byte * 2048)()
        for i in range(len(a)):
            data[i] = int(a[i], 16)
        f.close()
        buf_len = 5
        pdata = cast(data, c_void_p)
        try:
            packet = ifcs_ctypes.ifcs_hostif_packet_info_t()
            ifcs_ctypes.ifcs_hostif_packet_info_t_init(byref(packet))
            packet.tx_type = tx_opt
            packet.trap_handle = 0 # is ignored
            if (src != -1):
                packet.ssp = ifcs_ctypes.IFCS_HANDLE_SYSPORT(src)
            else:
                packet.ssp = 0

            if (dest != -1):
                packet.dsp = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dest)
            else:
                packet.dsp = 0

            packet.queue_num = 0 # is ignored
            packet.ring_num = 0
            packet.pkt_buf = pdata
            packet.pkt_buf_len = len(a)
        except Exception as e:
            log("exc", e)

        for i in range(0, count):
            rc = ifcs_ctypes.ifcs_hostif_send_packet(0, pointer(packet))
            if (rc != ifcs_ctypes.IFCS_SUCCESS):
                log_err('Packet send to switch failed')

        return

    def l2setup(self, args):
        attr = ifcs_ctypes.ifcs_attr_t()
        attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SYSPORT_HANDLE
        actual_count = c_uint32()

        sysport_hdl = (ifcs_ctypes.ifcs_handle_t * 5)

        for i in range(1,5):
            rc = ifcs_ctypes.ifcs_devport_attr_get(0, port, i, pointer(attr),
                                    pointer(actual_count))
            if (rc != ifcs_ctypes.IFCS_SUCCESS):
                log_err('Sysport handle get failed')
            sysport_hdl[i] = attr.value.handle;

        stp_hdl = ifcs_ctypes.ifcs_handle_t(ifcs_ctypes.IFCS_MOD_STP, 99)
        rc = ifcs_ctypes.ifcs_stp_instance_create(0, pointer(stp_hdl), 0, 0)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            log_err('stp instance create failed')

        attr.id = ifcs_ctypes.IFCS_L2VNI_STP_INSTANCE
        attr.value.handle = stp_hdl
        l2vni_hdl = ifcs_ctypes.IFCS_HANDLE_L2VNI(10);
        rc = ifcs_ctypes.ifcs_l2vni_create(0, pointer(l2vni_hdl), 1, pointer(attr))
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            log_err('l2vni create failed')

        for i in range(1,5):
            rc = ifcs_ctypes.ifcs_l2vni_member_add(0, l2vni_hdl, sysport_hdl[i], ifcs_ctypes.IFCS_BOOL_TRUE)
            if (rc != ifcs_ctypes.IFCS_SUCCESS):
                log_err('l2vni member add failed')

            rc = ifcs_ctypes.ifcs_stp_port_state_set(0, stp_hdl, sysport_hdl[i],
                                         ifcs_ctypes.IFCS_STP_PORT_STATE_FORWARDING)
            if (rc != ifcs_ctypes.IFCS_SUCCESS):
                log_err('stp forwarding state set failed')

        attr_list = (ifcs_ctypes.ifcs_attr_t() * 2)()
        attr_list[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_DEST
        attr_list[0].value.handle = sysport_hdl[1]
        attr_list[1].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_TYPE
        attr_list[1].value.u32 = ifcs_ctypes.IFCS_L2ENTRY_STATIC
        l2entry = ifcs_ctypes.ifcs_l2entry_key_t()
        l2entry.l2vni_handle = l2vni_hdl
        l2entry.mac_addr = (c_ubyte * 6)()
        l2entry.mac_addr[0] = 1
        l2entry.mac_addr[1] = 1
        l2entry.mac_addr[2] = 1
        l2entry.mac_addr[3] = 1
        l2entry.mac_addr[4] = 1
        l2entry.mac_addr[5] = 1
        rc = ifcs_ctypes.ifcs_l2entry_create(0, pointer(l2entry), 2, compat_pointer(attr_list, ifcs_ctypes.ifcs_attr_t))
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            log_err('fdb create failed')

    def recv(self, args):
        def print_pkt(buf, buf_len):
            pdata = cast(buf, POINTER(c_byte * buf_len))
            for i in range(buf_len):
                log("{:02X}".format(pdata.contents[i])),
            log("")
            return

        ################################################################################
        # CPU receive Packet Callback Function
        # node_id - Node ID
        # event_num - Rx Event
        # user_data - Data
        # packet - Ifcs Packet
        ################################################################################
        def rx_cbfn(node_id, user_data, packet):
            rx_qnum = packet.contents.queue_num
            rx_trap_handle = packet.contents.trap_handle

            log("rx_cbfn: Packet Received via CPU: Len(" + str(packet.contents.pkt_buf_len) + ")"),
            #INFO("Packet Received via CPU: Len(" + str(packet.contents.pkt_buf_len) + ")")

            #FIXME: get src_port from SSP
            ssp = packet.contents.ssp
            assert ifcs_ctypes.IFCS_HANDLE_MODULE(ssp) == ifcs_ctypes.IFCS_MOD_SYSPORT, "SSP is not System Type Handle"

            src_port = int(ifcs_ctypes.IFCS_HANDLE_VALUE(ssp) - 1)

            log("rx_cbfn: Appending to Reveived Packet List\n"),
            log("rx_cbfn: Packet received from {0}\n".format(src_port)),

            buf_len = packet.contents.pkt_buf_len
            buf = c_char_p(packet.contents.pkt_buf)
            packet = cast(buf, POINTER(c_char))
            packet = packet[:buf_len]
            hexdump(packet)
            #print_pkt(buf, buf_len)

            return

        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.cbfn = ifcs_ctypes.ifcs_hostif_packet_notify_t(rx_cbfn)
        if (ifcs_ctypes.ifcs_hostif_register_rx_packet_notify(0, None, self.cbfn) != ifcs_ctypes.IFCS_SUCCESS):
            log_err("Error: registering callback funtion");
        log_dbg(1, "Packet Recieve callback registered")
        log("Packet Recieve callback registered")
        # create the trap
        attr_count = 1
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()

        attr[0].id = ifcs_ctypes.IFCS_HOSTIF_TRAP_ATTR_ENABLE
        attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_TRUE

        # Any handle
        trap_handle = ifcs_ctypes.ifcs_handle_t()
        trap_handle.value = ifcs_ctypes.IFCS_HANDLE_HOSTIF_TRAP(ifcs_ctypes.IFCS_HOSTIF_TRAP_SWITCH_TO_CPU)
        rc = ifcs_ctypes.ifcs_hostif_trap_attr_set(0, trap_handle,
                                       attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert (rc == ifcs_ctypes.IFCS_SUCCESS or rc == ifcs_ctypes.IFCS_EXIST), "STC Trap enable failed: rc = [" + str(rc) + "]"

        return

    def help(self, args):
        self.cli.error()
        log("Usage:")
        log("pkt send -d <dest> -n <num> -f <filename>       - send <num> pkt from host port")
        # log("pkt recv                                        - register a receive callback")
        # log("pkt l2setup                                     - l2 setup")
        # log("pkt sendbob <ib> <ib_port> <num>                - send <num> BOB packets to <ib_port>")
        log("pkt help or ?                                   - show this text")
