
#-------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------

import sys
import argparse
import itertools
import time
import json
from utils.log_utils import *
from utils.compat_util import *
from verbosity import *
from cmdmgr import Command
from ctypes import *
from collections import OrderedDict
try:
    ifcs_ctypes= sys.modules["ifcs_ctypes"]
except KeyError:
    import ifcs_ctypes
from isai_cmds.util_all import *
from isai_cmds.util_cli_types import *
import shlex


# Class implements Isai related commands
class Isai(Command):
    def __init__(self, cli):
        self.cli = cli
        self.arg_list = []
        super(Isai, self).__init__()

        self.sub_cmds = {
            'show': self.show,
            'clear': self.clear,
            'set': self.set,
            'help': self.help,
            '?': self.help
        }
        self.isai_all_objs = IsaiAll(self.cli)
        self.show_isai_names = self.isai_all_objs.get_isai_obj_names()
        self.clear_isai_names = self.show_isai_names
        self.set_isai_names = self.show_isai_names

    def __del__(self):
        return

    def run_cmd(self, args):
        log_dbg(1, "In Isai run")
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        try:
            rc = self.sub_cmds[self.arg_list[1]](args)
            return rc
        except (KeyError):
            log_dbg(
                1, "KeyError in isai [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
            return ifcs_ctypes.IFCS_INVAL
        except (ValueError):
            log_dbg(
                1, "ValueError in isai [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
            return ifcs_ctypes.IFCS_INVAL
        except BaseException:
            log_dbg(
                1, "OtherError in isai [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
            return ifcs_ctypes.IFCS_INVAL

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            ''' display possible cmd options'''
            return compat_listkeys(self.sub_cmds)
        elif cmd == text:
            ''' display possible cmd options from text'''
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]
        elif remline and remline.split()[0] in self.show_isai_names:
            ''' display possible options of each object'''
            try:
                obj = self.getIsaiType(remline.split()[0])
                return [
                    j for j in obj.supported_operands if j.startswith(text)]
            except BaseException:
                return None
        else:
            ''' display possible objects for each command '''
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def complete_show(self, text):
        if text.upper() == text:
            return [i.lower()
                    for i in self.show_isai_names if i.upper().startswith(text)]
        else:
            return [i.lower()
                    for i in self.show_isai_names if i.lower().startswith(text)]

    def complete_clear(self, text):
        if text.upper() == text:
            return [i.lower()
                    for i in self.clear_isai_names if i.upper().startswith(text)]
        else:
            return [i.lower()
                    for i in self.clear_isai_names if i.lower().startswith(text)]

    def complete_set(self, text):
        if text.upper() == text:
            return [i.lower()
                    for i in self.set_isai_names if i.upper().startswith(text)]
        else:
            return [i.lower()
                    for i in self.set_isai_names if i.lower().startswith(text)]

    def getIsaiType(self, isai_obj_name):
        '''Get ISAI Type Object'''
        log_dbg(1, "In getIsaiType isai_obj_name " + isai_obj_name)

        '''First try in isai_all objs, then try in custom objects'''
        if isai_obj_name == "all":
            return self.isai_all_objs

        isai_objs = self.isai_all_objs.get_isai_obj_from_name(isai_obj_name)
        if isai_objs is None:
            return None

        return isai_objs

    # Disable command
    def disable(self, args):
        log_dbg(1, "In isai disable with args: " + args)
        isai_obj_name, args = self.validate_get_isai_info_from_args(args)

        log_dbg(1, " isai_obj: " + isai_obj_name)
        isai_obj = self.getIsaiType(isai_obj_name)
        if isai_obj is None:
            log_err('Unknown isai Object: ' + isai_obj)
            return

        log_dbg(1, " args: " + args)
        rc = isai_obj.disable(args)
        return ifcs_ctypes.IFCS_SUCCESS

    # Enable command
    def enable(self, args):
        log_dbg(1, "In isai enable with args: " + args)
        isai_obj_name, args = self.validate_get_isai_info_from_args(args)

        log_dbg(1, " isai_obj: " + isai_obj_name)
        isai_obj = self.getIsaiType(isai_obj_name)
        if isai_obj is None:
            log_err('Unknown isai Object: ' + isai_obj)
            return

        log_dbg(1, " args: " + args)
        rc = isai_obj.enable(args)
        return ifcs_ctypes.IFCS_SUCCESS

    # Clear command
    def clear(self, args):
        log_dbg(1, "In isai clear with args: " + args)

        isai_obj_name, args = self.validate_get_isai_info_from_args(args)

        log_dbg(1, " isai_obj: " + isai_obj_name)
        isai_obj = self.getIsaiType(isai_obj_name)
        if isai_obj is None:
            log_err('Unknown isai Object: ' + isai_obj)
            return

        log_dbg(1, " args: " + args)
        rc = isai_obj.clear(args)
        return ifcs_ctypes.IFCS_SUCCESS

    # SHOW command
    def show(self, args):
        log_dbg(1, "In isai Show with args: " + args)
        filter_option = ''

        isai_obj_name, args = self.validate_get_isai_info_from_args(args)

        log_dbg(1, " isai_obj: " + isai_obj_name)
        isai_obj = self.getIsaiType(isai_obj_name)
        if isai_obj is None:
            log_err('Unknown isai Object: ' + isai_obj)
            return

        if 'filter' in args:
            filter_option = args.split('filter')[1]
            args = args.split('filter')[0]

        log_dbg(1, " args: " + args)
        rc = isai_obj.show(args, filter_option)
        return ifcs_ctypes.IFCS_SUCCESS

    # SET command
    def set(self, args):
        ''' sets an attribute that an ISAI object supports '''
        log_dbg(1, "In Isai set with args: " + args)

        isai_obj_name, args = self.validate_get_isai_info_from_args(args)

        log_dbg(1, " isai_obj: " + isai_obj_name)
        isai_obj = self.getIsaiType(isai_obj_name)
        if isai_obj is None:
            log_err('Unknown ISAI Object: ' + isai_obj)
            return

        log_dbg(1, " args: " + args)
        rc = isai_obj.set(args)
        return ifcs_ctypes.IFCS_SUCCESS

    def show_help_menu(self, args):
        ''' show help menu '''
        log("\n")
        table = PrintTable()
        table.add_row(['ISAI Show Help', 'Description'])
        table.add_row(['attrs', 'Shows all set attributes on <isaiobj>'])
        table.add_row(['stats', 'Shows all statistics on <isaiobj>'])
        table.add_row(
            ['all', 'Shows all set attributes on all <isaiobj> of this type'])
        table.add_row(
            ['brief', 'Shows a brief set of attributes on <isaiobj>'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        show_help_string = """
Usage::
    Type isai show <tab> to see isai objects that support show command.
    Type isai show ? to see isai show help.
"""
        log(show_help_string)
        return

    def clear_help_menu(self, args):
        ''' clear help menu '''

        table = PrintTable()
        table.add_row(['ISAI Clear Help', 'Description'])
        table.add_row(['stats', 'Clears all statistics on <isaiobj>'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        clear_help_string = """
Usage::
    Type "isai clear <isai object> stats <isai object handle>"

"""
        log(clear_help_string)
        return

    def set_help_menu(self, args):
        ''' set help menu '''

        log("\n")
        table = PrintTable()
        table.add_row(['ISAI Set Help', 'Description'])
        table.add_row(['Set', 'Set an attribute on <isaiobj>'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        set_help_string = """
Usage::
    Type "isai set <isaiobj> handle <attribute> value"

    Example:
        isai set isai_ds_vr vr_oid 3242591732346388480 dummy 0 admin_v6_state 0
"""
        log(set_help_string)
        return

    def isai_help_menu(self, args):
        ''' isai help menu '''

        log("\n")
        table = PrintTable()
        table.add_row(['isai Command Help', ' Description'])
        table.add_row(['show', 'Show all the set attributes on isai object.'])
        table.add_row(['set', 'Set an attribute on isai object.'])
        table.add_row(
            ['clear', 'Clear all statistics on a particular isai object.'])
        table.add_row(['test', 'Run test commands that this object supports.'])
        table.add_row(['help', 'Show this help menu.'])
        table.add_row(['?', 'Show this help menu.'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        isai_help_string = """
Usage::

   Type "isai command" followed by <tab> to see isai objects that support the command.
"""
        log(isai_help_string)

        return isai_SUCCESS

    def help(self, args):
        help_menu = {
            'show': self.show_help_menu,
            'set': self.set_help_menu,
            'clear': self.clear_help_menu,
            'help': self.isai_help_menu,
            '?': self.isai_help_menu
        }

        self.arg_list = args.split()
        try:
            obj = self.getIsaiType(self.arg_list[2])
            obj.help(args)
        except BaseException:
            try:
                help_menu[self.arg_list[1]](args)
            except BaseException:
                self.isai_help_menu(args)

    #----------------------------
    # Isai class helper functions
    #----------------------------
    def check_for_api_class_handle(self, arg):
        try:
            mod = cli_ifcs_mod_map[ifcs_ctypes.IFCS_HANDLE_MODULE(int(arg,0))]
        except:
            return None, None

        try:
           obj = cli_ifcs_obj_map[mod][ifcs_ctypes.IFCS_HANDLE_OBJECT(int(arg,0)) - 1]
        except:
           return None, None

        return obj.lower(), str(arg)

    def validate_get_isai_info_from_args(self, args):
        log_dbg(1, "In validate_get_isai_info_from_args :" + args)

        arg_list = args.split()
        isai_cmd_name = arg_list[1]
        isai_obj_name = arg_list[2]

        if isai_cmd_name == "clear" and isai_obj_name == "stats":
            return "all", args

        if not isai_obj_name in self.show_isai_names:
            isai_obj_name, handle = self.check_for_api_class_handle(isai_obj_name)
            if isai_obj_name == None:
                log_err("Unsupported Isai command class")
                raise KeyError

            args = ' '.join(arg_list[:-1]) + ' ' + isai_obj_name + ' ' +str(handle)
            arg_list = args.split()
            isai_cmd_name = arg_list[1]
            isai_obj_name = arg_list[2]

        log_dbg(1, "isai_cmd " + isai_cmd_name)
        log_dbg(1, "isai_obj " + isai_obj_name)
        if isai_cmd_name == 'show':
            if isai_obj_name not in self.show_isai_names:
                log_err("Unsupported isai command class")
                raise KeyError
        elif isai_cmd_name == 'set':
            if isai_obj_name not in self.set_isai_names:
                log_err("Unsupported isai command class")
                raise KeyError
        elif isai_cmd_name == 'clear':
            if isai_obj_name not in self.clear_isai_names:
                log_err("Unsupported isai command class")
                raise KeyError

        return isai_obj_name, args
