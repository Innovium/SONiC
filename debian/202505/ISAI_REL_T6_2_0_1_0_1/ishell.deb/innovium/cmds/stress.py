
#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------


import shlex
import argparse
import itertools
import sys
from utils.compat_util import *
from verbosity import *
from cmdmgr import Command
from ctypes import *
try:
    ifcs_ctypes = sys.modules["ifcs_ctypes"]
except KeyError:
    import ifcs_ctypes
from ifcs_cmds.node import Node as node
from print_table import PrintTable
from snake import Snake

class Stress(Command):

    def __init__(self, cli):
        self.sub_cmds = {
                         'start'       : self.start,
                         'stop'        : self.stop,
                         'help'         : self.help,
                         '?'            : self.help
                        }
        self.cli = cli
        self.arg_list = []
        super(Stress, self).__init__()

        self.node_id = 0
        self.verbose = 0

    def run_cmd(self, args):
        self.arg_list = shlex.split(args)
        try:
            rc = self.sub_cmds[self.arg_list[2]](args)
            return rc
        except (KeyError):
            log_dbg(1, "Invalid cmd")
            self.help(args)
            return ifcs_ctypes.IFCS_PARAM
        except Exception as ex:
            self.cli.error()
            self.help(args)

    def start(self, args):
        snake_cfg_cmd = 'diagtest snake config -p all -lb PCS'
        snake_cfg_obj = Snake(self.cli, quiet="true")
        snake_cfg_obj.run_cmd(snake_cfg_cmd)

        snake_run_obj = Snake(self.cli, quiet="true")
        snake_run_cmd = 'diagtest snake start_traffic -n 25000 -s 301 -payload stress'
        snake_run_obj.run_cmd(snake_run_cmd)
        pass

    def stop(self, args):
        snake_stop_obj = Snake(self.cli, quiet="true")
        snake_stop_cmd = 'diagtest snake stop_traffic'
        snake_stop_obj.run_cmd(snake_stop_cmd)

        snake_uncfg_obj = Snake(self.cli, quiet="true")
        snake_uncfg_cmd = 'diagtest snake unconfig'
        snake_uncfg_obj.run_cmd(snake_uncfg_cmd)

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def help(self, args):
        table = PrintTable()
        table.add_row(['Command', 'Description'])
        table.add_row(['start', 'Start stress test'])
        table.add_row(['stop', 'Stop stress test'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        stress_help_string = """
Usage::

    Type "diagtest stress <command>" followed by -h to see command's sub-options.
"""
        log(stress_help_string)
