#-------------------------------------------------------------------------------
# Copyright (c) (2025) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------
from abc import ABC, abstractmethod
import ctypes
import struct
import sys

from verbosity import *

class WatsonDevice(ABC):
    @abstractmethod
    def get_dev_id(self):
        pass

    @abstractmethod
    def get_rev_id(self):
        pass

    @abstractmethod
    def enable(self):
        pass

    @abstractmethod
    def disable(self):
        pass

    @abstractmethod
    def reset(self):
        pass

    @abstractmethod
    def set_verbose(self, verbose):
        pass

    @abstractmethod
    def eth_enable(self):
        pass

    @abstractmethod
    def eth_disable(self):
        pass

class WatsonI2C(WatsonDevice):
    class Regs:
        I2C_DEV_ID              = 0x0000
        I2C_REV_ID              = 0x0002
        I2C_RST                 = 0x0004
        I2C_WIF_CFG             = 0x1000
        I2C_WIF_CNT             = 0x1002
        I2C_WIF_STS             = 0x10F0
        I2C_EVT_MATCH0          = 0x1100
        I2C_EVT_MATCH1          = 0x1102
        I2C_EVT_MATCH2          = 0x1104
        I2C_EVT_VALUE           = 0x1106
        I2C_EVT_EXP_VAL         = 0x110A
        I2C_EVT_EXP_MASK        = 0x1112
        I2C_STS_MATCH0          = 0x1200
        I2C_STS_MATCH1          = 0x1202
        I2C_STS_MATCH2          = 0x1204
        I2C_STS_VALUE           = 0x1206
        I2C_STS_EXP_VAL         = 0x120A
        I2C_STS_EXP_MASK        = 0x1212
        I2C_EVT_GOOD            = 0x1400
        I2C_EVT_BAD             = 0x1404
        I2C_EVT_TOTAL           = 0x1408
        I2C_EVT_PERIOD          = 0x140C
        I2C_EVT_CLEAR           = 0x14F0
        I2C_STS_GOOD            = 0x1500
        I2C_STS_BAD             = 0x1504
        I2C_STS_TOTAL           = 0x1508
        I2C_STS_PERIOD          = 0x150C
        I2C_STS_CLEAR           = 0x15F0
        I2C_PKT_CFG             = 0x2000
        I2C_PKT_PAGE            = 0x2002
        I2C_PKT_COUNT           = 0x2010
        I2C_PKT_BYTES           = 0x2014
        I2C_PKT_DROPPED         = 0x2018
        I2C_PKT_STATS_COUNT     = 0x201C
        I2C_PKT_EVENTS_COUNT    = 0x2020
        I2C_PKT_STATS_BYTES     = 0x2024
        I2C_PKT_EVENTS_BYTES    = 0x2028
        I2C_PKT_STATS_DROPPPED  = 0x202C
        I2C_PKT_EVENTS_DROPPPED = 0x202C
        I2C_PKT_STATUS          = 0x20E0
        I2C_PKT_CLEAR           = 0x20F0
        I2C_ETH_CFG             = 0x3000
        I2C_ETH_MTU_SZ          = 0x3002
        I2C_ETH_IP_CHKSUM       = 0x3004
        I2C_ETH_ADDR_CMD        = 0x3010
        I2C_ETH_WR_DATA         = 0x3012
        I2C_ETH_RD_DATA         = 0x3016
        I2C_ETH_PKT_IN_CNT      = 0x3020
        I2C_ETH_PKT_DROPPED_CNT = 0x3024
        I2C_ETH_TX_PKT_CNT      = 0x3028
        I2C_ETH_TX_BYTES_CNT    = 0x302C
        I2C_ETH_RX_PKT_CNT      = 0x3030
        I2C_ETH_RX_BYTES_CNT    = 0x3034
        I2C_ETH_DADDR_1         = 0x3040
        I2C_ETH_DADDR_0         = 0x3042
        I2C_ETH_SADDR_0         = 0x3044
        I2C_ETH_DADDR_2         = 0x3046
        I2C_ETH_SADDR_2         = 0x3048
        I2C_ETH_SADDR_1         = 0x304A
        I2C_IP_VER_TOS          = 0x304C
        I2C_ETH_TYPE            = 0x304E
        I2C_IP_IDENT            = 0x3050
        I2C_IP_LEN              = 0x3052
        I2C_IP_TTL_PROTO        = 0x3054
        I2C_IP_FLAGS_FRAG       = 0x3056
        I2C_IP_SRC_IP           = 0x3058
        I2C_IP_CHKSUM           = 0x305A
        I2C_IP_DST_IP           = 0x305C
        I2C_IP_SRC_IP2          = 0x305E
        I2C_UDP_SRC_PORT        = 0x3060
        I2C_IP_DST_IP2          = 0x3062
        I2C_UDP_LENGTH          = 0x3064
        I2C_UDP_DST_PORT        = 0x3066
        I2C_MAC_WATSON_HDR      = 0x3068
        I2C_UDP_CHKSUM          = 0x306A
        I2C_PKT_FIRST           = 0x8000
        I2C_PKT_LAST            = 0xffff

    I2C_WIF_CFG_MATCH_ALL   = 0x0004

    I2C_PKT_CFG_ENABLE      = 0x0001
    I2C_PKT_CFG_CLEAR       = 0x0002
    I2C_PKT_CFG_RESET       = 0x0004

    I2C_PKT_STATUS_CLR_BUSY = 0x0001
    I2C_PKT_STATUS_CLR_DONE = 0x0002
    I2C_PKT_STATUS_FULL     = 0x0004

    I2C_MATCH0_ENABLE       = 0x0001
    I2C_MATCH0_STORE_MATCH  = 0x0004
    I2C_MATCH0_OP_MASK      = 0x0038
    I2C_MATCH0_LENGTH_MASK  = 0x03C0
    I2C_MATCH0_NOT_ZERO     = 0x0400
    I2C_MATCH1_ID_MASK      = 0x00ff
    I2C_MATCH2_OFFLEN_MASK  = 0x7fff

    I2C_ETH_CFG_ENABLE      = 0x0001    # Ethernet enable
    I2C_ETH_CFG_PHY_RST     = 0x0002    # Ethernet PHY reset
    I2C_ETH_CFG_TXCLK_PHASE = 0x0004    # Ethernet TX clock phase
    I2C_ETH_CFG_RXBUF_ARM   = 0x0008    # Ethernet RX buffer arm
    I2C_ETH_CFG_HMEM_RD     = 0x0010    # Ethernet header memory read enable

    I2C_ETH_MAC_CMD_WR      = 0x0000    # Ethernet MAC write command
    I2C_ETH_MAC_CMD_RD      = 0x0001    # Ethernet MAC read command
    I2C_ETH_MAC_CMD_ADDR    = 0x01FE    # Ethernet MAC address mask

    I2C_PKT_PAGE_CNT        = 8
    I2C_PKT_BUFF_SZ         = ((Regs.I2C_PKT_LAST - Regs.I2C_PKT_FIRST) + 1)
    I2C_CHUNK_SZ            = (0x80 * 2)

    def __init__(self, i2c_bus, i2c_addr, pkt_file=None):
        try:
            self.smbus2 = importlib.import_module("smbus2")
        except ImportError:
            raise ImportError("smbus2 module not found. Please install it using 'pip install smbus2'")
        self.smbus = self.smbus2.SMBus(i2c_bus)
        self.i2c_addr = i2c_addr
        self.pkt_file = pkt_file
        self.pkt_buf = None
        self.pkt_offset = 0
        self.pkt_filling = False
        self.verbose = True

    def assign_pkt_file(self, pkt_file):
        self.pkt_file = pkt_file

    def set_verbose(self, verbose):
        self.verbose = verbose

    def enable(self):
        pkt_cfg = self._i2c_read_u16(self.Regs.I2C_PKT_CFG)
        pkt_cfg |= self.I2C_PKT_CFG_ENABLE
        self._i2c_write_u16(self.Regs.I2C_PKT_CFG, pkt_cfg)

    def disable(self):
        pkt_cfg = self._i2c_read_u16(self.Regs.I2C_PKT_CFG)
        pkt_cfg &= ~self.I2C_PKT_CFG_ENABLE
        self._i2c_write_u16(self.Regs.I2C_PKT_CFG, pkt_cfg)

    def reset(self):
        pkt_cfg = self._i2c_read_u16(self.Regs.I2C_PKT_CFG)
        enabled = (pkt_cfg & self.I2C_PKT_CFG_ENABLE) != 0
        # Disable the packet buffer
        pkt_cfg &= ~self.I2C_PKT_CFG_ENABLE
        self._i2c_write_u16(self.Regs.I2C_PKT_CFG, pkt_cfg)
        # Reset the packet buffer
        pkt_cfg |= self.I2C_PKT_CFG_RESET
        self._i2c_write_u16(self.Regs.I2C_PKT_CFG, pkt_cfg)
        # Clear the packet buffer
        pkt_cfg |= self.I2C_PKT_CFG_CLEAR
        self._i2c_write_u16(self.Regs.I2C_PKT_CFG, pkt_cfg)
        # Re-enable the packet buffer
        if enabled:
            pkt_cfg |= self.I2C_PKT_CFG_ENABLE
            self._i2c_write_u16(self.Regs.I2C_PKT_CFG, pkt_cfg)
        self.pkt_buf = None
        self.pkt_offset = 0

    def set_event_filter(self, event_id, not_zero, offset, length, value, mode):
        reg_val = ((not_zero << 10) & self.I2C_MATCH0_NOT_ZERO)
        reg_val |= ((length << 6) & self.I2C_MATCH0_LENGTH_MASK)
        reg_val |= ((mode << 2) & self.I2C_MATCH0_STORE_MATCH)
        reg_val |= self.I2C_MATCH0_ENABLE
        self._i2c_write_u16(self.Regs.I2C_EVT_MATCH0, reg_val)
        self._i2c_write_u16(self.Regs.I2C_EVT_MATCH1, event_id & self.I2C_MATCH1_ID_MASK)
        self._i2c_write_u16(self.Regs.I2C_EVT_MATCH2, offset & self.I2C_MATCH2_OFFLEN_MASK)
        self._i2c_write_u16(self.Regs.I2C_EVT_EXP_VAL, value & 0xffff)
        self._i2c_write_u16(self.Regs.I2C_EVT_EXP_VAL + 2, (value >> 16) & 0xffff)
        self._i2c_write_u16(self.Regs.I2C_EVT_EXP_VAL + 4, (value >> 32) & 0xffff)
        self._i2c_write_u16(self.Regs.I2C_EVT_EXP_VAL + 6, (value >> 48) & 0xffff)

    def set_stats_filter(self, stats_id, op, offset, length, value, mode):
        reg_val = ((length << 6) & self.I2C_MATCH0_LENGTH_MASK)
        reg_val |= ((op << 3) & self.I2C_MATCH0_OP_MASK)
        reg_val |= ((mode << 2) & self.I2C_MATCH0_STORE_MATCH)
        reg_val |= self.I2C_MATCH0_ENABLE
        self._i2c_write_u16(self.Regs.I2C_STS_MATCH0, reg_val)
        self._i2c_write_u16(self.Regs.I2C_STS_MATCH1, stats_id & self.I2C_MATCH1_ID_MASK)
        self._i2c_write_u16(self.Regs.I2C_STS_MATCH2, offset & self.I2C_MATCH2_OFFLEN_MASK)
        self._i2c_write_u16(self.Regs.I2C_STS_EXP_VAL, value & 0xffff)
        self._i2c_write_u16(self.Regs.I2C_STS_EXP_VAL + 2, (value >> 16) & 0xffff)

    def set_match(self, match):
        wif_cfg = self._i2c_read_u16(self.Regs.I2C_WIF_CFG)
        if (match):
            wif_cfg |= self.I2C_WIF_CFG_MATCH_ALL
        else:
            wif_cfg &= ~self.I2C_WIF_CFG_MATCH_ALL
        self._i2c_write_u16(self.Regs.I2C_WIF_CFG, wif_cfg)

    def eth_enable(self, mtu_sz = None, eth_hdr = None, ip_hdr = None, udp_hdr = None):
        ver = self.eth_reg_rd(0x00)
        log("MAC version: %x" % ver)
        if ver != 0x1502:
            raise Exception("Unsupported MAC version: %x" % ver)

        self.eth_hdr(eth_hdr)
        self.eth_ip_hdr(ip_hdr)
        self.eth_udp_hdr(udp_hdr)

        self._i2c_write_u16(self.Regs.I2C_ETH_CFG, self.I2C_ETH_CFG_PHY_RST)
        self._i2c_write_u16(self.Regs.I2C_ETH_CFG, 0x0000)
        self._i2c_write_u16(self.Regs.I2C_ETH_CFG, self.I2C_ETH_CFG_ENABLE)
        self._i2c_write_u16(self.Regs.I2C_ETH_MTU_SZ, mtu_sz if mtu_sz else 0x22fc)
        # Disable 4-byte aligment on both RX and RX fifo interfaces
        self.eth_reg_wr(0x3A, 0x0000)
        self.eth_reg_wr(0x3B, 0x0000)
        # Set MAC IP's receive length to 9600 (jumbo frames)
        self.eth_reg_wr(0x05, 0x2580)
        # Enable rx/tx, 1000Mb mode, rx fcs errors, remove crc-bytes and some other
        self.eth_reg_wr(0x02, 0x0100_00bb)

    def eth_disable(self):
        self._i2c_write_u16(self.Regs.I2C_ETH_CFG, 0x0000)
        self._i2c_write_u16(self.Regs.I2C_ETH_CFG, self.I2C_ETH_CFG_PHY_RST)

    def eth_reg_wr(self, addr, data):
        self._i2c_write_u16(self.Regs.I2C_ETH_WR_DATA, data & 0xffff)
        self._i2c_write_u16(self.Regs.I2C_ETH_WR_DATA + 2, (data >> 16) & 0xffff)
        self._i2c_write_u16(self.Regs.I2C_ETH_ADDR_CMD, (addr << 1) & self.I2C_ETH_MAC_CMD_ADDR)

    def eth_reg_rd(self, addr):
        self._i2c_write_u16(self.Regs.I2C_ETH_ADDR_CMD, ((addr << 1) & self.I2C_ETH_MAC_CMD_ADDR) | self.I2C_ETH_MAC_CMD_RD)
        data = self._i2c_read_u16(self.Regs.I2C_ETH_RD_DATA)
        data |= self._i2c_read_u16(self.Regs.I2C_ETH_RD_DATA + 2) << 16
        return data

    def eth_hdr(self, eth_hdr):
        if eth_hdr and "daddr" in eth_hdr:
            daddr = eth_hdr["daddr"]
        else:
            daddr = bytes([0x11, 0x22, 0x33, 0x44, 0x55, 0x66])
        if eth_hdr and "saddr" in eth_hdr:
            saddr = eth_hdr["saddr"]
        else:
            saddr = bytes([0x01, 0x02, 0x03, 0x04, 0x05, 0x06])
        if eth_hdr and "type" in eth_hdr:
            eth_type = eth_hdr["type"]
        else:
            eth_type = 0x0800
        self._i2c_write_u16(self.Regs.I2C_ETH_DADDR_0, struct.unpack(">H", daddr[0:2])[0])
        self._i2c_write_u16(self.Regs.I2C_ETH_DADDR_1, struct.unpack(">H", daddr[2:4])[0])
        self._i2c_write_u16(self.Regs.I2C_ETH_DADDR_2, struct.unpack(">H", daddr[4:6])[0])
        self._i2c_write_u16(self.Regs.I2C_ETH_SADDR_0, struct.unpack(">H", saddr[0:2])[0])
        self._i2c_write_u16(self.Regs.I2C_ETH_SADDR_1, struct.unpack(">H", saddr[2:4])[0])
        self._i2c_write_u16(self.Regs.I2C_ETH_SADDR_2, struct.unpack(">H", saddr[4:6])[0])
        self._i2c_write_u16(self.Regs.I2C_ETH_TYPE, eth_type)

    def eth_ip_hdr(self, ip_hdr):
        if ip_hdr and "ver_tos" in ip_hdr:
            ver_tos = ip_hdr["ver_tos"]
        else:
            ver_tos = 0x4500
        if ip_hdr and "ident" in ip_hdr:
            ident = ip_hdr["ident"]
        else:
            ident = 0x0000
        if ip_hdr and "length" in ip_hdr:
            length = ip_hdr["length"]
        else:
            length = 0x0000
        if ip_hdr and "ttl_proto" in ip_hdr:
            ttl_proto = ip_hdr["ttl_proto"]
        else:
            ttl_proto = 0x4011
        if ip_hdr and "flags_frag" in ip_hdr:
            flags_frag = ip_hdr["flags_frag"]
        else:
            flags_frag = 0x0000
        if ip_hdr and "src_ip" in ip_hdr:
            src_ip = ip_hdr["src_ip"]
        else:
            src_ip = bytes([0xc0, 0xa8, 0x01, 0x01])
        if ip_hdr and "dst_ip" in ip_hdr:
            dst_ip = ip_hdr["dst_ip"]
        else:
            dst_ip = bytes([0xc0, 0xa8, 0x01, 0x02])
        self._i2c_write_u16(self.Regs.I2C_IP_VER_TOS, ver_tos)
        self._i2c_write_u16(self.Regs.I2C_IP_IDENT, ident)
        self._i2c_write_u16(self.Regs.I2C_IP_LEN, length)
        self._i2c_write_u16(self.Regs.I2C_IP_TTL_PROTO, ttl_proto)
        self._i2c_write_u16(self.Regs.I2C_IP_FLAGS_FRAG, flags_frag)
        self._i2c_write_u16(self.Regs.I2C_IP_SRC_IP, struct.unpack(">H", src_ip[0:2])[0])
        self._i2c_write_u16(self.Regs.I2C_IP_SRC_IP2, struct.unpack(">H", src_ip[2:4])[0])
        self._i2c_write_u16(self.Regs.I2C_IP_DST_IP, struct.unpack(">H", dst_ip[0:2])[0])
        self._i2c_write_u16(self.Regs.I2C_IP_DST_IP2, struct.unpack(">H", dst_ip[2:4])[0])

    def eth_udp_hdr(self, udp_hdr):
        if udp_hdr and "src_port" in udp_hdr:
            src_port = udp_hdr["src_port"]
        else:
            src_port = 12345
        if udp_hdr and "dst_port" in udp_hdr:
            dst_port = udp_hdr["dst_port"]
        else:
            dst_port = 4300
        if udp_hdr and "length" in udp_hdr:
            length = udp_hdr["length"]
        else:
            length = 0x0000
        if udp_hdr and "chksum" in udp_hdr:
            chksum = udp_hdr["chksum"]
        else:
            chksum = 0x0000
        self._i2c_write_u16(self.Regs.I2C_UDP_SRC_PORT, src_port)
        self._i2c_write_u16(self.Regs.I2C_UDP_DST_PORT, dst_port)
        self._i2c_write_u16(self.Regs.I2C_UDP_LENGTH, length)
        self._i2c_write_u16(self.Regs.I2C_UDP_CHKSUM, chksum)

    def read(self):
        if self.pkt_buf is None:
            self.pkt_buf = self._read()
            if self.pkt_buf is None:
                return None
            self.pkt_offset = 0
            if self.pkt_file is not None:
                if self.verbose:
                    log("Writing packet buffer to %s" % self.pkt_file)
                with open(self.pkt_file, "wb") as pkt_file:
                    pkt_file.write(self.pkt_buf)
        else:
            if self.pkt_offset >= len(self.pkt_buf):
                return None
        msg_hdr = struct.unpack(">H", self.pkt_buf[self.pkt_offset:self.pkt_offset + 2])[0]
        msg_size = msg_hdr & 0x7fff
        msg_type = msg_hdr & 0x8000
        msg_id = self.pkt_buf[self.pkt_offset + 2]
        if self.verbose:
            log_dbg(1, "msg: id=%d offset=%d type=%#x size=%d" % (msg_id, self.pkt_offset, msg_type, msg_size))
        msg_data = struct.pack(">H", msg_type)
        msg_data += struct.pack(">H", msg_size)
        msg_data += self.pkt_buf[self.pkt_offset + 2:self.pkt_offset + msg_size]
        self.pkt_offset += msg_size
        if self.pkt_offset & 0x01:
            self.pkt_offset += 1
        return msg_data

    def is_empty(self):
        return self.pkt_buf is None

    def is_eof(self):
        return self.pkt_buf and self.pkt_offset >= len(self.pkt_buf)

    def is_full(self):
        pkt_status = self._i2c_read_u16(self.Regs.I2C_PKT_STATUS)
        return (pkt_status & self.I2C_PKT_STATUS_FULL) != 0

    def get_dev_id(self):
        return self._i2c_read_u16(self.Regs.I2C_DEV_ID)

    def get_rev_id(self):
        return self._i2c_read_u16(self.Regs.I2C_REV_ID)

    def get_status(self):
        return self._i2c_read_u16(self.Regs.I2C_WIF_STS)

    def get_events_good(self):
        return self._i2c_read_u32(self.Regs.I2C_EVT_GOOD)

    def get_events_bad(self):
        return self._i2c_read_u32(self.Regs.I2C_EVT_BAD)

    def get_stats_good(self):
        return self._i2c_read_u32(self.Regs.I2C_STS_GOOD)

    def get_stats_bad(self):
        return self._i2c_read_u32(self.Regs.I2C_STS_BAD)

    def get_pkt_count(self):
        return self._i2c_read_u32(self.Regs.I2C_PKT_COUNT)

    def get_pkt_bytes(self):
        return self._i2c_read_u32(self.Regs.I2C_PKT_BYTES)

    def get_pkt_dropped(self):
        return self._i2c_read_u32(self.Regs.I2C_PKT_DROPPED)

    def _read(self):
        if not self.is_full():
            if self.verbose:
                if not self.pkt_filling:
                    log("Waiting for packet buffer to fill ... ")
                    sys.stdout.flush()
                    self.pkt_filling = True
            return None

        pkt_bytes = self.get_pkt_bytes()
        if self.verbose:
            log_no_newline("Reading packet buffer %d bytes " % pkt_bytes)
            sys.stdout.flush()

        pkt_buf = b''
        for page in range(self.I2C_PKT_PAGE_CNT):
            if self.verbose:
                log_no_newline(".")
                sys.stdout.flush()
            curr_bytes = min(pkt_bytes, self.I2C_PKT_BUFF_SZ)
            pkt_buf += self._read_page(page, curr_bytes)
            pkt_bytes -= curr_bytes
            if pkt_bytes == 0:
                break
        if self.verbose:
            log()

        pkt_len = len(pkt_buf)
        pkt_buf = struct.unpack(">%dH" % (pkt_len // 2), pkt_buf)
        pkt_buf = struct.pack("<%dH" % (pkt_len // 2), *pkt_buf)

        return pkt_buf

    def _read_page(self, page, read_size):
        self._i2c_write_u16(self.Regs.I2C_PKT_PAGE, page)
        page_buf = b''
        chunk_addr = self.Regs.I2C_PKT_FIRST
        while read_size > 0:
            curr_size = min(read_size, self.I2C_CHUNK_SZ)
            assert chunk_addr + curr_size <= self.Regs.I2C_PKT_LAST + 1
            page_buf += self._i2c_read_bytes(chunk_addr, curr_size)
            chunk_addr += curr_size
            read_size -= curr_size
        return page_buf

    def _i2c_read_bytes(self, reg, size):
        # Bulk transfer
        reg |= 0x0001
        wr_msg = self.smbus2.i2c_msg.write(self.i2c_addr, [reg & 0xff, reg >> 8, (size // 2) & 0xff])
        rd_msg = self.smbus2.i2c_msg.read(self.i2c_addr, size)
        self.smbus.i2c_rdwr(wr_msg, rd_msg)
        return ctypes.string_at(rd_msg.buf, size)

    def _i2c_read_u16(self, reg, byteorder='little'):
        wr_msg = self.smbus2.i2c_msg.write(self.i2c_addr, [reg & 0xff, reg >> 8])
        rd_msg = self.smbus2.i2c_msg.read(self.i2c_addr, 2)
        self.smbus.i2c_rdwr(wr_msg, rd_msg)

        word = int.from_bytes(rd_msg.buf[0], byteorder)
        word |= int.from_bytes(rd_msg.buf[1], byteorder) << 8

        return word

    def _i2c_read_u32(self, reg, byteorder='little'):
        lo_word = self._i2c_read_u16(reg, byteorder)
        hi_word = self._i2c_read_u16(reg + 2, byteorder)
        return lo_word | (hi_word << 16)

    def _i2c_write_u16(self, reg, val):
        msg_data = [reg & 0xff, (reg >> 8) & 0xff, val & 0xff, (val >> 8) & 0xff]
        wr_msg = self.smbus2.i2c_msg.write(self.i2c_addr, msg_data)
        self.smbus.i2c_rdwr(wr_msg)
