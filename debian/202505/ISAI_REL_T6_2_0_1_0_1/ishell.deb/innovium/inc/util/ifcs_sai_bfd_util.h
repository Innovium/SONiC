/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_tunnel_util.h
 * @brief ISAI Util Include file for TUNNEL module
 */


#ifndef __IFCS_SAI_BFD_TUNNEL_UTIL_H__
#define __IFCS_SAI_BFD_TUNNEL_UTIL_H__

#include "util/ifcs_sai_bfd_util_dep.h"

/*
 * @brief get number of current configured BFD session
 *
 * @param [in]  node_id                  - Node id
 * @return sai_status_t
 */
sai_status_t
isai_im_bfd_session_current_number_get(
    ifcs_node_id_t  node_id, uint32_t *session_count);

sai_status_t
isai_im_bfd_init(sai_switch_init_info_t *sai_switch_init_info_p);

sai_status_t
isai_im_bfd_deinit(sai_switch_deinit_info_t *sai_switch_deinit_info_p);

#endif
