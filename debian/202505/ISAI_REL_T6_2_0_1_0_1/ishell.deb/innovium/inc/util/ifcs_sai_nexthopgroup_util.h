/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_nexthopgroup_util.h
 * @brief ISAI Util Include file for NEXTHOPGROUP module
 */


#ifndef __IFCS_SAI_NEXTHOPGROUP_UTIL_H__
#define __IFCS_SAI_NEXTHOPGROUP_UTIL_H__

#include "util/ifcs_sai_nexthopgroup_util_dep.h"


/*
 * @brief Initializes nexthopgroup module
 *
 * @param [in]  sai_switch_init_info_p   - Pointer to swith init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_nexthopgroup_init(
    sai_switch_init_info_t *sai_switch_init_info_p);


/*
 * @brief Un-initializes nexthopgroup module
 *
 * @param [in]  switch_deinit_info_p   - Pointer to switch de-init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_nexthopgroup_deinit(
    sai_switch_deinit_info_t *switch_deinit_info_p);

/*
 * @brief  Converts SAI object ID to IFCS handle
 *
 * @param [in]  sai_object_id - SAI object ID
 * @param [out] ifcs_handle   - Handle to IFCS nexthop-group object
 * @return sai_status_t
 */
extern sai_status_t
isai_im_nexthopgroup_stoi_xlate_oid(
    sai_object_id_t sai_object_id,
    ifcs_handle_t   *ifcs_handle_p);

/*
 * @brief Converts SAI object ID to ifcs handle
 *
 * @param [in]  switch_oid   - Switch Object ID
 * @param [in]  ifcs_handle  - IFCS Handle
 * @param [out] object_id_p  - Pointer to SAI object ID
 * @return sai_status_t
 */
extern sai_status_t
isai_im_nexthopgroup_itos_xlate_oid(
    sai_object_id_t switch_oid,
    ifcs_handle_t   ifcs_handle,
    sai_object_id_t *object_id_p);

sai_status_t
isai_im_nexthopgroup_get_group_hdl(sai_object_id_t   object_id,
                                   ifcs_handle_t     *group_hdl_p);
sai_status_t
isai_im_nexthopgroup_get_mem_hdl(sai_object_id_t     object_id,
                                   ifcs_handle_t     *group_mem_hdl_p);


/*
 * @brief Get Nexthopgroup object type resource availability.
 *
 * @param[in] switch_id   SAI Switch object id
 * @param[in] attr_count  Number of attributes
 * @param[in] attr_list_p List of attributes that to distinguish resource
 * @param[out] count_p    Available objects left
 *
 * @return #SAI_STATUS_NOT_SUPPORTED if the given object type does not support resource accounting.
 * Otherwise, return #SAI_STATUS_SUCCESS.
 */
sai_status_t
isai_im_nexthopgroup_object_type_get_availability(sai_object_id_t       switch_id,
                                                  uint32_t              attr_count,
                                                  const sai_attribute_t *attr_list_p,
                                                  uint64_t              *count_p);


#endif /* __IFCS_SAI_NEXTHOPGROUP_UTIL_H__ */
