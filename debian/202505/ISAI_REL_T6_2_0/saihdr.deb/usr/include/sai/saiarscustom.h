/**
 *copyright (c) 2024 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 *    @file    saiarscustom.h
 *
 * @brief   This module defines custom attributes for the Switch Abstraction Interface (SAI)
 */

#ifndef __SAIARSCUSTOM_H_
#define __SAIARSCUSTOM_H_

#include <saiars.h>
#include <saitypes.h>

/**
 * @brief SAI ars custom attribute
 */
typedef enum _sai_ars_attr_custom_t
{
    /**​
     * @brief Enable past port load as the quality parameter at ARS level.
     *​
     * @type bool​
     * @flags CREATE_AND_SET​
     * @default true
     * @validonly SAI_ARS_PROFILE_ATTR_PORT_LOAD_PAST == true
     */
    SAI_ARS_ATTR_CUSTOM_PORT_LOAD_PAST = SAI_ARS_ATTR_CUSTOM_RANGE_START,

    /**​
     * @brief Enable future port load as the quality parameter at ARS level.
     *​
     * @type bool​
     * @flags CREATE_AND_SET​
     * @default true
     * @validonly SAI_ARS_PROFILE_ATTR_PORT_LOAD_FUTURE == true
     */
    SAI_ARS_ATTR_CUSTOM_PORT_LOAD_FUTURE,

    /**​
     * @brief Enable current port load as the quality parameter at ARS level.
     *​
     * @type bool​
     * @flags CREATE_AND_SET​
     * @default true
     * @validonly SAI_ARS_PROFILE_ATTR_PORT_LOAD_CURRENT == true
     */
    SAI_ARS_ATTR_CUSTOM_PORT_LOAD_CURRENT,

    /**​
     * @brief Enable Queue Delay as the quality parameter at ARS level.
     *​
     * @type bool​
     * @flags CREATE_AND_SET​
     * @default true
     * @validonly SAI_ARS_PROFILE_ATTR_CUSTOM_QUEUE_DELAY == true
     */
    SAI_ARS_ATTR_CUSTOM_QUEUE_DELAY,

}sai_ars_attr_custom_t;

#endif /* __SAIARSCUSTOM_H_ */