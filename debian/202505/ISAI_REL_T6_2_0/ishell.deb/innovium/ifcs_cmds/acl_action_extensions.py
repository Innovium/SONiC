
#-------------------------------------------------------------------------------
# * Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

from ctypes import *
from ifcs_cmds.acl_action import *
from print_table import PrintTable
import sys
from utils.compat_util import *
from verbosity import log, log_dbg, log_err
ifcs_ctypes=sys.modules['ifcs_ctypes']

def show_acl_action_extension_attrs(args,
                                    aa_obj,
                                    ignore_notfound_err=False,
                                    display_count=False,
                                    count_val=0):
    log_dbg(1, " Inside acl_action extension attrs show")
    acl_action = int(args)
    if not aa_obj:
        return

    attrCount = ifcs_ctypes.IFCS_ACL_ACTION_ATTR_COUNT_GET_ALL
    attr = (ifcs_ctypes.ifcs_attr_t * attrCount)()
    attr_p = compat_pointer(attr, ifcs_ctypes.ifcs_attr_t)

    try:
        actual_count = aa_obj.getAttr(acl_action, attr, attr_p, attrCount,
                                      ignore_notfound_err)
    except KeyError:
        einfo = "{}".format(sys.exc_info())
        log_dbg(
            1,
            "KeyError in show acl_action extension attrs. acl_action: {}, error: {}"
            .format(acl_action, einfo))
        if ignore_notfound_err and aa_obj.not_found_exc_msg.format(
                ifcs_ctypes.IFCS_NOTFOUND) in einfo:
            # Don't display error message for expected exception.
            # Re-raise for handling.
            raise
        log_err("Failed to get attributes for acl_action ")
        raise
    except:
        log_dbg(
            1,
            "OtherError in show acl_action extension attrs. acl_action: {}, error: {}"
            .format(acl_action, sys.exc_info()))
        log_err("Failed to get attributes for acl_action ")
        raise KeyError

    attrCount = actual_count.value

    if display_count:
        log("AclAction count: {0}".format(count_val))
    table = PrintTable()
    table.add_row(['acl_action', aa_obj.handle_to_str(acl_action, True)])
    _type = ''
    _map = {
        'DROP' : 'drop',
        'DROP_OVERRIDE' : 'drop_override',
        'COPY_TO_CPU' : 'ctc',
        'COPY_TO_CPU_OVERRIDE': 'ctc_override',
        'CPU_QUEUE' : 'cpu_queue',
        'PKT_QOS' : 'qos',
        'QUEUE' : 'queue',
        'SET_TC' : 'set_tc',
        'SET_DP' : 'set_dp',
        'SET_VLAN_ID' : 'set_vlan',
        'SET_VLAN_PRIORITY_CFI' : 'set_vlan',
        'SET_DSCP' : 'set_dscp',
        'SET_ENCAP_DSCP' : 'set_dscp',
        'SET_SYSTEM_ECN' : 'set_system_ecn',
        'USER_COUNTER' : 'set_user_counter',
        'IPT'      : 'ipt',
        'LEARN_OVERRIDE' : 'learn_override',
        'ACL_USER_COOKIE' : 'acl_user_cookie',
        'IPV4_TTL_DECREMENT_OVERRIDE' : 'ttl_decrement_override',
        'IPV6_TTL_DECREMENT_OVERRIDE' : 'ttl_decrement_override',
        'MPS_ALB_DISABLE' : 'mps_alb_disable',
        'DSPLAG_ALB_DISABLE' : 'dsplag_alb_disable',
        'ECMP_MEMBER_SEL_MODE' : 'ecmp_member_sel_mode',
        'FWD_LAYER_TYPE' : 'fwd_layer_type',
        'ECMP_ELEMENT_SEL' : 'ecmp_element_sel',
        'LAG_ELEMENT_SEL' : 'lag_element_sel',
        'MARK_FOR_TRIM' : 'mark_for_trim',
        'SET_TRIMMED_DSCP_IPV4' : 'set_trimmed_dscp',
        'SET_TRIMMED_DSCP_IPV6' : 'set_trimmed_dscp',
        'SET_TRIMMED_DSCP_UPD_HDR_IPV4' : 'set_trimmed_dscp_upd_hdr',
        'SET_TRIMMED_DSCP_UPD_HDR_IPV6' : 'set_trimmed_dscp_upd_hdr',
        }
    for j in range(attrCount):
        attr_name, attr_type, attr_val, attr_valid = aa_obj.get_attr_name_value(attr[j])
        if not attr_valid:
            continue

        if attr_name == 'value':
            table.add_row([attr_name, '--'])
            sub_fields = aa_obj.get_sub_attr_name_value(
                attr_name, attr_type, attr_val)
            if _type in _map.keys():
                table.add_row([_map[_type], sub_fields[_map[_type]]])
            continue
        elif attr_name == 'type':
            _type = attr_val
        else:
            table.add_row([attr_name, attr_val])
    table.print_table()
    table.reset_table()

    #aa_obj.display(handle, attr, actual_count.value)

    return
