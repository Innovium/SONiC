
#-------------------------------------------------------------------------------
# * Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
# *-----------------------------------------------------------------------------

from ctypes import *
from utils.compat_util import *
from verbosity import log, log_dbg, log_err
from ifcs_cmds.ingress_tunnel_vni_map_entry import *
from print_table import PrintTable
import sys
ifcs_ctypes=sys.modules['ifcs_ctypes']


def show_ingress_tunnel_vni_map_entry_extension_brief(
        args, ingress_tunnel_vni_map_entry):
    log_dbg(1, " Inside ingress_tunnel_vni_map_entry extension brief show")
    #self.handle = int(args)

    try:
        if args:
            rc, all_ingress_tunnel_vni_map_entry = ingress_tunnel_vni_map_entry.bulk_get_all_ingress_tunnel_vni_map_entry_keys(args)
        else:
            rc, all_ingress_tunnel_vni_map_entry = ingress_tunnel_vni_map_entry.bulk_get_all_ingress_tunnel_vni_map_entry_keys()
    except BaseException:
        log_err(" Failed to get all ingress_tunnel_vni_map_entry")
        return

    table = PrintTable()
    field_names = []

    field_names.append('key_type')
    field_names.append('key')
    field_names.append('l2vni')
    field_names.append('l3vni')
    table.add_row(field_names)

    try:
        if ingress_tunnel_vni_map_entry.filter_option['sort'] in ingress_tunnel_vni_map_entry.get_methods.keys():
            all_ingress_tunnel_vni_map_entry = sorted(
                all_ingress_tunnel_vni_map_entry,
                key=lambda x: ingress_tunnel_vni_map_entry.get_methods[ingress_tunnel_vni_map_entry.filter_option['sort']](x))
        else:
            log("Cannot sort on {0}".format(ingress_tunnel_vni_map_entry.filter_option['sort']))
    except BaseException:
        pass

    all_ingress_tunnel_vni_map_entry = sorted(
        all_ingress_tunnel_vni_map_entry,
        key=lambda x: x.contents.key_type)

    log("Total ingress_tunnel_vni_map_entry count: {0} ".format(len(all_ingress_tunnel_vni_map_entry)))
    count = 0
    for map_entry in all_ingress_tunnel_vni_map_entry:
        attr_row = []
        key_type_str = ''
        key_type = map_entry.contents.key_type
        if key_type == ifcs_ctypes.IFCS_INGRESS_TUNNEL_VNI_MAP_KEY_TYPE_IPV4_GRE:
            key_type_str = 'ipv4_gre'
            key = map_entry.contents.key.ipv4_gre_key.packet_value
        elif key_type == ifcs_ctypes.IFCS_INGRESS_TUNNEL_VNI_MAP_KEY_TYPE_IPV6_GRE:
            key_type_str = 'ipv6_gre'
            key = map_entry.contents.key.ipv6_gre_key.packet_value
        elif key_type == ifcs_ctypes.IFCS_INGRESS_TUNNEL_VNI_MAP_KEY_TYPE_IPV4_VXLAN:
            key_type_str = 'ipv4_vxlan'
            key = map_entry.contents.key.ipv4_vxlan_key.packet_value
        elif key_type == ifcs_ctypes.IFCS_INGRESS_TUNNEL_VNI_MAP_KEY_TYPE_IPV6_VXLAN:
            key_type_str = 'ipv6_vxlan'
            key = map_entry.contents.key.ipv6_vxlan_key.packet_value

        attr_row.append(key_type_str)
        attr_row.append(str(key))

        try:
            l2vni = ingress_tunnel_vni_map_entry.getL2vni(map_entry, True)
            l3vni = ingress_tunnel_vni_map_entry.getL3vni(map_entry, True)
        except KeyError:
            einfo = "{}".format(sys.exc_info())
            log_dbg(
                1,
                "KeyError in show ingress_tunnel_vni_map_entry extension brief. ingress_tunnel_vni_map_entry: {} (key_type: {}, key: {}), error: {}"
                .format(map_entry, key_type_str, key, einfo))
            if ingress_tunnel_vni_map_entry.not_found_exc_msg.format(
                    ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                # Skip the instance as the object is not found.
                continue
            # Re-raise other exceptions for handling.
            raise

        attr_row.append(ingress_tunnel_vni_map_entry.handle_to_str(l2vni))
        attr_row.append(ingress_tunnel_vni_map_entry.handle_to_str(l3vni))

        table.add_row(attr_row)
        count += 1

    table.print_table(brief=True)
    log("Total ingress_tunnel_vni_map_entry count: {0}".format(count))

    return
