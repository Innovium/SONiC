/**
 *copyright (c) 2024 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 *    @file    saiqueuecustom.h
 *
 * @brief   This module defines custom of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAIQUEUECUSTOM_H_
#define __SAIQUEUECUSTOM_H_

#include <saiqueue.h>
#include <saitypes.h>


/**
 * @brief SAI queue custom attribute
 */
typedef enum _sai_queue_attr_custom_t
{
    /**
     * @brief Drop unknown unicast packets on a lossless queue.
     *
     * If the attribute is true, drop unknown unicast packets
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default true
     */
    SAI_QUEUE_ATTR_LOSSLESS_FLOOD_CONTROL_ENABLE = SAI_QUEUE_ATTR_CUSTOM_RANGE_START + 1,

}sai_queue_attr_custom_t;


/**
 * @brief SAI queue stat custom
 */
typedef enum _sai_queue_stat_custom_t
{
    /** Get/set unknown unicast packet drop count [uint64_t] */
    SAI_QUEUE_STAT_LOSSLESS_FLOOD_CONTROL_PACKETS = SAI_QUEUE_STAT_CUSTOM_RANGE_BASE + 1,

    /** Get/set unknown unicast bytes drop count [uint64_t] */
    SAI_QUEUE_STAT_LOSSLESS_FLOOD_CONTROL_BYTES,

    /** Custom statistics to get queue delay [uint64_t] */
    SAI_QUEUE_STAT_CUSTOM_QUEUE_DELAY,

    /** Get current queue occupancy in cells [uint64_t] */
    SAI_QUEUE_STAT_CUSTOM_CURR_OCCUPANCY_CELLS,

    /** Get watermark queue occupancy in cells [uint64_t] */
    SAI_QUEUE_STAT_CUSTOM_WATERMARK_CELLS,

    /** Custom range end */
    SAI_QUEUE_STAT_CUSTOM_RANGE_END

}sai_queue_stat_custom_t;

#endif /* __SAIQUEUECUSTOM_H_ */
