/**
 *copyright (c) 2024 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 *    @file    saiarsprofilecustom.h
 *
 * @brief   This module defines custom of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAIARSPROFILECUSTOM_H_
#define __SAIARSPROFILECUSTOM_H_

#include <saiarsprofile.h>
#include <saitypes.h>

/**
 * @brief SAI ars profile custom attribute
 */
typedef enum _sai_ars_profile_attr_custom_t
{
    /**​
     * @brief Enable Queue Delay as the quality parameter. This is the average queue delay measured on a queue.​
     *​
     * @type bool​
     * @flags CREATE_AND_SET​
     * @default false​
     * @validonly SAI_ARS_PROFILE_ATTR_ALGO == SAI_ARS_PROFILE_ALGO_EWMA​
     */
    SAI_ARS_PROFILE_ATTR_CUSTOM_QUEUE_DELAY = SAI_ARS_PROFILE_ATTR_CUSTOM_RANGE_START,

    /**​
     * @brief Weight attribute is used in EWMA calculations.​
     * Large weight lowers the significance of instantaneous measure on the overall average.​
     *​
     * @type sai_uint8_t​
     * @flags CREATE_AND_SET​
     * @default 16​
     * @validonly SAI_ARS_PROFILE_ATTR_ALGO == SAI_ARS_PROFILE_ALGO_EWMA​
     */
    SAI_ARS_PROFILE_ATTR_CUSTOM_QUEUE_DELAY_WEIGHT,

    /**​
     * @brief Sampling interval in microseconds of data for quality measure computation​
     *​
     * @type sai_uint32_t​
     * @flags CREATE_AND_SET​
     * @default 16​
     */
    SAI_ARS_PROFILE_ATTR_CUSTOM_QUEUE_DELAY_SAMPLING_INTERVAL,

    /**​
     * @brief Minimum Queue delay threshold in nanoseconds for quantization process.​
     * Used by hardware to allocate the quantization bands.​
     *​
     * @type sai_uint32_t​
     * @flags CREATE_AND_SET​
     * @default 0​
     */
    SAI_ARS_PROFILE_ATTR_CUSTOM_QUEUE_DELAY_MIN_VAL,

    /**​
     * @brief Maximum Queue delay threshold in nanoseconds for quantization process.​
     * Used by hardware to allocate the quantization bands.​
     *​
     * @type sai_uint32_t​
     * @flags CREATE_AND_SET​
     * @default 0
     */
    SAI_ARS_PROFILE_ATTR_CUSTOM_QUEUE_DELAY_MAX_VAL,

}sai_ars_profile_attr_custom_t;

#endif /* __SAIARSPROFILECUSTOM_H_ */