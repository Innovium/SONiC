##-------------------------------------------------------------------------------
# * Copyright (c) (2025) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------
#
#       @ File:-       test_multi_traffic_send.py
#       @ Description:-
#               Sample script to set L2 MAC entry trap to CPU attribute.
#       @ Prerequisites:-
#               1. CLI was started with a correct inno config file.
#               2. Node create was successful.
#               3. Create snake configuration via IFCS command "diagtest sanke config"
#       @ Usage:-
#               From the CLI prompt, type console to take you to the python
#               interpreter mode.
#                       e.g. IVM:0>console
#               Once in the console, import this file.
#                       e.g. >>>from test_multi_traffic_send import *
#               Call the function run_traffic_test(dest_port, thread_num)
#                       e.g. >>>run_traffic_test(29, 4)
#               Exit the console(python interpreter mode) by typing exit().
#               This will take you back to the cli prompt.
#        @ Notes:-
#                1. User MUST make sure the testing port status is LINK_UP
#                2. The processing time may take around ~1 minutes.
#                3. Use "CTRL+C" key may cause abnormal existing, in such condition,
#                   use "sudo kill -9" to clear the remained process.
#        @ Example:- CN10K+TL10-DB
#                IVM:0>port loopback 29 PCS
#                IVM:0>port enable 29
#                IVM:0>shell sleep 3
#                IVM:0>Innovium shell server: Accepted shell client 127.0.0.1:53150
#                console
#                 Innovium Interactive Python Console, 3.10.9 (main, Mar  5 2025, 06:33:34) [GCC 9.4.0] on linux
#                  Type "help()" for more information, "exit() " or "quit() " to return to Innovium command shell.
#                >>> from test_multi_traffic_send import *
#                >>> run_traffic_test(29, 4)
#                traffic_send thread 1
#                traffic_send thread 2
#                traffic_send thread 3
#                traffic_send thread 4
#
#                Run IFCS remote shell to get the transmit rate.
#                IVM-R>ifcs show rate devport filter nz
#                +----------------------------------------------------------------------------------------------+
#                | Devport | Input Pps | Input Gbps | Input Err/sec | Output Pps | Output Gbps | Output Err/sec |
#                |----------------------------------------------------------------------------------------------|
#                |      29 | 230578.19 |      16.65 |          0.00 |  230578.19 |       16.65 |           0.00 |
#                +----------------------------------------------------------------------------------------------+
# --------------------------------------------------------------------------------

import os
import sys
from ctypes import *
import sys
try:
    ifcs_ctypes = sys.modules['ifcs_ctypes']
except KeyError:
    import ifcs_ctypes

from verbosity import log
from utils.compat_util import *
import threading

def build_packet(vlan_id, pkt_len):
    header = [0x00, 0x00, 0x00, 0x00, 0x00, 0xAA, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBB, 0x81, 0x00, 0x00, vlan_id]
    pkt_buf = b''.join(compat_chr(byte) for byte in header)
    pkt_buf += compat_chr(0xff) * (pkt_len - 16)
    return pkt_buf

def traffic_thread(dest_port, vlan_id, pkt_len, pkt_cnt):
    pkt_buf = build_packet(vlan_id, pkt_len)
    node_id = 0

    ifcs_packet = ifcs_ctypes.ifcs_hostif_packet_info_t()
    ret = ifcs_ctypes.ifcs_hostif_packet_info_t_init(pointer(ifcs_packet))
    assert ret == ifcs_ctypes.IFCS_SUCCESS

    ifcs_packet.dsp = ifcs_ctypes.IFCS_HANDLE_SYSPORT((dest_port))
    ifcs_packet.pkt_buf = cast(pkt_buf, c_void_p)
    ifcs_packet.pkt_buf_len = pkt_len
    ifcs_packet.tx_type = ifcs_ctypes.IFCS_HOSTIF_TX_TYPE_PIPELINE_BYPASS

    for _ in range(pkt_cnt):
        ifcs_ctypes.ifcs_hostif_send_packet(node_id, pointer(ifcs_packet))

def traffic_send_thread(dest_port, thread_id):
    #print(f"traffic_send thread {thread_id + 1}")
    traffic_thread(dest_port, vlan_id=dest_port, pkt_len=9216, pkt_cnt=1000000)

def run_traffic_test(dest_port, thread_num):
    # Create and start threads
    threads = []
    for i in range(0, thread_num):
        thread = threading.Thread(target=traffic_send_thread, args=(dest_port, i,))
        threads.append(thread)
        thread.start()

    # Wait for threads to complete
    #for thread in threads:
    #    thread.join()


def main(*args):
    run_traffic_test(29,4)

if __name__ == '__main__':
    run_traffic_test(dest_port=29, thread_num=2)

