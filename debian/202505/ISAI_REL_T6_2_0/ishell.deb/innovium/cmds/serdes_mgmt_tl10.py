#-------------------------------------------------------------------------------
# Copyright (c) (2025) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you, your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------
import argparse
import ctypes
import numpy as np
import sys
import time
import traceback

from cmdmgr import Command, CommandError
from testutil import pci, torrent
from print_table import PrintTable
from verbosity import *

try:
    ifcs_ctypes = sys.modules["ifcs_ctypes"]
except KeyError:
    import ifcs_ctypes


def _status_to_string(rc):
    return compat_bytesToStr(ifcs_ctypes.ifcs_status_to_string(rc))

class SD0801:
    COMMON_REGS = (
        'PHY_PLL_CFG',
        'CMN_SSM_BIAS_TMR',
        'CMN_PLLSM0_PLLEN_TMR',
        'CMN_PLLSM0_PLLPRE_TMR',
        'CMN_PLLSM0_PLLLOCK_TMR',
        'CMN_PLLSM1_PLLEN_TMR',
        'CMN_PLLSM1_PLLPRE_TMR',
        'CMN_PLLSM1_PLLLOCK_TMR',
        'CMN_BGCAL_INIT_TMR',
        'CMN_BGCAL_ITER_TMR',
        'CMN_IBCAL_INIT_TMR',
        'CMN_IBCAL_ITER_TMR',
        'CMN_TXPUCAL_INIT_TMR',
        'CMN_TXPUCAL_ITER_TMR',
        'CMN_TXPDCAL_INIT_TMR',
        'CMN_TXPDCAL_ITER_TMR',
        'CMN_RXCAL_INIT_TMR',
        'CMN_RXCAL_ITER_TMR',
        'CMN_SD_CAL_REFTIM_START',
        'CMN_SD_CAL_PLLCNT_START',
        'CMN_PDIAG_PLL0_CLK_SEL_M0',
        'CMN_PDIAG_PLL0_CLK_SEL_M1',
        'CMN_PDIAG_PLL1_CLK_SEL_M0',
        'CMN_PDIAG_PLL1_ITRIM_M0',
        'CMN_PDIAG_PLL0_CP_PADJ_M0',
        'CMN_PDIAG_PLL1_CP_PADJ_M0',
        'CMN_PDIAG_PLL0_CP_IADJ_M0',
        'CMN_PDIAG_PLL0_CTRL_M0',
        'CMN_PDIAG_PLL1_CTRL_M0',
        'CMN_PLL0_VCOCAL_INIT_TMR',
        'CMN_PLL1_VCOCAL_INIT_TMR',
        'CMN_PLL0_VCOCAL_ITER_TMR',
        'CMN_PLL1_VCOCAL_ITER_TMR',
        'CMN_PLL0_VCOCAL_REFTIM_START',
        'CMN_PLL1_VCOCAL_REFTIM_START',
        'CMN_PLL0_VCOCAL_PLLCNT_START',
        'CMN_PLL1_VCOCAL_PLLCNT_START',
        'CMN_PLL0_LOCK_REFCNT_START',
        'CMN_PLL1_LOCK_REFCNT_START',
        'CMN_PLL0_LOCK_PLLCNT_START',
        'CMN_PLL1_LOCK_PLLCNT_START',
        'CMN_PLL0_LOCK_PLLCNT_THR',
        'CMN_PLL1_LOCK_PLLCNT_THR',
        'CMN_DIAG_BIAS_OVRD1',
        'CMN_DIAG_SH_RESISTOR',
        'CMN_TXPDCAL_TUNE',
        'CMN_TXPUCAL_TUNE',
        'CMN_CDIAG_PLL0_PROG_CLK_CTRL0',
        'CMN_CDIAG_PLL0_PROG_CLK_CTRL1',
        'CMN_CDIAG_PLL1_PROG_CLK_CTRL0',
        'CMN_CDIAG_PLL1_PROG_CLK_CTRL1',
        'CMN_PLL0_DSM_FBH_OVRD_M0',
        'CMN_PLL0_DSM_FBL_OVRD_M0',
        'CMN_PLL1_DSM_FBH_OVRD_M0',
        'CMN_PLL1_DSM_FBL_OVRD_M0',
    )

    LANE_REGS = (
        'PHY_PMA_XCVR_CTRL',
        'PHY_PMA_XCVR_LPBK',
        'RX_SDCAL0_INIT_TMR',
        'RX_SDCAL0_ITER_TMR',
        'RX_SDCAL1_INIT_TMR',
        'RX_SDCAL1_ITER_TMR',
        'TX_RCVDET_ST_TMR',
        'XCVR_DIAG_HSCLK_SEL',
        'XCVR_DIAG_HSCLK_DIV',
        'XCVR_DIAG_PLLDRC_CTRL',
        'TX_PSC_A0',
        'TX_PSC_A1',
        'TX_PSC_A2',
        'TX_PSC_A3',
        'RX_PSC_A0',
        'RX_PSC_A1',
        'RX_PSC_A2',
        'RX_PSC_A3',
        'RX_PSC_A4',
        'RX_PSC_A5',
        'RX_PSC_CAL',
        'RX_PSC_RDY',
        'DRV_DIAG_TX_DRV',
        'TX_TXCC_CPOST_MULT_00',
        'TX_TXCC_MGNFS_MULT_000',
        'TX_TXCC_CTRL',
        'RX_REE_PTXEQSM_EQENM_EVAL',
        'RX_REE_GCSM1_EQENM_PH1',
        'RX_REE_GCSM1_EQENM_PH2',
        'RX_REE_PERGCSM_EQENM_PH1',
        'RX_REE_PERGCSM_EQENM_PH2',
        'RX_REE_SMGM_CTRL1',
        'RX_REE_SMGM_CTRL2',
        'XCVR_DIAG_PSC_OVRD',
        'RX_DIAG_DFE_CTRL',
        'RX_DIAG_NQST_CTRL',
        'RX_DIAG_DFE_AMP_TUNE_2',
        'RX_DIAG_DFE_AMP_TUNE_3',
        'RX_DIAG_PI_RATE',
        'RX_DIAG_PI_CAP',
        'RX_DIAG_ACYA',
        'RX_CDRLF_CNFG',
        'TX_TXCC_IPRE_COEF_VALUE',
        'TX_TXCC_IPOST_COEF_VALUE',
        'TX_TXCC_PRE_OVRD',
        'TX_TXCC_MAIN_OVRD',
        'TX_TXCC_POST_OVRD',
        'TX_TXCC_PRE_CVAL',
        'TX_TXCC_MAIN_CVAL',
        'TX_TXCC_POST_CVAL',
    )

    BIST_REGS = (
        'TX_BIST_CTRL',
        'TX_BIST_UDDWR',
        'TX_BIST_SEED0',
        'TX_BIST_SEED1',
        'RX_BIST_CTRL',
        'RX_BIST_SYNCCNT',
        'RX_BIST_UDDWR',
        'RX_BIST_ERRCNT',
    )

    REE_REGS = (
        'RX_REE_TAP1_DIAG',
        'RX_REE_TAP2_DIAG',
        'RX_REE_TAP3_DIAG',
        'RX_REE_TAP4_DIAG',
        'RX_REE_TAP5_DIAG',
        'RX_REE_PEAK_DIAG',
        'RX_REE_ATTEN_DIAG',
        'RX_REE_LFEQ_DIAG',
        'RX_REE_VGA_GAIN_DIAG',
        'RX_REE_OFF_COR_DIAG',
    )

    def __init__(self):
        pass

    @staticmethod
    def mdioPortAddr(lane):
        flds = pci.read_fields('MPIC{}_ENABLE'.format(lane))
        if flds['speed_mode_f'] == 1:
            port_addr = flds['pcs_10g_port_addr_f']
        else:
            flds = pci.read_fields('MPIC{}_CTRL'.format(lane))
            port_addr = flds['pcs_1g_port_addr_f']
        return port_addr

    @staticmethod
    def mdioRead(addr, lane):
        port_addr = SD0801.mdioPortAddr(lane)
        pci.write_fields('MPIC{}_MDIO_CTRL_REG'.format(lane),
            clause_sel_f=0,
            operation_f=0,
            port_addr_f=port_addr,
            dev_addr_f=3,
            zero_f=0,
            data_wr_f=addr)
        pci.write_fields('MPIC{}_MDIO_CTRL_REG'.format(lane),
            clause_sel_f=0,
            operation_f=3,
            port_addr_f=port_addr,
            dev_addr_f=3,
            zero_f=0,
            data_wr_f=0)
        v = pci.read_fields('MPIC{}_MDIO_CTRL_REG'.format(lane))
        return v['data_wr_f']

    @staticmethod
    def mdioWrite(addr, data, lane):
        port_addr = SD0801.mdioPortAddr(lane)
        pci.write_fields('MPIC{}_MDIO_CTRL_REG'.format(lane),
            clause_sel_f=0,
            operation_f=0,
            port_addr_f=port_addr,
            dev_addr_f=3,
            zero_f=0,
            data_wr_f=addr)
        pci.write_fields('MPIC{}_MDIO_CTRL_REG'.format(lane),
            clause_sel_f=0,
            operation_f=1,
            port_addr_f=port_addr,
            dev_addr_f=3,
            zero_f=0,
            data_wr_f=data)

    @staticmethod
    def getPatternName(value):
        value = (value >> 8) & 0x0f
        if value == 0:
            name = "User defined"
        elif value == 0x08:
            name = "PRBS7"
        elif value == 0x09:
            name = "PRBS15"
        elif value == 0x0a:
            name = "PRBS23"
        elif value == 0x0b:
            name = "PRBS31"
        else:
            name = "Unknown"
        return name

class PCS:
    MDIO_COMMON_REGS = {
        0x00: 'PCS Control Register 1',
        0x01: 'PCS Status Register 1',
        0x02: 'PCS Device Identifier 1',
        0x03: 'PCS Device Identifier 2',
        0x04: 'PCS Speed Ability',
        0x05: 'PCS Devices in Package 1',
        0x06: 'PCS Devices in Package 2',
        0x07: 'PCS Control Register 2',
        0x08: 'PCS Status Register 2',
        0x0e: 'PCS Package identifier register 1',
        0x0f: 'PCS Package identifier register 2',
    }

    MDIO_1G_REGS = {
        0x18: '10G Base-X PCS status register',
        0x19: '10G Base-X PCS test control register',
    }

    MDIO_10G_REGS = {
        0x20: '10GBASE-R PCS Status 1',
        0x21: '10GBASE-R PCS Status 2',
        0x22: '10GBASE-R PCS Test Pattern Seed A_0',
        0x23: '10GBASE-R PCS Test Pattern Seed A_1',
        0x24: '10GBASE-R PCS Test Pattern Seed A_2',
        0x25: '10GBASE-R PCS Test Pattern Seed A_3',
        0x26: '10GBASE-R PCS Test Pattern Seed B_0',
        0x27: '10GBASE-R PCS Test Pattern Seed B_1',
        0x28: '10GBASE-R PCS Test Pattern Seed B_2',
        0x29: '10GBASE-R PCS Test Pattern Seed B_3',
        0x2a: '10GBASE-R PCS Test Pattern Control',
        0x2b: '10GBASE-R PCS Test Pattern Error Counter',
        0xaa: '10GBASE-R FEC ability',
        0xab: '10GBASE-R FEC control',
        0xac: '10GBASE-R FEC corrected blocks counter (lo)',
        0xad: '10GBASE-R FEC corrected blocks counter (hi)',
        0xae: '10GBASE-R FEC uncorrected blocks counter (lo)',
        0xaf: '10GBASE-R FEC uncorrected blocks counter (hi)',
    }

    @staticmethod
    def getDesc(addr, speed):
        desc = PCS.MDIO_COMMON_REGS.get(addr)
        if desc is not None:
            return desc
        desc = PCS.MDIO_10G_REGS.get(addr) if speed == 10 else PCS.MDIO_1G_REGS.get(addr)
        if desc is not None:
            return desc
        return ''
class MPICImpl(torrent.TorrentImpl):
    RETRY_COUNT = 1000

    def __init__(self, node_id):
        self.node_id = node_id
        super(MPICImpl, self).__init__()

    def read(self, addr):
        retry = 0
        fields = pci.read_fields('MPIC_STS_APB_ACCESS')
        while fields['req_rdy_f'] == 0:
            retry += 1
            if retry == self.RETRY_COUNT:
                raise Exception('apb_read: timeout waiting for req_rdy_f before access')
            time.sleep(1/1000000)
            fields = pci.read_fields('MPIC_STS_APB_ACCESS')

        pci.write_fields('MPIC_DO_APB_ACCESS',
            wr_data_f = 0,
            addr_f    = addr,
        )

        pci.write_fields('MPIC_DO_APB_ACCESS_CTRL',
            write_f = 0
        )

        retry = 0
        fields = pci.read_fields('MPIC_STS_APB_ACCESS')
        while fields['req_rdy_f'] == 0:
            retry += 1
            if retry == self.RETRY_COUNT:
                raise Exception('apb_read: timeout waiting for req_rdy_f before access')
            time.sleep(1/1000000)
            fields = pci.read_fields('MPIC_STS_APB_ACCESS')

        data = fields['rsp_data_f']
        return data

    def write(self, addr, value):
        retry = 0
        fields = pci.read_fields('MPIC_STS_APB_ACCESS')
        while fields['req_rdy_f'] == 0:
            retry += 1
            if retry == self.RETRY_COUNT:
                raise Exception('apb_write: timeout waiting for req_rdy_f before access')
            time.sleep(1/1000000)
            fields = pci.read_fields('MPIC_STS_APB_ACCESS')

        pci.write_fields('MPIC_DO_APB_ACCESS',
            wr_data_f = value,
            addr_f    = addr
        )

        pci.write_fields('MPIC_DO_APB_ACCESS_CTRL',
            write_f = 1
        )

        retry = 0
        fields = pci.read_fields('MPIC_STS_APB_ACCESS')
        while fields['req_rdy_f'] == 0:
            retry += 1
            if retry == self.RETRY_COUNT:
                raise Exception('apb_write: timeout waiting for req_rdy_f before access')
            time.sleep(1/1000000)
            fields = pci.read_fields('MPIC_STS_APB_ACCESS')

        return addr

    def phy_reset(self, lane):
        phy_lane_reset_n = pci.read_fields('PHY_LANE_CTRL')['phy_l{:02}_reset_n_f'.format(lane)]
        if phy_lane_reset_n:
            pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 0})
            time.sleep(1/1000000)
            pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 1})

    def pma_power_down(self, lane):
        self._pma_power_state(lane, 0)

    def pma_power_up(self, lane):
        self._pma_power_state(lane, 4)
        self._pma_power_state(lane, 0)
        self._pma_power_state(lane, 1)

    @staticmethod
    def _pma_power_state(lane, state):
        if lane == 0:
            MPICImpl._pma_power_state_lane0(state)
        else:
            MPICImpl._pma_power_state_lane1(state)
        time.sleep(1/1000000)

    @staticmethod
    def _pma_power_state_lane0(state):
        if state == 0:
            pci.write_fields('PMA_XCVR_LN0', power_state_req_ln_0_f=0)
            return
        fields = pci.read_fields('PMA_XCVR_LN0')
        prev_state = fields['power_state_ack_ln_0_f']
        pci.write_fields('PMA_XCVR_LN0', power_state_req_ln_0_f=state)
        retry_count = 1000
        while True:
            fields = pci.read_fields('PMA_XCVR_LN0')
            if fields['power_state_ack_ln_0_f'] == state:
                break
            retry_count -= 1
            if retry_count == 0:
                raise Exception('Lane 0: power state change {} to {} failed'.format(prev_state, state))

    @staticmethod
    def _pma_power_state_lane1(state):
        if state == 0:
            pci.write_fields('PMA_XCVR_LN1', power_state_req_ln_1_f=0)
            return
        fields = pci.read_fields('PMA_XCVR_LN1')
        prev_state = fields['power_state_ack_ln_1_f']
        pci.write_fields('PMA_XCVR_LN1', power_state_req_ln_1_f=state)
        retry_count = 1000
        while True:
            fields = pci.read_fields('PMA_XCVR_LN1')
            if fields['power_state_ack_ln_1_f'] == state:
                break
            retry_count -= 1
            if retry_count == 0:
                raise Exception('Lane 1: power state change {} to {} failed'.format(prev_state, state))

class Serdes(Command):
    NUM_LANES = 2
    RETRY_COUNT = 1000

    JITTER_PATTERNS = {
        #       1G                                   					10G
        '1T': ((0x2aa,),                            					(0xaa,)),
        #       11_0011_0011
        #       00_1100_1100                          					0011_0011
        '2T': ((0x333, 0x0cc),                      					(0x33,)),
        #       11_0000_1111 = 30f
        #       11_1100_0011 = 3c3
        #       00_1111_0000 = 0f0
        #       00_0011_1100 = 03c                  					0000_1111
        '4T': ((0x30f, 0x3c3, 0x0f0, 0x03c),        					(0x0f,)),
        #                                           					0001_1111 = 1f
        #                                           					0111_1100 = 7c
        #                                           					1111_0000 = f0
        #                                           					1100_0001 = c1
        #       00_0001_1111                        					0000_0111 = 07
        '5T': ((0x1f,),                             					(0x1f, 0x7c, 0xf0, 0xc1, 0x07)),
        #       00_1111_1111 = 0ff
        #       11_1100_0000 = 3c0
        #       00_0000_1111 = 00f
        #       11_1111_1100 = 3fc
        #       11_0000_0000 = 300
        #       00_0011_1111 = 03f
        #       11_1111_0000 = 3f0                  					1111_1111 = ff
        #       00_0000_0011 = 003                  					0000_0000 = 00
    '8T': ((0x0ff, 0x3c0, 0x00f, 0x3fc, 0x300, 0x03f,0x3f0, 0x003), 	(0xff, 0x00)),
        #                                           					1111_1111 = ff
        #                                           					0000_0011 = 03
        #                                           					1111_0000 = f0
        #       11_1111_1111 = 3ff                  					0011_1111 = 3f
        #       00_0000_0000 = 000                  					0000_0000 = 00
        '10T':((0x3ff, 0x000),                      					(0xff, 0x03, 0xf0, 0x3f, 0x00)),
    }

    LPBK_MODES = ('none', 'serial', 'isi', 'line', 'rclk', 'nepar', 'fepar')

    PATTERNS = ('7', 'PRBS7', '15', 'PRBS15', '23', 'PRBS23', '31', 'PRBS31', '1T', '2T', '4T', '5T', '8T', '10T')

    @staticmethod
    def _hex_int(x):
        if x[:2] == '0x':
            return int(x, 16)
        return int(x, 10)

    def __init__(self, node_id):
        self.node_id = node_id
        self.torrent = torrent.Torrent(MPICImpl(node_id))
        self.tx_pattern = [None] * Serdes.NUM_LANES
        self.rx_pattern = [None] * Serdes.NUM_LANES

        self.parser = parser = argparse.ArgumentParser(prog='diagtest serdes mgmt')
        parser.add_argument('--devport', help='all, one ore more comma seperated devport numbers')
        parser.add_argument('--lane', help='all, one ore more comma seperated lane numbers')
        sub_parsers = parser.add_subparsers()

        parser = sub_parsers.add_parser('help')
        parser.add_argument('cmd', nargs='?', default='')
        parser.set_defaults(func=lambda kwargs: Serdes._cliHelp(self, **kwargs))

        parser = sub_parsers.add_parser('apb', help='SerDes APB registers')
        apb = parser.add_subparsers()
        parser = apb.add_parser('read', help='Read SerDes register')
        parser.add_argument('reg', type=str, help='Register name or address')
        parser.set_defaults(func=lambda kwargs: Serdes._cliApbRead(self, **kwargs))

        parser = apb.add_parser('write', help='Write SerDes register')
        parser.add_argument('reg', type=str, help='Register name or address')
        parser.add_argument('value', type=Serdes._hex_int, help='Value to write')
        parser.set_defaults(func=lambda kwargs: Serdes._cliApbWrite(self, **kwargs))

        parser = apb.add_parser('dump', help='Dump SerDes register')
        dump = parser.add_subparsers()
        parser = dump.add_parser('common', help='Dump all common SerDes registers')
        parser.set_defaults(func=lambda kwargs: Serdes._cliApbDumpCommon(self, **kwargs))

        parser = dump.add_parser('lane', help='Dump all lane SerDes registers')
        parser.set_defaults(func=lambda kwargs: Serdes._cliApbDumpLane(self, **kwargs))

        parser = dump.add_parser('ree', help='Dump all REE registers')
        parser.set_defaults(func=lambda kwargs: Serdes._cliApbDumpRee(self, **kwargs))

        parser = dump.add_parser('all', help='Dump all registers')
        parser.add_argument('--filename', '-f', type=str, help='Filename')
        parser.set_defaults(func=lambda kwargs: Serdes._cliApbDumpAll(self, **kwargs))

        parser = sub_parsers.add_parser('bist', help='Built-in Self Test')
        bist = parser.add_subparsers()
        parser = bist.add_parser('on', help='Enable BIST function')
        parser.set_defaults(func=lambda kwargs: Serdes._cliBistOn(self, **kwargs))

        parser = bist.add_parser('off', help='Disable BIST function')
        parser.set_defaults(func=lambda kwargs: Serdes._cliBistOff(self, **kwargs))

        parser = bist.add_parser('tx', help='BIST TX functions')
        bist_tx = parser.add_subparsers()
        parser = bist_tx.add_parser('start', help='Start TX pattern generator')
        parser.add_argument('--pattern', type=str.upper, choices=Serdes.PATTERNS)
        parser.set_defaults(func=lambda kwargs: Serdes._cliBistTxStart(self, **kwargs))

        parser = bist_tx.add_parser('stop', help='Stop TX pattern generator')
        parser.set_defaults(func=lambda kwargs: Serdes._cliBistTxStop(self, **kwargs))

        parser = bist_tx.add_parser('error', help='Inject error in the TX pattern generator')
        parser.set_defaults(func=lambda kwargs: Serdes._cliBistTxError(self, **kwargs))

        parser = bist.add_parser('rx', help='BIST RX functions')
        bist_rx = parser.add_subparsers()
        parser = bist_rx.add_parser('start', help='Start RX pattern checker')
        parser.add_argument('--pattern', type=str.upper, choices=Serdes.PATTERNS)
        parser.set_defaults(func=lambda kwargs: Serdes._cliBistRxStart(self, **kwargs))

        parser = bist_rx.add_parser('stop', help='Stop RX pattern checker')
        parser.set_defaults(func=lambda kwargs: Serdes._cliBistRxStop(self, **kwargs))

        parser = bist_rx.add_parser('reset', help='Reset RX error counter')
        parser.set_defaults(func=lambda kwargs: Serdes._cliBistRxReset(self, **kwargs))

        parser = bist.add_parser('status', help='BIST status')
        parser.set_defaults(func=lambda kwargs: Serdes._cliBistStatus(self, **kwargs))

        parser = bist.add_parser('regs', help='Read all BIST registers')
        parser.set_defaults(func=lambda kwargs: Serdes._cliBistRegs(self, **kwargs))

        parser = sub_parsers.add_parser('mdio', help='MDIO registers')
        mdio = parser.add_subparsers()
        parser = mdio.add_parser('read', help='Read from MDIO register')
        parser.add_argument('--addr', type=Serdes._hex_int, required=True, help='MDIO register address')
        parser.set_defaults(func=lambda kwargs: Serdes._cliMdioRead(self, **kwargs))

        parser = mdio.add_parser('write', help='Write to MDIO register')
        parser.add_argument('--addr', type=Serdes._hex_int, required=True, help='MDIO register address')
        parser.add_argument('--value', type=Serdes._hex_int, required=True, help='Value to write')
        parser.set_defaults(func=lambda kwargs: Serdes._cliMdioWrite(self, **kwargs))

        parser = mdio.add_parser('dump', help='Dump all MDIO registers')
        parser.set_defaults(func=lambda kwargs: Serdes._cliMdioDump(self, **kwargs))

        parser = sub_parsers.add_parser('phy', help='Physical layer functions')
        phy = parser.add_subparsers()

        parser = phy.add_parser('invert_tx', help='Set TX polarity')
        parser.add_argument('invert_tx', type=str, choices=('on', 'off'))
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyInvertTx(self, **kwargs))

        parser = phy.add_parser('invert_rx', help='Set RX polarity')
        parser.add_argument('invert_rx', type=str, choices=('on', 'off'))
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyInvertRx(self, **kwargs))

        parser = phy.add_parser('lpbk', help='Set loopback mode')
        parser.add_argument('--mode', choices=Serdes.LPBK_MODES, required=True)
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyLpbk(self, **kwargs))

        parser = phy.add_parser('rx_training', help='Enable RX training')
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyRxTraining(self, **kwargs))

        parser = phy.add_parser('on', help='Turn on phy')
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyOn(self, **kwargs))

        parser = phy.add_parser('off', help='Turn off phy')
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyOff(self, **kwargs))

        parser = phy.add_parser('reset', help='Toggle phy reset')
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyReset(self, **kwargs))

        parser = phy.add_parser('status', help='Show phy status')
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyStatus(self, **kwargs))

        parser = phy.add_parser('taps', help='TX Taps functions')
        taps = parser.add_subparsers()
        parser = taps.add_parser('init', help='Set TX INIT taps')
        parser.add_argument('--pre', type=Serdes._hex_int, required=True)
        parser.add_argument('--main', type=Serdes._hex_int, required=True)
        parser.add_argument('--post', type=Serdes._hex_int, required=True)
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyTapsInit(self, **kwargs))

        parser = taps.add_parser('set', help='Set TX taps override')
        parser.add_argument('--pre', type=Serdes._hex_int)
        parser.add_argument('--main', type=Serdes._hex_int)
        parser.add_argument('--post', type=Serdes._hex_int)
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyTapsSet(self, **kwargs))

        parser = taps.add_parser('get', help='Get TX taps')
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyTapsGet(self, **kwargs))

        parser = taps.add_parser('clear', help='Clear TX taps')
        parser.add_argument('--pre', action='store_true')
        parser.add_argument('--main', action='store_true')
        parser.add_argument('--post', action='store_true')
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyTapsClear(self, **kwargs))

        parser = phy.add_parser('attn', help='TX Taps functions')
        attn = parser.add_subparsers()
        parser = attn.add_parser('set')
        parser.add_argument('attn', type=int)
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyAttnSet(self, **kwargs))

        parser = attn.add_parser('get')
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyAttnGet(self, **kwargs))

        parser = sub_parsers.add_parser('link', help='Show link status')
        parser.set_defaults(func=lambda kwargs: Serdes._cliLinkStatus(self, **kwargs))

        parser = sub_parsers.add_parser('bathtub', help='The bathtub eye surf function')
        parser.add_argument('--cycles', type=Serdes._hex_int, default=0x2000, help='Number of test cycles')
        parser.add_argument('--delay', type=Serdes._hex_int, default=0x000f, help='Eye surf timer delay')
        parser.add_argument('--filename', '-f', type=str, default=None, help='Save the data to a file')
        parser.add_argument('--xrange', '-x', type=int, default=31, help='Range of x axis +/-N')
        parser.add_argument('--depth', '-d', type=int, default=31, help='Specify the bathtub depth')
        parser.add_argument('--peak', '-p', type=int, help='Specify the peak value')
        parser.set_defaults(func=lambda kwargs: Serdes._cliEyeSurfBathTub(self, **kwargs))

        parser = sub_parsers.add_parser('eyesurf', help='The full eye surf function')
        parser.add_argument('--cycles', type=Serdes._hex_int, default=0x2000, help='Number of test cycles')
        parser.add_argument('--delay', type=Serdes._hex_int, default=0x000f, help='Eye surf timer delay')
        parser.add_argument('--filename', '-f', type=str, default=None, help='Save the data to a file')
        parser.add_argument('--xyrange', '-r', type=int, default=31, help='Range of x and y axis +/-N')
        parser.add_argument('--peak', '-p', type=int, help='Specify the peak value')
        parser.set_defaults(func=lambda kwargs: Serdes._cliEyeSurfFull(self, **kwargs))

        parser = sub_parsers.add_parser('eyeplot', help='Plot eye diagram from the specified data file')
        parser.add_argument('filename', type=str, help='eye data file')
        parser.add_argument('--peak', '-p', type=int, default=1, help='Specify the peak value')
        parser.set_defaults(func=lambda kwargs: Serdes._cliEyePlot(self, **kwargs))

        self.sub_cmds = self.parser._subparsers._actions[-1].choices

        super(Serdes, self).__init__()

    @staticmethod
    def _bistPattern(speed, pattern):
        if pattern == '7' or pattern == 'PRBS7' or pattern is None:
            pattern = 0x0800 # PRBS7
            name = 'PRBS7'
        elif pattern == '15' or pattern == 'PRBS15':
            pattern = 0x0900 # PRBS15
            name = 'PRBS15'
        elif pattern == '23' or pattern == 'PRBS23':
            pattern = 0x0a00 # PRBS23
            name = 'PRBS23'
        elif pattern == '31' or pattern == 'PRBS31':
            pattern = 0x0b00 # PRBS31
            name = 'PRBS31'
        else:
            name = pattern
            pattern = Serdes.JITTER_PATTERNS.get(name)
            if pattern is not None:
                pattern = pattern[0] if speed == 1 else pattern[1]
        return (name, pattern)

    @staticmethod
    def _laneSpeed(lane):
        fields = pci.read_fields('MPIC{}_ENABLE'.format(lane))
        speed = 10 if fields['speed_mode_f'] == 1 else 1
        return speed

    @staticmethod
    def _pcsLink(lane):
        flds = pci.read_fields('MPIC{}_ENABLE'.format(lane))
        speed = Serdes._laneSpeed(lane)
        if speed == 10:
            pcs_link = flds['pcs_10g_block_lock_f']
        else:
            pcs_link = flds['pcs_1g_sync_status_f']
        return pcs_link

    @staticmethod
    def _linkFault(lane):
        fields = pci.read_fields('MPIC{}_RX_CONFIG'.format(lane))
        return fields['remote_fault_f'] or fields['local_fault_f']

    def _cliHelp(self, devport, lane, cmd=''):
        if cmd == '':
            self.parser.print_help()
            return ifcs_ctypes.IFCS_SUCCESS
        parser = self.parser._subparsers._actions[-1].choices.get(cmd)
        if parser is None:
            log_err('Unknown command: {}'.format(cmd))
            return ifcs_ctypes.IFCS_INVAL
        parser.print_help()
        return ifcs_ctypes.IFCS_SUCCESS

    def _getLanes(self, devport, lane, required=False):
        if devport is not None and lane is not None:
            raise CommandError('Specify either devport or lane number')
        if devport is None:
            if lane is None:
                raise CommandError('Please specify --devport or --lane option')
            if lane == 'all':
                if required:
                    raise CommandError('Please supply a specific devport or lane number')
                return compat_listrange(Serdes.NUM_LANES)
            if isinstance(lane, int):
                return [lane]
            try:
                lanes = lane.split(',')
                lanes = [int(l, 10) for l in lanes]
                return lanes
            except Exception as e:
                raise CommandError('Invalid lane specification {}'.format(lane))
        if devport == 'all':
            if required:
                raise CommandError('Please supply a specific devport or lane number')
            return compat_listrange(Serdes.NUM_LANES)
        if isinstance(devport, str):
            try:
                devports = devport.split(',')
                devports = [int(d, 10) for d in devports]
            except Exception as e:
                raise CommandError('Invalid devport specification {}'.format(devport))
        else:
            devports = [devport]
        lanes = []
        for devport in devports:
            count = ctypes.c_uint32()
            attrs = (ifcs_ctypes.ifcs_attr_t * 2)()
            attrs[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_TYPE
            attrs[1].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_START_LANE
            rc = ifcs_ctypes.ifcs_devport_attr_get(self.node_id, devport, len(attrs), compat_pointer(attrs, ifcs_ctypes.ifcs_attr_t), pointer(count))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                raise CommandError('Devport attr get failed on devport {}, rc={}'.format(devport, _status_to_string(rc)))
            assert attrs[0].bitmap.u32 == 1
            assert attrs[1].bitmap.u32 == 1
            if attrs[0].value.u32 != ifcs_ctypes.IFCS_DEVPORT_TYPE_AUX:
                raise CommandError('The specified devport {} is not an mgmt type'.format(devport))
            lanes.append(attrs[1].value.u32)
        return lanes

    def _cliApbRead(self, reg, devport, lane):
        lanes = self._getLanes(devport, lane)
        try:
            reg_addr = Serdes._hex_int(reg)
        except ValueError:
            reg_addr = self.torrent.get_addr(reg)

        if reg_addr is None:
            log_err('Unknown register : {}'.format(reg))
            return ifcs_ctypes.IFCS_SUCCESS

        reg_name = self.torrent.get_name(reg_addr)
        if self.torrent.is_cmn_addr(reg_addr):
            lanes = (0,)
        table = PrintTable()
        table.set_justification('left')
        row = ['Register']
        for lane in lanes:
            row.extend(('Lane {}'.format(lane), ''))
        table.add_row(row)
        row = [reg_name]
        for lane in lanes:
            _, addr, value = self.torrent.read(reg_addr, lane)
            row.extend(('{:04x}'.format(addr), '{:04x}'.format(value)))
        table.add_row(row)
        table.print_table()
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliApbWrite(self, reg, value, devport, lane):
        lanes = self._getLanes(devport, lane)
        try:
            reg_addr = Serdes._hex_int(reg)
        except ValueError:
            reg_addr = self.torrent.get_addr(reg)
        reg_name = self.torrent.get_name(reg_addr)
        if self.torrent.is_cmn_addr(reg_addr):
            lanes = (0,)
        table = PrintTable()
        table.set_justification('left')
        row = ['Register']
        for lane in lanes:
            row.extend(('Lane {}'.format(lane), ''))
        table.add_row(row)
        row = [reg_name]
        for lane in lanes:
            _, addr, value = self.torrent.write(reg_addr, value, lane)
            row.extend(('{:04x}'.format(addr), '{:04x}'.format(value)))
        table.add_row(row)
        table.print_table()
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliApbDumpCommon(self, devport, lane):
        table = PrintTable()
        table.set_justification('left')
        table.add_row(('Register', 'Address','Value'))
        for reg in SD0801.COMMON_REGS:
            _, addr, value = self.torrent.read_cmn(reg)
            table.add_row((reg, '{:04x}'.format(addr), '{:04x}'.format(value)))
        table.print_table()
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliApbDumpLane(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        table = PrintTable()
        table.set_justification('left')

        row = ['Register']
        for lane in lanes:
            row.extend(['Lane {}'.format(lane), 'Value'])
        table.add_row(row)

        for reg in SD0801.LANE_REGS:
            row = [reg]
            for lane in lanes:
                _, addr, value = self.torrent.read(reg, lane)
                row.extend(('{:04x}'.format(addr), '{:04x}'.format(value)))
            table.add_row(row)
        table.print_table()
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliApbDumpRee(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        table = PrintTable()
        table.set_justification('left')

        row = ['Register']
        for lane in lanes:
            row.extend(['Lane {}'.format(lane), 'Value'])
        table.add_row(row)

        for reg in SD0801.REE_REGS:
            row = [reg]
            for lane in lanes:
                _, addr, value = self.torrent.read(reg, lane)
                row.extend(('{:04x}'.format(addr), '{:04x}'.format(value)))
            table.add_row(row)
        table.print_table()
        return ifcs_ctypes.IFCS_SUCCESS

    def _dumpRegs(self, output, name, base, count):
        base_str = '{:016b}'.format(base)
        if (base & 0xc000) == 0xc000:
            base_str = base_str[0:2] + '_' + base_str[2] + '_' + base_str[3] + '_' + base_str[4:8]
        else:
            base_str = base_str[0:2] + '_' + base_str[2] + '_' + base_str[3:7]
        if isinstance(output, PrintTable):
            output.add_row((name, '0x{:04x}'.format(base), '', base_str))
        else:
            output.write('{}: 0x{:04x} - {}\n'.format(name, base, base_str))
        for idx in range(count):
            addr = base + idx
            name, _, data = self.torrent.read(addr, 0)
            if name == "":
                name = "*"
            binstr = "{:016b}".format(data)
            binstr = '_'.join([binstr[i:i+4] for i in range(0, len(binstr), 4)])
            if isinstance(output, PrintTable):
                output.add_row(('0x{:04x}'.format(addr), '0x{:04x}'.format(data), '0b{}'.format(binstr), name))
            else:
                output.write('0x{:04x}: 0x{:04x} - 0b{} {}\n'.format(addr, data, binstr, name))

    def _cliApbDumpAll(self, devport, lane, filename):
        if filename is None:
            output = PrintTable()
            output.set_justification('left')
        else:
            log('Dumping SerDes registers to file:', filename)
            output = open(filename, "wt")
        self._dumpRegs(output, 'Common',         0x0000, 0x200)
        self._dumpRegs(output, 'Tx Lane 0',      0x4000, 0x200)
        self._dumpRegs(output, 'RX Lane 0',      0x8000, 0x200)
        self._dumpRegs(output, 'Common PHY PCS', 0xc000, 0x100)
        self._dumpRegs(output, 'Lane PHY PCS',   0xd000, 0x100)
        self._dumpRegs(output, 'Common PHY PMA', 0xe000, 0x100)
        self._dumpRegs(output, 'Lane PHY PMA',   0xf000, 0x100)
        if isinstance(output, PrintTable):
            output.print_table()
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliBistOn(self, devport, lane):
        self.torrent.enable_power_island_overide()
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliBistOff(self, devport, lane):
        bist_active = False
        # Make sure BIST Tx and Rx are disable
        for lane in range(Serdes.NUM_LANES):
            _, _, value = self.torrent.read('TX_BIST_CTRL', lane)
            if value & 0x001:
                log('Lane {}: bist tx is active'.format(lane))
                bist_active = True

            _, _, value = self.torrent.read('RX_BIST_CTRL', lane)
            if value & 0x001:
                log('Lane {}: bist rx is active'.format(lane))
                bist_active = True

        if bist_active:
            return

        self.torrent.disable_power_island_overide()
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliBistTxStart(self, pattern, devport, lane):
        lanes = self._getLanes(devport, lane)
        _, _, value = self.torrent.read('CMN_CDIAG_DIAG_PWRI_OVRD')
        if (value & 0x8200) != 0x8200:
            log('Please run bist on first')
            return
        for lane in lanes:
            (pattern_name, pattern_value) = self._bistPattern(self._laneSpeed(lane), pattern)
            _, _, value = self.torrent.read('TX_BIST_CTRL', lane)
            value &= 0xffff - 0x0f01
            self.torrent.write('TX_BIST_CTRL', value, lane)
            if pattern_name.startswith('PRBS'):
                value |= pattern_value
            else:
                self.torrent.write('TX_BIST_CTRL', value | 0x0002, lane)
                for user in pattern_value:
                    self.torrent.write('TX_BIST_UDDWR', user, lane)
            value |= 0x0001
            self.torrent.write('TX_BIST_CTRL', value, lane)
            self.tx_pattern[lane] = pattern_name
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliBistTxStop(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            #12: Disable the transmitter BIST
            _, _, value = self.torrent.read('TX_BIST_CTRL', lane)
            value &= 0xffff - 0x0001
            self.torrent.write('TX_BIST_CTRL', value, lane)
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliBistTxError(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            _, _, value = self.torrent.read('TX_BIST_CTRL', lane)
            if not (value & 0x0001):
                continue
            # Toggle force error
            self.torrent.write('TX_BIST_CTRL', value | 0x0010, lane)
            self.torrent.write('TX_BIST_CTRL', value & (0xffff - 0x0010), lane)
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliBistRxStart(self, pattern, devport, lane):
        lanes = self._getLanes(devport, lane)
        _, _, value = self.torrent.read('CMN_CDIAG_DIAG_PWRI_OVRD')
        if (value & 0x8200) != 0x8200:
            log('Please run bist on first')
            return
        for lane in lanes:
            (pattern_name, pattern_value) = self._bistPattern(self._laneSpeed(lane), pattern)
            # Set the BIST receiver sync count to 250
            self.torrent.write('RX_BIST_SYNCCNT', 0x00fa, lane)
            #4: Select rx data pattern
            _, _, value = self.torrent.read('RX_BIST_CTRL', lane)
            value &= 0xffff - 0x0f00
            if pattern_name.startswith('PRBS'):
                value |= pattern_value
            else:
                # Receiver BIST user defined data FIFO clear
                self.torrent.write('RX_BIST_CTRL', value | 0x0002, lane)
                for user in pattern_value:
                    self.torrent.write('RX_BIST_UDDWR', user, lane)
            value |= 0x0001
            self.torrent.write('RX_BIST_CTRL', value, lane)
            self.rx_pattern[lane] = pattern_name
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliBistRxStop(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            #13: Receiver BIST error reset
            _, _, value = self.torrent.read('RX_BIST_CTRL', lane)
            value |= 0x0010
            self.torrent.write('RX_BIST_CTRL', value, lane)
            #11: Disable the receiver BIST
            value &= 0xffff - 0x0001
            self.torrent.write('RX_BIST_CTRL', value, lane)
            # Clear Receiver BIST error reset
            value &= 0xffff - 0x0010
            self.torrent.write('RX_BIST_CTRL', value, lane)
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliBistRxReset(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            _, _, value = self.torrent.read('RX_BIST_CTRL', lane)
            value |= 0x0010
            self.torrent.write('RX_BIST_CTRL', value, lane)
            value &= 0xffff - 0x0010
            self.torrent.write('RX_BIST_CTRL', value, lane)
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliBistStatus(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        header_row = ['']
        tx_row = ['TX']
        tx_invert_row = ['Invert TX']
        rx_row = ['RX']
        rx_invert_row = ['Invert RX']
        sync_row = ['Pattern sync']
        err_row = ['Error counter']
        for lane in lanes:
            header_row.append('Lane {}'.format(lane))
            _, _, value = self.torrent.read('TX_BIST_CTRL', lane)
            if value & 0x0001:
                if self.tx_pattern[lane] is None:
                    tx_row.append(SD0801.getPatternName(value))
                else:
                    tx_row.append(self.tx_pattern[lane])
            else:
                tx_row.append('off')

            _, _, value = self.torrent.read('RX_BIST_CTRL', lane)
            if value & 0x0001:
                if self.rx_pattern[lane] is None:
                    rx_row.append(SD0801.getPatternName(value))
                else:
                    rx_row.append(self.rx_pattern[lane])
            else:
                rx_row.append('off')

            _, _, value = self.torrent.read('PHY_PMA_XCVR_CTRL', lane)
            sync_row.extend(('yes' if value & 0x0002 else 'no',))
            tx_invert_row.append('on' if value & 0x0100 else 'off')
            rx_invert_row.append('on' if value & 0x0001 else 'off')

            _, _, value = self.torrent.read('RX_BIST_ERRCNT', lane)
            err_row.append(value)

        table = PrintTable()
        table.set_justification('left')
        table.add_row(header_row)
        table.add_row(tx_row)
        table.add_row(rx_row)
        table.add_row(tx_invert_row)
        table.add_row(rx_invert_row)
        table.add_row(sync_row)
        table.add_row(err_row)
        table.print_table()

        for lane in lanes:
            self._cliBistRxReset(devport=None, lane=lane)

        for lane in lanes:
            fields = pci.read_fields('PMA_RX_CNFG_LN{}'.format(lane))
            if fields['eq_training_data_valid_f']:
                pci.write_fields('PMA_RX_CNFG_LN{}'.format(lane), eq_training_data_valid_f=0)
                log('Lane {}: RX training disabled'.format(lane))

        return ifcs_ctypes.IFCS_SUCCESS

    def _cliBistRegs(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        table = PrintTable()
        table.set_justification('left')

        row = ['Register']
        for lane in lanes:
            row.extend(('Lane {}'.format(lane), 'Value'))
        table.add_row(row)

        regs = ('CMN_CDIAG_DIAG_PWRI_OVRD',)
        for reg in regs:
            row = [reg]
            for lane in lanes:
                if lane == 0:
                    _, addr, value = self.torrent.read(reg)
                    row.extend(('{:04x}'.format(addr), '{:04x}'.format(value)))
                else:
                    row.extend(('', ''))
            table.add_row(row)

        for reg in SD0801.BIST_REGS:
            row = [reg]
            for lane in lanes:
                _, addr, value = self.torrent.read(reg, lane)
                row.extend(('{:04x}'.format(addr), '{:04x}'.format(value)))
            table.add_row(row)

        for reg in ('PHY_PMA_XCVR_CTRL',):
            row = [reg]
            for lane in lanes:
                _, addr, value = self.torrent.read(reg, lane)
                row.extend(('{:04x}'.format(addr), '{:04x}'.format(value)))
            table.add_row(row)

        table.print_table()
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliMdioRead(self, addr, devport, lane):
        lanes = self._getLanes(devport, lane, required=True)
        table = PrintTable()
        table.set_justification('left')
        table.add_row(('Address', 'Description', 'Value'))

        value = SD0801.mdioRead(addr, lanes[0])
        desc = PCS.getDesc(addr, Serdes._laneSpeed(lanes[0]))
        table.add_row(('{:04x}'.format(addr), desc, '{:04x}'.format(value)))

        table.print_table()
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliMdioWrite(self, addr, value, devport, lane):
        lanes = self._getLanes(devport, lane, required=True)
        SD0801.mdioWrite(addr, value, lanes[0])
        self._cliMdioRead(addr, lanes[0])
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliMdioDump(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        table = PrintTable()
        table.set_justification('left')
        row = ['Address', 'Description']
        row.extend(('Lane {}'.format(lane) for lane in lanes))
        table.add_row(row)

        for addr, desc in PCS.MDIO_COMMON_REGS.items():
            row = ['{:04x}'.format(addr), desc]
            for lane in lanes:
                value = SD0801.mdioRead(addr, lane)
                row.append('{:04x}'.format(value))
            table.add_row(row)

        speed = Serdes._laneSpeed(lane)
        for addr, desc in PCS.MDIO_10G_REGS.items() if speed == 10 else PCS.MDIO_1G_REGS.items():
            row = ['{:04x}'.format(addr), desc]
            for lane in lanes:
                value = SD0801.mdioRead(addr, lane)
                row.append('{:04x}'.format(value))
            table.add_row(row)
        table.print_table()
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliPhyInvertRx(self, invert_rx, devport, lane):
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            phy_lane_reset_n = pci.read_fields('PHY_LANE_CTRL')['phy_l{:02}_reset_n_f'.format(lane)]
            if phy_lane_reset_n:
                pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 0})
            _, _, value = self.torrent.read('PHY_PMA_XCVR_CTRL', lane)
            if invert_rx == 'on':
                value |= 0x0001
            else:
                value &= 0xffff - 0x0001
            self.torrent.write('PHY_PMA_XCVR_CTRL', value, lane)
            if phy_lane_reset_n:
                pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 1})
            log('Lane {}: invert_rx={}'.format(lane, invert_rx))
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliPhyInvertTx(self, invert_tx, devport, lane):
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            phy_lane_reset_n = pci.read_fields('PHY_LANE_CTRL')['phy_l{:02}_reset_n_f'.format(lane)]
            if phy_lane_reset_n:
                pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 0})
            _, _, value = self.torrent.read('PHY_PMA_XCVR_CTRL', lane)
            if invert_tx == 'on':
                value |= 0x0100
            else:
                value &= 0xffff - 0x0100
            self.torrent.write('PHY_PMA_XCVR_CTRL', value, lane)
            if phy_lane_reset_n:
                pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 1})
            log('Lane {}: invert_tx={}'.format(lane, invert_tx))
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliPhyLpbk(self, mode, devport, lane):
        lanes = self._getLanes(devport, lane)
        if mode == 'none':
            mode = None
        for lane in lanes:
            _, _, value = self.torrent.read('PHY_PMA_XCVR_LPBK', lane)
            value &= 0xffff - 0x003f
            if mode is not None:
                value |= 0x0001 << (Serdes.LPBK_MODES.index(mode) - 1)
            self.torrent.write('PHY_PMA_XCVR_LPBK', value, lane)
            phy_lane_reset_n = pci.read_fields('PHY_LANE_CTRL')['phy_l{:02}_reset_n_f'.format(lane)]
            if phy_lane_reset_n:
                pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 0})
                time.sleep(1/1000000)
                pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 1})
            log('Lane {}: loopback={}'.format(lane, mode))
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliPhyRxTraining(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            pci.write_fields('PMA_RX_CNFG_LN{}'.format(lane), eq_training_data_valid_f = 1)
            log('Lane {}: RX training enabled'.format(lane))
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliPhyOn(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 1})
            log('Lane {}: SerDes on'.format(lane))
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliPhyOff(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 0})
            log('Lane {}: SerDes off'.format(lane))
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliPhyReset(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            phy_lane_reset_n = pci.read_fields('PHY_LANE_CTRL')['phy_l{:02}_reset_n_f'.format(lane)]
            if phy_lane_reset_n:
                pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 0})
                time.sleep(1/1000000)
                pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 1})
            log('Lane {}: SerDes reset'.format(lane))
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliPhyStatus(self, devport, lane):
        enabled_row = ['Enabled']
        speed_row = ['Speed']
        signal_detect_row = ['Signal Detect']
        pcs_link_row = ['PCS Link']
        loopback_row = ['Loopback']
        tx_invert_row = ['Invert TX']
        rx_invert_row = ['Invert RX']

        for lane in range(Serdes.NUM_LANES):
            speed_row.append('{}G'.format(Serdes._laneSpeed(lane)))

            flds = pci.read_fields('PHY_LANE_CTRL')
            enabled_row.append('yes' if flds['phy_l{:02}_reset_n_f'.format(lane)] else 'no')
            signal_detect_row.append('yes' if flds['pma_rx_signal_detect_ln_{}_f'.format(lane)] else 'no')

            pcs_link = Serdes._pcsLink(lane)
            pcs_link_row.append('up' if pcs_link else 'down')

            _, _, value = self.torrent.read('PHY_PMA_XCVR_LPBK', lane)
            if value & 0x0001:
                loopback = 'serial'
            elif value & 0x0002:
                loopback = 'isi'
            elif value & 0x0004:
                loopback = 'line'
            elif value & 0x0008:
                loopback = 'recovered clock'
            elif value & 0x0010:
                loopback = 'ne parallel'
            elif value & 0x0020:
                loopback = 'fe parallel'
            else:
                loopback = 'none'
            loopback_row.append(loopback)

            _, _, value = self.torrent.read('PHY_PMA_XCVR_CTRL', lane)
            tx_invert_row.append('on' if value & 0x0100 else 'off')
            rx_invert_row.append('on' if value & 0x0001 else 'off')

        table = PrintTable()
        table.set_justification('left')
        table.add_row(('', 'Lane 0', 'Lane 1'))
        table.add_row(speed_row)
        table.add_row(enabled_row)
        table.add_row(signal_detect_row)
        table.add_row(pcs_link_row)
        table.add_row(loopback_row)
        table.add_row(tx_invert_row)
        table.add_row(rx_invert_row)
        table.print_table()
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliPhyTapsInit(self, pre, main, post, devport, lane):
        lanes = self._getLanes(devport, lane)

        ipre = ((main & 0x3f) << 8) + (pre & 0x3f)
        ipost = (post & 0x3f)

        _, _, value = self.torrent.read('CMN_DIAG_SH_RESISTOR')
        tx_res_cal = (value >> 8) & 0x3f
        total_taps = abs(main) + abs(pre) + abs(post)
        if total_taps > tx_res_cal:
            log_err('The total taps {} must be less or equal to tx_res_cal {}'.format(total_taps, tx_res_cal))
            return

        for lane in lanes:
            self.torrent.write('TX_TXCC_IPRE_COEF_VALUE', ipre, lane)
            self.torrent.write('TX_TXCC_IPOST_COEF_VALUE', ipost, lane)
            phy_lane_reset_n = pci.read_fields('PHY_LANE_CTRL')['phy_l{:02}_reset_n_f'.format(lane)]
            if phy_lane_reset_n:
                pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 0})
                time.sleep(1/1000000)
                pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 1})
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliPhyTapsSet(self, pre, main, post, devport, lane):
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            if pre is not None:
                _, _, value = self.torrent.read('TX_TXCC_PRE_OVRD', lane)
                value &= 0xffff - 0x003f
                value |= 0x0100 | (pre & 0x003f)
                self.torrent.write('TX_TXCC_PRE_OVRD', value, lane)

            if main is not None:
                _, _, value = self.torrent.read('TX_TXCC_MAIN_OVRD', lane)
                value &= 0xffff - 0x003f
                value |= 0x0100 | (main & 0x003f)
                self.torrent.write('TX_TXCC_MAIN_OVRD', value, lane)

            if post is not None:
                _, _, value = self.torrent.read('TX_TXCC_POST_OVRD', lane)
                value &= 0xffff - 0x003f
                value |= 0x0100 | (post & 0x003f)
                self.torrent.write('TX_TXCC_POST_OVRD', value, lane)
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliPhyTapsClear(self, pre, main, post, devport, lane):
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            if pre:
                _, _, value = self.torrent.read('TX_TXCC_PRE_OVRD', lane)
                value &= 0xffff - 0x013f
                self.torrent.write('TX_TXCC_PRE_OVRD', value, lane)

            if main:
                _, _, value = self.torrent.read('TX_TXCC_MAIN_OVRD', lane)
                value &= 0xffff - 0x013f
                self.torrent.write('TX_TXCC_MAIN_OVRD', value, lane)

            if post:
                _, _, value = self.torrent.read('TX_TXCC_POST_OVRD', lane)
                value &= 0xffff - 0x013f
                self.torrent.write('TX_TXCC_POST_OVRD', value, lane)
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliPhyTapsGet(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        table = PrintTable()
        table.set_justification('left')

        row = ['Register']
        for lane in lanes:
            row.extend(['Lane {}'.format(lane), 'Value'])
        table.add_row(row)

        regs = ('CMN_DIAG_SH_RESISTOR',)
        for reg in regs:
            row = [reg]
            for lane in range(Serdes.NUM_LANES):
                if lane == 0:
                    _, addr, value = self.torrent.read(reg)
                    row.extend(('{:04x}'.format(addr), '{:04x}'.format(value)))
                else:
                    row.extend(('', ''))
            table.add_row(row)

        regs =  ('TX_TXCC_IPRE_COEF_VALUE', 'TX_TXCC_IPOST_COEF_VALUE',
                 'TX_TXCC_PRE_OVRD', 'TX_TXCC_MAIN_OVRD', 'TX_TXCC_POST_OVRD',
                 'TX_TXCC_PRE_CVAL', 'TX_TXCC_MAIN_CVAL', 'TX_TXCC_POST_CVAL',
                 'TX_TXCC_MGNFS_MULT_000','TX_TXCC_MGNFS_MULT_001',
                 'TX_TXCC_MGNFS_MULT_010', 'TX_TXCC_MGNFS_MULT_011',
                 'TX_TXCC_MGNFS_MULT_100', 'TX_TXCC_MGNFS_MULT_101',
                 'TX_TXCC_MGNFS_MULT_110', 'TX_TXCC_MGNFS_MULT_111')
        for reg in regs:
            row = [reg]
            for lane in lanes:
                _, addr, value = self.torrent.read(reg, lane)
                row.extend(('{:04x}'.format(addr), '{:04x}'.format(value)))
            table.add_row(row)

        table.print_table()
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliPhyAttnSet(self, attn, devport, lane):
        if attn > 7:
            log_err("The largest allowed value is 7")
            return
        if attn < 0:
            log_err("The lowest allowed value is 0")
            return
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            pci.write_fields('PMA_TX_CNFG_LN{}'.format(lane), vmargin_f=attn)
            flds = pci.read_fields('PMA_TX_CNFG_LN{}'.format(lane))
            vmargin = flds['vmargin_f']
            _, _, value = self.torrent.read('TX_TXCC_MGNFS_MULT_{:03b}'.format(vmargin), lane)
            log('Lane {}: Attenuation: vmargin={}, multiplier={}/128'.format(lane, vmargin, value))
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliPhyAttnGet(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            flds = pci.read_fields('PMA_TX_CNFG_LN{}'.format(lane))
            vmargin = flds['vmargin_f']
            _, _, value = self.torrent.read('TX_TXCC_MGNFS_MULT_{:03b}'.format(vmargin), lane)
            log('Lane {}: Attenuation: vmargin={}, multiplier={}/128'.format(lane, vmargin, value))
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliLinkStatus(self, devport, lane):
        table = PrintTable()
        table.set_justification('left')
        table.add_row(('', 'Lane 0', 'Lane 1'))

        fields = pci.read_fields('PHY_LANE_CTRL')
        table.add_row(('PHY_LANE_CTRL', '', ''))
        table.add_row(('phy_cmn_reset_n', fields['phy_cmn_reset_n_f'], ''))
        table.add_row(('phy_lane_reset_n', fields['phy_l00_reset_n_f'], fields['phy_l01_reset_n_f']))
        table.add_row(('pma_rx_signal_detect', fields['pma_rx_signal_detect_ln_0_f'], fields['pma_rx_signal_detect_ln_1_f']))
        table.add_row(('','',''))

        reg = 'MPIC{}_ENABLE'
        values = []
        for lane in range(Serdes.NUM_LANES):
            values.append(pci.read_fields(reg.format(lane)))

        table.add_row((reg.format('n'), '', ''))
        fields = ('pcs_10g_loopback_input', 'pcs_10g_scr_loopbk_en', 'pcs_10g_block_lock', 'pcs_10g_scr_loopbk_en')
        for field in fields:
            row = [field]
            for lane in range(Serdes.NUM_LANES):
                row.append(values[lane]['{}_f'.format(field)])
            table.add_row(row)
        table.add_row(('','',''))

        reg = 'MPIC{}_RX_CONFIG'
        values = []
        for lane in range(Serdes.NUM_LANES):
            values.append(pci.read_fields(reg.format(lane)))

        table.add_row((reg.format('n'), '', ''))
        fields = ('remote_fault', 'local_fault',)
        for field in fields:
            row = [field]
            for lane in range(Serdes.NUM_LANES):
                row.append(values[lane]['{}_f'.format(field)])
            table.add_row(row)

        table.print_table()
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliEyeSurfBathTub(self, devport, lane, cycles, delay, filename, xrange, depth, peak):
        lanes = self._getLanes(devport, lane)

        for lane in lanes:
            log('Reading eye surf data lane {}'.format(lane))
            if not self.torrent.is_eyesurf_enabled(lane):
                self.torrent.eyesurf_enable(lane)

            eye_data = self.torrent.bathtub(cycles, delay, xrange, depth, lane)
            if filename is not None:
                self._eyesurf_save("{}-{}.tub".format(filename, lane), eye_data)

            eye_surf = torrent.EyeSurf(eye_data, peak, is_full=False)
            eye_surf.plot()

        return ifcs_ctypes.IFCS_SUCCESS

    def _cliEyeSurfFull(self, devport, lane, cycles, delay, filename, xyrange, peak):
        lanes = self._getLanes(devport, lane)

        for lane in lanes:
            log('Reading eye surf data lane {}'.format(lane))
            if not self.torrent.is_eyesurf_enabled(lane):
                self.torrent.eyesurf_enable(lane)

            eye_data = self.torrent.eyesurf(cycles, delay, xyrange, lane)
            if filename is not None:
                self._eyesurf_save("{}-{}.eye".format(filename, lane), eye_data)

            eye_surf = torrent.EyeSurf(eye_data, peak, is_full=True)
            eye_surf.plot()

        return ifcs_ctypes.IFCS_SUCCESS

    def _cliEyePlot(self, devport, lane, filename, peak):
        eye_data = []
        with open(filename, 'r') as file:
            for line in file:
                eye_row = [int(v) for v in line.split(',')]
                eye_data.append(eye_row)
        eye_surf = self.torrent.EyeSurf(eye_data, peak, is_full=filename.endswith('.eye'))
        eye_surf.plot()
        return ifcs_ctypes.IFCS_SUCCESS

    @staticmethod
    def _eyesurf_save(filename, eye_data):
        log('Writing to file {}'.format(filename))
        try:
            with open(filename, 'w') as output:
                for row in eye_data:
                    output.write(",".join(str(value) for value in row))
                    output.write("\n")
        except IOError as err:
            log_err('Failed to write file {}: {}'.format(filename, err))

serdes_instances = {}

def run_cmd(node_id, args_list):
    try:
        serdes = serdes_instances.get(node_id)
        if serdes is None:
            serdes = Serdes(node_id)
            serdes_instances[node_id] = serdes
        args = serdes.parser.parse_args(args_list)
        if not hasattr(args, 'func'):
            args_list.append('--help')
            args = serdes.parser.parse_args(args_list)
            return ifcs_ctypes.IFCS_INVAL
        cmd_func = args.func
        kwargs = vars(args)
        kwargs.pop('func')
        log_dbg(1, 'args: {}'.format(kwargs))
        return cmd_func(kwargs)
    except CommandError as cmd_err:
        log_err('{}'.format(cmd_err))
        return cmd_err.rc
    except Exception as ex:
        log_err(str(ex))
        log(traceback.format_exc())
    return ifcs_ctypes.IFCS_INVAL
