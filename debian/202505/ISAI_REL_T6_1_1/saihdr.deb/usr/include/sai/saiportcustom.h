/**
 *copyright (c) 2024 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 *    @file    saiportcustom.h
 *
 * @brief   This module defines custom of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAIPORTCUSTOM_H_
#define __SAIPORTCUSTOM_H_

#include <saiport.h>
#include <saitypes.h>


/**
 * @brief SAI port custom attribute
 */
typedef enum _sai_port_attr_custom_t
{
    /**
     * @brief Update dot1p of outgoing packets
     *
     * Enabling this on an ingress port to mark the dot1p at the outgoing
     * port with the respective SAI_PORT_ATTR_QOS_TC_AND_COLOR_TO_DOT1P_MAP
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default true
     */
    SAI_PORT_ATTR_CUSTOM_UPDATE_DOT1P = SAI_PORT_ATTR_CUSTOM_RANGE_START + 1,

    /**
     * @brief Estimate of the one-way (From port to neighbor) link propagation
     *        delay in nanoseconds.
     *
     * This shall be added to PTP header correction-field along with resident time in Peer Delay Mechanism.
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default = (0)
     * @validonly SAI_SWITCH_ATTR_CUSTOM_PTP_CLOCK_TYPE == SAI_SWITCH_PTP_CLOCK_TYPE_TRANSPARENT_P2P
     */
    SAI_PORT_ATTR_CUSTOM_PTP_PEER_MEAN_PATH_DELAY,

    /**
     * @brief Per lane PRBS Lock Status
     *
     * Per Lane list of lock status for PRBS. The values are a list of
     * boolean where count is the number of lanes in the port and list
     * specifies list of values which are lane specific
     *
     * @type sai_uint8_list_t
     * @flags READ_ONLY
     */
    SAI_PORT_ATTR_CUSTOM_PRBS_LOCK_STATUS_PER_LANE,
    /**
     * @brief Per lane PRBS Rx Status
     *
     * Per Lane list of status for PRBS. The values are a list of enum
     * sai_port_prbs_rx_status_t where count is the number of lanes in the
     * port and list specifies list of values which are lane specific
     *
     * @type sai_uint32_list_t sai_port_prbs_rx_status_t
     * @flags READ_ONLY
     */
    SAI_PORT_ATTR_CUSTOM_PRBS_RX_STATUS_PER_LANE,
    /**
     * @brief Per lane PRBS Rx State
     *
     * Per Lane list of state for PRBS. The values are a list of
     * sai_port_prbs_rx_state_t where count is the number of lanes in the  
     * port and list specifies list of values which are lane specific    
     *
     * @type sai_port_prbs_rx_state_list_t$
     * @flags READ_ONLY
     */
    SAI_PORT_ATTR_CUSTOM_PRBS_RX_STATE_PER_LANE,

}sai_port_attr_custom_t;


/**
 * @brief SAI port stat custom
 */
typedef enum _sai_port_stat_custom_t
{
    /** Port stats custom user discards (eg. per-TC BUM flood control drops) */
    SAI_PORT_STAT_CUSTOM_IN_USER_DROPPED_PACKETS = SAI_PORT_STAT_CUSTOM_RANGE_BASE,

    /** Custom Port stat ether stats TX packets */
    SAI_PORT_STAT_CUSTOM_IF_OUT_PKTS,

    /** Custom port stat to get port occupancy/utilization percentage */
    SAI_PORT_STAT_CUSTOM_OUT_CURR_OCCUPANCY_LEVEL,


    /** Per Lane PRBS Error Count */
    /** Prbs Error Count For Lane 1*/
    SAI_PORT_STAT_CUSTOM_PRBS_ERROR_COUNT_LANE_0,

    /** Prbs Error Count For Lane 2*/
    SAI_PORT_STAT_CUSTOM_PRBS_ERROR_COUNT_LANE_1,

    /** Prbs Error Count For Lane 3*/
    SAI_PORT_STAT_CUSTOM_PRBS_ERROR_COUNT_LANE_2,

    /** Prbs Error Count For Lane 4*/
    SAI_PORT_STAT_CUSTOM_PRBS_ERROR_COUNT_LANE_3,

    /** Prbs Error Count For Lane 5*/
    SAI_PORT_STAT_CUSTOM_PRBS_ERROR_COUNT_LANE_4,

    /** Prbs Error Count For Lane 6*/
    SAI_PORT_STAT_CUSTOM_PRBS_ERROR_COUNT_LANE_5,

    /** Prbs Error Count For Lane 7*/
    SAI_PORT_STAT_CUSTOM_PRBS_ERROR_COUNT_LANE_6,

    /** Prbs Error Count For Lane 8*/
    SAI_PORT_STAT_CUSTOM_PRBS_ERROR_COUNT_LANE_7,

    /** Per Lane PRBS Bit Error Rate in 1E-18 */
    /** Prbs BER For Lane 1*/
    SAI_PORT_STAT_CUSTOM_PRBS_BER_LANE_0,

    /** Prbs BER For Lane 2*/
    SAI_PORT_STAT_CUSTOM_PRBS_BER_LANE_1,

    /** Prbs BER For Lane 3*/
    SAI_PORT_STAT_CUSTOM_PRBS_BER_LANE_2,

    /** Prbs BER For Lane 4*/
    SAI_PORT_STAT_CUSTOM_PRBS_BER_LANE_3,

    /** Prbs BER For Lane 5*/
    SAI_PORT_STAT_CUSTOM_PRBS_BER_LANE_4,

    /** Prbs BER For Lane 6*/
    SAI_PORT_STAT_CUSTOM_PRBS_BER_LANE_5,

    /** Prbs BER For Lane 7*/
    SAI_PORT_STAT_CUSTOM_PRBS_BER_LANE_6,

    /** Prbs BER For Lane 8*/
    SAI_PORT_STAT_CUSTOM_PRBS_BER_LANE_7,


    /** Port stat custom range end */
    SAI_PORT_STAT_CUSTOM_RANGE_END

}sai_port_stat_custom_t;

#endif /* __SAIPORTCUSTOM_H_ */
