/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2025) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_shim_switch.c
 * @brief This file provides aliasing to the SAI attribute/stats/types which contributed to SAI
 *        open source community from Marvell, but before maintained as custom. 
 */


#define SAI_SWITCH_CUSTOM_ATTR_ECMP_HASH_IPV4_RDMA     SAI_SWITCH_ATTR_ECMP_HASH_IPV4_RDMA
#define SAI_SWITCH_CUSTOM_ATTR_ECMP_HASH_IPV6_RDMA     SAI_SWITCH_ATTR_ECMP_HASH_IPV4_RDMA 
#define SAI_SWITCH_CUSTOM_ATTR_LAG_HASH_IPV4_RDMA      SAI_SWITCH_ATTR_LAG_HASH_IPV4_RDMA
#define SAI_SWITCH_CUSTOM_ATTR_LAG_HASH_IPV6_RDMA      SAI_SWITCH_ATTR_LAG_HASH_IPV6_RDMA
#define SAI_NATIVE_CUSTOM_HASH_FIELD_RDMA_BTH_OPCODE   SAI_NATIVE_HASH_FIELD_RDMA_BTH_OPCODE
#define SAI_NATIVE_CUSTOM_HASH_FIELD_RDMA_BTH_DEST_QP  SAI_NATIVE_HASH_FIELD_RDMA_BTH_DEST_QP

#define SAI_LAG_MEMBER_ATTR_CUSTOM_WEIGHT SAI_LAG_MEMBER_ATTR_WEIGHT

#define SAI_MIRROR_SESSION_ATTR_CUSTOM_GRE_FLAGS_VER_RSVD                         SAI_MIRROR_SESSION_ATTR_GRE_HEADER_FIRST_16BIT
#define SAI_MIRROR_SESSION_ATTR_CUSTOM_ERSPAN_SESSION_ID                          SAI_MIRROR_SESSION_ATTR_ERSPAN_SESSION_ID
#define SAI_ERSPAN_ENCAPSULATION_TYPE_CUSTOM_MIRROR_L3_GRE_TUNNEL_ERSPAN_TYPE_II  SAI_ERSPAN_ENCAPSULATION_TYPE_II
#define SAI_ERSPAN_ENCAPSULATION_TYPE_CUSTOM_MIRROR_L3_GRE_TUNNEL_ERSPAN_TYPE_III SAI_ERSPAN_ENCAPSULATION_TYPE_III

#define SAI_TAM_COLLECTOR_ATTR_CUSTOM_SRC_MAC      SAI_TAM_COLLECTOR_ATTR_SRC_MAC
#define SAI_TAM_COLLECTOR_ATTR_CUSTOM_DST_MAC      SAI_TAM_COLLECTOR_ATTR_DST_MAC
#define SAI_TAM_COLLECTOR_ATTR_CUSTOM_DESTINATION  SAI_TAM_COLLECTOR_ATTR_DESTINATION
#define SAI_TAM_TRANSPORT_TYPE_CUSTOM_GRE          SAI_TAM_TRANSPORT_TYPE_GRE
