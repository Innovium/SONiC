/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License
 *Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */
/**
 * @file  ifcs_sai_switch.h
 * @brief ISAI IM Include file for SWITCH module
 */

#ifndef __IFCS_SAI_SWITCH_H__
#define __IFCS_SAI_SWITCH_H__

#define ISAI_MODULE_LOCK_SWITCH 1ULL

#include "ifcs_sai_acl.h"
#include "ifcs_sai_ars.h"
#include "ifcs_sai_arsprofile.h"
#include "ifcs_sai_bridge.h"
#include "ifcs_sai_buffer.h"
#include "ifcs_sai_counter.h"
#include "ifcs_sai_debug_counter.h"
#include "ifcs_sai_fdb.h"
#include "ifcs_sai_hash.h"
#include "ifcs_sai_hostif.h"
#include "ifcs_sai_isolation_group.h"
#include "ifcs_sai_l2mc.h"
#include "ifcs_sai_l2mc_group.h"
#include "ifcs_sai_lag.h"
#include "ifcs_sai_mirror.h"
#include "ifcs_sai_my_mac.h"
#include "ifcs_sai_neighbor.h"
#include "ifcs_sai_nexthop.h"
#include "ifcs_sai_nexthopgroup.h"
#include "ifcs_sai_port.h"
#include "ifcs_sai_qosmap.h"
#include "ifcs_sai_queue.h"
#include "ifcs_sai_route.h"
#include "ifcs_sai_router.h"
#include "ifcs_sai_routerintf.h"
#include "ifcs_sai_samplepacket.h"
#include "ifcs_sai_stp.h"
#include "ifcs_sai_synce.h"
#include "ifcs_sai_tam.h"
#include "ifcs_sai_tunnel.h"
#include "ifcs_sai_udf.h"
#include "ifcs_sai_vlan.h"
#include "ifcs_sai_wred.h"
#include "isai_im_nmgr.h"
#endif /* __IFCS_SAI_SWITCH_H__ */
