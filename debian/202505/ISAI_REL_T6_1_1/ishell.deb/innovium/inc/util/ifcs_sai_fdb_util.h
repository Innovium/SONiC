/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_fdb_util.h
 * @brief ISAI Util Include file for FDB module
 */


#ifndef __IFCS_SAI_FDB_UTIL_H__
#define __IFCS_SAI_FDB_UTIL_H__

#include "util/ifcs_sai_fdb_util_dep.h"

sai_status_t
isai_im_fdb_init(sai_switch_init_info_t *sai_switch_init_info_p);

sai_status_t
isai_im_fdb_deinit(sai_switch_deinit_info_t *sai_switch_deinit_info_p);

sai_status_t
isai_im_fdb_register_event_cb(isai_fdb_event_cb_t cb_p,
                              void                *user_data_p);

sai_status_t
isai_im_fdb_unregister_event_cb(isai_fdb_event_cb_t cb_p);

/**
 * @brief: Flush FDB Entries
 *
 * @param [in] switch_id                     - Switch Id
 * @param [in] attr_count                     - Number of attributes
 * @param [in] attr_list_p                   - Pointer to List of attributes
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_fdb_flush_entries(sai_object_id_t       switch_id,
                          uint32_t              attr_count,
                          const sai_attribute_t *attr_list_p);

sai_status_t
isai_im_fdb_pre_deinit(sai_switch_deinit_info_t *switch_deinit_info_p);

/*
 * @brief Get FDB Trap handle
 *
 * @param [in] switch_id Switch object id
 * @param [out] fdb_trap_hdl  - Pointer FDB trap handle
 * @return sai_status_t
 */
sai_status_t
isai_im_fdb_trap_hdl_get(sai_object_id_t switch_id,
                         ifcs_handle_t   *fdb_trap_hdl_p);

/*
 * @brief Get FDB Entry object type resource availability.
 *
 * @param[in] switch_id SAI Switch object id
 * @param[in] attr_count Number of attributes
 * @param[in] attr_list List of attributes that to distinguish resource
 * @param[out] count_p Available objects left
 *
 * @return #SAI_STATUS_NOT_SUPPORTED if the given object type does not support resource accounting.
 * Otherwise, return #SAI_STATUS_SUCCESS.
 */
sai_status_t
isai_im_fdb_object_type_get_availability(sai_object_id_t       switch_id,
                                         uint32_t              attr_count,
                                         const sai_attribute_t *attr_list,
                                         uint64_t              *count_p);

/*
 * @brief Enable mirror on drop for all L2 entries configured
 *
 * @param[in] node_id     - node_id
 * @param[in] mod_trap - hostif trap handle to be used for fdb MoD
 *
 * @return sai_status_t
 */
sai_status_t
isai_im_fdb_mod_enable(ifcs_node_id_t   node_id, ifcs_handle_t    mod_trap);

/*
 * @brief Disable mirror on drop for all L2 entries configured
 *
 * @param[in] node_id     - node_id
 * @param[in] mod_trap - hostif trap handle to be used for fdb MoD
 *
 * @return sai_status_t
 */
sai_status_t
isai_im_fdb_mod_disable(ifcs_node_id_t   node_id, ifcs_handle_t    mod_trap);
sai_status_t
isai_im_fdb_evpn_mh_protection_switch(ifcs_node_id_t  node_id,
                                  sai_object_id_t   bridge_port_oid,
                                  sai_object_id_t   protection_group_oid,
                                  ifcs_handle_t     old_prot_ecmp_hdl,
                                  bool              switch_over);
#endif /* __IFCS_SAI_FDB_UTIL_H__ */
