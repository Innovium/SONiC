/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_lag_util.h
 * @brief ISAI Util Include file for LAG module
 */


#ifndef __IFCS_SAI_LAG_UTIL_H__
#define __IFCS_SAI_LAG_UTIL_H__

#include "util/ifcs_sai_lag_util_dep.h"

sai_status_t
isai_im_lag_set_untagged_vlan_attr_lag_db(const sai_object_id_t oid,
                                   bool                  vlan_enabled,
                                   uint16_t              untagged_vlan);

sai_status_t
isai_im_lag_get_untagged_vlan_attr_lag_db(const sai_object_id_t oid,
                                   bool                  *vlan_enabled_p,
                                   uint16_t              *untagged_vlan_p);

sai_status_t
isai_im_lag_init(sai_switch_init_info_t *sai_switch_init_info_p);

sai_status_t
isai_im_lag_deinit(sai_switch_deinit_info_t *switch_deinit_info_p);

sai_status_t
isai_im_lag_add_lag_db_stp_list(ifcs_node_id_t node_id, ifcs_handle_t  hdl,
                            uint32_t stp_hdl, uint32_t stp_port_state);

sai_status_t
isai_im_lag_get_lag_db_stp_state(ifcs_node_id_t node_id, ifcs_handle_t hdl,
                        ifcs_handle_t   stp_hdl, uint32_t *stp_port_state_p);

sai_status_t
isai_im_lag_update_lag_db_stp_list(ifcs_node_id_t node_id, ifcs_handle_t hdl,
                        ifcs_handle_t   stp_hdl, uint32_t stp_port_state);

sai_status_t
isai_im_lag_remove_lag_db_stp_list(ifcs_node_id_t node_id, ifcs_handle_t hdl,
                            uint32_t stp_hdl);

sai_status_t
isai_im_lag_ds_get_lag_oid(ifcs_node_id_t node_id, ifcs_handle_t    lag_hdl,
                            sai_object_id_t *oid_p);
sai_status_t
isai_im_lag_ds_get_lag_hdl(sai_object_id_t  lag_oid, ifcs_handle_t  *lag_hdl_p);
sai_status_t
isai_im_lag_ds_get_all_lag_members(ifcs_node_id_t node_id,
                                    sai_object_id_t  lag_oid,
                                    sai_object_list_t *lag_members_p);
sai_status_t
isai_im_lag_set_ars_enabled_attr_lag_db(const sai_object_id_t oid,
                                   bool                  ars_enabled);
sai_status_t
isai_im_lag_mem_get_weight_attr_lag_mem_db(const sai_object_id_t oid,
                                           uint32_t          *weight);
sai_status_t
isai_im_lag_ds_check_cross_dependency_on_lag(ifcs_node_id_t node_id,
                                    sai_object_id_t  lag_oid);
ifcs_status_t
isai_im_lag_member_get(ifcs_node_id_t node_id,
                       ifcs_handle_t lag,
                       uint32_t member_count,
                       ifcs_handle_t *member_list_p,
                       uint32_t *actual_member_count_p);
sai_status_t
isai_im_lag_nh_list_update(
                   ifcs_node_id_t    node_id,
                   sai_object_id_t   lag_oid,
                   ifcs_handle_t     *mem_handle_p,
                   uint32_t          mem_cnt,
                   bool              is_mem_add);

#endif /* __IFCS_SAI_LAG_UTIL_H__ */
