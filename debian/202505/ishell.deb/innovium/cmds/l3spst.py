#------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#------------------------------------------------------------------------------
#

HOSTIF_SEND_PKT_BUSY_RETRY_CNT = 500

import os
import shlex
import argparse
import itertools
import time
import random
import json
from verbosity import *
from ctypes import *
from utils.common_util import strToList
from utils.compat_util import *
from cmdmgr import Command
from collections import OrderedDict
from ifcs_cmds.sysport import Sysport as sysport
from ifcs_cmds.devport import Devport as Devport
from ifcs_cmds.queue import Queue as Queue
from ifcs_cmds.tc import Tc as Tc
from ifcs_cmds.node import Node as Node
from print_table import PrintTable
from spst_tests_version import *
from spst_tests_common import *
import sys
ifcs_ctypes = sys.modules['ifcs_ctypes']

PROT_IPV4_TCP = 0
PROT_IPV4_UDP = 1
PROT_IPV6_TCP = 2
PROT_IPV6_UDP = 3
PROT_MAX = 4

L4SRCPORT = 0x55AA
L4DSTPORT = 0xAA55

L2HDR_SZ=18
L4DSTPORT_MIRROR = 0xB496
# Protocol field offsets
L2_ETYPE_OFFSET = 16

IPV4_VER_IHL_OFFSET = 18
IPV4_DSCP_OFFSET = 19
IPV4_LEN_OFFSET = 20
IPV4_FLAGFRAG_OFFSET = 24
IPV4_TTL_OFFSET = 26
IPV4_NXT_HDR = 27
IPV4_CSUM_OFFSET = 28
IPV4_SIP_OFFSET = 30
IPV4_DIP_OFFSET = 34
IPV4_OPTIONS_OFFSET = IPV4_VER_IHL_OFFSET + 20

IPV6_VER_OFFSET = 18
IPV6_LEN_OFFSET = 22
IPV6_NXT_HDR = 24
IPV6_HOP_OFFSET = 25
IPV6_SIP_OFFSET = 26
IPV6_DIP_OFFSET = 42

MAX_DEV_PORTS = 520
MAX_PKTS = 2000

rng = None

'''
L3spst Class - Initialize and Setup the switch for L3spst.

Configuration:
  IVM:0>diagtest l3spst config -p 1-32 -lb 'PCS' [-b|-bs] -id 2
  -p : list of ports is a comma-separated list or hyphen separated
  -lb: {NONE,PCS,PMA}    Loopback type (default: NONE)
  -id: ID                User defined snake id [1-1023] (default: None)
  Ixia traffic can ingress on any port
  The other ports must be configured in internal loopback or have external loopback module
  The script does the following forwarding setup
    1. Ports put in internal loopback if specified using -lb option
    2. Sysports configured as L3PORT
    3. VRFs (L3VNIs) created, one per port
    4. L3 Interfaces created one per Sysport
    5. Nexthops created one per L3 interface
    6. Host Route entries (VRF, IP) -> NH (Intf, Dest Sysport) created.
       Packet snakes with below Routes:
       Route entry (VRF1, IP) -> NH1(Intf1, SP2)
       Route entry (VRF2, IP) -> NH2(Intf2, SP3)
       ..
       Route entry (VRF128, IP) -> NH0(Intf0, SP1)

Start traffic:
    IVM:0>diagtest l3spst start_traffic -id 2

Stop traffic:
    IVM:0>diagtest l3spst stop_traffic -id 2

Unconfig:
    IVM:0>diagtest l3spst unconfig -id 2

UNIDIR
******
It is assumed that each port has a loopback connection connecting its ingress to its egress.
The loopbacks can be either internal (PCS, PMA) or external (via a loopback module).
Since there are no physical connections between different ports, rules A and B do not apply and
hence we can specify any random subset out of the set of loopback connected ports.

External Traffic Stream Configuration
*************************************
If external traffic generator is used, the streams must be configured as follows:

UNIDIR
-- All ports have internal or external loopback
-- Ingress port will have external connection to traffic generator, so must have internal loopback
-- FWD: Ingress at any port

Packet headers are as follows:

L2 Header
=========
For FWD flows (bidir cross, unidir):
    dst_mac     : 00:03:00:00:00:01
    src_mac     : 00:03:00:00:00:02
For FWD flows (bidir straight):
    dst_mac     : 00:05:00:00:00:01
    src_mac     : 00:03:00:00:00:02
For REV flows (bidir cross, unidir):
    dst_mac     : 00:05:00:00:00:01
    src_mac     : 00:03:00:00:00:02
For REV flows (bidir straight):
    dst_mac     : 00:03:00:00:00:01
    src_mac     : 00:03:00:00:00:02

L3 Header
=========
For FWD flows:
    version        : 4
    ttl            : 255
    src            : 13.0.0.1
    dst            : 12.0.0.1
For REV flows:
    version        : 4
    ttl            : 255
    src            : 12.0.0.1
    dst            : 13.0.0.1
'''

def auto_int(x):
    return int(x, 0)

def config_show_sort_key(x):
    return x.id

SNAKE_UNCONFIG = 0
SNAKE_CONFIGD  = 1
SNAKE_RUNNING  = 2
SNAKE_STOPPED  = 3
NUM_NH_PER_PORT  = 200
NUM_MAX_DSCP_QOS_PROFILE = 2
NUM_MAX_DOT1PCFI_QOS_PROFILE = 2

def ace_get_packets(node_id, ace):
    attr = ifcs_ctypes.ifcs_attr_t()
    attr_p = pointer(attr)
    attr.id = ifcs_ctypes.IFCS_ACE_ATTR_PACKETS
    attr_count=1
    actual_count = c_uint32()
    actual_count_p = pointer(actual_count)

    rc = ifcs_ctypes.IFCS_STATUS_REASON(
        ifcs_ctypes.ifcs_ace_attr_get(
             node_id, ace,
             attr_count, attr_p,
             actual_count_p))

    spstcommon_handle_device_access_error(rc, "ifcs_ace_attr_get")
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to get ace stats for ace %d" % ace)
        return

    if (attr.bitmap.u64) != 1:
        return None
    return attr.value.u64

def ace_clear_packets_bytes(node_id, ace):
    attr = (ifcs_ctypes.ifcs_attr_t * 2)()
    attr_count = 0
    attr[0].id = ifcs_ctypes.IFCS_ACE_ATTR_PACKETS
    attr[0].bitmap.u64 = 1
    attr[0].value.u64 = 0
    attr_count += 1

    attr[1].id = ifcs_ctypes.IFCS_ACE_ATTR_BYTES
    attr[1].bitmap.u64 = 1
    attr[1].value.u64 = 0
    attr_count += 1

    rc = ifcs_ctypes.IFCS_STATUS_REASON(
        ifcs_ctypes.ifcs_ace_attr_set(
             node_id, ace,
             attr_count,
             compat_pointer(attr, ifcs_ctypes.ifcs_attr_t)))

    spstcommon_handle_device_access_error(rc, "ifcs_ace_attr_set")
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to clear ace stats for ace %d" % ace)

    return rc

#Get ACE count in ACL
def get_acl_ace_count(node_id, acl):
    attr = ifcs_ctypes.ifcs_attr_t()
    attr_p = pointer(attr)
    attr.id = ifcs_ctypes.IFCS_ACL_ATTR_ACE_COUNT
    attr_count=1
    actual_count = c_uint32()
    actual_count_p = pointer(actual_count)

    rc = ifcs_ctypes.IFCS_STATUS_REASON(
        ifcs_ctypes.ifcs_acl_attr_get(
             node_id, acl,
             attr_count, attr_p,
             actual_count_p))

    spstcommon_handle_device_access_error(rc, "ifcs_acl_attr_get")
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to get ace count for acl %d" % acl)
        return

    if (attr.bitmap.u32) != 1:
        return None
    return attr.value.u32

def _get_ib_from_devport(node_id, devport):
    '''
        Utility function that takes a devport
        and returns IB for the devport
    '''
    attr = ifcs_ctypes.ifcs_attr_t()
    count  = ifcs_ctypes.c_uint32()

    attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_IB
    attr_count = 1
    rc = ifcs_ctypes.ifcs_devport_attr_get(node_id, devport, attr_count, pointer(attr),
                               pointer(count))
    spstcommon_handle_device_access_error(rc, "ifcs_devport_attr_get")
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to get IB for devport %d" % devport)
        return

    return attr.value

def _get_ibport_from_devport(node_id, devport):
    '''
        Utility function that takes a devport
        and returns IB port for the devport
    '''
    attr = ifcs_ctypes.ifcs_attr_t()
    count  = ifcs_ctypes.c_uint32()

    attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_IBPORT
    attr_count = 1
    rc = ifcs_ctypes.ifcs_devport_attr_get(node_id, devport, attr_count, pointer(attr),
                               pointer(count))
    spstcommon_handle_device_access_error(rc, "ifcs_devport_attr_get")
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to get IB port for devport %d" % devport)
        return

    return attr.value.u32

def flexstat_get_packets(node_id, flex_counterset_hdl, sp_hdl):
    actual_count = c_uint32()
    actual_count_p = pointer(actual_count)

    counter_value = c_uint64()
    counter_value_p = pointer(counter_value)

    stats_id = ifcs_ctypes.ifcs_flex_counterset_sysport_stats_id_t()
    #stats_id = ifcs_ctypes.IFCS_FLEX_COUNTERSET_STATS_ID_PKTS
    stats_id_p = pointer(stats_id)

    rc = ifcs_ctypes.IFCS_STATUS_REASON(
        ifcs_ctypes.ifcs_flex_counterset_stats_get(
             node_id, flex_counterset_hdl,
             1, stats_id_p, counter_value_p,
             actual_count_p))

    spstcommon_handle_device_access_error(rc, "ifcs_flex_counterset_stats_get")
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to get flex counterset stats rc: %d" % rc)
        return

    return counter_value.value

def flexstat_clear_packets_bytes(node_id, sinst_info):
    stats_id = ifcs_ctypes.ifcs_flex_counterset_sysport_stats_id_t()
    #stats_id = ifcs_ctypes.IFCS_FLEX_COUNTERSET_STATS_ID_PKTS
    stats_id_p = pointer(stats_id)

    for fc_hdl in sinst_info.list_of_flex_counterset_hdl:
        rc = ifcs_ctypes.IFCS_STATUS_REASON(
             ifcs_ctypes.ifcs_flex_counterset_stats_clear(0, fc_hdl, 1, stats_id_p))

        spstcommon_handle_device_access_error(rc, "ifcs_flex_counterset_stats_clear")
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("Failed to create flexcounter set packet stats rc %d" % rc)
    return

def pkt_vos_cb(node_id, user_data, packet):
    global L2HDR_SZ
    mismatch = 0
    buf_len = packet.contents.pkt_buf_len
    buf = c_char_p(packet.contents.pkt_buf)
    packet = cast(buf, POINTER(c_char))
    packet = packet[:buf_len]
    prot_sel = -1
    apphdr_offset = 0

    
    if compat_ord(packet[L2_ETYPE_OFFSET]) == 0x08 and compat_ord(packet[L2_ETYPE_OFFSET+1]) == 0x00:
        # ipv4 pkt
        ihl = compat_ord(packet[IPV4_VER_IHL_OFFSET]) & 0xf
        apphdr_offset = L2HDR_SZ + ihl*4 + 4
        if compat_ord(packet[IPV4_NXT_HDR]) == 0x06:
            prot_sel = PROT_IPV4_TCP
        elif compat_ord(packet[IPV4_NXT_HDR]) == 0x11:
            prot_sel = PROT_IPV4_UDP
    elif compat_ord(packet[L2_ETYPE_OFFSET]) == 0x86 and compat_ord(packet[L2_ETYPE_OFFSET+1]) == 0xDD:
        # ipv6 pkt
        apphdr_offset = L2HDR_SZ + 40 + 4
        if compat_ord(packet[IPV6_NXT_HDR]) == 0x06:
            prot_sel = PROT_IPV6_TCP
        elif compat_ord(packet[IPV6_NXT_HDR]) == 0x11:
            prot_sel = PROT_IPV6_UDP

    if apphdr_offset == 0:
        log("Received ethertype invalid;pkt[L2_ETYPE_OFFSET]: {} pkt[L2_ETYPE_OFFSET+1]: {}. Received pkt: {}".format(packet[L2_ETYPE_OFFSET], packet[L2_ETYPE_OFFSET+1]))
        log(":".join("{:02x}".format(compat_ord(c)) for c in packet))
        # Incrementing global mismatch counter id (not per L3spst-id) as we don't know the snake-id here
        L3spst.vos_glob_mismatch += 1
        return

    if prot_sel == -1:
        log(":".join("{:02x}".format(compat_ord(c)) for c in packet))
        # Incrementing global mismatch counter id (not per L3spst-id) as we don't know the snake-id here
        L3spst.vos_glob_mismatch += 1
        return

    if compat_ord(packet[apphdr_offset]) == 0xBE and compat_ord(packet[apphdr_offset+1]) == 0xBA and \
       compat_ord(packet[apphdr_offset+2]) == 0xFE and compat_ord(packet[apphdr_offset+3]) == 0xCA:
        log_dbg(1, "Received packet signature verified")
    else:
        log("Received packet signature invalid. Received pkt:")
        log(":".join("{:02x}".format(compat_ord(c)) for c in packet))
        # Incrementing global mismatch counter id (not per L3spst-id) as we don't know the snake-id here
        L3spst.vos_glob_mismatch += 1
        return

    snake_id_idx = apphdr_offset + 4
    pkt_id_idx = snake_id_idx + 1
    snake_id = compat_ord(packet[snake_id_idx])
    find = False
    for instance in L3spst.sinst_info_runs:
        if instance.id == snake_id:
            sinst_info = instance
            find = True
            break
    if find == False:
        log("L3spst pkt_id {0} doesn't exist".format(snake_id))
        log("Received pkt")
        log(":".join("{:02x}".format(compat_ord(c)) for c in packet))
        L3spst.vos_glob_mismatch += 1
        return


    pkt_id = compat_ord(packet[pkt_id_idx]) | (compat_ord(packet[pkt_id_idx + 1]) << 8) | (compat_ord(packet[pkt_id_idx + 2]) << 16)

    log_dbg(1, "Received pkt_id {}".format(pkt_id))

    if pkt_id >= MAX_PKTS:
        # Invalid pkt_id
        log("Invalid pkt_id: {}".format(pkt_id))
        log("Received pkt")
        log(":".join("{:02x}".format(compat_ord(c)) for c in packet))
        L3spst.vos_glob_mismatch += 1
        return

    gen_pkt = sinst_info.vos_gen_pkts[pkt_id]
    sinst_info.vos_num_rcvd_total += 1
    sinst_info.vos_rcv_pktids[pkt_id] += 1

    if isinstance(gen_pkt, int):
        # Why is it of type int; if it is a valid pkt it should be of type bytes.
        # pkt_id not expected
        log("Unexpected pkt_id: {}".format(pkt_id))
        log("Received pkt")
        log(":".join("{:02x}".format(compat_ord(c)) for c in packet))
        sinst_info.vos_num_rcvd_bad += 1
        return

    if len(gen_pkt) != len(packet):
        mismatch = 1
        sent_received = (gen_pkt, packet)
        sinst_info.len_mismatch.append(sent_received)

    if mismatch == 0:
        # now compare the content
        for i in range(len(gen_pkt)):
           if packet[i] != gen_pkt[i]:
               mismatch = 1
               snake_pkt_byte = (snake_id, pkt_id, i, gen_pkt, packet)
               sinst_info.byte_mismatch.append(snake_pkt_byte)

    if mismatch == 0:
        sinst_info.vos_num_rcvd_good += 1
        sinst_info.vos_prot_sel_good_rcv_cnt[prot_sel] += 1
    else:
        sinst_info.vos_num_rcvd_bad += 1
    return

class PortFwdInst():
    def __init__(self):
        self.sp_hdl              = 0
        self.sp_def_tc           = 0
        self.sp_def_dp           = 0
        self.sp_cookie           = 0
        self.l3vni_hdl           = 0
        self.l3vni_cookie        = 0
        self.qosmap_dscp_hdl     = 0
        self.qosmap_grp_dscp_hdl = 0
        self.qosmap_grp_dot1pcfi_hdl = 0
        self.qosmap_dot1pcfi_hdl = 0
        self.si_vlan             = 0
        self.intf_hdl            = 0
        self.intf_cookie         = 0
        self.intf_egr_cookie     = 0
        self.dscp                = 0
        self.dot1p               = 0
        self.cfi                 = 0
        self.nh_hdls             = OrderedDict()
        self.nh_cookie_list      = OrderedDict()
        self.nh4_picked_hdl      = 0    # ACL should use this NH handle for V4
        self.nh4_picked_cookie   = 0
        self.nh6_picked_hdl      = 0    # ACL should use this NH handle for V6
        self.nh6_picked_cookie   = 0
        self.v4_route_cookie     = 0
        self.v6_route_cookie     = 0
        self.dcdp_hdl            = 0


# Object to store A "run" devport stats.
class SnakeInstInfo():
    def __init__(self):
        self.devport_list = []
        self.lb_type = 0
        self.sdd = 0
        self.node_id = 0
        self.verbose = 0
        self.port_fwd_inst_list  = [0] * MAX_DEV_PORTS
        self.ip1 = 0x0
        self.ip2 = 0x0
        self.id = 0
        self.type = 'None'
        self.intfmac1 = None
        self.intfmac2 = None
        self.v4_dscp = 0
        self.v4_flags = 0
        self.v4_frag = 0
        self.v4_ttl = 0
        self.v6_tc = 0
        self.dot1q_pcp = 0
        self.dot1q_dei = 0
        self.v6_hoplimit = 0
        self.v6_sip = []
        self.v6_dip = []
        self.l4_sport = 0
        self.l4_dport = 0
        self.l4_dport_mirror = L4DSTPORT_MIRROR
        self.l2hdr_etv4 = []
        self.l2hdr_etv6 = []
        self.payload_type = ""
        self.vos = 0
        self.vos_gen_pkts        = [0] * MAX_PKTS
        self.vos_rcv_pktids      = [0] * MAX_PKTS
        self.vos_num_gen_pkts    = 0
        self.vos_num_rcvd_total  = 0
        self.vos_num_rcvd_good   = 0
        self.vos_num_rcvd_bad    = 0
        self.vos_prot_sel_gen_cnt = [0] * PROT_MAX
        self.vos_prot_sel_good_rcv_cnt = [0] * PROT_MAX
        self.mirror_cfg = False
        self.mirror_port_list =[]
        self.collector_hdl = [0] * L3spst.num_ibs
        self.collector_set_hdls = [0] * L3spst.num_ibs
        self.dbg1 = 0
        self.stress_prot_sel = 0
        self.stress_data_bytes = None
        self.state = SNAKE_UNCONFIG
        self.recirc_ibport = L3spst.recirc_ibport

        #ACL handles
        self.ingress_ace_list_hdls = [[] for i in range (MAX_DEV_PORTS)]
        self.egress_ace_list_hdls = [[] for i in range (MAX_DEV_PORTS)]
        self.egress_ace_list_hdls2 = [[] for i in range (MAX_DEV_PORTS)]
        self.ingress_ace_list_hdls2 = [[] for i in range (MAX_DEV_PORTS)]
        self.egress_ace_list_hdls3 = [[] for i in range (MAX_DEV_PORTS)]
        self.ingress_ace_list_hdls3 = [[] for i in range (MAX_DEV_PORTS)]
        self.egress_ace_list_hdls4 = [[] for i in range (MAX_DEV_PORTS)]
        self.ingress_ace_list_hdls4 = [[] for i in range (MAX_DEV_PORTS)]
        self.ingress_ace_list_hdls5 = [[] for i in range (MAX_DEV_PORTS)]
        self.ingress_ace_list_hdls6 = [[] for i in range (MAX_DEV_PORTS)]
        self.ingress_ace_list_hdls7 = [[] for i in range (MAX_DEV_PORTS)]

        self.ingress_match_list_hdls = [[] for i in range (MAX_DEV_PORTS)]
        self.egress_match_list_hdls = [[] for i in range (MAX_DEV_PORTS)]
        self.egress_match_list_hdls2 = [[] for i in range (MAX_DEV_PORTS)]
        self.ingress_match_list_hdls2 = [[] for i in range (MAX_DEV_PORTS)]
        self.egress_match_list_hdls3 = [[] for i in range (MAX_DEV_PORTS)]
        self.ingress_match_list_hdls3 = [[] for i in range (MAX_DEV_PORTS)]
        self.egress_match_list_hdls4 = [[] for i in range (MAX_DEV_PORTS)]
        self.ingress_match_list_hdls4 = [[] for i in range (MAX_DEV_PORTS)]
        self.ingress_match_list_hdls5 = [[] for i in range (MAX_DEV_PORTS)]
        self.ingress_match_list_hdls6 = [[] for i in range (MAX_DEV_PORTS)]
        self.ingress_match_list_hdls7 = [[] for i in range (MAX_DEV_PORTS)]

        self.ingress_acl_list_hdls = [[] for i in range (MAX_DEV_PORTS)]
        self.egress_acl_list_hdls = [[] for i in range (MAX_DEV_PORTS)]
        self.egress_acl_list_hdls2 = [[] for i in range (MAX_DEV_PORTS)]
        self.ingress_acl_list_hdls2 = [[] for i in range (MAX_DEV_PORTS)]
        self.egress_acl_list_hdls3 = [[] for i in range (MAX_DEV_PORTS)]
        self.ingress_acl_list_hdls3 = [[] for i in range (MAX_DEV_PORTS)]
        self.egress_acl_list_hdls4 = [[] for i in range (MAX_DEV_PORTS)]
        self.ingress_acl_list_hdls4 = [[] for i in range (MAX_DEV_PORTS)]
        self.ingress_acl_list_hdls5 = [[] for i in range (MAX_DEV_PORTS)]
        self.ingress_acl_list_hdls6 = [[] for i in range (MAX_DEV_PORTS)]
        self.ingress_acl_list_hdls7 = [[] for i in range (MAX_DEV_PORTS)]

        self.ing_acl_list_for_table1 = []
        self.ing_acl_list_for_table2 = []
        self.egr_acl_list_for_table1 = []
        self.egr_acl_list_for_table2 = []
        self.egr_acl_list_for_table3 = []
        self.ing_acl_list_for_table3 = []
        self.egr_acl_list_for_table4 = []
        self.ing_acl_list_for_table4 = []
        self.ing_acl_list_for_table5 = []
        self.ing_acl_list_for_table6 = []
        self.ing_acl_list_for_table7 = []

        self.ing_ace_list_for_table1 = []
        self.ing_ace_list_for_table2 = []
        self.egr_ace_list_for_table1 = []
        self.egr_ace_list_for_table2 = []
        self.egr_ace_list_for_table3 = []
        self.ing_ace_list_for_table3 = []
        self.egr_ace_list_for_table4 = []
        self.ing_ace_list_for_table4 = []
        self.ing_ace_list_for_table5 = []
        self.ing_ace_list_for_table6 = []
        self.ing_ace_list_for_table7 = []

        self.list_of_acl_table_hdl = []
        self.list_of_mp_hdl = []
        self.list_of_ap_hdl = []
        self.list_of_cip_hdl = []
        self.list_of_fpf_hdl = []

        self.list_of_all_acl_match_hdls = []
        self.list_of_all_acl_action_hdls = []

        self.list_of_flex_pool_hdl = []
        self.list_of_flex_counterset_hdl = []

        self.ace_priority = 100

        self.len_mismatch = []
        self.byte_mismatch = []

    def display(self):
        import pprint
        pprint.pprint(vars(self))

    def display_config(self, id):
        for instance in L3spst.sinst_info_runs:
            if instance.id == id:
                sinst_info = instance
                table = PrintTable()
                header = []
                header.append("Devports")
                header.append("Loopback type")
                header.append("Snake id")
                header.append("Snake type")
                table.add_row(header)

                data = []
                data.append(str(sinst_info.devport_list)[1:-1])
                data.append(str(sinst_info.lb_type))
                data.append(str(id))
                data.append(str(sinst_info.type))
                table.add_row(data)
                table.print_table()
                table.reset_table()
                break


class FilePacketData():
    # Sample file format is given below.
    #
    # {
    #     "1": {
    #         "payload": "a0:a1:a2:a3:a4:a5:a6:a8:a9:aa:ab:ac:ad:ae:af"
    #        },
    #     "2": {
    #         "payload": "b0:b1:b2:b3:b4:b5:b6:b8:b9:ba:bb:bc:bd:be:bf"
    #        }
    # }
    #
    # payload field bytes are specified in hex and is repeated within a packet.
    def __init__(self, file_name):
        # Load json file
        try:
            with open(file_name, "r") as jfile:
                pkts = json.load(jfile)
            pkt_list = OrderedDict(sorted(pkts.items()))
        except:
            log_dbg(
                1, "Failed to open and load json from packet data file {}: {}".
                format(file_name, sys.exc_info()))
            raise TypeError(
                "Cannot open file or file content is not valid json")
        # Validate json
        try:
            for idx in pkt_list:
                pdata = pkt_list[idx]["payload"].split(":")
                if not len(pdata) or (len(pdata) == 1 and pdata[0] == ""):
                    raise TypeError(
                        "Payload data of packet {} is empty".format(idx))
                pkt_list[idx]["payload"] = pdata
            if not len(pkt_list):
                raise TypeError(
                    "json does not contain packet data field named payload")
        except:
            log_dbg(
                1, "Unsupported json format in packet data file {} : {}".format(
                    file_name, sys.exc_info()))
            raise TypeError("Unsupported json data format in file")
        try:
            for idx in pkt_list:
                pdata = pkt_list[idx]["payload"]
                int_vals = [int(x, 16) for x in pdata]
                pkt_list[idx]["payload"] = int_vals
        except:
            log_dbg(
                1,
                "Error converting packet data from hex to int for packet {}: {}"
                .format(idx, sys.exc_info()))
            raise TypeError(
                "Non-hex character in packet data field for packet {}".format(
                    idx))
        self.pkt_data = []  # Will contain list of bytes for each packet
        for idx in pkt_list:
            pdata = pkt_list[idx]["payload"]
            for pos in range(len(pdata)):
                if pdata[pos] < 0 or pdata[pos] > 255:
                    raise TypeError(
                        "byte value is out of range at offset {} in packet data field for packet {}"
                        .format(pos + 1, idx))
            self.pkt_data.append(pdata[:])
        self.byte_offset = 0  # Offset within byte for a packet
        self.pkt_num = 0  # Offset within byte for a packet

    def get_next_byte(self):
        val = self.pkt_data[self.pkt_num][self.byte_offset]
        self.byte_offset += 1
        if self.byte_offset >= len(self.pkt_data[self.pkt_num]):
            self.byte_offset = 0
        return val

    def get_packet_data(self, data_len):
        reps = int(data_len / len(self.pkt_data[self.pkt_num])) + 1
        pkt_data = self.pkt_data[self.pkt_num] * reps
        return pkt_data[:data_len]

    def select_first_pkt(self):
        self.pkt_num = 0
        self.byte_offset = 0

    def select_last_pkt(self):
        self.pkt_num = len(self.pkt_data) - 1
        self.byte_offset = 0

    def select_next_pkt(self):
        self.pkt_num += 1
        if self.pkt_num >= len(self.pkt_data):
            self.pkt_num = 0
        self.byte_offset = 0

    def get_curr_pkt_size(self):
        return len(self.pkt_data[self.pkt_num])


class L3spst(Command):
    # All runs' devport stats are saved in below list
    sinst_info_runs = []
    snake_file_version = 0
    ver_disp = "" # nomenclature: <ifcs_version>_<snake_version>
    num_ibs = 0
    recirc_ibport = 0
    sibp_only_mask = [0] * 2

    cpu_queue_num = 3
    trap_id = 65
    trap_hdl = ifcs_ctypes.ifcs_handle_t()
    rx_cbfn             = 0
    vos_glob_mismatch   = 0
    # Incremented for each run config (diagtest L3spst config)
    run = -1
    device_access_error_exc_msg = DEVICE_ACCESS_ERROR_EXC_MSG

    def __init__(self, cli, quiet="false"):
        self.sub_cmds = {
                         'config'       : self.config,
                         'config_show'  : self.config_show,
                         'start_traffic': self.start_traffic,
                         'stop_traffic' : self.stop_traffic,
                         'show_vos_stats'  : self.show_vos_stats,
                         'clear_vos_stats' : self.clear_vos_stats,
                         'show_dbginfo' : self.show_dbginfo,
                         'show_acl_stats'   : self.show_acl_stats,
                         'clear_acl_stats'  : self.clear_acl_stats,
                         'unconfig'     : self.unconfig,
                         'show_version' : self.show_ver,
                         'help'         : self.help,
                         '?'            : self.help
                        }
        self.cli = cli
        self.quiet = quiet
        self.arg_list = []
        self.node_id = 0
        self.node_device_type = ifcs_ctypes.im_nmgr_node_device_type_get(self.cli.node_id)
        if self.node_device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
            L3spst.num_ibs = 6
            L3spst.recirc_ibport = 32
            L3spst.sibp_only_mask[0] = 0x0
            L3spst.sibp_only_mask[1] = 0x3f
        elif self.node_device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TL10:
            L3spst.num_ibs = 8
            L3spst.recirc_ibport = 64
            L3spst.sibp_only_mask[0] = 0x0
            L3spst.sibp_only_mask[1] = 0x7f
        else:
            assert False, "Not supported on this device type {}".format(self.node_device_type)
 
        
        version_num = [0] * 6
        for idx in range(len(SPST_TESTS_VERSION)):
            version_num[idx] = SPST_TESTS_VERSION[idx]
        self.ver_disp = "{}.{}.{}.{}.{}.{}".format(
            version_num[0], version_num[1], version_num[2], version_num[3],
            version_num[4], version_num[5])
        self.ver_disp = "{}_{}".format(self.ver_disp, self.snake_file_version)
        self.file_pkt_data_obj = None
        super(L3spst, self).__init__()

    def __del__(self):
        return

    def show_ver(self, args):
        table = PrintTable()
        table.add_row(['IFCS L3Spst Version',"%s"%(self.ver_disp)])
        table.print_table()
        table.reset_table()

    def _get_ib_ibp(self, ib, ibp):
        '''
        Utility routine to get ib+ibp encoding
        '''
        if self.node_device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
            return (((ib & 0x7) << 6) | (ibp & 0x3f))
        elif self.node_device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TL10:
            return (((ib & 0x7) << 7) | (ibp & 0x7f))
        else:
            assert False, "Not supported on this device type {}".format(self.node_device_type)

    def run_cmd(self, args):
        self.arg_list = shlex.split(args)
        try:
            rc = self.sub_cmds[self.arg_list[2]](args)
            return rc
        except (KeyError) as kex:
            log_err("Invalid cmd; Exception: {}".format(kex))
            self.help(args)
            return ifcs_ctypes.IFCS_PARAM
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            self.cli.error()
            log_err("Exception: {}".format(ve))
        except Exception as ex:
            self.cli.error()
            log_err("Exception: {}".format(ex))

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def help(self, args):
        table = PrintTable()
        table.add_row(['Command', 'Description'])
        table.add_row(['config', 'Configure L3spst test'])
        table.add_row(['config_show', 'Show L3spst test configuration'])
        table.add_row(['start_traffic', 'Start L3spst test traffic'])
        table.add_row(['stop_traffic', 'Stop L3spst test traffic'])
        table.add_row(['show_vos_stats', 'Display vos statistics'])
        table.add_row(['clear_vos_stats', 'Clear vos statistics'])
        table.add_row(['show_acl_stats', 'Display acl statistics'])
        table.add_row(['clear_acl_stats', 'Clear acl statistics'])
        table.add_row(['verify', 'Verify if traffic is running on all configured ports'])
        table.add_row(['unconfig', 'Unconfigure L3spst test'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        l3spst_help_string = """
Usage::

    Type "diagtest L3spst <command>" followed by -h to see command's sub-options.
"""
        log(l3spst_help_string)

    def insert_run_data(self, run_data):
        # Increment run and insert run data
        L3spst.run += 1
        L3spst.sinst_info_runs.append(run_data)

    def get_run_data(self, run):
        return L3spst.sinst_info_runs[run]

    def get_cur_run_data(self):
        run = L3spst.run
        return L3spst.sinst_info_runs[run]

    def get_max_devport(self, node_id=0):
        # Do get all devport to figure out max devports configured
        def myCallback(node_id, arg, attr_count, attr_list, user_data):
            devport = arg
            devport_list.append(devport)

        devport_list = []

        callback_type = CFUNCTYPE(
            ifcs_ctypes.UNCHECKED(None),
            ifcs_ctypes.ifcs_node_id_t,
            ifcs_ctypes.ifcs_devport_t,
            c_uint32,
            POINTER(ifcs_ctypes.ifcs_attr_t),
            POINTER(None))
        callback = callback_type(myCallback)

        attr = ifcs_ctypes.ifcs_attr_t()
        ifcs_ctypes.ifcs_attr_t_init(pointer(attr))
        ifcs_ctypes.ifcs_attr_t_id_set(pointer(attr), ifcs_ctypes.IFCS_DEVPORT_ATTR_TYPE)
        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_DEVPORT_TYPE_ETH)

        try:
            rc = ifcs_ctypes.ifcs_devport_get_all(node_id, 1, pointer(attr), compat_funcPointer(callback, ifcs_ctypes.ifcs_devport_user_cb_t), None, None)
            spstcommon_handle_device_access_error(rc, "ifcs_devport_get_all")
            if ( rc != ifcs_ctypes.IFCS_SUCCESS):
                log_err("Failed to get all devport rc: {0}".format(rc))
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("In except of devport get_all")
            pass

        return (len(devport_list))

    def configDevportGetSysportHandle(self, devport):
        '''
            Utility function that takes a devport
            and returns the handle to its corresponding
            sysport
        '''
        attr        =  ifcs_ctypes.ifcs_attr_t()
        count       =  c_uint32()
        attr.id     =  ifcs_ctypes.IFCS_DEVPORT_ATTR_SYSPORT
        attr_count  =  1
        rc = ifcs_ctypes.ifcs_devport_attr_get(self.cli.node_id, devport, attr_count, pointer(attr),
                                   pointer(count))
        spstcommon_handle_device_access_error(rc, "ifcs_devport_attr_get")
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("Failed to get sysport for devport %d" % devport)
            return

        return attr.value.handle

    def configDevportSetAdminState(self, sinst_info, devport, admin_state):
        '''
            Utility function to configure devport's admin_state
        '''
        err = 0
        try:
            # Enable devport
            attr_list = (ifcs_ctypes.ifcs_attr_t * 3)()
            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointer(attr_list, ifcs_ctypes.ifcs_attr_t))
            assert rc == ifcs_ctypes.IFCS_SUCCESS

            attr_count = 0
            attr_list[attr_count].id         = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE
            attr_list[attr_count].value.data = admin_state
            attr_count += 1

            if admin_state == ifcs_ctypes.IFCS_BOOL_TRUE:
                if self.node_device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
                    attr_list[attr_count].id        = ifcs_ctypes.IFCS_DEVPORT_ATTR_RX_EQ_FINE_TUNE
                    attr_list[attr_count].value.u32 = ifcs_ctypes.IFCS_DEVPORT_SERDES_RX_EQ_FINE_TUNE_CONTINUOUS
                    attr_count += 1
                if sinst_info.sdd:
                    attr_list[attr_count].id        = ifcs_ctypes.IFCS_DEVPORT_ATTR_SD_TX_OUTPUT_ENABLE
                    attr_list[attr_count].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE
                    attr_count += 1

            rc = ifcs_ctypes.ifcs_devport_attr_set(self.cli.node_id,
                                       devport,
                                       attr_count,
                                       compat_pointer(attr_list, ifcs_ctypes.ifcs_attr_t))
            spstcommon_handle_device_access_error(rc, "ifcs_devport_attr_set")
            assert rc == ifcs_ctypes.IFCS_SUCCESS, "ifcs_devport_attr_set ADMIN_STATE failed: rc={0} ".format(rc)
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Set devport admin state failed")
            err = 1

        return err

    def configSysportSetFwdMode(self, sinst_info, mode=ifcs_ctypes.IFCS_SYSPORT_FWD_MODE_L3_ONLY):
        '''
            Utility function to config sysports FWD MODE. Default mode in this API is L3_ONLY
        '''
        err = 0
        try:
            log_dbg(1, "Configure sysports as L3PORT")
            #sysport_hdls = sinst_info.sysport_hdls
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            # Set sysport's PORT_FWD_MODE to given mode
            for port in sinst_info.devport_list:
                attr = ifcs_ctypes.ifcs_attr_t()
                rc = ifcs_ctypes.ifcs_attr_t_init(pointer(attr))
                assert rc == ifcs_ctypes.IFCS_SUCCESS

                # Get PORT_FWD_MODE
                attr.id        = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_FWD_MODE
                actual_count   = c_uint32()
                actual_count_p = pointer(actual_count)

                rc = ifcs_ctypes.ifcs_sysport_attr_get(self.cli.node_id,
                                           port_fwd_inst_list[port].sp_hdl,
                                           1,
                                           pointer(attr),
                                           actual_count_p)
                spstcommon_handle_device_access_error(rc, "ifcs_sysport_attr_get")
                if attr.value.u32 == mode:
                    continue

                # Set PORT_FWD_MODE
                attr_list  = (ifcs_ctypes.ifcs_attr_t * 1)()
                attr_count = 0
                attr_list[attr_count].id           = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_FWD_MODE
                attr_list[attr_count].value.u32    = mode
                attr_count += 1

                rc = ifcs_ctypes.ifcs_sysport_attr_set(self.cli.node_id,
                                                port_fwd_inst_list[port].sp_hdl,
                                                attr_count,
                                                attr_list)
                spstcommon_handle_device_access_error(rc, "ifcs_sysport_attr_set")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "sysport setAttr failed: port: {0}, rc :{1}".format(
                     port, rc)

                log_dbg(1, "   Configured sysports as L3PORT successfully")
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Error setting devport fwd mode to L3")
            err = 1

        return err

    def configSysport(self, sinst_info, config = 1):
        '''
            Utility function to config sysports default TC/DP. Default mode in this API is L3_ONLY
        '''

        global rng
        err = 0
        try:
            log_dbg(1, "Configure sysports as L3PORT")
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            tc_list = [0] * NUM_MAX_DSCP_QOS_PROFILE
            dp_list = [0] * NUM_MAX_DSCP_QOS_PROFILE
            # Set sysport's PORT_FWD_MODE to given mode
            for ind,port in enumerate(sinst_info.devport_list):
                if config == 1:
                    if ind >= NUM_MAX_DSCP_QOS_PROFILE :
                        if port == sinst_info.devport_list[-1] and (len(sinst_info.devport_list)%2 != 0):
                            port_fwd_inst_list[port].sp_def_tc = port_fwd_inst_list[sinst_info.devport_list[-2]].sp_def_tc
                            port_fwd_inst_list[port].sp_def_dp = port_fwd_inst_list[sinst_info.devport_list[-2]].sp_def_dp
                        else:
                            port_fwd_inst_list[port].sp_def_tc = tc_list[ind%NUM_MAX_DSCP_QOS_PROFILE]
                            port_fwd_inst_list[port].sp_def_dp = dp_list[ind%NUM_MAX_DSCP_QOS_PROFILE]
                    else:
                        port_fwd_inst_list[port].sp_def_tc = tc_list[ind] = rng.randint(0,15)
                        port_fwd_inst_list[port].sp_def_dp = dp_list[ind] = rng.randint(0,3)
                    port_fwd_inst_list[port].sp_cookie = rng.randint(1, 1023)
                else:
                    port_fwd_inst_list[port].sp_def_tc = 0
                    port_fwd_inst_list[port].sp_def_dp = 0
                    port_fwd_inst_list[port].sp_cookie = 0


                attr_list  = (ifcs_ctypes.ifcs_attr_t * 3)()
                attr_count = 0

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_SYSPORT_ATTR_DEFAULT_TC
                attr_list[attr_count].value.u32    = port_fwd_inst_list[port].sp_def_tc
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_SYSPORT_ATTR_DEFAULT_DP
                attr_list[attr_count].value.u32    = port_fwd_inst_list[port].sp_def_dp
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_SYSPORT_ATTR_USER_COOKIE
                attr_list[attr_count].value.u32    = port_fwd_inst_list[port].sp_cookie
                attr_count += 1

                rc = ifcs_ctypes.ifcs_sysport_attr_set(self.cli.node_id,
                                                port_fwd_inst_list[port].sp_hdl,
                                                attr_count,
                                                attr_list)
                spstcommon_handle_device_access_error(rc, "ifcs_sysport_attr_set")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "sysport setAttr failed: port: {0}, rc :{1}".format(
                     port, rc)

                log_dbg(1, "   Configured sysports successfully")
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Error setting sysport params")
            err = 1

        return err


    def configDevportsEnable(self, sinst_info):
        #Set devport admin state back to UP
        err = 0
        try:
            log_dbg(1, "Enabling devports")
            for port in sinst_info.devport_list:
                self.configDevportSetAdminState(sinst_info, port, ifcs_ctypes.IFCS_BOOL_TRUE)
            log_dbg(1, "   Enabled devports successfully")
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Error setting devport admin state to UP")
            err = 1
        return err

    def configDevportsDisable(self, sinst_info):
        #Set devport admin state to DOWN
        err = 0
        try:
            log_dbg(1, "Disabling ports")
            for port in sinst_info.devport_list:
                self.configDevportSetAdminState(sinst_info, port, ifcs_ctypes.IFCS_BOOL_FALSE)
            log_dbg(1, "   Disabled devports successfully")
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Error setting devport admin state to DOWN")
            err = 1
        return err

    def configDevportsLoopback(self, sinst_info, loopback_type='NONE'):
        log_dbg(1, "Setting Loopback type for all ports")
        err = 0
        try:
            devport_attr_ct = 1
            devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
            if (loopback_type == 'PCS'):
                lb = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_PCS
            elif (loopback_type == 'PMA'):
                lb = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_PMA
            elif (loopback_type == 'NONE'):
                lb = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_NONE
            else:
                log_err("Invalid loopback type specified: {0}".format(loopback_type))
                lb_config_failed = 1
                return lb_config_failed

            # Set loopback type for all devports
            for port in sinst_info.devport_list:
                devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LOOPBACK
                devport_attr[0].value.u32 = lb
                rc = ifcs_ctypes.ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t))
                spstcommon_handle_device_access_error(rc, "ifcs_devport_attr_set")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Devport loopback set to {0} FAILED. port={1} rc=[{2}]".format(loopback_type, port, rc)
            log_dbg(1, "   Set loopback type successfully")

        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Hit except (Devport loopback) config")
            err = 1

        return err

    def configL3vniCreate(self, sinst_info):
        '''
            Utility function to create one L3VNI per port
        '''
        global rng
        err = 0
        try:
            log_dbg(1, "Creating L3VNIs")
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            rand_l3vni_list = rng.sample(compat_listrange(1, 255), len(sinst_info.devport_list))
            for ind,port in enumerate(sinst_info.devport_list):
                l3vni_attr_count = 1
                l3vni_attr = ifcs_ctypes.ifcs_attr_t()
                l3vni_attr.id        = ifcs_ctypes.IFCS_L3VNI_ATTR_USER_COOKIE
                l3vni_attr.value.u32 = rng.randint(1, 1023)
                handle       = ifcs_ctypes.ifcs_handle_t()
                handle.value = ifcs_ctypes.IFCS_HANDLE_L3VNI(rand_l3vni_list[ind])
                rc = ifcs_ctypes.ifcs_l3vni_create(self.cli.node_id,
                                       pointer(handle),
                                       l3vni_attr_count,
                                       pointer(l3vni_attr))
                spstcommon_handle_device_access_error(rc, "ifcs_l3vni_create")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Failed to create l3vni {0} ret: {1}".format(port, rc)
                port_fwd_inst_list[port].l3vni_hdl = handle.value
                port_fwd_inst_list[port].l3vni_cookie = l3vni_attr.value.u32

            log_dbg(1, "   Created L3VNIs successfully")
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("L3vni create failed")
            err = 1

        return err

    def configQosMapDscpCreate(self, sinst_info):
        '''
            Utility function to create L3 Interfaces
        '''
        global rng
        err = 0
        try:
            log_dbg(1, "Creating qos maps/mapgroups for tc/dp to dscp")

            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            qos_grp_hdl = [0] * NUM_MAX_DSCP_QOS_PROFILE
            qos_map_hdl = [0] * NUM_MAX_DSCP_QOS_PROFILE
            dscp_list   = [0] * NUM_MAX_DSCP_QOS_PROFILE

            for ind,port in enumerate(sinst_info.devport_list):
                if ind >= NUM_MAX_DSCP_QOS_PROFILE:
                    if port == sinst_info.devport_list[-1] and (len(sinst_info.devport_list)%2 != 0):
                            port_fwd_inst_list[port].qosmap_grp_dscp_hdl = port_fwd_inst_list[sinst_info.devport_list[-3]].qosmap_grp_dscp_hdl
                            port_fwd_inst_list[port].qosmap_dscp_hdl     = port_fwd_inst_list[sinst_info.devport_list[-3]].qosmap_dscp_hdl
                            port_fwd_inst_list[port].dscp                = port_fwd_inst_list[sinst_info.devport_list[-3]].dscp

                    else:
                            port_fwd_inst_list[port].qosmap_grp_dscp_hdl = qos_grp_hdl[ind%NUM_MAX_DSCP_QOS_PROFILE]
                            port_fwd_inst_list[port].qosmap_dscp_hdl     = qos_map_hdl[ind%NUM_MAX_DSCP_QOS_PROFILE]
                            port_fwd_inst_list[port].dscp                = dscp_list[ind%NUM_MAX_DSCP_QOS_PROFILE]
                    continue


                qos_map_info = ifcs_ctypes.ifcs_qos_map_info_t()
                qos_map_info.type = ifcs_ctypes.IFCS_QOS_MAP_TYPE_TC_DP_TO_DSCP
                qos_map_info.list.arr = (ifcs_ctypes.ifcs_qos_map_t * 1)()

                if port == sinst_info.devport_list[0]:
                    if len(sinst_info.devport_list)%2 == 0:
                        indx = -1
                    else:
                        indx = -2
                    qos_map_info.list.arr[0].map_src.tc_dp.tc = port_fwd_inst_list[sinst_info.devport_list[indx]].sp_def_tc
                    qos_map_info.list.arr[0].map_src.tc_dp.dp = port_fwd_inst_list[sinst_info.devport_list[indx]].sp_def_dp
                else:
                    qos_map_info.list.arr[0].map_src.tc_dp.tc = port_fwd_inst_list[sinst_info.devport_list[ind-1]].sp_def_tc
                    qos_map_info.list.arr[0].map_src.tc_dp.dp = port_fwd_inst_list[sinst_info.devport_list[ind-1]].sp_def_dp

                qos_map_info.list.arr[0].map_value.dscp   = port_fwd_inst_list[port].dscp = dscp_list[ind] = rng.randint(0,63)
                # Override last port's dscp with pre-generated value
                if port == sinst_info.devport_list[0]:
                    qos_map_info.list.arr[0].map_value.dscp = port_fwd_inst_list[port].dscp = dscp_list[ind] = ((sinst_info.v4_dscp & 0xfc) >> 2)
                qos_map_info.list.count                   = 1

                attr_count = 0
                attr_list = (ifcs_ctypes.ifcs_attr_t * 1)()
                attr_list[attr_count].id = ifcs_ctypes.IFCS_QOS_MAP_ATTR_QOS_MAP_INFO
                attr_list[attr_count].value.qos_map_info = qos_map_info
                attr_count += 1

                qosmap_hdl = ifcs_ctypes.ifcs_handle_t()
                qosmap_hdl.value = ifcs_ctypes.IFCS_NULL_HANDLE

                rc = ifcs_ctypes.ifcs_qos_map_create(self.cli.node_id, pointer(qosmap_hdl), attr_count, attr_list)
                spstcommon_handle_device_access_error(rc, "ifcs_qos_map_create")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Failed to create qos map for intf " + str(port) + "ret: " + str(rc)
                port_fwd_inst_list[port].qosmap_dscp_hdl = qos_map_hdl[ind] = qosmap_hdl.value

                attr_count = 0
                attr_list = (ifcs_ctypes.ifcs_attr_t * 2)()
                attr_list[attr_count].id           = ifcs_ctypes.IFCS_QOS_MAP_GROUP_ATTR_ACTION_TYPE
                attr_list[attr_count].value.u32    = ifcs_ctypes.IFCS_QOS_ACTION_TYPE_MARK
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_QOS_MAP_GROUP_ATTR_TC_DP_TO_DSCP
                attr_list[attr_count].value.handle = qosmap_hdl
                attr_count += 1

                qosmap_grp_hdl = ifcs_ctypes.ifcs_handle_t()
                qosmap_grp_hdl.value = ifcs_ctypes.IFCS_NULL_HANDLE

                rc = ifcs_ctypes.ifcs_qos_map_group_create(self.cli.node_id, pointer(qosmap_grp_hdl), attr_count, attr_list)
                spstcommon_handle_device_access_error(rc, "ifcs_qos_map_group_create")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Failed to create qos map for intf " + str(port) + "ret: " + str(rc)
                port_fwd_inst_list[port].qosmap_grp_dscp_hdl = qos_grp_hdl[ind] = qosmap_grp_hdl.value

            log_dbg(1, "   Created Qos Maps/Groups successfully")
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Error creating QOS Maps/Groups interfaces")
            err = 1

        return err

    def configQosMapDot1pCfiCreate(self, sinst_info):
        '''
            Utility function to create L3 Interfaces
        '''
        global rng
        err = 0
        try:
            log_dbg(1, "Creating qos maps/mapgroups for tc/dp to dot1p cfi")

            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            qos_grp_hdl = [0] * NUM_MAX_DOT1PCFI_QOS_PROFILE
            qos_map_hdl = [0] * NUM_MAX_DOT1PCFI_QOS_PROFILE
            dot1p_list  = [0] * NUM_MAX_DOT1PCFI_QOS_PROFILE
            cfi_list    = [0] * NUM_MAX_DOT1PCFI_QOS_PROFILE

            for ind,port in enumerate(sinst_info.devport_list):

                if ind >= NUM_MAX_DOT1PCFI_QOS_PROFILE:
                    if port == sinst_info.devport_list[-1] and (len(sinst_info.devport_list)%2 != 0):
                        port_fwd_inst_list[port].qosmap_grp_dot1pcfi_hdl = port_fwd_inst_list[sinst_info.devport_list[-3]].qosmap_grp_dot1pcfi_hdl
                        port_fwd_inst_list[port].qosmap_dot1pcfi_hdl     = port_fwd_inst_list[sinst_info.devport_list[-3]].qosmap_dot1pcfi_hdl
                        port_fwd_inst_list[port].dot1p                   = port_fwd_inst_list[sinst_info.devport_list[-3]].dot1p
                        port_fwd_inst_list[port].cfi                     = port_fwd_inst_list[sinst_info.devport_list[-3]].cfi
                    else:
                        port_fwd_inst_list[port].qosmap_grp_dot1pcfi_hdl = qos_grp_hdl[ind%NUM_MAX_DOT1PCFI_QOS_PROFILE]
                        port_fwd_inst_list[port].qosmap_dot1pcfi_hdl     = qos_map_hdl[ind%NUM_MAX_DOT1PCFI_QOS_PROFILE]
                        port_fwd_inst_list[port].dot1p                   = dot1p_list[ind%NUM_MAX_DOT1PCFI_QOS_PROFILE]
                        port_fwd_inst_list[port].cfi                     = cfi_list[ind%NUM_MAX_DOT1PCFI_QOS_PROFILE]
                    continue
                qos_map_info = ifcs_ctypes.ifcs_qos_map_info_t()
                qos_map_info.type = ifcs_ctypes.IFCS_QOS_MAP_TYPE_TC_DP_TO_DOT1P_CFI
                qos_map_info.list.arr = (ifcs_ctypes.ifcs_qos_map_t * 1)()

                if port == sinst_info.devport_list[0]:
                    if len(sinst_info.devport_list)%2 == 0:
                        indx = -1
                    else:
                        indx = -2
                    qos_map_info.list.arr[0].map_src.tc_dp.tc = port_fwd_inst_list[sinst_info.devport_list[indx]].sp_def_tc
                    qos_map_info.list.arr[0].map_src.tc_dp.dp = port_fwd_inst_list[sinst_info.devport_list[indx]].sp_def_dp
                else:
                    qos_map_info.list.arr[0].map_src.tc_dp.tc = port_fwd_inst_list[sinst_info.devport_list[ind-1]].sp_def_tc
                    qos_map_info.list.arr[0].map_src.tc_dp.dp = port_fwd_inst_list[sinst_info.devport_list[ind-1]].sp_def_dp

                qos_map_info.list.arr[0].map_value.dot1p_cfi.dot1p   = port_fwd_inst_list[port].dot1p = dot1p_list[ind] = rng.randint(0,7)
                qos_map_info.list.arr[0].map_value.dot1p_cfi.cfi     = port_fwd_inst_list[port].cfi   = cfi_list[ind] = rng.randint(0,1)
                # Override last port's dscp with pre-generated value
                if port == sinst_info.devport_list[0]:
                    qos_map_info.list.arr[0].map_value.dot1p_cfi.dot1p = port_fwd_inst_list[port].dot1p = dot1p_list[ind] = (sinst_info.dot1q_pcp)
                    qos_map_info.list.arr[0].map_value.dot1p_cfi.cfi   = port_fwd_inst_list[port].cfi = cfi_list[ind] = (sinst_info.dot1q_dei)
                qos_map_info.list.count                   = 1

                attr_count = 0
                attr_list = (ifcs_ctypes.ifcs_attr_t * 1)()
                attr_list[attr_count].id = ifcs_ctypes.IFCS_QOS_MAP_ATTR_QOS_MAP_INFO
                attr_list[attr_count].value.qos_map_info = qos_map_info
                attr_count += 1

                qosmap_hdl = ifcs_ctypes.ifcs_handle_t()
                qosmap_hdl.value = ifcs_ctypes.IFCS_NULL_HANDLE

                rc = ifcs_ctypes.ifcs_qos_map_create(self.cli.node_id, pointer(qosmap_hdl), attr_count, attr_list)
                spstcommon_handle_device_access_error(rc, "ifcs_qos_map_create")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Failed to create qos map for dsp " + str(port) + "ret: " + str(rc)
                port_fwd_inst_list[port].qosmap_dot1pcfi_hdl = qos_map_hdl[ind] = qosmap_hdl.value

                attr_count = 0
                attr_list = (ifcs_ctypes.ifcs_attr_t * 2)()
                attr_list[attr_count].id           = ifcs_ctypes.IFCS_QOS_MAP_GROUP_ATTR_ACTION_TYPE
                attr_list[attr_count].value.u32    = ifcs_ctypes.IFCS_QOS_ACTION_TYPE_MARK
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_QOS_MAP_GROUP_ATTR_TC_DP_TO_DOT1P_CFI
                attr_list[attr_count].value.handle = qosmap_hdl
                attr_count += 1

                qosmap_grp_hdl = ifcs_ctypes.ifcs_handle_t()
                qosmap_grp_hdl.value = ifcs_ctypes.IFCS_NULL_HANDLE

                rc = ifcs_ctypes.ifcs_qos_map_group_create(self.cli.node_id, pointer(qosmap_grp_hdl), attr_count, attr_list)
                spstcommon_handle_device_access_error(rc, "ifcs_qos_map_group_create")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Failed to create qos map for intf " + str(port) + "ret: " + str(rc)
                port_fwd_inst_list[port].qosmap_grp_dot1pcfi_hdl = qos_grp_hdl[ind] = qosmap_grp_hdl.value

            log_dbg(1, "Created Qos Maps/Groups for tc/dp to dot1pcfi successfully")
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Error creating QOS Maps/Groups interfaces")
            err = 1

        return err

    def configSysportDot1pCfiMap(self, sinst_info, config = 1):
        '''
            Utility function to config sysports qosmap
        '''
        err = 0
        try:
            log_dbg(1, "Configure sysports as qosmap group")
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            # Set sysport's qosmap
            for port in sinst_info.devport_list:
                attr = ifcs_ctypes.ifcs_attr_t()
                rc = ifcs_ctypes.ifcs_attr_t_init(pointer(attr))
                assert rc == ifcs_ctypes.IFCS_SUCCESS

                # Set sysport qosmap group
                attr_list  = (ifcs_ctypes.ifcs_attr_t * 1)()
                attr_count = 0
                attr_list[attr_count].id           = ifcs_ctypes.IFCS_SYSPORT_ATTR_QOS_TC_DP_TO_DOT1P_CFI_MAP
                if config == 1:
                    attr_list[attr_count].value.handle = port_fwd_inst_list[port].qosmap_grp_dot1pcfi_hdl
                else:
                    attr_list[attr_count].value.handle = 0

                attr_count += 1

                rc = ifcs_ctypes.ifcs_sysport_attr_set(self.cli.node_id,
                                                port_fwd_inst_list[port].sp_hdl,
                                                attr_count,
                                                attr_list)
                spstcommon_handle_device_access_error(rc, "ifcs_sysport_attr_set")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "sysport qosmap grp setAttr failed: port: {0}, rc :{1}".format(
                     port, rc)

                log_dbg(1, "   Configured sysports with qosmap grp successfully")
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Error setting sysport qosmap grp")
            err = 1

        return err

    def configIntfCreate(self, sinst_info):
        '''
            Utility function to create L3 Interfaces
        '''
        err = 0
        global rng
        try:
            log_dbg(1, "Creating L3 interfaces")

            flag = True
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            rand_vlan_list = rng.sample(compat_listrange(1, 4095), len(sinst_info.devport_list))
            rand_intf_list = rng.sample(compat_listrange(1, 60415), len(sinst_info.devport_list))
            for ind,port in enumerate(sinst_info.devport_list):
                if flag is True:
                    transportMac = sinst_info.intfmac1
                    flag = False
                else:
                    transportMac = sinst_info.intfmac2
                    flag = True


                attr_list  = (ifcs_ctypes.ifcs_attr_t * 10)()
                attr_count = 0
                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_TYPE
                attr_list[attr_count].value.u32    = ifcs_ctypes.IFCS_INTF_TYPE_L3_PORT_CVID
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_FORWARDING_INSTANCE
                attr_list[attr_count].value.handle = port_fwd_inst_list[port].l3vni_hdl
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_TRANSPORT_INSTANCE
                attr_list[attr_count].value.handle = port_fwd_inst_list[port].sp_hdl
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_TRANSPORT_MAC
                attr_list[attr_count].value.mac    = transportMac
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_IPV4_UNICAST_ENABLE
                attr_list[attr_count].value.data   = True
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_TRANSPORT_CVID
                attr_list[attr_count].value.u16    = rand_vlan_list[ind]
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_QOS_TC_DP_TO_DSCP_MAP
                attr_list[attr_count].value.handle = port_fwd_inst_list[port].qosmap_grp_dscp_hdl
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_USER_COOKIE
                attr_list[attr_count].value.u32    = port_fwd_inst_list[port].intf_cookie = rng.randint(1,1023)
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_EGRESS_USER_COOKIE
                attr_list[attr_count].value.u32    = port_fwd_inst_list[port].intf_egr_cookie = rng.randint(1,15)
                attr_count += 1

                handle = ifcs_ctypes.ifcs_handle_t()
                handle.value = ifcs_ctypes.IFCS_HANDLE_INTF(rand_intf_list[ind])
                rc = ifcs_ctypes.ifcs_intf_create(self.cli.node_id, pointer(handle), attr_count, attr_list)
                spstcommon_handle_device_access_error(rc, "ifcs_intf_create")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Failed to create intf " + str(port) + "ret: " + str(rc)
                port_fwd_inst_list[port].intf_hdl = handle.value
                port_fwd_inst_list[port].si_vlan  = rand_vlan_list[ind]


            log_dbg(1, "   Created L3 interfaces successfully")
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Error creating L3 interfaces")
            err = 1

        return err

    def configNexthopCreate(self, sinst_info):
        '''
            Utility function to create Nexthops
        '''
        err = 0
        try:
            log_dbg(1, "Creating Nexthops")
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            for nh_iter in range(NUM_NH_PER_PORT):
                flag = True
                for port in sinst_info.devport_list:
                    if flag is False:
                        dest_mac = sinst_info.intfmac1
                        flag = True
                    else:
                        dest_mac = sinst_info.intfmac2
                        flag = False

                    attr_list = (ifcs_ctypes.ifcs_attr_t * 10)()
                    attr_count = 0
                    attr_list[attr_count].id           = ifcs_ctypes.IFCS_NEXTHOP_ATTR_INTF
                    attr_list[attr_count].value.handle = port_fwd_inst_list[port].intf_hdl
                    attr_count += 1

                    attr_list[attr_count].id           = ifcs_ctypes.IFCS_NEXTHOP_ATTR_DEST_MAC
                    attr_list[attr_count].value.mac    = dest_mac
                    attr_count += 1

                    attr_list[attr_count].id           = ifcs_ctypes.IFCS_NEXTHOP_ATTR_LOCAL_DESTINATION
                    attr_list[attr_count].value.handle = port_fwd_inst_list[port].sp_hdl
                    attr_count += 1

                    attr_list[attr_count].id           = ifcs_ctypes.IFCS_NEXTHOP_ATTR_NO_DECREMENT_TTL
                    attr_list[attr_count].value.u8     = 1
                    attr_count += 1

                    attr_list[attr_count].id           = ifcs_ctypes.IFCS_NEXTHOP_ATTR_USER_COOKIE
                    attr_list[attr_count].value.u32    = port_fwd_inst_list[port].nh_cookie_list[nh_iter] = rng.randint(1,15)
                    attr_count += 1

                    handle       = ifcs_ctypes.ifcs_handle_t()
                    handle.value = ifcs_ctypes.IFCS_NULL_HANDLE
                    rc = ifcs_ctypes.ifcs_nexthop_create(self.cli.node_id,
                                             pointer(handle),
                                             attr_count,
                                             attr_list)
                    spstcommon_handle_device_access_error(rc, "ifcs_nexthop_create")
                    assert rc == ifcs_ctypes.IFCS_SUCCESS, "Failed to create nexthop {0} ret: {1}".format(port, rc)
                    port_fwd_inst_list[port].nh_hdls[nh_iter] = handle.value

            log_dbg(1, "   Created Nexthops successfully")
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Error creating nexthops")
            err = 1

        return err

    def configRouteCreateInternal(self, sinst_info, ipv4 = 1):
        err = 0
        global rng
        try:
            port_fwd_inst_list = sinst_info.port_fwd_inst_list

            fwd_policy             =  ifcs_ctypes.ifcs_fwd_policy_t()
            fwd_policy.fwd_action  =  ifcs_ctypes.IFCS_FWD_ACTION_FORWARD
            ip_addr   = ifcs_ctypes.ifcs_ip_addr_t()
            mask      = ifcs_ctypes.ifcs_ip_addr_t()
            if ipv4 == 1:
                # configure FWD routes
                # set FWD ip addr
                ip_addr.ipv4 = sinst_info.ip1
                # configure same ip in all VRF aka L3VNI
                mask.ipv4 =  0xffffffff
            else:
                for dip_offset in range(0,16):
                    ip_addr.ipv6[dip_offset] = sinst_info.v6_dip[dip_offset]

                mask.ipv6    = (0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF)

            log_dbg(1, "Creating Route entries")


            # set FWD port list
            port_list = sinst_info.devport_list

            '''
            Bidir Cross
            Fwd Flow: (Ixia -> 1 (->2); 2 -> 3(->4), 4 -> Ixia ... )
                > Incoming on Odd ports, Outgoing on Even ports

            Rev Flow: (Ixia -> 4 (->3); 3 -> 2(->1); 1 -> Ixia ... )
                > Incoming on Even ports, Outgoing on Odd ports

            Bidir Straight
            Fwd Flow: (Ixia -> 1; 1<->2(->3); 3<->4; 4 -> Ixia ... )
                > Incoming on Odd ports, Outgoing on Even ports

            Rev Flow: (Ixia -> 4; 4<->3(->2); 2<->1; 1 -> Ixia ... )
                > Incoming on Even ports, Outgoing on Odd ports
            '''
            for i, port in enumerate(port_list):
                # FWD/REV BIDIR_CROSS : ingress is on every other port starting from the 1st port
                #      in the port list
                # So, skip alternate ports starting from the second port
                #
                # FWD/REV BIDIR_STRAIGHT : ingress is on every other port starting from the 2nd port
                #      in the reversed port list
                # So, skip alternate ports starting from the first port
                #
                # FWD UNIDIR : ingress is on each port as all ports are in loopback mode
                # So, do not skip any port
                if (sinst_info.type == 'bidir_cross' and (i % 2)) or (sinst_info.type == 'bidir_straight' and (i % 2 == 0)):
                    continue

                # Last route should map to port1 nh
                nh_id_picked = rng.randint(0, NUM_NH_PER_PORT-1)
                if port == port_list[-1]:
                    nh = port_fwd_inst_list[port_list[0]].nh_hdls[nh_id_picked]
                    nh_cookie = port_fwd_inst_list[port_list[0]].nh_cookie_list[nh_id_picked]
                    if ipv4 == 1:
                        port_fwd_inst_list[port_list[0]].nh4_picked_hdl = nh
                        port_fwd_inst_list[port_list[0]].nh4_picked_cookie = nh_cookie

                    else:
                        port_fwd_inst_list[port_list[0]].nh6_picked_hdl = nh
                        port_fwd_inst_list[port_list[0]].nh6_picked_cookie = nh_cookie

                else:
                    nh  = port_fwd_inst_list[port_list[i+1]].nh_hdls[nh_id_picked]
                    nh_cookie = port_fwd_inst_list[port_list[i+1]].nh_cookie_list[nh_id_picked]
                    if ipv4 == 1:
                        port_fwd_inst_list[port_list[i+1]].nh4_picked_hdl = nh
                        port_fwd_inst_list[port_list[i+1]].nh4_picked_cookie = nh_cookie
                    else:
                        port_fwd_inst_list[port_list[i+1]].nh6_picked_hdl = nh
                        port_fwd_inst_list[port_list[i+1]].nh6_picked_cookie = nh_cookie

                # Create key
                ip_dest = ifcs_ctypes.ifcs_ip_prefix_t()
                ifcs_ctypes.ifcs_ip_prefix_t_init(pointer(ip_dest))
                if ipv4 == 1:
                    ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)
                else:
                    ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

                ifcs_ctypes.ifcs_ip_prefix_t_addr_set(pointer(ip_dest), pointer(ip_addr))
                ifcs_ctypes.ifcs_ip_prefix_t_mask_set(pointer(ip_dest), pointer(mask))

                route_entry_key = ifcs_ctypes.ifcs_route_entry_key_t()
                ifcs_ctypes.ifcs_route_entry_key_t_init(pointer(route_entry_key))
                ifcs_ctypes.ifcs_route_entry_key_t_key_type_set(pointer(route_entry_key),
                    ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_L3VNI)
                ifcs_ctypes.ifcs_route_entry_key_t_ip_dest_l3vni_set(pointer(route_entry_key),
                    route_entry_key.key.ip_dest_l3vni)
                ifcs_ctypes.ifcs_route_entry_key_ip_dest_l3vni_t_l3vni_set(pointer(route_entry_key.key.ip_dest_l3vni),
                    port_fwd_inst_list[port].l3vni_hdl)
                ifcs_ctypes.ifcs_route_entry_key_ip_dest_l3vni_t_ip_dest_set(pointer(route_entry_key.key.ip_dest_l3vni),
                    pointer(ip_dest))

                attr_list                              =   (ifcs_ctypes.ifcs_attr_t * 10)()
                attr_count                             =   0
                attr_list[attr_count].id               =   ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_NEXTHOP
                attr_list[attr_count].value.handle     =   nh
                attr_count += 1

                attr_list[attr_count].id               =   ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_FWD_POLICY
                attr_list[attr_count].value.fwd_policy =   fwd_policy
                attr_count += 1

                attr_list[attr_count].id               =   ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_USER_COOKIE
                if ipv4 == 1:
                    attr_list[attr_count].value.u32        =   port_fwd_inst_list[port].v4_route_cookie = rng.randint(1,255)
                else:
                    attr_list[attr_count].value.u32        =   port_fwd_inst_list[port].v6_route_cookie = rng.randint(1,255)

                attr_count += 1

                rc =   ifcs_ctypes.ifcs_route_entry_create(self.cli.node_id,
                                               pointer(route_entry_key),
                                               attr_count,
                                               attr_list)
                spstcommon_handle_device_access_error(rc, "ifcs_route_entry_create")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Failed to create route entry for port {0} ret: {1}".format(port, rc)
            log_dbg(1, "   Created {0} route entries successfully".format(sinst_info.type))
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except Exception as e:
            log_err("Error creating route entries: {}".format(e))
            err = 1

        return err

    def configV4RouteCreate(self, sinst_info):
        '''
            Utility function to create V4 Route entries
        '''
        # Create FWD route entries
        return self.configRouteCreateInternal(sinst_info, 1)

    def configV6RouteCreate(self, sinst_info):
        '''
            Utility function to create V6 Route entries
        '''
        # Create FWD route entries
        return self.configRouteCreateInternal(sinst_info, 0)

    def configDcdpCreate(self, sinst_info):
        err = 0
        try:
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            for ind,port in enumerate(sinst_info.mirror_port_list):
                attr_count = 0
                dcdp_attr = ifcs_ctypes.ifcs_attr_t()
                dcdp_attr.id = ifcs_ctypes.IFCS_DUP_COPY_DEST_PORT_ATTR_SYSPORT
                dcdp_attr.value.handle = port_fwd_inst_list[port].sp_hdl

                dcdp_hdl = ifcs_ctypes.ifcs_handle_t()
                dcdp_hdl.value = ifcs_ctypes.IFCS_NULL_HANDLE
                attr_count += 1

                rc = ifcs_ctypes.ifcs_dup_copy_dest_port_create(self.cli.node_id, pointer(dcdp_hdl), attr_count, pointer(dcdp_attr))
                spstcommon_handle_device_access_error(rc, "ifcs_dup_copy_dest_port_create")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Failed to create DCDP port {0} ret: {1}".format(port, rc)
                port_fwd_inst_list[port].dcdp_hdl = dcdp_hdl.value
                log_dbg(1, "   Configured DCDP successfully")
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Error in creating DCDP")
            err = 1

        return err

    def configCollectorCreate(self, sinst_info):
        err = 0
        try:
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            for ind,port in enumerate(sinst_info.mirror_port_list):
                attr_list = (ifcs_ctypes.ifcs_attr_t * 3)()
                attr_count = 0
                attr_list[attr_count].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_COLLECTOR_TYPE
                attr_list[attr_count].value.u32 = ifcs_ctypes.IFCS_COLLECTOR_TYPE_SPAN

                attr_count += 1
                attr_list[attr_count].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DIRECTION
                attr_list[attr_count].value.u32 = ifcs_ctypes.IFCS_TRAFFIC_MONITOR_DIRECTION_EGRESS

                attr_count += 1
                attr_list[attr_count].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DCDP
                attr_list[attr_count].value.handle = port_fwd_inst_list[port].dcdp_hdl

                collector_hdl = ifcs_ctypes.ifcs_handle_t()
                collector_hdl.value = ifcs_ctypes.IFCS_NULL_HANDLE
                attr_count += 1
                rc = ifcs_ctypes.ifcs_collector_create(self.cli.node_id, pointer(collector_hdl), attr_count, attr_list)
                spstcommon_handle_device_access_error(rc, "ifcs_collector_create")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Failed to create Collector {0} ret: {1}".format(ind, rc)
                sinst_info.collector_hdl[ind] = collector_hdl.value
                log_dbg(1, "   Created Collectors successfully")
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Error in creating Collectors")
            err = 1

        return err

    def configCollectorSetCreate(self, sinst_info):
        err = 0
        try:
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            member_hdl_list = (ifcs_ctypes.ifcs_handle_t * 4)()
            for ind,port in enumerate(sinst_info.mirror_port_list):
                attr_list = (ifcs_ctypes.ifcs_attr_t * 2)()
                attr_count = 0
                attr_list[attr_count].id = ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_COLLECTOR_SET_TYPE
                attr_list[attr_count].value.u32 = ifcs_ctypes.IFCS_COLLECTOR_TYPE_SPAN

                attr_count += 1
                attr_list[attr_count].id = ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_DIRECTION
                attr_list[attr_count].value.u32 = ifcs_ctypes.IFCS_TRAFFIC_MONITOR_DIRECTION_EGRESS
                attr_count += 1

                collector_set_hdls = ifcs_ctypes.ifcs_handle_t()
                collector_set_hdls.value = ifcs_ctypes.IFCS_NULL_HANDLE
                rc = ifcs_ctypes.ifcs_collector_set_create(self.cli.node_id, pointer(collector_set_hdls), attr_count, attr_list)
                spstcommon_handle_device_access_error(rc, "ifcs_collector_set_create")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Failed to create Collector Set {0} ret: {1}".format(ind, rc)

                member_count = 4
                for i in range(member_count):
                    if ind+i < self.num_ibs:
                        member_hdl_list[i] = sinst_info.collector_hdl[ind+i]
                    else:
                        member_hdl_list[i] = sinst_info.collector_hdl[ind+i-self.num_ibs]
                rc = ifcs_ctypes.ifcs_collector_set_member_add(self.cli.node_id, collector_set_hdls, member_count, member_hdl_list, 0, None)
                spstcommon_handle_device_access_error(rc, "ifcs_collector_set_member_add")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Failed to add Members to Collector Set {0} ret: {1}".format(ind, rc)
                sinst_info.collector_set_hdls[ind] = collector_set_hdls.value

                log_dbg(1, "   Created Collector Sets successfully")
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Error in creating Collector Sets")
            err = 1

        return err

    def configRouteDropruleInternal(self, sinst_info, port_fwd_inst_list, drop_port, ipv4):
        err = 0
        ipSubnet  = ifcs_ctypes.ifcs_ip_addr_t()
        mask      = ifcs_ctypes.ifcs_ip_addr_t()
        ip_dest = ifcs_ctypes.ifcs_ip_prefix_t()
        ifcs_ctypes.ifcs_ip_prefix_t_init(pointer(ip_dest))
        if ipv4:
            ipSubnet.ipv4 = sinst_info.ip1
            mask.ipv4 =  0xffffffff
            ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)
        else:
            for dip_offset in range(0,16):
                ipSubnet.ipv6[dip_offset] = sinst_info.v6_dip[dip_offset]
            mask.ipv6 = (0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF)
            ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)


        ifcs_ctypes.ifcs_ip_prefix_t_addr_set(pointer(ip_dest), pointer(ipSubnet))
        ifcs_ctypes.ifcs_ip_prefix_t_mask_set(pointer(ip_dest), pointer(mask))

        route_entry_key = ifcs_ctypes.ifcs_route_entry_key_t()
        ifcs_ctypes.ifcs_route_entry_key_t_init(pointer(route_entry_key))
        ifcs_ctypes.ifcs_route_entry_key_t_key_type_set(pointer(route_entry_key),
                ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_L3VNI)
        ifcs_ctypes.ifcs_route_entry_key_t_ip_dest_l3vni_set(pointer(route_entry_key),
                route_entry_key.key.ip_dest_l3vni)
        ifcs_ctypes.ifcs_route_entry_key_ip_dest_l3vni_t_l3vni_set(pointer(route_entry_key.key.ip_dest_l3vni),
                port_fwd_inst_list[drop_port].l3vni_hdl)
        ifcs_ctypes.ifcs_route_entry_key_ip_dest_l3vni_t_ip_dest_set(pointer(route_entry_key.key.ip_dest_l3vni),
                pointer(ip_dest))

        attr_list                              = (ifcs_ctypes.ifcs_attr_t * 10)()
        attr_count                             = 0

        fwd_policy = ifcs_ctypes.ifcs_fwd_policy_t()
        fwd_policy.fwd_action                  = ifcs_ctypes.IFCS_FWD_ACTION_DROP
        attr_list[attr_count].id               = ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_FWD_POLICY
        attr_list[attr_count].value.fwd_policy = fwd_policy
        attr_count += 1
        if sinst_info.vos == 1:
            ctc_policy = ifcs_ctypes.ifcs_ctc_policy_t()
            ifcs_ctypes.ifcs_ctc_policy_t_init(pointer(ctc_policy))
            ctc_policy.ctc_action = ifcs_ctypes.IFCS_COPY_TO_CPU_ENABLE
            if self.trap_hdl.value == 0:
                log_err("ctc policy trap handle is 0")
                assert 0, "ctc policy trap handle is 0"
            ctc_policy.trap_handle = self.trap_hdl
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_CTC_POLICY)
            ifcs_ctypes.ifcs_attr_t_value_ctc_policy_set(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, attr_count), pointer(ctc_policy))
            attr_count += 1

        rc = ifcs_ctypes.ifcs_route_entry_attr_set(self.cli.node_id,
                                       pointer(route_entry_key),
                                       attr_count,
                                       attr_list)
        spstcommon_handle_device_access_error(rc, "ifcs_route_entry_attr_set")
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("Failed to set route entry attr to drop for port {0}, ret:{1}".format(drop_port, rc))
            err = 1

        return err,route_entry_key

    def configV4RouteDroprule(self, sinst_info, port_fwd_inst_list, drop_port):
        return self.configRouteDropruleInternal(sinst_info, port_fwd_inst_list, drop_port, 1)

    def configV6RouteDroprule(self, sinst_info, port_fwd_inst_list, drop_port):
        return self.configRouteDropruleInternal(sinst_info, port_fwd_inst_list, drop_port, 0)

    def clearRouteDroprule(self, sinst_info, route_entry_key):
        err = 0
        # Use previously created route_entry key, change fwd_policy attr action to forward
        attr_list                              =   (ifcs_ctypes.ifcs_attr_t * 10)()
        attr_count                             =   0

        fwd_policy = ifcs_ctypes.ifcs_fwd_policy_t()
        fwd_policy.fwd_action                  =   ifcs_ctypes.IFCS_FWD_ACTION_FORWARD
        attr_list[attr_count].id               =   ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_FWD_POLICY
        attr_list[attr_count].value.fwd_policy =   fwd_policy
        attr_count += 1

        if sinst_info.vos == 1:
            ctc_policy = ifcs_ctypes.ifcs_ctc_policy_t()
            ifcs_ctypes.ifcs_ctc_policy_t_init(pointer(ctc_policy))
            ctc_policy.ctc_action = ifcs_ctypes.IFCS_COPY_TO_CPU_DISABLE
            ctc_policy.trap_handle = self.trap_hdl
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_CTC_POLICY)
            ifcs_ctypes.ifcs_attr_t_value_ctc_policy_set(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, attr_count), pointer(ctc_policy))
            attr_count += 1

        rc = ifcs_ctypes.ifcs_route_entry_attr_set(self.cli.node_id,
                                       pointer(route_entry_key),
                                       attr_count,
                                       attr_list)
        spstcommon_handle_device_access_error(rc, "ifcs_route_entry_attr_set")
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("Failed to set route entry attr to forward for port {0}, ret: {1}".format(drop_port_list[i], rc))
            err = 1

        return err

    '''
    def clearV4RouteDroprule(self, sinst_info, route_entry_key):
        return self.clearRouteDropruleInternal(sinst_info, route_entry_key, 1)

    def clearV6RouteDroprule(self, sinst_info, route_entry_key):
        return self.clearRouteDropruleInternal(sinst_info, route_entry_key, 0)
    '''

    def configRouteDeleteInternal(self, sinst_info, ipv4 = 1):
        err =0
        try:
            def myCallback(node_id, arg, attr_count, attr_list, user_data):
                key_obj = ifcs_ctypes.ifcs_route_entry_key_t()
                memmove(pointer(key_obj), arg, sizeof(key_obj))
                route_entry_list.append(pointer(key_obj))

            route_entry_list = []

            callback_type = CFUNCTYPE(ifcs_ctypes.UNCHECKED(None),
                                      ifcs_ctypes.ifcs_node_id_t,
                                      POINTER(ifcs_ctypes.ifcs_route_entry_key_t),
                                      c_uint32,
                                      POINTER(ifcs_ctypes.ifcs_attr_t),
                                      POINTER(None))
            callback = callback_type(myCallback)

            log_dbg(1, "Deleting Route entries")


            # set FWD port list
            port_list = sinst_info.devport_list
            port_fwd_inst_list = sinst_info.port_fwd_inst_list

            for i, port in enumerate(port_list):
                # FWD/REV BIDIR_CROSS : ingress is on every other port starting from the 1st port
                #      in the port list
                # So, skip alternate ports starting from the second port
                #
                # FWD/REV BIDIR_STRAIGHT : ingress is on every other port starting from the 2nd port
                #      in the reversed port list
                # So, skip alternate ports starting from the first port
                #
                # FWD UNIDIR : ingress is on each port as all ports are in loopback mode
                # So, do not skip any port
                if (sinst_info.type == 'bidir_cross' and (i % 2)) or (sinst_info.type == 'bidir_straight' and (i % 2 == 0)):
                    continue

                # Last route should map to port1 nh
                # Last route should map to port1 nh
                if port == port_list[-1]:
                    if ipv4 == 1:
                        nh  = port_fwd_inst_list[port_list[0]].nh4_picked_hdl
                    else:
                        nh  = port_fwd_inst_list[port_list[0]].nh6_picked_hdl

                else:
                    if ipv4 == 1:
                        nh  = port_fwd_inst_list[port_list[i+1]].nh4_picked_hdl
                    else:
                        nh  = port_fwd_inst_list[port_list[i+1]].nh6_picked_hdl


                attr_list                              =   (ifcs_ctypes.ifcs_attr_t * 10)()
                attr_count                             =   0
                attr_list[attr_count].id               =   ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_NEXTHOP
                attr_list[attr_count].value.handle     =   nh
                attr_count                            +=   1

                rc = ifcs_ctypes.ifcs_route_entry_get_all(self.cli.node_id,
                                              None,
                                              attr_count,
                                              attr_list,
                                              compat_funcPointer(callback, ifcs_ctypes.ifcs_route_entry_user_cb_t),
                                              None,
                                              None)
                spstcommon_handle_device_access_error(rc, "ifcs_route_entry_get_all")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Route entry get failed for port {0}: rc {1}".format(port, rc)

            for route in route_entry_list:
                rc = ifcs_ctypes.ifcs_route_entry_delete(self.cli.node_id,
                                             route)
                spstcommon_handle_device_access_error(rc, "ifcs_route_entry_delete")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Route entry delete failed: rc {0}".format(rc)

            log_dbg(1, "   Deleted {0} route entries successfully".format(sinst_info.type))
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except Exception as e:
            log_err("Error deleting route entries: {}".format(e))
            err = 1

        return err

    def configV4RouteDelete(self, sinst_info):
        '''
            Utility function to delete route entries
        '''
        # Delete V4 FWD route entries
        return self.configRouteDeleteInternal(sinst_info, 1)

    def configV6RouteDelete(self, sinst_info):
        '''
            Utility function to delete route entries
        '''
        # Delete V6 FWD route entries
        return self.configRouteDeleteInternal(sinst_info, 0)

    def configDcdpDelete(self, sinst_info):
        err = 0
        try:
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            for ind,port in enumerate(sinst_info.mirror_port_list):
                handle = port_fwd_inst_list[port].dcdp_hdl
                rc = ifcs_ctypes.ifcs_dup_copy_dest_port_delete(self.cli.node_id, handle)
                spstcommon_handle_device_access_error(rc, "ifcs_dup_copy_dest_port_delete")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "DCDP: port {0}, handle {1} delete failed: rc {2}".format(port, handle, rc)
            log_dbg(1, "   Deleted DCDP successfully")
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except Exception as e:
            log_err("Error deleting DCDP: {}".format(e))
            err = 1
        return err

    def configCollectorDelete(self, sinst_info):
        err = 0
        try:
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            for ind,port in enumerate(sinst_info.mirror_port_list):
                handle = sinst_info.collector_hdl[ind]
                rc = ifcs_ctypes.ifcs_collector_delete(self.cli.node_id, handle)
                spstcommon_handle_device_access_error(rc, "ifcs_collector_delete")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Collector: port {0}, handle {1} delete failed: rc {2}".format(port, handle, rc)
            log_dbg(1, "   Deleted Collectors successfully")
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except Exception as e:
            log_err("Error deleting Collectors: {}".format(e))
            err = 1
        return err

    def configCollectorSetDelete(self, sinst_info):
        err = 0
        try:
            member_hdl_list = (ifcs_ctypes.ifcs_handle_t * 4)()
            for ind,port in enumerate(sinst_info.mirror_port_list):
                member_count = 4
                for i in range(member_count):
                    if ind+i < self.num_ibs:
                        member_hdl_list[i] = sinst_info.collector_hdl[ind+i]
                    else:
                        member_hdl_list[i] = sinst_info.collector_hdl[ind+i-self.num_ibs]
                handle = sinst_info.collector_set_hdls[ind]
                rc = ifcs_ctypes.ifcs_collector_set_member_remove(self.cli.node_id, handle, member_count, member_hdl_list)
                spstcommon_handle_device_access_error(rc, "ifcs_collector_set_member_remove")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Collector Set {0} member remove failed: rc {1}".format(ind, rc)

                rc = ifcs_ctypes.ifcs_collector_set_delete(self.cli.node_id, handle)
                spstcommon_handle_device_access_error(rc, "ifcs_collector_set_delete")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Collector Set {0} delete failed: rc {1}".format(ind, rc)
            log_dbg(1, "   Deleted Collector Sets successfully")
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except Exception as e:
            log_err("Error deleting Collector sets: {}".format(e))
            err = 1
        return err

    def configNexthopDelete(self, sinst_info):
        err = 0
        try:
            log_dbg(1, "Deleting nexthops")
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            for nh_iter in range(NUM_NH_PER_PORT):
                for port in sinst_info.devport_list:
                    handle = port_fwd_inst_list[port].nh_hdls[nh_iter]
                    rc = ifcs_ctypes.ifcs_nexthop_delete(self.cli.node_id,
                                             handle)
                    spstcommon_handle_device_access_error(rc, "ifcs_nexthop_delete")
                    assert rc == ifcs_ctypes.IFCS_SUCCESS, "Nexthop: port {0}, handle {1} delete failed: rc {2}".format(port, handle, rc)
            log_dbg(1, "   Deleted nexthops successfully")
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except Exception as e:
            log_err("Error deleting nexthops: {}".format(e))
            err = 1
        return err

    def configIntfDelete(self, sinst_info):
        err = 0
        try:
            log_dbg(1, "Deleting interfaces")
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            for port in sinst_info.devport_list:
                handle = port_fwd_inst_list[port].intf_hdl
                rc = ifcs_ctypes.ifcs_intf_delete(self.cli.node_id,
                                      handle)
                spstcommon_handle_device_access_error(rc, "ifcs_intf_delete")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Intf: port {0}, handle {1} delete failed: rc {2}".format(port, handle, rc)
            log_dbg(1, "   Deleted interfaces successfully")
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except Exception as e:
            log_err("Error deleting L3 interfaces: {}".format(e))
            err = 1
        return err

    def configQosMapDscpDelete(self, sinst_info):
        err = 0
        try:
            log_dbg(1, "Deleting Qos Maps/Map Groups")
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            for ind,port in enumerate(sinst_info.devport_list):
                if ind >= NUM_MAX_DSCP_QOS_PROFILE :
                    port_fwd_inst_list[port].qosmap_grp_dscp_hdl = 0
                    port_fwd_inst_list[port].qosmap_dscp_hdl = 0

                    continue

                handle = port_fwd_inst_list[port].qosmap_grp_dscp_hdl
                rc = ifcs_ctypes.ifcs_qos_map_group_delete(self.cli.node_id,
                                      handle)
                spstcommon_handle_device_access_error(rc, "ifcs_qos_map_group_delete")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Qos MAP Group: port {0}, handle {1} delete failed: rc {2}".format(port, handle, rc)
                handle  = port_fwd_inst_list[port].qosmap_dscp_hdl
                rc = ifcs_ctypes.ifcs_qos_map_delete(self.cli.node_id,
                                      handle)
                spstcommon_handle_device_access_error(rc, "ifcs_qos_map_delete")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Qos MAP: port {0}, handle {1} delete failed: rc {2}".format(port, handle, rc)

            log_dbg(1, "   Deleted QOSMaps/MapGroups successfully")
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except Exception as e:
            log_err("Error deleting DSCP qos maps/map groups: {}".format(e))
            err = 1
        return err

    def configQosMapDot1pCfiDelete(self, sinst_info):
        err = 0
        try:
            log_dbg(1, "Deleting Qos Maps/Map Groups")
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            for ind,port in enumerate(sinst_info.devport_list):
                if ind >= NUM_MAX_DSCP_QOS_PROFILE :
                    port_fwd_inst_list[port].qosmap_grp_dot1pcfi_hdl = 0
                    port_fwd_inst_list[port].qosmap_dot1pcfi_hdl = 0
                    continue

                handle = port_fwd_inst_list[port].qosmap_grp_dot1pcfi_hdl
                rc = ifcs_ctypes.ifcs_qos_map_group_delete(self.cli.node_id,
                                      handle)
                spstcommon_handle_device_access_error(rc, "ifcs_qos_map_group_delete")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Qos MAP Group: port {0}, handle {1} delete failed: rc {2}".format(port, handle, rc)
                handle  = port_fwd_inst_list[port].qosmap_dot1pcfi_hdl
                rc = ifcs_ctypes.ifcs_qos_map_delete(self.cli.node_id,
                                      handle)
                spstcommon_handle_device_access_error(rc, "ifcs_qos_map_delete")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Qos MAP: port {0}, handle {1} delete failed: rc {2}".format(port, handle, rc)

            log_dbg(1, "   Deleted dot1pcfi QOSMaps/MapGroups successfully")
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except Exception as e:
            log_err("Error deleting dot1pcif qos maps/map groups: {}".format(e))
            err = 1
        return err

    def configL3vniDelete(self, sinst_info):
        err = 0
        try:
            log_dbg(1, "Deleting L3VNIs")
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            for port in sinst_info.devport_list:
                handle = port_fwd_inst_list[port].l3vni_hdl
                rc = ifcs_ctypes.ifcs_l3vni_delete(self.cli.node_id,
                                       handle)
                spstcommon_handle_device_access_error(rc, "ifcs_l3vni_delete")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "L3VNI: port {0}, handle {1} delete failed: rc {2}".format(port, handle, rc)
            log_dbg(1, "   Deleted L3VNIs successfully")
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except Exception as e:
            log_err("Error deleting L3 vnis: {}".format(e))
            err = 1
        return err

    def compute_l3_header_checksum(self, header, header_size):
        num_bytes = header_size
        offset = 0
        checksum = 0
        while num_bytes > 0:
            data_16_bit = 0
            data_16_bit += (header[offset] << 8) & 0xff00
            data_16_bit += header[offset+1] & 0xff

            offset += 2
            num_bytes -= 2

            #log("data %d"%(data_16_bit))
            checksum += data_16_bit
            checksum = (checksum >> 16) + (checksum & 0xffff)

        return (~checksum & 0xffff)

    def saveL2hdr(self, sinst_info):
        '''
        Utility routine to save the L2hdr content. Will be used in start_traffic while building pkts
        '''
        l2hdr = []
        global rng
        l2hdr.extend(list(sinst_info.intfmac2))
        l2hdr.extend(list(sinst_info.intfmac1))
        # Add TPID,vlanid
        l2hdr.append(0x81)
        l2hdr.append(0x00)
        fdp = sinst_info.devport_list[0]
        vid = sinst_info.port_fwd_inst_list[fdp].si_vlan

        tmp = ((sinst_info.dot1q_pcp << 13) | (sinst_info.dot1q_dei << 12) | vid) & 0xffff
        '''
        # until packet issue with pcp and dei is resolved, using only vid in the 8021q hdr
        tmp = vid
        '''
        l2hdr.append((tmp & 0xff00)>>8)
        l2hdr.append(tmp & 0xff)

        sinst_info.l2hdr_etv4 = l2hdr[:]
        sinst_info.l2hdr_etv4.append(0x08)
        sinst_info.l2hdr_etv4.append(0x00)

        sinst_info.l2hdr_etv6 = l2hdr[:]
        sinst_info.l2hdr_etv6.append(0x86)
        sinst_info.l2hdr_etv6.append(0xDD)
        return 0

    def show_vos_stats(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='L3spst test show_vos_stats', prog='snake show_vos_stats', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=0, help='L3spst id needed if more than one snake configured')

        try:
            res = parser.parse_args(self.arg_list)
        except SystemExit:
            return
        except:
            log_err("Parsing failed")
            return "FAILED"

        if res.id:
            if res.id == -1:
                sinst_info = self.get_cur_run_data()
            else:
                find = False
                for instance in L3spst.sinst_info_runs:
                    if instance.id == res.id:
                        sinst_info = instance
                        find = True
                        break
                if find == False:
                    log("L3spst with id",res.id,"doesn't exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in L3spst.sinst_info_runs:
                snake_count += 1
            if snake_count > 1:
                log_err("More than one snake configured. Use snake id to stop traffic on a specific snake")
                return 'FAILED'
            sinst_info = self.get_cur_run_data()

        log("Total CPU packets sent                   : {}".format(sinst_info.vos_num_gen_pkts))
        log("Total CPU packets received               : {}".format(sinst_info.vos_num_rcvd_total))
        log("Good CPU packets received                : {}".format(sinst_info.vos_num_rcvd_good))
        log("Bad CPU packets received                 : {}".format(sinst_info.vos_num_rcvd_bad))
        if L3spst.vos_glob_mismatch > 0:
            log("Global (across all snakes) errors    : {}".format(L3spst.vos_glob_mismatch))

        log("\nSpecifics:")
        log("IPV4 TCP packets sent: {}  received: {}".format(sinst_info.vos_prot_sel_gen_cnt[PROT_IPV4_TCP], sinst_info.vos_prot_sel_good_rcv_cnt[PROT_IPV4_TCP]))
        log("IPV4 UDP packets sent: {}  received: {}".format(sinst_info.vos_prot_sel_gen_cnt[PROT_IPV4_UDP], sinst_info.vos_prot_sel_good_rcv_cnt[PROT_IPV4_UDP]))
        log("IPV6 TCP packets sent: {}  received: {}".format(sinst_info.vos_prot_sel_gen_cnt[PROT_IPV6_TCP], sinst_info.vos_prot_sel_good_rcv_cnt[PROT_IPV6_TCP]))
        log("IPV6 UDP packets sent: {}  received: {}".format(sinst_info.vos_prot_sel_gen_cnt[PROT_IPV6_UDP], sinst_info.vos_prot_sel_good_rcv_cnt[PROT_IPV6_UDP]))

        # Print PASS/FAIL
        if sinst_info.vos_num_gen_pkts == 0:
            log("\nVOS_PFSTATUS: FAIL (Traffic not sent yet)")
            return 'FAILED'

        #TODO: L3spst.vos_glob_mismatch is conceptually a global counter (across multiple snakes)
        # Revisit the second condition below when multi-snake support is needed
        if sinst_info.vos_num_rcvd_bad != 0 or L3spst.vos_glob_mismatch != 0:
            # signature is good but payload is corrupted is caught here
            log("\nVOS_PFSTATUS: FAIL (Bad packets received)")

            for mismatch in sinst_info.len_mismatch:
                gen_pkt = mismatch[0]
                packet = mismatch[1]
                log("Length mismatch; Sent pkt len {} Rcvd pkt len {}".format(len(gen_pkt), len(packet)))
                log("Sent pkt")
                log(":".join("{:02x}".format(compat_ord(c)) for c in gen_pkt))
                log("Received pkt")
                log(":".join("{:02x}".format(compat_ord(c)) for c in packet))

            for mismatch in sinst_info.byte_mismatch:
                snake_id = mismatch[0]
                pkt_id = mismatch[1]
                i = mismatch[2]
                gen_pkt = mismatch [3]
                packet = mismatch [4]
                log("ID: {} pktid: {} mismatch; byte: {} sent: 0x{:02x} rcvd: 0x{:02x} xor: 0x{:02x}".format( \
                snake_id, pkt_id, i, compat_ord(gen_pkt[i]), compat_ord(packet[i]), (compat_ord(gen_pkt[i]) ^ compat_ord(packet[i]))))

            return 'FAILED'

        if sinst_info.vos_num_rcvd_total != sinst_info.vos_num_gen_pkts:
            
            log("\nVOS_PFSTATUS: FAIL (Mismatch between sent and received pkts OR some packets with bad hdr received)")
            missing_packets_printed = 0
            for i in range(sinst_info.vos_num_gen_pkts):
                print_pkt = 0
                if sinst_info.vos_rcv_pktids[i] == 0:
                    log("Didn't receive pktid: {}".format(i))
                    print_pkt = 1
                if sinst_info.vos_rcv_pktids[i] > 1:
                    log("Received pktid: {} {} times".format(i, sinst_info.vos_rcv_pktids[i]))
                    print_pkt = 1

                if print_pkt == 1:
                    log(" ".join("{:02x}".format(compat_ord(c)) for c in sinst_info.vos_gen_pkts[i]))
                    missing_packets_printed += 1
                if missing_packets_printed == 10:
                    log("Truncating our missing packets output to 10 packets for space saving purposes")
                    break

            for mismatch in sinst_info.len_mismatch:
                gen_pkt = mismatch[0]
                packet = mismatch[1]
                log("Length mismatch; Sent pkt len {} Rcvd pkt len {}".format(len(gen_pkt), len(packet)))
                log("Sent pkt")
                log(":".join("{:02x}".format(compat_ord(c)) for c in gen_pkt))
                log("Received pkt")
                log(":".join("{:02x}".format(compat_ord(c)) for c in packet))

            for mismatch in sinst_info.byte_mismatch:
                snake_id = mismatch[0]
                pkt_id = mismatch[1]
                i = mismatch[2]
                gen_pkt = mismatch [3]
                packet = mismatch [4]
                log("ID: {} pktid: {} mismatch; byte: {} sent: 0x{:02x} rcvd: 0x{:02x} xor: 0x{:02x}".format( \
                snake_id, pkt_id, i, compat_ord(gen_pkt[i]), compat_ord(packet[i]), (compat_ord(gen_pkt[i]) ^ compat_ord(packet[i]))))

            return 'FAILED'

        log("\nVOS_PFSTATUS: PASS")
        return 'PASS'

    def clear_vos_stats(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='L3spst test clear_vos_stats', prog='snake clear_vos_stats', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=0, help='L3spst id needed if more than one snake configured')

        try:
            res = parser.parse_args(self.arg_list)
        except SystemExit:
            return
        except:
            log_err("Parsing failed")
            return "FAILED"

        if res.id:
            if res.id == -1:
                sinst_info = self.get_cur_run_data()
            else:
                find = False
                for instance in L3spst.sinst_info_runs:
                    if instance.id == res.id:
                        sinst_info = instance
                        find = True
                        break
                if find == False:
                    log("L3spst with id",res.id,"doesn't exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in L3spst.sinst_info_runs:
                snake_count += 1
            if snake_count > 1:
                log_err("More than one snake configured. Use snake id to stop traffic on a specific snake")
                return 'FAILED'
            sinst_info = self.get_cur_run_data()

        sinst_info.vos_num_gen_pkts = 0
        sinst_info.vos_num_rcvd_total = 0
        sinst_info.vos_num_rcvd_good = 0
        sinst_info.vos_num_rcvd_bad = 0
        sinst_info.vos_prot_sel_gen_cnt = [0] * PROT_MAX
        sinst_info.vos_prot_sel_good_rcv_cnt = [0] * PROT_MAX
        sinst_info.len_mismatch = []
        sinst_info.byte_mismatch = []
        L3spst.vos_glob_mismatch = 0
        sinst_info.vos_gen_pkts = [0] * MAX_PKTS
        sinst_info.vos_rcv_pktids = [0] * MAX_PKTS
        sinst_info.stress_prot_sel = 0
        sinst_info.stress_data_bytes = None
        return 'PASS'

    def _gen_pkt_helper(self, sinst_info, res, size, pktid, l4dport_override=0):
        data = []
        rem_size = size - len(sinst_info.l2hdr_etv4)
        prot_sel = -1

        if res.payload == "file":
            rand_bytes = self.file_pkt_data_obj.get_packet_data(rem_size)
        else:
            # Generate a stream of bits of rem_size*8 size and create a hex string
            randbits='{:08x}'.format((rng.getrandbits(rem_size*8)))
            x = 2
            # Convert the long hex string to list of bytes
            rand_bytes = [int(randbits[y - x:y], 16) for y in range(x, len(randbits) + x, x)]

            if len(rand_bytes) < rem_size:
                # It can so happen the leading bit in randbits could be 0s and the total num of bytes
                # could be less than anticipated. In such case, do padding
                pad = rem_size - len(rand_bytes)
                for pcur in range(pad):
                    # Appending 0xAA
                    rand_bytes.append(170)
                    sinst_info.dbg1 += 1

        
        if size <= 106:
            ihl = 5
            prot_sel = PROT_IPV4_TCP
        else:
            if res.payload == "file":
                tmp = random.randint(0, 31)
            else:
                tmp = rand_bytes[0]
            #Bits 0,1 for selecting from above protocol combination
            prot_sel = (tmp & 0x3)
            # Bits 2,3,4 for options
            ihl = ((tmp & 0x1c)>>2) + 5 # +5 because the minimum IHL is 5

        if prot_sel == PROT_IPV4_TCP or prot_sel == PROT_IPV4_UDP:
            data = sinst_info.l2hdr_etv4[:]
            data.extend(rand_bytes)
            #version,IHL field
            data[IPV4_VER_IHL_OFFSET] = (((0x4 << 4) | ihl) & 0xff)
            data[IPV4_DSCP_OFFSET] = sinst_info.v4_dscp
            # Total length field; +4 coz crc size should also be included
            data[IPV4_LEN_OFFSET] = (((rem_size) & 0xff00) >> 8)
            data[IPV4_LEN_OFFSET+1] = ((rem_size) & 0xff)
            flagfrag = (sinst_info.v4_flags << 13) | (sinst_info.v4_frag)
            data[IPV4_FLAGFRAG_OFFSET] = (flagfrag & 0xff00) >> 8
            data[IPV4_FLAGFRAG_OFFSET+1] = (flagfrag & 0xff)
            data[IPV4_TTL_OFFSET] = sinst_info.v4_ttl

            l4sport_offset = len(sinst_info.l2hdr_etv4) + ihl*4
            # Set protocol
            if prot_sel == PROT_IPV4_TCP:
                data[IPV4_NXT_HDR] = 0x06
                log_dbg(1, "IPv4 TCP pkt; l4sport_off {}".format(l4sport_offset))
            else:
                data[IPV4_NXT_HDR] = 0x11
                log_dbg(1, "IPv4 UDP pkt; l4sport_off {}".format(l4sport_offset))

            data[IPV4_CSUM_OFFSET] = 0x0
            data[IPV4_CSUM_OFFSET+1] = 0x0
            data[IPV4_SIP_OFFSET] = (sinst_info.ip2 & 0xff000000) >> 24
            data[IPV4_SIP_OFFSET+1] = (sinst_info.ip2 & 0xff0000) >> 16
            data[IPV4_SIP_OFFSET+2] = (sinst_info.ip2 & 0xff00) >> 8
            data[IPV4_SIP_OFFSET+3] = (sinst_info.ip2 & 0xff)

            data[IPV4_DIP_OFFSET] = (sinst_info.ip1 & 0xff000000) >> 24
            data[IPV4_DIP_OFFSET+1] = (sinst_info.ip1 & 0xff0000) >> 16
            data[IPV4_DIP_OFFSET+2] = (sinst_info.ip1 & 0xff00) >> 8
            data[IPV4_DIP_OFFSET+3] = (sinst_info.ip1 & 0xff)

            # If options exists, set the length in the second byte of options
            if ihl > 5:
                data[IPV4_OPTIONS_OFFSET + 1] = (ihl*4 - 20)

            hdr = data[len(sinst_info.l2hdr_etv4):len(sinst_info.l2hdr_etv4)+ihl*4]
            hdrsz = ihl*4
            csum = self.compute_l3_header_checksum(hdr, hdrsz)
            data[IPV4_CSUM_OFFSET] = (csum & 0xff00) >> 8
            data[IPV4_CSUM_OFFSET+1] = (csum & 0xff)

        elif prot_sel == PROT_IPV6_TCP or prot_sel == PROT_IPV6_UDP:
            data = sinst_info.l2hdr_etv6[:]
            data.extend(rand_bytes)

            l4sport_offset = len(sinst_info.l2hdr_etv6) + 40

            # version 4bits
            #data[IPV6_VER_OFFSET] = 0x60
            # TC split between VER_OFFSET and next byte.
            # Using the generated bytes at IPV6_VER_OFFSET, IPV6_VER_OFFSET+1, IPV6_VER_OFFSET+2 to fill the 20bits of flowlabel
            tmp = ((0x6 << 28) | (sinst_info.v6_tc << 20) | (data[IPV6_VER_OFFSET] << 12) | (data[IPV6_VER_OFFSET + 1] << 4) | (data[IPV6_VER_OFFSET + 2] & 0xf))
            data[IPV6_VER_OFFSET] = (tmp & 0xff000000) >> 24
            data[IPV6_VER_OFFSET + 1] = (tmp & 0xff0000) >> 16
            data[IPV6_VER_OFFSET + 2] = (tmp & 0xff00) >> 8
            data[IPV6_VER_OFFSET + 3] = (tmp & 0xff)

            # Payload length field; +4 coz crc size should also be included
            data[IPV6_LEN_OFFSET] = (((rem_size - 40) & 0xff00) >> 8)
            data[IPV6_LEN_OFFSET+1] = ((rem_size - 40) & 0xff)
            # Set protocol
            if prot_sel == PROT_IPV6_TCP:
                data[IPV6_NXT_HDR] = 0x06
                log_dbg(1, "IPv6 TCP pkt; l4sport_off {}".format(l4sport_offset))
            else:
                data[IPV6_NXT_HDR] = 0x11
                log_dbg(1, "IPv6 TCP pkt; l4sport_off {}".format(l4sport_offset))

            # Hop limit
            data[IPV6_HOP_OFFSET] = sinst_info.v6_hoplimit

            # SIP
            for i in range(16):
                data[IPV6_SIP_OFFSET + i] = sinst_info.v6_sip[i]

            # DIP
            for i in range(16):
                data[IPV6_DIP_OFFSET + i] = sinst_info.v6_dip[i]

        else:
            log_err("Prot_sel invalid: {}".format(prot_sel))
            return -1,-1,None

        data[l4sport_offset] = ((sinst_info.l4_sport & 0xff00) >> 8)
        data[l4sport_offset+1] = (sinst_info.l4_sport & 0xff)
        if l4dport_override == 0:
            data[l4sport_offset+2] = ((sinst_info.l4_dport & 0xff00) >> 8)
            data[l4sport_offset+3] = (sinst_info.l4_dport & 0xff)
        else:
            data[l4sport_offset+2] = ((l4dport_override & 0xff00) >> 8)
            data[l4sport_offset+3] = (l4dport_override & 0xff)

        apphdr_offset = l4sport_offset + 4

        data[apphdr_offset] = 0xBE
        data[apphdr_offset + 1] = 0xBA
        data[apphdr_offset + 2] = 0xFE
        data[apphdr_offset + 3] = 0xCA
        #Snake-id
        data[apphdr_offset + 4] = sinst_info.id
        # pkt-id
        data[apphdr_offset + 5] = ((pktid) & 0xff)
        data[apphdr_offset + 6] = (((pktid) & 0xff00) >> 8)
        data[apphdr_offset + 7] = (((pktid) & 0xff0000) >> 16)

        if res.payload == "file":
            # Make the byte sequence after app header to match with the one user specified
            apphdr_end_offset = apphdr_offset + 7 + 1
            data_len = len(data)
            if apphdr_end_offset < data_len:
                data = data[:apphdr_end_offset]
                data.extend(rand_bytes[:data_len - apphdr_end_offset])

        log_dbg(1, "Sz: {} len(data): {}".format(size, len(data)))

        data_bytes = b''
        for c in range(len(data)):
            data_bytes += compat_chr(data[c])

        return 0,prot_sel,data_bytes

    def _gen_pkt(self, sinst_info, res, size, pktid, l4dport_override=0):
        if res.payload == "rrstress":
            return self._gen_pkt_helper(sinst_info, res, size, pktid, l4dport_override)
        elif res.payload == "file":
            ret_vals = self._gen_pkt_helper(sinst_info, res, size, pktid,
                                            l4dport_override)
            self.file_pkt_data_obj.select_next_pkt()
            return ret_vals
        elif res.payload == "stress":
            rc = 0
            if sinst_info.stress_data_bytes == None:
                ret,prot_sel,data_bytes = self._gen_pkt_helper(sinst_info, res, size, pktid, l4dport_override)
                if ret < 0 or prot_sel < 0:
                    return ret,prot_sel,data_bytes

                sinst_info.stress_data_bytes = data_bytes
                sinst_info.stress_prot_sel = prot_sel
                rc = ret

            return rc,sinst_info.stress_prot_sel,sinst_info.stress_data_bytes

    def _send_packet(self, sinst_info, pdata, res, size):
        try:
            packet = ifcs_ctypes.ifcs_hostif_packet_info_t()
            ifcs_ctypes.ifcs_hostif_packet_info_t_init(byref(packet))
            packet.tx_type = ifcs_ctypes.IFCS_HOSTIF_TX_TYPE_PIPELINE_BYPASS
            dport = sinst_info.devport_list[0]
            packet.dsp = sinst_info.port_fwd_inst_list[dport].sp_hdl
            packet.pkt_buf = pdata
            packet.pkt_buf_len = size
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except Exception as e:
            log_err("Exception when building pkt: {}".format(e))
            return -1

        tx_busy_count = 0
        while (1):
            rc = ifcs_ctypes.ifcs_hostif_send_packet(sinst_info.node_id, pointer(packet))
            spstcommon_handle_device_access_error(rc, "ifcs_hostif_send_packet")
            if (rc == ifcs_ctypes.IFCS_SUCCESS):
                break
            if (rc != ifcs_ctypes.IFCS_BUSY):
                log_err("Packet send to pcie failed rc: {}".format(rc))
                return -1
            tx_busy_count += 1

            if tx_busy_count >= HOSTIF_SEND_PKT_BUSY_RETRY_CNT:
                log_err("Packet send failed after {} retries; rc: {}".format(HOSTIF_SEND_PKT_BUSY_RETRY_CNT, rc))
                return -1

            time.sleep(0.001)

        return 0

    def show_dbginfo(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='L3spst show_dbginfo', prog='L3spst show_dbginfo', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=None, help='Snake id. Needed if more than one snake configured')

        try:
            res = parser.parse_args(self.arg_list)
        except SystemExit:
            return
        except:
            log_err("Parsing failed")
            return "FAILED"

        if res.id:
            if res.id == -1:
                sinst_info = self.get_cur_run_data()
            else:
                find = False
                for instance in L3spst.sinst_info_runs:
                    if instance.id == res.id:
                        sinst_info = instance
                        find = True
                        break
                if find == False:
                    log_err("L3spst with id ", res.id, " does not exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in L3spst.sinst_info_runs:
                snake_count += 1
            if snake_count > 1:
                log_err("More than one snake configured. Use snake id to start traffic on a specific snake")
                return 'FAILED'
            sinst_info = self.get_cur_run_data()

        sinst_info.display()

    def start_traffic(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='L3spst test start_traffic', prog='L3spst start_traffic', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=None, help='Snake id. Needed if more than one snake configured')
        parser.add_argument('-s', type=str, default="1500:1", help='Comma separated pktsizes; a pktsize can be given a count. Ex: 1500:20,9216:10 results in 20 pkts of size 1500bytes and 10 pkts of 9216bytes')
        #parser.add_argument('-payload', type=str, choices=['rrstress', 'custom'], default='rrstress', help='Packet payload')
        parser.add_argument('-payload', type=str, choices=['rrstress', 'stress', 'file'], default='rrstress', help='Packet payload')
        #parser.add_argument('-custom_value', type=auto_int, default=0, help='16-bit Custom payload. Used if payload is of type custom')
        parser.add_argument('-payload_filename', type=str, default=None, dest='payload_file_name', help='Packet data json file name. Used if payload is of type file')
        parser.add_argument('-v', help='Verbose', action="store_true")
        parser.add_argument('-m', help='Trigger a packet for mirroring action', action="store_true")
        parser.add_argument('-vos', default=None, help='Validate-on-stop. If selected, upon stop_traffic, the traffic is terminated back to CPU and compared against injected packets. Supported only for uni-dir, loopback=PCS or PMA, single snake only', action="store_true")

        try:
            res = parser.parse_args(self.arg_list)
        except SystemExit:
            return
        except:
            log_err("Parsing failed")
            return "FAILED"

        if res.id:
            if res.id == -1:
                sinst_info = self.get_cur_run_data()
            else:
                find = False
                for instance in L3spst.sinst_info_runs:
                    if instance.id == res.id:
                        sinst_info = instance
                        find = True
                        break
                if find == False:
                    log_err("L3spst with id ", res.id, " does not exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in L3spst.sinst_info_runs:
                snake_count += 1
            if snake_count > 1:
                log_err("More than one snake configured. Use snake id to start traffic on a specific snake")
                return 'FAILED'
            sinst_info = self.get_cur_run_data()

        payload = res.payload
        '''
        # Only rrstress supported, for now
        payload_data = res.custom_value
        # Basic validations
        if payload_data and payload != 'custom':
            log_err("ERROR: custom_value can be used only with payload of type custom")
            return 'FAILED'

        if (res.payload == 'custom') and (payload_data == None):
            log_err("ERROR: custom_value is mandatory for payload type custom")
            return 'FAILED'

        max_custom_val = 0xffff
        if payload_data and payload_data not in range(max_custom_val):
            log_err("ERROR: custom_value valid range is 0-{0}".format(max_custom_val))
            return 'FAILED'
        '''

        if res.payload == 'file' and res.payload_file_name is None:
            log("ERROR: payload_filename is mandatory for payload type file")
            return 'FAILED'

        self.file_pkt_data_obj = None
        if res.payload == 'file':
            try:
                self.file_pkt_data_obj = FilePacketData(res.payload_file_name)
                self.file_pkt_data_obj.select_first_pkt()
            except Exception as e:
                log("ERROR: Error processing packet data file : " + str(e))
                return 'FAILED'

        if res.vos:
            if sinst_info.lb_type == 'NONE':
                log_err("ERROR: Validate-on-stop is not supported for loopback-type NONE")
                return 'FAILED'
            sinst_info.vos = 1
        else:
            sinst_info.vos = 0

        pktsizes = res.s.split(',')
        sinst_info.vos_gen_pkts = [0] * MAX_PKTS
        sinst_info.vos_rcv_pktids = [0] * MAX_PKTS
        sinst_info.stress_prot_sel = 0
        sinst_info.stress_data_bytes = None

        # Only one packet size allowed for payload-type 'stress'
        if res.payload == 'stress' and len(pktsizes) > 1:
            log_err("Only one packet size allowed for payload-type=stress".format(MAX_PKTS))
            return 'FAILED'

        # Only one packet allowed for payload-type 'stress'; res.m (mirroring) needs a special packet
        if res.payload == 'stress' and res.m:
            log_err("Mirroring not allowed when payload-type=stress".format(MAX_PKTS))
            return 'FAILED'

        numpkts = 0
        for szitem in pktsizes:
            if numpkts >= MAX_PKTS:
                log_err("Max pkts supported: {}".format(MAX_PKTS))
                return 'FAILED'

            curcnt = 0
            cursize = 0
            if ':' in szitem:
                toks = szitem.split(':')
                cursize = int(toks[0])
                curcnt = int(toks[1])
            else:
                cursize = int(szitem)
                curcnt = 1

            if cursize < 64:
                cursize = 64

            cursize = cursize - 4
            for cc in range(curcnt):

                ret,prot_sel,data_bytes = self._gen_pkt(sinst_info, res, cursize, numpkts)
                if ret < 0 or prot_sel < 0:
                    log_err("Generate packet failed ret: {}".format(ret));
                    return 'FAILED'

                pdata = cast(data_bytes, c_void_p)
                ret = self._send_packet(sinst_info, pdata, res, cursize)
                if ret < 0:
                    log_err("Send packet failed ret: {}".format(ret));
                    return 'FAILED'

                if sinst_info.vos == 1:
                    sinst_info.vos_num_gen_pkts += 1
                    sinst_info.vos_prot_sel_gen_cnt[prot_sel] += 1
                    sinst_info.vos_gen_pkts.insert(numpkts, data_bytes)

                if(res.v == True):
                    log("Sent Packet-id {}(len:{}):".format(numpkts, len(data_bytes)))
                    log(":".join("{:02x}".format(compat_ord(c)) for c in data_bytes))

                numpkts += 1

        if res.m:
            # Generate a 1500 byte pkt for mirroring
            cursize = 1496
            ret,prot_sel,data_bytes = self._gen_pkt(sinst_info, res, cursize, numpkts, l4dport_override=sinst_info.l4_dport_mirror)
            if ret < 0 or prot_sel < 0:
                log_err("Generate packet failed ret: {}".format(ret));
                return 'FAILED'

            pdata = cast(data_bytes, c_void_p)
            ret = self._send_packet(sinst_info, pdata, res, cursize)
            if ret < 0:
                log_err("Send packet failed ret: {}".format(ret));
                return 'FAILED'

            if sinst_info.vos == 1:
                sinst_info.vos_num_gen_pkts += 1
                sinst_info.vos_prot_sel_gen_cnt[prot_sel] += 1
                sinst_info.vos_gen_pkts.insert(numpkts, data_bytes)

            log("Sent mirror action pkt of size {}".format(len(data_bytes)))
            if(res.v == True):
                log("Sent Packet-id {}(len:{}):".format(numpkts, len(data_bytes)))
                log(":".join("{:02x}".format(compat_ord(c)) for c in data_bytes))

            numpkts += 1

        sinst_info.state = SNAKE_RUNNING
        return 'PASS'

    def stop_traffic(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='L3spst test stop_traffic', prog='L3spst stop_traffic', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=None, help='Snake id. Needed if more than one snake configured')
        parser.add_argument('-d', type=int, default=14, dest='delay', help='Delay - how much time do we want to sleep after l3 stop_traffic')

        try:
            res = parser.parse_args(self.arg_list)
        except SystemExit:
            return
        except:
            log_err("Parsing failed")
            return "FAILED"

        if res.id:
            if res.id == -1:
                sinst_info = self.get_cur_run_data()
            else:
                find = False
                for instance in L3spst.sinst_info_runs:
                    if instance.id == res.id:
                        sinst_info = instance
                        find = True
                        break
                if find == False:
                    log_err("L3spst with id ", res.id, " does not exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in L3spst.sinst_info_runs:
                snake_count += 1
            if snake_count > 1:
                log_err("More than one snake configured. Use snake id to stop traffic on a specific snake")
                return 'FAILED'
            sinst_info = self.get_cur_run_data()

        #sysport_hdls = sinst_info.sysport_hdls
        devport_obj = Devport(self.cli)

        verbose = sinst_info.verbose
        devport_list = sinst_info.devport_list
        port_fwd_inst_list = sinst_info.port_fwd_inst_list

        # Configure same ip in all VRF aka L3VNI
        log_dbg(1, "Creating drop route entries")

        # Unidir: Set one route to drop for the only flow.
        # This will stop traffic since we have a snake traffic pattern
        drop_port_list = [devport_list[0]]

        if sinst_info.vos == 1:
            # Register rx callback
            L3spst.rx_cbfn = ifcs_ctypes.ifcs_hostif_packet_notify_t(pkt_vos_cb)
            rc = ifcs_ctypes.ifcs_hostif_register_rx_packet_notify(self.cli.node_id, None, L3spst.rx_cbfn)
            spstcommon_handle_device_access_error(rc, "ifcs_hostif_register_rx_packet_notify")
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err("ERROR: Registering Packet Callback Function")

        err,v4route_entry_key = self.configV4RouteDroprule(sinst_info, port_fwd_inst_list, devport_list[0])
        if err:
            log_err("Failed to configure V4 droprule")
            return 'FAILED'

        err,v6route_entry_key = self.configV6RouteDroprule(sinst_info, port_fwd_inst_list, devport_list[0])
        if err:
            log_err("Failed to configure V4 droprule")
            return 'FAILED'

        # Check sent packets against received packets - keep sleeping for 100ms until they match
        # Only sleep up to a max time of res.delay
        received = False
        maxNumSleeps = res.delay * 10
        for x in range (maxNumSleeps):
            all_received_packets = L3spst.vos_glob_mismatch + sinst_info.vos_num_rcvd_total
            all_sent_packets = sinst_info.vos_num_gen_pkts
            if all_received_packets == all_sent_packets:
                received = True
                break
            time.sleep(0.1)
        time.sleep(2) # Need to sleep for two extra seconds to let sysport polling catch up

        if not received:
            log("Stop traffic did not receive all packets in {} seconds".format(res.delay))

        err = self.clearRouteDroprule(sinst_info, v4route_entry_key)
        if err:
            log_err("Failed to clear V4 droprule")
            return 'FAILED'
        err = self.clearRouteDroprule(sinst_info, v6route_entry_key)
        if err:
            log_err("Failed to clear V6 droprule")
            return 'FAILED'

        '''
        for i, drop_port in enumerate(drop_port_list):
            # Create key
            ipSubnet.ipv4 = sinst_info.ip1

            ip_dest = ifcs_ctypes.ifcs_ip_prefix_t()
            ifcs_ctypes.ifcs_ip_prefix_t_init(pointer(ip_dest))
            ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)
            ifcs_ctypes.ifcs_ip_prefix_t_addr_set(pointer(ip_dest), pointer(ipSubnet))
            ifcs_ctypes.ifcs_ip_prefix_t_mask_set(pointer(ip_dest), pointer(mask))

            route_entry_key = ifcs_ctypes.ifcs_route_entry_key_t()
            route_entry_key_list.insert(i, route_entry_key)
            ifcs_ctypes.ifcs_route_entry_key_t_init(pointer(route_entry_key_list[i]))
            ifcs_ctypes.ifcs_route_entry_key_t_key_type_set(pointer(route_entry_key_list[i]),
                    ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_L3VNI)
            ifcs_ctypes.ifcs_route_entry_key_t_ip_dest_l3vni_set(pointer(route_entry_key_list[i]),
                    route_entry_key.key.ip_dest_l3vni)
            ifcs_ctypes.ifcs_route_entry_key_ip_dest_l3vni_t_l3vni_set(pointer(route_entry_key_list[i].key.ip_dest_l3vni),
                    port_fwd_inst_list[drop_port].l3vni_hdl)
            ifcs_ctypes.ifcs_route_entry_key_ip_dest_l3vni_t_ip_dest_set(pointer(route_entry_key_list[i].key.ip_dest_l3vni),
                    pointer(ip_dest))

            attr_list                              = (ifcs_ctypes.ifcs_attr_t * 10)()
            attr_count                             = 0

            fwd_policy = ifcs_ctypes.ifcs_fwd_policy_t()
            fwd_policy.fwd_action                  = ifcs_ctypes.IFCS_FWD_ACTION_DROP
            attr_list[attr_count].id               = ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_FWD_POLICY
            attr_list[attr_count].value.fwd_policy = fwd_policy
            attr_count += 1
            if sinst_info.vos == 1:
                ctc_policy = ifcs_ctypes.ifcs_ctc_policy_t()
                ifcs_ctypes.ifcs_ctc_policy_t_init(pointer(ctc_policy))
                ctc_policy.ctc_action = ifcs_ctypes.IFCS_COPY_TO_CPU_ENABLE
                if self.trap_hdl.value == 0:
                    log_err("ctc policy trap handle is 0")
                    assert 0, "ctc policy trap handle is 0"
                ctc_policy.trap_handle = self.trap_hdl
                ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_CTC_POLICY)
                ifcs_ctypes.ifcs_attr_t_value_ctc_policy_set(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, attr_count), pointer(ctc_policy))
                attr_count += 1

            rc = ifcs_ctypes.ifcs_route_entry_attr_set(self.cli.node_id,
                                           pointer(route_entry_key_list[i]),
                                           attr_count,
                                           attr_list)
            assert rc == ifcs_ctypes.IFCS_SUCCESS, "Failed to set route entry attr to drop for port {0}, ret:{1}".format(drop_port, rc)

        time.sleep(res.delay)

        for i, route_entry_key in enumerate(route_entry_key_list):
            # Use previously created route_entry key, change fwd_policy attr action to forward
            attr_list                              =   (ifcs_ctypes.ifcs_attr_t * 10)()
            attr_count                             =   0

            fwd_policy.fwd_action                  =   ifcs_ctypes.IFCS_FWD_ACTION_FORWARD
            attr_list[attr_count].id               =   ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_FWD_POLICY
            attr_list[attr_count].value.fwd_policy =   fwd_policy
            attr_count += 1

            if sinst_info.vos == 1:
                ctc_policy = ifcs_ctypes.ifcs_ctc_policy_t()
                ifcs_ctypes.ifcs_ctc_policy_t_init(pointer(ctc_policy))
                ctc_policy.ctc_action = ifcs_ctypes.IFCS_COPY_TO_CPU_DISABLE
                ctc_policy.trap_handle = self.trap_hdl
                ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_CTC_POLICY)
                ifcs_ctypes.ifcs_attr_t_value_ctc_policy_set(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, attr_count), pointer(ctc_policy))
                attr_count += 1

            rc = ifcs_ctypes.ifcs_route_entry_attr_set(self.cli.node_id,
                                           pointer(route_entry_key),
                                           attr_count,
                                           attr_list)
            assert rc == ifcs_ctypes.IFCS_SUCCESS, "Failed to set route entry attr to forward for port {0}, ret: {1}".format(drop_port_list[i], rc)
        '''

        sinst_info.state = SNAKE_STOPPED
        log("Stopped traffic on L3spst id {0}".format(sinst_info.id))
        return 'PASS'

    def config(self, args):
        global rng

        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='L3spst test config', prog='L3spst config', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-p', type=str, default="all", help='Port list')
        parser.add_argument('-lb', type=str, choices=['NONE', 'PCS', 'PMA'], default='NONE', help='Loopback type')
        parser.add_argument('-sdd', help='Disable serdes tx on ports; used if lb is not NONE', action="store_true")
        parser.add_argument('-id', type=int, default=None, help='User defined snake id  [1-1023]')
        parser.add_argument('-seed', type=int, default=0, help='Optional seed value')
        parser.add_argument('-v', help='Verbose', action="store_true")
        parser.add_argument('-m', help='Configure for mirroring action', action="store_true")

        try:
            res = parser.parse_args(self.arg_list)
        except SystemExit:
            return
        except:
            log_err("Parsing failed")
            return "FAILED"

        seed = 0
        if res.seed == 0:
            seed = random.randrange(sys.maxsize)
        else:
            seed = res.seed

        log("Seed used: {}".format(seed))
        rng = random.Random(seed)

        '''
        If -p arg not given, default port range is all ports.
        '''
        max_dev_port = self.get_max_devport()
        max_devport_range = "1-2"
        if max_dev_port:
            max_devport_range = "1-%d"%(max_dev_port)

        if res.p == 'all':
            # Port range not given, default to all ports
            devport_arg = max_devport_range
            devport_arg_list = max_devport_range.split(",")
        else:
            # Use given devport range
            try:
                devport_arg = res.p
                devport_arg_list = res.p.split(",")
            except:
                devport_arg = max_devport_range
                devport_arg_list = max_devport_range.split(",")

        # Allocate run's data object which saves config and stats
        sinst_info = SnakeInstInfo()

        find = False
        if res.id != None:
            for instance in L3spst.sinst_info_runs:
                if instance.id == res.id:
                    log_err('Snake id already in use!\n')
                    return 'FAILED'
            sinst_info.id = res.id
        else:
            for index in range(1, 1024):
                find = False
                for instance in L3spst.sinst_info_runs:
                    if instance.id == index:
                        find = True
                        break
                if find == False:
                    sinst_info.id = index
                    break
                if index == 1023:
                    log_err("Can not alloc snake id")
                    return 'FAILED'

        for i, dp in enumerate(devport_arg_list):
            if '-' in dp:
                dp_range = devport_arg.split(",")[i].split("-")
                for j in range(int(dp_range[0]), int(dp_range[1]) + 1):
                    sinst_info.devport_list.append(j)
            else:
                sinst_info.devport_list.append(int(dp))

        devport_list = sinst_info.devport_list
        port_fwd_inst_list = sinst_info.port_fwd_inst_list

        # check if devport_list of new snake is overlapping with devport list of existing snake(s), if yes, return FAILED
        new_devport_set = set(devport_list)
        port_overlap = False
        for instance in L3spst.sinst_info_runs:
            if instance:
                existing_devport_set = set(instance.devport_list)
                if (existing_devport_set & new_devport_set):
                    port_overlap = True
                    break;
        if port_overlap:
            log_err("one or more ports in the devport list is already part of an existing snake. use ports that are not part of any existing snake(s)")
            return 'FAILED'

        lb_type = res.lb
        sinst_info.lb_type = lb_type

        verbose = res.v
        sinst_info.verbose = res.v

        sdd = res.sdd
        sinst_info.sdd = sdd

        sinst_info.type = 'unidir'

        # Configure
        ret = ifcs_ctypes.ifcs_status_t()
        attr = (ifcs_ctypes.ifcs_attr_t * 1)()

        attr[0].id = ifcs_ctypes.IFCS_LINKSCAN_ATTR_ENABLE
        attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE

        # generate one-time settings that includes
        # V4: Smac(6), Dmac(6), DSCP(1), Flags/Frag(2), TTL(1), SIP(4), DIP(4); V6: TC(1),
        # Hoplimit(1), SIPv6(16), DIPv6(16); L4: L4Srcport(2), L4Dstport(2)
        # These add up to: 62 bytes
        x = 2
        reqsize = 62
        randbits='{:08x}'.format((rng.getrandbits(reqsize*8)))
        # Convert the long hex string to list of bytes
        rand_bytes = [int(randbits[y - x:y], 16) for y in range(x, len(randbits) + x, x)]
        if len(rand_bytes) < reqsize:
            # It can so happen the leading bit in randbits could be 0s and the total num of bytes
            # could be less than anticipated. In such case, do padding
            pad = reqsize - len(rand_bytes)
            for pcur in range(pad):
                # Appending 0xAA
                rand_bytes.append(170)

        # Make sure mac1 and mac2 are not completely zero (by setting lsb to a non-zero value)
        if rand_bytes[5] == 0:
            rand_bytes[5] = 0x1
        if rand_bytes[11] == 0:
            rand_bytes[11] = 0x1

        sinst_info.intfmac1 = (rand_bytes[0] & 0xfe, rand_bytes[1], rand_bytes[2], rand_bytes[3], rand_bytes[4], rand_bytes[5])
        sinst_info.intfmac2 = (rand_bytes[6] & 0xfe, rand_bytes[7], rand_bytes[8], rand_bytes[9], rand_bytes[10], rand_bytes[11])
        sinst_info.v4_dscp = rand_bytes[12]
        sinst_info.v4_flags = 0x1 # Always set MF=1
        sinst_info.v4_frag = ((rand_bytes[13] & 0x1F) << 8) | (rand_bytes[14])
        # Ensure v4_frag is non-zero
        if sinst_info.v4_frag == 0:
            sinst_info.v4_frag = 0xA5
        sinst_info.v4_ttl = rand_bytes[15]
        if sinst_info.v4_ttl <= 1:
            sinst_info.v4_ttl += 2

        # Avoiding multicast ipv4 range
        if rand_bytes[16] > 223:
            rand_bytes[16] = 223
        if rand_bytes[20] > 223:
            rand_bytes[20] = 223
        # Avoiding local ipv4
        if rand_bytes[16] == 127:
            rand_bytes[16] = 126
        if rand_bytes[20] == 127:
            rand_bytes[20] = 126

        sinst_info.ip2 = ((rand_bytes[16] << 24) | (rand_bytes[17] << 16) | (rand_bytes[18] << 8) | (rand_bytes[19]))
        sinst_info.ip1 = ((rand_bytes[20] << 24) | (rand_bytes[21] << 16) | (rand_bytes[22] << 8) | (rand_bytes[23]))

        sinst_info.dot1q_pcp = rand_bytes[24] & 0x7
        sinst_info.dot1q_dei = ((rand_bytes[24] & 0x8) >> 3)
        sinst_info.v6_tc = sinst_info.v4_dscp
        sinst_info.v6_hoplimit = sinst_info.v4_ttl

        # Avoiding multicast and local ipv6
        if rand_bytes[26] > 0xf0:
            rand_bytes[26] = 0xe0
        if rand_bytes[42] > 0xf0:
            rand_bytes[42] = 0xe0

        sinst_info.v6_sip.extend(rand_bytes[26:26+16])
        sinst_info.v6_dip.extend(rand_bytes[42:42+16])

        # There were cases observed with parser setting TUNNEL_DETECTED with randomly generated l4 ports
        # Setting to fixed values until that's resolved
        #sinst_info.l4_sport = ((rand_bytes[58] << 8) | (rand_bytes[58]))
        #sinst_info.l4_dport = ((rand_bytes[60] << 8) | (rand_bytes[61]))
        sinst_info.l4_sport = L4SRCPORT
        sinst_info.l4_dport = L4DSTPORT


        try:
            for port in devport_list:
                port_inst = PortFwdInst()
                port_inst.sp_hdl = self.configDevportGetSysportHandle(port)
                #port_inst.sp_hdl = sysport_hdls[port]
                port_fwd_inst_list[port] = port_inst

        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Sysport get FAILED")
            pass

        # Disable all Devports
        err = self.configDevportsDisable(sinst_info)
        if err:
            log_err("L3spst devports disable failed")
            return 'FAILED'

        # Set Loopback mode
        if verbose:
            log("Setting devports loopback mode to {0}".format(sinst_info.lb_type))
        err = self.configDevportsLoopback(sinst_info, sinst_info.lb_type)
        if err:
            log_err("L3spst lpbk config failed")
            return 'FAILED'

        # Configure Sysports as L3ONLY
        if verbose:
            log("Setting devports fwd mode to L3_ONLY")
        err = self.configSysportSetFwdMode(sinst_info, ifcs_ctypes.IFCS_SYSPORT_FWD_MODE_L3_ONLY)
        if err:
            log_err("L3spst sysport fwdmode set failed")
            return 'FAILED'

        #Config Sysports
        if verbose:
            log("Configuring sysport attributes")
        err = self.configSysport(sinst_info, 1)
        if err:
            log_err("L3spst sysport config failed")
            return 'FAILED'


        # Enable all Devports
        err = self.configDevportsEnable(sinst_info)
        if err:
            log_err("L3spst devports enable failed")
            return 'FAILED'

        # Check for expected number of ports only if mirroring config is requested
        if res.m:
            if len(sinst_info.devport_list) < self.num_ibs:
                log_err("Error: Minimum no. of ports expected:{}".format(self.num_ibs))
                return 'FAILED'
            sinst_info.mirror_cfg = True

        # Create VRFs (L3VNI)
        if verbose:
            log("Creating L3 vnis")
        err = self.configL3vniCreate(sinst_info)
        if err:
            log_err("L3spst l3vni create failed")
            return 'FAILED'

        # Create QOS Map/Map Groups for tc/dp to dscp (One per OIF)
        if verbose:
            log("Creating Qos Map/Map Groups")
        err = self.configQosMapDscpCreate(sinst_info)
        if err:
            log_err("L3spst qosmap dscp create failed")
            return 'FAILED'

        # Create QOS Map/Map Groups for tc/dp to dot1pcfi (One per DSP)
        if verbose:
            log("Creating Qos Map/Map Groups")
        err = self.configQosMapDot1pCfiCreate(sinst_info)
        if err:
            log_err("L3spst qosmap dot1p/cfi create failed")
            return 'FAILED'

        # Configure dot1pcif QOS map Groups to DSP
        if verbose:
            log("Configure qosmap groups to DSP")
        err = self.configSysportDot1pCfiMap(sinst_info, 1)
        if err:
            log_err("L3spst qosmap group to dsp failed")
            return 'FAILED'


        # Create L3 Interfaces (One per Sysport)
        if verbose:
            log("Creating L3 intfs")
        err = self.configIntfCreate(sinst_info)
        if err:
            log_err("L3spst intf create failed")
            return 'FAILED'

        # Create Nexthops (One per L3 interface)
        if verbose:
            log("Creating nexthops")
        err = self.configNexthopCreate(sinst_info)
        if err:
            log_err("L3spst nexthop create failed")
            return 'FAILED'

        # Create Host Route entries (VRF, IPv4) -> NH (Intf, Dest Sysport)
        if verbose:
            log("Creating V4 route entries")
        err = self.configV4RouteCreate(sinst_info)
        if err:
            log_err("L3spst v4 route create failed")
            return 'FAILED'

        # Create Host Route entries (VRF, IPv6) -> NH (Intf, Dest Sysport)
        if verbose:
            log("Creating V6 route entries")
        err = self.configV6RouteCreate(sinst_info)
        if err:
            log_err("L3spst v6 route create failed")
            return 'FAILED'

        if res.m:
	        # Create Miror on the first six ports of the user provided list
	        # TBD: Ensure that this list is a port per IB
            sinst_info.mirror_port_list = sinst_info.devport_list[0:self.num_ibs]
            if verbose:
                log("Creating DCDP")
            err = self.configDcdpCreate(sinst_info)
            if err:
                log_err("L3spst DCDP create failed")
                return 'FAILED'

            if verbose:
                log("Creating Collectors")
            err = self.configCollectorCreate(sinst_info)
            if err:
                log_err("L3spst Collector create failed")
                return 'FAILED'

            if verbose:
                log("Creating Collector Sets")
            err = self.configCollectorSetCreate(sinst_info)
            if err:
                log_err("L3spst Collector Sets create failed")
                return 'FAILED'

        err = self.saveL2hdr(sinst_info)
        if err:
            log_err("L3spst saveL2hdr failed")
            return 'FAILED'

        nodeObj = Node(self.cli)
        nodeObj.set("ifcs set node stats_poll_interval 1000")
        queueObj = Queue(self.cli)
        for port in sinst_info.devport_list:
            queueObj.set("ifcs set queue devport {} queue_id 0 uc_dynamic_threshold_factor 8".format(port))
            queueObj.set("ifcs set queue devport {} queue_id 0 nonuc_dynamic_threshold_factor 8".format(port))

        tcObj = Tc(self.cli)
        for tcind in range(8):
            tcObj.set("ifcs set tc {} queue_id 0".format(tcind))

        # Create trap hdl on first snake config; used when validate_on_stop is specified
        if self.run == -1:
            self.trap_hdl.value = ifcs_ctypes.IFCS_HANDLE_HOSTIF_TRAP(self.trap_id)
            attr_count = 0
            attr = (ifcs_ctypes.ifcs_attr_t * 1)()
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_HOSTIF_TRAP_ATTR_QUEUE_NUM)
            ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), self.cpu_queue_num)
            attr_count += 1
            rc = ifcs_ctypes.ifcs_hostif_trap_create(self.cli.node_id,
                                                     pointer(self.trap_hdl),
                                                     attr_count,
                                                     compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
            spstcommon_handle_device_access_error(rc, "ifcs_hostif_trap_create")
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err(
                    "Hostif trap create failed for cpu queue {} with rc: {}".
                    format(self.cpu_queue_num, rc))
                assert 0, "ERR during trap handle create; rc: {}".format(rc)

            
            attr_count = 0
            attr = (ifcs_ctypes.ifcs_attr_t * 3)()
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_THRESHOLD_MODE)
            ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_THRESHOLD_MODE_STATIC)
            attr_count += 1
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_UC_STATIC_THRESHOLD_LIMIT)
            ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), 39000)
            attr_count += 1
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_NONUC_STATIC_THRESHOLD_LIMIT)
            ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), 39000)
            attr_count += 1
            rc = ifcs_ctypes.ifcs_cpu_queue_attr_set(self.cli.node_id,
                                                     self.cpu_queue_num,
                                                     attr_count,
                                                     compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
            spstcommon_handle_device_access_error(rc, "ifcs_cpu_queue_attr_set")
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err(
                    "Dynamic threshold attribute set failed for cpu queue {} with rc: {}"
                    .format(self.cpu_queue_num, rc))
                assert 0, "ERR during cpu_queue threshold attr set; rc: {}".format(
                    rc)

        # Config success, save the config data useful for report generation
        self.insert_run_data(sinst_info)

        sinst_info.state = SNAKE_CONFIGD

        if (self.quiet == "false"):
            #display config
            sinst_info.display_config(sinst_info.id)

        # Wait for all ports to go link-up for 5 secs
        if verbose:
            log("Waiting for all ports to go link-up")

        if (lb_type != 'NONE'):
            timer_val = 5
        else:
            timer_val = 15
        wait_time = 0
        devport_attr_ct = 1
        devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
        devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LINK_STATUS
        devport_attr[0].value.u32 = 0
        actual_count = c_uint32()
        link_status = True
        try:
            while wait_time < timer_val:
                link_status = True
                for devport in devport_list:
                    rc = ifcs_ctypes.ifcs_devport_attr_get (self.cli.node_id, devport, 1,
                                     compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t), pointer(actual_count))
                    spstcommon_handle_device_access_error(rc, "ifcs_devport_attr_get")
                    assert rc == ifcs_ctypes.IFCS_SUCCESS, "ERROR during devport attr get for port {0}: rc={1}({2})".format(
                        devport, rc,
                        compat_bytesToStr(
                            ifcs_ctypes.ifcs_status_to_string(rc)))

                    if (devport_attr[0].value.u32 != 1):
                        link_status=False
                if link_status:
                    break
                else:
                    wait_time+=0.1
                    time.sleep(0.1)

            assert link_status == True, "Not all devports are up"
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Error in config: all devports are not up")
            return 'FAILED'

        # Create and enable all ACL tables
        self.configAclCreateIngress(sinst_info)
        self.configAclCreateEgress(sinst_info)

        if verbose:
            log("Config done")
        return 'PASS'

    def configAclIpCompression(self, sinst_info):

        for entry_count in range(4):
            attrList = (ifcs_ctypes.ifcs_attr_t * 5)()
            for index in range(5):
                rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                assert rc == ifcs_ctypes.IFCS_SUCCESS
            index = 0

            if entry_count == 0:
                index = 0
                ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_COMPRESSED_IP_ADDRESS_ATTR_TYPE)
                ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_COMPRESSED_IP_TYPE_SOURCE)
                index += 1

                ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_COMPRESSED_IP_ADDRESS_ATTR_PRIORITY);
                ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), 1);
                index += 1

                ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_COMPRESSED_IP_ADDRESS_ATTR_IP_PREFIX);

                ip_prefix = ifcs_ctypes.ifcs_ip_prefix_t()
                ipv4_addr = ifcs_ctypes.ifcs_ip_addr_t()
                ipv4_mask = ifcs_ctypes.ifcs_ip_addr_t()
                ipv4_addr.ipv4 = sinst_info.ip2
                ipv4_mask.ipv4 = 0xffffffff
                ifcs_ctypes.ifcs_ip_prefix_t_init(pointer(ip_prefix))
                ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_prefix), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)
                ifcs_ctypes.ifcs_ip_prefix_t_addr_set(pointer(ip_prefix), pointer(ipv4_addr))
                ifcs_ctypes.ifcs_ip_prefix_t_mask_set(pointer(ip_prefix), pointer(ipv4_mask))
                ifcs_ctypes.ifcs_attr_t_value_ip_prefix_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), pointer(ip_prefix));
                index += 1

            elif entry_count == 1:
                index = 0
                ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_COMPRESSED_IP_ADDRESS_ATTR_TYPE)
                ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_COMPRESSED_IP_TYPE_DESTINATION)
                index += 1

                ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_COMPRESSED_IP_ADDRESS_ATTR_PRIORITY);
                ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), 2);
                index += 1

                ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_COMPRESSED_IP_ADDRESS_ATTR_IP_PREFIX);

                ip_prefix = ifcs_ctypes.ifcs_ip_prefix_t()
                ipv4_addr = ifcs_ctypes.ifcs_ip_addr_t()
                ipv4_mask = ifcs_ctypes.ifcs_ip_addr_t()
                ipv4_addr.ipv4 = sinst_info.ip1
                ipv4_mask.ipv4 = 0xffffffff
                ifcs_ctypes.ifcs_ip_prefix_t_init(pointer(ip_prefix))
                ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_prefix), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)
                ifcs_ctypes.ifcs_ip_prefix_t_addr_set(pointer(ip_prefix), pointer(ipv4_addr))
                ifcs_ctypes.ifcs_ip_prefix_t_mask_set(pointer(ip_prefix), pointer(ipv4_mask))
                ifcs_ctypes.ifcs_attr_t_value_ip_prefix_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), pointer(ip_prefix));
                index += 1

            elif entry_count == 2:
                index = 0
                ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_COMPRESSED_IP_ADDRESS_ATTR_TYPE)
                ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_COMPRESSED_IP_TYPE_SOURCE)
                index += 1

                ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_COMPRESSED_IP_ADDRESS_ATTR_PRIORITY);
                ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), 3);
                index += 1

                ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_COMPRESSED_IP_ADDRESS_ATTR_IP_PREFIX);

                ip_prefix = ifcs_ctypes.ifcs_ip_prefix_t()
                ipv6_addr = ifcs_ctypes.ifcs_ip_addr_t()
                ipv6_mask = ifcs_ctypes.ifcs_ip_addr_t()
                for addr_offset in range(16):
                    ipv6_addr.ipv6[addr_offset] = sinst_info.v6_sip[addr_offset]
                    ipv6_mask.ipv6[addr_offset] = 255
                ipv6_mask.ipv6[addr_offset] = 0
                ifcs_ctypes.ifcs_ip_prefix_t_init(pointer(ip_prefix))
                ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_prefix), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)
                ifcs_ctypes.ifcs_ip_prefix_t_addr_set(pointer(ip_prefix), pointer(ipv6_addr))
                ifcs_ctypes.ifcs_ip_prefix_t_mask_set(pointer(ip_prefix), pointer(ipv6_mask))
                ifcs_ctypes.ifcs_attr_t_value_ip_prefix_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), pointer(ip_prefix));
                index += 1

            else:
                index = 0
                ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_COMPRESSED_IP_ADDRESS_ATTR_TYPE)
                ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_COMPRESSED_IP_TYPE_DESTINATION)
                index += 1

                ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_COMPRESSED_IP_ADDRESS_ATTR_PRIORITY);
                ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), 4);
                index += 1

                ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_COMPRESSED_IP_ADDRESS_ATTR_IP_PREFIX);

                ip_prefix = ifcs_ctypes.ifcs_ip_prefix_t()
                ipv6_addr = ifcs_ctypes.ifcs_ip_addr_t()
                ipv6_mask = ifcs_ctypes.ifcs_ip_addr_t()
                for addr_offset in range(16):
                    ipv6_addr.ipv6[addr_offset] = sinst_info.v6_dip[addr_offset]
                    ipv6_mask.ipv6[addr_offset] = 255
                ipv6_mask.ipv6[addr_offset] = 0
                ifcs_ctypes.ifcs_ip_prefix_t_init(pointer(ip_prefix))
                ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_prefix), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)
                ifcs_ctypes.ifcs_ip_prefix_t_addr_set(pointer(ip_prefix), pointer(ipv6_addr))
                ifcs_ctypes.ifcs_ip_prefix_t_mask_set(pointer(ip_prefix), pointer(ipv6_mask))
                ifcs_ctypes.ifcs_attr_t_value_ip_prefix_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), pointer(ip_prefix));
                index += 1

            acl_cip_hdl = ifcs_ctypes.ifcs_handle_t()
            attrCount = index
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_acl_compressed_ip_address_create(
                    self.node_id, pointer(acl_cip_hdl), attrCount,
                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

            spstcommon_handle_device_access_error(rc, "ifcs_acl_compressed_ip_address_create")
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err("ifcs_acl_compressed_ip_address_create failed with rc: {}" .format(rc))
                assert 0, "ERR during ifcs_acl_compressed_ip_address_create; rc: {}".format( rc)

            sinst_info.list_of_cip_hdl.append(acl_cip_hdl)

    def configAclFpf(self, sinst_info, direction, base_offset):

        fpf_priority = 0
        fpf_cookie = 0
        for fpf_count in range(2):
            fpf_priority += 1
            fpf_cookie += 1
            attrList = (ifcs_ctypes.ifcs_attr_t * 6)()
            for index in range(6):
                rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                assert rc == ifcs_ctypes.IFCS_SUCCESS
            index = 0

            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_FPF_ATTR_DIRECTION)
            ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), direction)
            index += 1

            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_FPF_ATTR_BASE_OFFSET);
            ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), base_offset)
            index += 1

            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_FPF_ATTR_PRIORITY)
            ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), fpf_priority)
            index += 1

            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_FPF_ATTR_COOKIE)
            ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), fpf_cookie)
            index += 1

            #fpf match type
            match_info = ifcs_ctypes.ifcs_fpf_match_info_t()
            ifcs_ctypes.ifcs_fpf_match_info_t_init(pointer(match_info))
            match_info.count = 1
            match_info.arr = (ifcs_ctypes.ifcs_fpf_match_info_t * 1)()

            ifcs_ctypes.ifcs_fpf_match_info_t_type_set(pointer(match_info), ifcs_ctypes.IFCS_FPF_MATCH_TYPE_ETHER_TYPE)
            if fpf_cookie == 1:
                ifcs_ctypes.ifcs_fpf_match_info_t_value_set(pointer(match_info), 0x800)
            else:
                ifcs_ctypes.ifcs_fpf_match_info_t_value_set(pointer(match_info), 0x86dd)
            ifcs_ctypes.ifcs_fpf_match_info_t_mask_set(pointer(match_info), 0xffff)

            fpf_match_list = ifcs_ctypes.ifcs_fpf_match_list_t()
            fpf_match_list.count = 1
            fpf_match_list.arr = pointer(match_info)

            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_FPF_ATTR_MATCH_LIST)
            ifcs_ctypes.ifcs_attr_t_value_fpf_match_list_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), pointer(fpf_match_list));
            index += 1

            #fpf extractors
            fpf_extraction_cmd_list = ifcs_ctypes.ifcs_fpf_extraction_cmd_list_t()
            field_info = ifcs_ctypes.ifcs_fpf_extraction_cmd_info_t()
            ifcs_ctypes.ifcs_fpf_extraction_cmd_info_t_init(pointer(field_info))
            field_info.count = 2
            field_info.arr = (ifcs_ctypes.ifcs_fpf_extraction_cmd_info_t * 2)()

            #field1, src_ip part1
            ifcs_ctypes.ifcs_fpf_extraction_cmd_info_t_base_set(compat_pointerAtIndex(field_info.arr, ifcs_ctypes.ifcs_fpf_extraction_cmd_info_t, 0), ifcs_ctypes.IFCS_FPF_BASE_TYPE_L3);
            if fpf_cookie == 1:
                ifcs_ctypes.ifcs_fpf_extraction_cmd_info_t_offset_set(compat_pointerAtIndex(field_info.arr, ifcs_ctypes.ifcs_fpf_extraction_cmd_info_t, 0), 12);
            else:
                ifcs_ctypes.ifcs_fpf_extraction_cmd_info_t_offset_set(compat_pointerAtIndex(field_info.arr, ifcs_ctypes.ifcs_fpf_extraction_cmd_info_t, 0), 8);
            ifcs_ctypes.ifcs_fpf_extraction_cmd_info_t_field_set(compat_pointerAtIndex(field_info.arr, ifcs_ctypes.ifcs_fpf_extraction_cmd_info_t, 0), ifcs_ctypes.IFCS_FPF_FIELD_1);


            #field2, src_ip part2
            ifcs_ctypes.ifcs_fpf_extraction_cmd_info_t_base_set(compat_pointerAtIndex(field_info.arr, ifcs_ctypes.ifcs_fpf_extraction_cmd_info_t, 1), ifcs_ctypes.IFCS_FPF_BASE_TYPE_L3);
            if fpf_cookie == 1:
                ifcs_ctypes.ifcs_fpf_extraction_cmd_info_t_offset_set(compat_pointerAtIndex(field_info.arr, ifcs_ctypes.ifcs_fpf_extraction_cmd_info_t, 1), 14);
            else:
                ifcs_ctypes.ifcs_fpf_extraction_cmd_info_t_offset_set(compat_pointerAtIndex(field_info.arr, ifcs_ctypes.ifcs_fpf_extraction_cmd_info_t, 1), 10);
            ifcs_ctypes.ifcs_fpf_extraction_cmd_info_t_field_set(compat_pointerAtIndex(field_info.arr, ifcs_ctypes.ifcs_fpf_extraction_cmd_info_t, 1), ifcs_ctypes.IFCS_FPF_FIELD_2);

            fpf_extraction_cmd_list.count = 2
            fpf_extraction_cmd_list.arr = field_info.arr

            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_FPF_ATTR_EXTRACTION_CMD_LIST)
            ifcs_ctypes.ifcs_attr_t_value_fpf_extraction_cmd_list_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), pointer(fpf_extraction_cmd_list));
            index += 1

            acl_fpf_hdl = ifcs_ctypes.ifcs_handle_t()
            attrCount = index
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_fpf_create(
                    self.node_id, pointer(acl_fpf_hdl), attrCount,
                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

            spstcommon_handle_device_access_error(rc, "ifcs_fpf_create")
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err("ifcs_acl_compressed_ip_address_create failed with rc: {}" .format(rc))
                assert 0, "ERR during ifcs_acl_compressed_ip_address_create; rc: {}".format( rc)

            sinst_info.list_of_fpf_hdl.append(acl_fpf_hdl)

    def configAclFlexPool(self, sinst_info, direction, size, acl_tbl_hdl):
        flex_pool_hdl = ifcs_ctypes.ifcs_handle_t()

        #create flex pool
        attrList = (ifcs_ctypes.ifcs_attr_t * 4)()
        for index in range(4):
            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
        index = 0

        ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_FLEX_POOL_ATTR_TARGET)
        ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_FLEX_POOL_TARGET_ACL)
        index += 1

        ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_FLEX_POOL_ATTR_DIRECTION)
        ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), direction)
        index += 1

        ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_FLEX_POOL_ATTR_COUNTER_MODE)
        ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_FLEX_POOL_COUNTER_MODE_ALL)
        index += 1

        ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_FLEX_POOL_ATTR_SIZE)
        ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), size)
        index += 1

        attrCount = index
        rc = ifcs_ctypes.IFCS_STATUS_REASON(
            ifcs_ctypes.ifcs_flex_pool_create(
                self.node_id, pointer(flex_pool_hdl), attrCount,
                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

        spstcommon_handle_device_access_error(rc, "ifcs_flex_pool_create")
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("Failed to create flex pool rc: %d"%rc)
        else:
            sinst_info.list_of_flex_pool_hdl.append(flex_pool_hdl)
            log_dbg(1, "Successfully created flex pool")

        #associate with acl table
        attrList = (ifcs_ctypes.ifcs_attr_t * 1)()
        for index in range(1):
            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
        index = 0

        ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_FLEX_POOL_ATTR_TARGET_INSTANCE)
        ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), acl_tbl_hdl)
        index += 1

        attrCount = index
        rc = ifcs_ctypes.IFCS_STATUS_REASON(
            ifcs_ctypes.ifcs_flex_pool_attr_set(
                self.node_id, flex_pool_hdl, attrCount,
                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

        spstcommon_handle_device_access_error(rc, "ifcs_flex_pool_attr_set")
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("Failed to assoicate flex pool with acl table rc: %d"%rc)
        else:
            log_dbg(1, "Successfully assoicated flex pool with acl table")

    def configAclFlexCounterset(self, sinst_info):
        flex_pool_hdl = sinst_info.list_of_flex_pool_hdl[0]

        #create flex counterset
        flex_counterset_hdl = ifcs_ctypes.ifcs_handle_t()

        attrList = (ifcs_ctypes.ifcs_attr_t * 1)()
        for index in range(1):
            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
        index = 0

        ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_FLEX_COUNTERSET_ATTR_FLEX_POOL)
        ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), flex_pool_hdl)
        index += 1

        attrCount = index
        rc = ifcs_ctypes.IFCS_STATUS_REASON(
            ifcs_ctypes.ifcs_flex_counterset_create(
                self.node_id, pointer(flex_counterset_hdl), attrCount,
                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

        spstcommon_handle_device_access_error(rc, "ifcs_flex_counterset_create")
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("Failed to create flex counterset rc: %d"%rc)
            return 0
        else:
            sinst_info.list_of_flex_counterset_hdl.append(flex_counterset_hdl)
            log_dbg(1, "Successfully created flex counterset")
            return flex_counterset_hdl

    def configAclCreate(self, table_type, lookupStage, scope, maxWidth, size, numTables, tableStartPriority, catchAll, fillTable, sinst_info):
        global ingress_delete_acls, egress_delete_acls

        for table_count in range(numTables):
            log_dbg(1, "Creating ACL Match Profile")
            matchProfile = ifcs_ctypes.ifcs_handle_t()
            attrList = (ifcs_ctypes.ifcs_attr_t * 9)()
            for index in range(9):
                rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                assert rc == ifcs_ctypes.IFCS_SUCCESS
            index = 0

            match_types = ifcs_ctypes.ifcs_u32_list_t()
            if table_type == 0:
                sinst_info.ace_priority = 1000
                match_types.count = 14
                match_types.arr = (c_uint32 * match_types.count)()
                match_types.arr[0] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_SYSPORT
                match_types.arr[1] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_L3VNI
                match_types.arr[2] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_L3_INTERFACE
                match_types.arr[3] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_FORWARD_DESTINATION_TYPE
                match_types.arr[4] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_FORWARD_DESTINATION
                match_types.arr[5] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_FWD_LAYER
                match_types.arr[6] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_DESTINATION_MAC_HIT
                match_types.arr[7] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_L2_INTERFACE_USER_COOKIE
                match_types.arr[8] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_L3_INTERFACE_USER_COOKIE
                match_types.arr[9] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L2_TYPE
                match_types.arr[10] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_DESTINATION_MAC_TYPE
                match_types.arr[11] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_TUNNEL_DETECTED
                match_types.arr[12] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_TUNNEL_TERMINATED
                match_types.arr[13] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L3_TYPE
            elif table_type == 5:
                sinst_info.ace_priority = 6000
                match_types.count = 16
                match_types.arr = (c_uint32 * match_types.count)()
                match_types.arr[0] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L3VNI_USER_COOKIE
                match_types.arr[1] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_IP_EXT_HDR_1_TYPE
                match_types.arr[2] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_IP_EXT_HDR_2_TYPE
                match_types.arr[3] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_STP_STATE
                match_types.arr[4] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_COMPRESSED_SOURCE_IP_ADDRESS
                match_types.arr[5] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_COMPRESSED_DESTINATION_IP_ADDRESS
                match_types.arr[6] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L3_TYPE
                match_types.arr[7] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_FPF_COOKIE
                match_types.arr[8] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_FPF_VALID
                match_types.arr[9] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_FPF_FIELD1
                match_types.arr[10] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_FPF_FIELD2
                match_types.arr[11] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_IP_IS_FRAG
                match_types.arr[12] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_IP_FIRST_FRAG
                match_types.arr[13] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_ROUTABLE
                match_types.arr[14] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_DESTINATION_L3_HIT
                match_types.arr[15] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_ROUTE_DESTINATION_IP_USER_COOKIE
            elif table_type == 1:
                sinst_info.ace_priority = 2000
                match_types.count = 4
                match_types.arr = (c_uint32 * match_types.count)()
                match_types.arr[0] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_DESTINATION_MAC_ADDRESS
                match_types.arr[1] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_EGRESS_SYSPORT
                match_types.arr[2] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_EGRESS_SYSPORT_LAG
                match_types.arr[3] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INT_DIB_DIBP
            elif table_type == 2:
                sinst_info.ace_priority = 3000
                match_types.count = 5
                match_types.arr = (c_uint32 * match_types.count)()
                match_types.arr[0] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_SYSPORT
                match_types.arr[1] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INT_SIB_SIBP
                match_types.arr[2] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L4_PROTOCOL
                match_types.arr[3] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_SOURCE_L4_PORT
                match_types.arr[4] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L3_TYPE
            elif table_type == 3:
                sinst_info.ace_priority = 4000
                match_types.count = 1
                match_types.arr = (c_uint32 * match_types.count)()
                match_types.arr[0] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L3_TYPE
            elif table_type == 4:
                sinst_info.ace_priority = 5000
                match_types.count = 4
                match_types.arr = (c_uint32 * match_types.count)()
                match_types.arr[0] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_MIRROR
                match_types.arr[1] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_DESTINATION_L4_PORT
                match_types.arr[2] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_EGRESS_SYSPORT
                match_types.arr[3] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INT_SIB_SIBP
                match_index = 0
                cs_index = 0
            elif table_type == 6:
                sinst_info.ace_priority = 7000
                match_types.count = 9
                match_types.arr = (c_uint32 * match_types.count)()
                match_types.arr[0] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_FWD_LAYER
                match_types.arr[1] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_NEXTHOP_NO_DECREMENT_TTL
                match_types.arr[2] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INT_IPT_INGRESS_ENABLE
                match_types.arr[3] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_SYSTEM_TC_DP
                match_types.arr[4] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L3_QOS
                match_types.arr[5] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_EGRESS_L3_TTL
                match_types.arr[6] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_EGRESS_SYSPORT
                match_types.arr[7] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_EGRESS_L3_INTERFACE_USER_COOKIE
                match_types.arr[8] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L3_NEXTHOP_USER_COOKIE
            elif table_type == 7:
                sinst_info.ace_priority = 8000
                match_types.count = 8
                match_types.arr = (c_uint32 * match_types.count)()
                match_types.arr[0] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_SOURCE_IPV6_ADDRESS
                match_types.arr[1] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_DESTINATION_IPV6_ADDRESS
                match_types.arr[2] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_ETHER_TYPE
                match_types.arr[3] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_VLAN_PRIORITY
                match_types.arr[4] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_VLAN_CFI
                match_types.arr[5] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_VLAN_ID
                match_types.arr[6] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_L3_TTL
                match_types.arr[7] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L3_QOS
            elif table_type == 8:
                sinst_info.ace_priority = 9000
                match_types.count = 5
                match_types.arr = (c_uint32 * match_types.count)()
                match_types.arr[0] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_SOURCE_MAC_ADDRESS
                match_types.arr[1] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_DESTINATION_MAC_ADDRESS
                match_types.arr[2] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L4_PROTOCOL
                match_types.arr[3] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_SOURCE_L4_PORT
                match_types.arr[4] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_DESTINATION_L4_PORT
            elif table_type == 9:
                sinst_info.ace_priority = 10000
                match_types.count = 1
                match_types.arr = (c_uint32 * match_types.count)()
                match_types.arr[0] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_SYSPORT
            elif table_type == 10:
                sinst_info.ace_priority = 11000
                match_types.count = 1
                match_types.arr = (c_uint32 * match_types.count)()
                match_types.arr[0] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_SYSPORT
            else:
                log_err("Invalid table_type: %d"%table_type)

            attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_PROFILE_ATTR_MATCH_TYPES
            attrList[index].value.u32_list = match_types
            index += 1

            attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_PROFILE_ATTR_LOOKUP_STAGE
            attrList[index].value.u32 = lookupStage
            index += 1

            attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_PROFILE_ATTR_DIRECTION
            if table_type == 0 or table_type == 3 or table_type == 5 or table_type == 7 or table_type == 8 or table_type == 9 or table_type == 10:
                attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_DIRECTION_INGRESS
            else:
                attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_DIRECTION_EGRESS

            index += 1

            attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_PROFILE_ATTR_MAX_WIDTH
            attrList[index].value.u32 = maxWidth
            index += 1

            if table_type == 0 or table_type == 5 or table_type == 7 or table_type == 8:
                attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_PROFILE_ATTR_PORT_SHARING
                attrList[index].value.data = ifcs_ctypes.IFCS_BOOL_TRUE
                index += 1

            attrCount = index
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.im_acl_match_profile_create(
                    self.node_id, pointer(matchProfile), attrCount,
                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err("Failed to create ACL Match Profile: %d"%rc)
            else:
                sinst_info.list_of_mp_hdl.append(matchProfile)
                log_dbg(1, "Successfully created ACL Match Profile")

            log_dbg(1, "Creating ACL Action Profile")
            actionProfile = ifcs_ctypes.ifcs_handle_t()
            attrList = (ifcs_ctypes.ifcs_attr_t * 4)()
            for index in range(4):
                rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                assert rc == ifcs_ctypes.IFCS_SUCCESS
            index = 0

            action_types = ifcs_ctypes.ifcs_u32_list_t()
            action_types.count = 3
            action_types.arr = (c_uint32 * action_types.count)()
            action_types.arr[0] = ifcs_ctypes.IFCS_ACL_ACTION_TYPE_DROP
            action_types.arr[1] = ifcs_ctypes.IFCS_ACL_ACTION_TYPE_FLEX_COUNTERSET
            action_types.arr[2] = ifcs_ctypes.IFCS_ACL_ACTION_TYPE_MIRROR
            attrList[index].id = ifcs_ctypes.IFCS_ACL_ACTION_PROFILE_ATTR_ACTION_TYPES
            attrList[index].value.u32_list = action_types
            index += 1

            attrList[index].id = ifcs_ctypes.IFCS_ACL_ACTION_PROFILE_ATTR_LOOKUP_STAGE
            attrList[index].value.u32 = lookupStage
            index += 1

            attrList[index].id = ifcs_ctypes.IFCS_ACL_ACTION_PROFILE_ATTR_DIRECTION
            if table_type == 0 or table_type == 3 or table_type == 5 or table_type == 7 or table_type == 8 or table_type == 9 or table_type == 10:
                attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_DIRECTION_INGRESS
            else:
                attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_DIRECTION_EGRESS
            index += 1

            attrCount = index
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_acl_action_profile_create(
                    self.node_id, pointer(actionProfile), attrCount,
                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

            spstcommon_handle_device_access_error(rc, "ifcs_acl_action_profile_create")
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err("Failed to create ACL Action Profile: %d"%rc)
            else:
                sinst_info.list_of_ap_hdl.append(actionProfile)
                log_dbg(1, "Successfully created ACL Action Profile")

            log_dbg(1, "Creating ACL Table")
            aclTable = ifcs_ctypes.ifcs_handle_t()
            attrList = (ifcs_ctypes.ifcs_attr_t * 10)()
            for index in range(10):
                rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                assert rc == ifcs_ctypes.IFCS_SUCCESS
            index = 0

            attrList[index].id = ifcs_ctypes.IFCS_ACL_TABLE_ATTR_MATCH_PROFILE
            attrList[index].value.handle = matchProfile
            index += 1

            attrList[index].id = ifcs_ctypes.IFCS_ACL_TABLE_ATTR_ACTION_PROFILE
            attrList[index].value.handle = actionProfile
            index += 1

            attrList[index].id = ifcs_ctypes.IFCS_ACL_TABLE_ATTR_LOOKUP_STAGE
            attrList[index].value.u32 = lookupStage
            index += 1

            attrList[index].id = ifcs_ctypes.IFCS_ACL_TABLE_ATTR_DIRECTION
            if table_type == 0 or table_type == 3 or table_type == 5 or table_type == 7 or table_type == 8 or table_type == 9 or table_type == 10:
                attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_DIRECTION_INGRESS
            else:
                attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_DIRECTION_EGRESS
            index += 1

            if table_type == 4:
                attrList[index].id = ifcs_ctypes.IFCS_ACL_TABLE_ATTR_PREMATCH
                attrList[index].value.u32 = (ifcs_ctypes.IFCS_ACL_PREMATCH_MIRRORED | ifcs_ctypes.IFCS_ACL_PREMATCH_NOT_MIRRORED)
                index += 1

            attrList[index].id = ifcs_ctypes.IFCS_ACL_TABLE_ATTR_SCOPE
            attrList[index].value.u32 = scope
            index += 1

            priority = table_count + tableStartPriority
            attrList[index].id = ifcs_ctypes.IFCS_ACL_TABLE_ATTR_PRIORITY
            attrList[index].value.u32 = priority
            index += 1

            attrList[index].id = ifcs_ctypes.IFCS_ACL_TABLE_ATTR_SIZE
            attrList[index].value.u32 = size
            index += 1

            attrCount = index
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_acl_table_create(
                    self.node_id,
                    pointer(aclTable),
                    attrCount,
                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

            spstcommon_handle_device_access_error(rc, "ifcs_acl_table_create")
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err("Failed to create ACL Table:%d"%rc)
            else:
                sinst_info.list_of_acl_table_hdl.append(aclTable)
                log_dbg(1, "Successfully created ACL Table {}".format(table_type))
                if table_type == 10:
                    self.configAclFlexPool(sinst_info,  ifcs_ctypes.IFCS_FLEX_POOL_DIRECTION_INGRESS, 100, aclTable)

            if table_type == 4:
                devport_list = sinst_info.mirror_port_list
                port_fwd_inst_list = sinst_info.port_fwd_inst_list
                mirror_id = 0
            else:
                devport_list = sinst_info.devport_list
                port_fwd_inst_list = sinst_info.port_fwd_inst_list

            nxt = 0
            mac_flag = True
            for devport in devport_list:
                log_dbg(1, "Creating ACL matches for port {}".format (devport))
                if devport == devport_list[-1]: #last port
                    next_devport = devport_list[0]
                    last_port = 1
                else:
                    last_port = 0
                    next_devport = devport_list[nxt+1]

                if devport == devport_list[0]:
                    prev_devport = devport_list[-1]
                else:
                    prev_devport = devport_list[nxt-1]

                prev_port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[prev_devport].sp_hdl)
                next_port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[next_devport].sp_hdl)

                if mac_flag is False:
                    dest_mac = sinst_info.intfmac1
                    src_mac = sinst_info.intfmac2
                    mac_flag = True
                else:
                    dest_mac = sinst_info.intfmac2
                    src_mac = sinst_info.intfmac1
                    mac_flag = False
                nxt += 1

                if table_type == 0:
                    ing_tbl0_ace1_match_hdls = []
                    ing_tbl0_ace2_match_hdls = []
                    #INGRESS
                    #1 match ingress sysport
                    match_number = 1
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_SYSPORT
                    index += 1
                    sp_hdl = ifcs_ctypes.ifcs_handle_t()
                    port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[devport].sp_hdl)
                    sp_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)
                    ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_MATCH_ATTR_OBJECT);
                    ifcs_ctypes.ifcs_attr_t_value_handle_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), sp_hdl);
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d ingress sysport %d for port %d"%(match_number, port_sp, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1


                    #4 match ingres_l3vni
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_L3VNI
                    index += 1
                    ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_MATCH_ATTR_OBJECT);
                    ifcs_ctypes.ifcs_attr_t_value_handle_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), port_fwd_inst_list[devport].l3vni_hdl);
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d l3vni for ingress L3VNI port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for ingress L3VNI port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #5 match ingres_l3_interface
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_L3_INTERFACE
                    index += 1
                    ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_MATCH_ATTR_OBJECT);
                    ifcs_ctypes.ifcs_attr_t_value_handle_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), port_fwd_inst_list[devport].intf_hdl);
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d ingress L3 interface for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d ingress l3 interface for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #6 match forward_destination_type
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_FORWARD_DESTINATION_TYPE
                    index += 1
                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    #1: sysport, 2: lag 5: NH
                    value.arr[0]=5
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #8 match fwd_layer
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_FWD_LAYER
                    index += 1
                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    #0: switched, 1: routed
                    value.arr[0]=1
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #9 match destination_mac_hit
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_DESTINATION_MAC_HIT
                    index += 1
                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    #0: not hit, 1: hit
                    value.arr[0]=1
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #11 match ingress l2 interface user cookie
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_L2_INTERFACE_USER_COOKIE
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 2
                    value.arr = (c_uint8 * 2)()
                    value.arr[0]= ((port_fwd_inst_list[devport].sp_cookie & 0x300) >> 8)
                    value.arr[1]= (port_fwd_inst_list[devport].sp_cookie & 0xff)
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #13 match ingress l3 interface user cookie
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_L3_INTERFACE_USER_COOKIE
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 2
                    value.arr = (c_uint8 * 2)()
                    value.arr[0]= ((port_fwd_inst_list[devport].intf_cookie & 0x300) >> 8)
                    value.arr[1]= (port_fwd_inst_list[devport].intf_cookie & 0xff)
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("Create AclMatch %d l3intf user cookie %d for port %d failed"%(match_number, port_fwd_inst_list[next_devport].intf_cookie, devport))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d l3intf user cookie %d for port %d"%(match_number, port_fwd_inst_list[next_devport].intf_cookie, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #16 match l2 type
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L2_TYPE
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    # 0: none 1: Ethernet2, 2:LLC-SNAP 3:LLC
                    value.arr[0]=1
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #18 match destination mac type
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_DESTINATION_MAC_TYPE
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    # 0: UC  1: IPMC 2: L2MC 3: BC
                    value.arr[0]=0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #19 match tunnel detected
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_TUNNEL_DETECTED
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    value.arr[0]=0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #20 match tunnel terminated
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_TUNNEL_TERMINATED
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    value.arr[0]=0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    ######################################################
                    #### MATCHES that are different in ACE 1 and ACE2 ####
                    #### should come after the common Matches ############
                    ######################################################

                    for acl_match in sinst_info.ingress_match_list_hdls[devport]:
                        ing_tbl0_ace1_match_hdls.append(acl_match)
                        ing_tbl0_ace2_match_hdls.append(acl_match)
                        sinst_info.list_of_all_acl_match_hdls.append(acl_match)


                    #17 match l3 type

                    for ace_counter in range(2):
                        aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                        attrList = (ifcs_ctypes.ifcs_attr_t * 4)()
                        for index in range(4):
                            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                            assert rc == ifcs_ctypes.IFCS_SUCCESS
                        index = 0
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                        attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L3_TYPE
                        index += 1

                        #set value
                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 1
                        value.arr = (c_uint8 * 1)()
                        # 4: ipv4 5: ipv4_ext, 6: ipv6 7:ipv6_ext
                        if ace_counter == 0:
                            value.arr[0] = 0x4
                        else:
                            value.arr[0] = 0x6

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                        attrList[index].value.u8_list = value
                        index += 1

                        #set mask
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MASK
                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 1
                        value.arr = (c_uint8 * 1)()
                        if ace_counter == 0:
                            value.arr[0] = 0x6
                        else:
                            value.arr[0] = 0x7

                        attrList[index].value.u8_list = value
                        index += 1

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                        attrList[index].value.handle = matchProfile
                        index += 1

                        attrCount = index
                        rc = ifcs_ctypes.IFCS_STATUS_REASON(
                                ifcs_ctypes.ifcs_acl_match_create(
                                    self.node_id,
                                    pointer(aclMatch1),
                                    attrCount,
                                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                        spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                            log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                        else:
                            log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                            if ace_counter == 0:
                                ing_tbl0_ace1_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            else:
                                ing_tbl0_ace2_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            #sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                    match_number += 1

                    #7 match forwarding destination
                    for ace_counter in range(2):
                        aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                        attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                        for index in range(3):
                            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                            assert rc == ifcs_ctypes.IFCS_SUCCESS
                        index = 0
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                        attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_FORWARD_DESTINATION
                        index += 1
                        ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_MATCH_ATTR_OBJECT);
                        if ace_counter == 0:
                            ifcs_ctypes.ifcs_attr_t_value_handle_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), port_fwd_inst_list[next_devport].nh4_picked_hdl);
                        else:
                            ifcs_ctypes.ifcs_attr_t_value_handle_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), port_fwd_inst_list[next_devport].nh6_picked_hdl);
                        index += 1

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                        attrList[index].value.handle = matchProfile
                        index += 1

                        attrCount = index
                        rc = ifcs_ctypes.IFCS_STATUS_REASON(
                                ifcs_ctypes.im_acl_match_create(
                                    self.node_id,
                                    pointer(aclMatch1),
                                    attrCount,
                                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                            log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                        else:
                            log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                            if ace_counter == 0:
                                ing_tbl0_ace1_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            else:
                                ing_tbl0_ace2_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                    match_number += 1

                    #match_set = sinst_info.ingress_match_list_hdls[devport]

                elif table_type == 5:
                    ing_tbl5_ace1_match_hdls = []
                    ing_tbl5_ace2_match_hdls = []
                    #INGRESS
                    #1 match ingress sysport
                    match_number = 1
                    #14 match ingress l3vni user cookie
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L3VNI_USER_COOKIE
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 2
                    value.arr = (c_uint8 * 2)()
                    value.arr[0]= ((port_fwd_inst_list[devport].l3vni_cookie & 0x300) >> 8)
                    value.arr[1]= (port_fwd_inst_list[devport].l3vni_cookie & 0xff)
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls3[devport].append(aclMatch1)
                        match_number += 1

                    #21 match ip ext hdr1 type
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_IP_EXT_HDR_1_TYPE
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    #0: none
                    value.arr[0]=0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls3[devport].append(aclMatch1)
                        match_number += 1

                    #22 match ip ext hdr2 type
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_IP_EXT_HDR_2_TYPE
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    #0: none
                    value.arr[0]=0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls3[devport].append(aclMatch1)
                        match_number += 1

                    #23 match ingress stp state
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_STP_STATE
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    #0: blocking 1: listen 2: learn 3: forward
                    value.arr[0]=3
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls3[devport].append(aclMatch1)
                        match_number += 1

                    #match_set = sinst_info.ingress_match_list_hdls[devport]

                    #24 match fpf valid
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_FPF_VALID
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    value.arr[0]=3
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d (fpf valid) for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d (fpf valid) for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls3[devport].append(aclMatch1)
                        match_number += 1

                    #23 match routable
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_ROUTABLE
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    #0: not routable 1: routable
                    value.arr[0]=1
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d (routable) for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d (routable) for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls3[devport].append(aclMatch1)
                        match_number += 1

                    #23 match destination l3 hit
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_DESTINATION_L3_HIT
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    #0: not hit 1: hit
                    value.arr[0]=1
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d ( destination l3 hit) for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d ( destination l3 hit) for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls3[devport].append(aclMatch1)
                        match_number += 1

                    for acl_match in sinst_info.ingress_match_list_hdls3[devport]:
                        ing_tbl5_ace1_match_hdls.append(acl_match)
                        ing_tbl5_ace2_match_hdls.append(acl_match)
                        sinst_info.list_of_all_acl_match_hdls.append(acl_match)

                    ######################################################
                    #### MATCHES that are different in ACE 1 and ACE2 ####
                    #### should come after the common Matches ############
                    ######################################################

                    #13 match route destination ip user cookie
                    for ace_counter in range(2):
                        aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                        attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                        for index in range(3):
                            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                            assert rc == ifcs_ctypes.IFCS_SUCCESS
                        index = 0
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                        attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_ROUTE_DESTINATION_IP_USER_COOKIE
                        index += 1

                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 1
                        value.arr = (c_uint8 * 1)()
                        if ace_counter == 0 :
                            route_cookie = (port_fwd_inst_list[devport].v4_route_cookie & 0xff)
                        else:
                            route_cookie = (port_fwd_inst_list[devport].v6_route_cookie & 0xff)
                        value.arr[0]= (route_cookie & 0xff)
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                        attrList[index].value.u8_list = value
                        index += 1

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                        attrList[index].value.handle = matchProfile
                        index += 1

                        attrCount = index
                        rc = ifcs_ctypes.IFCS_STATUS_REASON(
                                ifcs_ctypes.ifcs_acl_match_create(
                                    self.node_id,
                                    pointer(aclMatch1),
                                    attrCount,
                                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                        spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                            log_err("Create AclMatch %d route destination ip user cookie %d for port %d failed"%(match_number, route_cookie, devport))
                        else:
                            log_dbg(1, "Successfully created AclMatch %d route destination ip user cookie %d for port %d"%(match_number, route_cookie, devport))
                            if ace_counter == 0:
                                ing_tbl5_ace1_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            else:
                                ing_tbl5_ace2_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            #sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                    match_number += 1

                    #25 match fpf cookie
                    fpf_cookie = 0
                    for fpf_count in range(2):
                        fpf_cookie += 1
                        aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                        attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                        for index in range(3):
                            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                            assert rc == ifcs_ctypes.IFCS_SUCCESS
                        index = 0
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                        attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_FPF_COOKIE
                        index += 1

                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 1
                        value.arr = (c_uint8 * 1)()
                        value.arr[0]=fpf_cookie
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                        attrList[index].value.u8_list = value
                        index += 1

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                        attrList[index].value.handle = matchProfile
                        index += 1

                        attrCount = index
                        rc = ifcs_ctypes.IFCS_STATUS_REASON(
                                ifcs_ctypes.ifcs_acl_match_create(
                                    self.node_id,
                                    pointer(aclMatch1),
                                    attrCount,
                                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                        spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                            log_err("table_type %d, failed to create AclMatch %d (fpf cookie) for port %d rc %d"%(table_type, match_number, devport, rc))
                        else:
                            log_dbg(1, "Successfully created AclMatch %d (fpf cookie) for port %d"%(match_number, devport))
                            sinst_info.ingress_match_list_hdls3[devport].append(aclMatch1)
                            sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            if fpf_count == 0:
                                ing_tbl5_ace1_match_hdls.append(aclMatch1)
                            else:
                                ing_tbl5_ace2_match_hdls.append(aclMatch1)
                    match_number += 1

                    #27 match fpf field1
                    for fpf_count in range(2):
                        aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                        attrList = (ifcs_ctypes.ifcs_attr_t * 4)()
                        for index in range(4):
                            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                            assert rc == ifcs_ctypes.IFCS_SUCCESS
                        index = 0
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                        attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_FPF_FIELD1
                        index += 1

                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 2
                        value.arr = (c_uint8 * 2)()
                        #TODO@ACLP2 fill source ipv4 and ipv6 addr part1 (two bytes)
                        if fpf_count == 0:
                            value.arr[0]=(sinst_info.ip2 >> 24) & 0xFF
                            value.arr[1]=(sinst_info.ip2 >> 16) & 0xFF
                        else:
                            value.arr[0] = sinst_info.v6_sip[0]
                            value.arr[1] = sinst_info.v6_sip[1]
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                        attrList[index].value.u8_list = value
                        index += 1

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MASK
                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 2
                        value.arr = (c_uint8 * 2)()
                        value.arr[0] = 0xff
                        value.arr[1] = 0xff
                        attrList[index].value.u8_list = value
                        index += 1

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                        attrList[index].value.handle = matchProfile
                        index += 1

                        attrCount = index
                        rc = ifcs_ctypes.IFCS_STATUS_REASON(
                                ifcs_ctypes.ifcs_acl_match_create(
                                    self.node_id,
                                    pointer(aclMatch1),
                                    attrCount,
                                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                        spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                            log_err("table_type %d, failed to create AclMatch %d (fpf field1) for port %d rc %d"%(table_type, match_number, devport, rc))
                        else:
                            log_dbg(1, "Successfully created AclMatch %d (fpf field1) for port %d"%(match_number, devport))
                            sinst_info.ingress_match_list_hdls3[devport].append(aclMatch1)
                            sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            if fpf_count == 0:
                                ing_tbl5_ace1_match_hdls.append(aclMatch1)
                            else:
                                ing_tbl5_ace2_match_hdls.append(aclMatch1)
                    match_number += 1

                    #28 match fpf field2
                    for fpf_count in range(2):
                        aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                        attrList = (ifcs_ctypes.ifcs_attr_t * 4)()
                        for index in range(4):
                            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                            assert rc == ifcs_ctypes.IFCS_SUCCESS
                        index = 0
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                        attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_FPF_FIELD2
                        index += 1

                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 2
                        value.arr = (c_uint8 * 2)()
                        #TODO@ACLP2 fill source ipv4 and ipv6 addr part2 (two bytes)
                        if fpf_count == 0:
                            value.arr[0]=(sinst_info.ip2 >> 8) & 0xFF
                            value.arr[1]=(sinst_info.ip2) & 0xFF
                        else:
                            value.arr[0] = sinst_info.v6_sip[2]
                            value.arr[1] = sinst_info.v6_sip[3]
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                        attrList[index].value.u8_list = value
                        index += 1

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MASK
                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 2
                        value.arr = (c_uint8 * 2)()
                        value.arr[0] = 0xff
                        value.arr[1] = 0xff
                        attrList[index].value.u8_list = value
                        index += 1

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                        attrList[index].value.handle = matchProfile
                        index += 1

                        attrCount = index
                        rc = ifcs_ctypes.IFCS_STATUS_REASON(
                                ifcs_ctypes.ifcs_acl_match_create(
                                    self.node_id,
                                    pointer(aclMatch1),
                                    attrCount,
                                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                        spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                            log_err("table_type %d, failed to create AclMatch %d (fpf field2) for port %d rc %d"%(table_type, match_number, devport, rc))
                        else:
                            log_dbg(1, "Successfully created AclMatch %d (fpf field2) for port %d"%(match_number, devport))
                            sinst_info.ingress_match_list_hdls3[devport].append(aclMatch1)
                            sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            if fpf_count == 0:
                                ing_tbl5_ace1_match_hdls.append(aclMatch1)
                            else:
                                ing_tbl5_ace2_match_hdls.append(aclMatch1)
                    match_number += 1

                    #29 match l3 type
                    for ace_counter in range(2):
                        aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                        attrList = (ifcs_ctypes.ifcs_attr_t * 4)()
                        for index in range(4):
                            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                            assert rc == ifcs_ctypes.IFCS_SUCCESS
                        index = 0
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                        attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L3_TYPE
                        index += 1

                        #set value
                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 1
                        value.arr = (c_uint8 * 1)()
                        # 4: ipv4 5: ipv4_ext, 6: ipv6 7:ipv6_ext
                        if ace_counter == 0:
                            value.arr[0] = 0x4
                        else:
                            value.arr[0] = 0x6

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                        attrList[index].value.u8_list = value
                        index += 1

                        #set mask
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MASK
                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 1
                        value.arr = (c_uint8 * 1)()
                        if ace_counter == 0:
                            value.arr[0] = 0x6
                        else:
                            value.arr[0] = 0x7

                        attrList[index].value.u8_list = value
                        index += 1

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                        attrList[index].value.handle = matchProfile
                        index += 1

                        attrCount = index
                        rc = ifcs_ctypes.IFCS_STATUS_REASON(
                                ifcs_ctypes.ifcs_acl_match_create(
                                    self.node_id,
                                    pointer(aclMatch1),
                                    attrCount,
                                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                        spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                            log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                        else:
                            log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                            if ace_counter == 0:
                                ing_tbl5_ace1_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            else:
                                ing_tbl5_ace2_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            #sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                    match_number += 1

                    # match 28 COMPRESSED SOURCE IP
                    for ace_counter in range(2):
                        aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                        attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                        for index in range(3):
                            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                            assert rc == ifcs_ctypes.IFCS_SUCCESS
                        index = 0
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                        attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_COMPRESSED_SOURCE_IP_ADDRESS
                        index += 1
                        cip_hdl = ifcs_ctypes.ifcs_handle_t()

                        if ace_counter == 0:
                            cip_hdl = sinst_info.list_of_cip_hdl[0]
                        else:
                            cip_hdl = sinst_info.list_of_cip_hdl[2]

                        ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_MATCH_ATTR_OBJECT);
                        ifcs_ctypes.ifcs_attr_t_value_handle_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), cip_hdl);
                        index += 1

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                        attrList[index].value.handle = matchProfile
                        index += 1

                        attrCount = index
                        rc = ifcs_ctypes.IFCS_STATUS_REASON(
                                ifcs_ctypes.ifcs_acl_match_create(
                                    self.node_id,
                                    pointer(aclMatch1),
                                    attrCount,
                                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                        spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                            log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                        else:
                            log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                            if ace_counter == 0:
                                ing_tbl5_ace1_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            else:
                                ing_tbl5_ace2_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            #sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                    match_number += 1

                    # match 29 COMPRESSED DESTINATION IP
                    for ace_counter in range(2):
                        aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                        attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                        for index in range(3):
                            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                            assert rc == ifcs_ctypes.IFCS_SUCCESS
                        index = 0
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                        attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_COMPRESSED_DESTINATION_IP_ADDRESS
                        index += 1
                        cip_hdl = ifcs_ctypes.ifcs_handle_t()

                        if ace_counter == 0:
                            cip_hdl = sinst_info.list_of_cip_hdl[1]
                        else:
                            cip_hdl = sinst_info.list_of_cip_hdl[3]

                        ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_MATCH_ATTR_OBJECT);
                        ifcs_ctypes.ifcs_attr_t_value_handle_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), cip_hdl);
                        index += 1

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                        attrList[index].value.handle = matchProfile
                        index += 1

                        attrCount = index
                        rc = ifcs_ctypes.IFCS_STATUS_REASON(
                                ifcs_ctypes.ifcs_acl_match_create(
                                    self.node_id,
                                    pointer(aclMatch1),
                                    attrCount,
                                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                        spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                            log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                        else:
                            log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                            if ace_counter == 0:
                                ing_tbl5_ace1_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            else:
                                ing_tbl5_ace2_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            #sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                    match_number += 1

                    #23 match ip_is_frag
                    for ace_counter in range(2):
                        if ace_counter == 1:
                            break
                        aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                        attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                        for index in range(3):
                            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                            assert rc == ifcs_ctypes.IFCS_SUCCESS
                        index = 0
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                        attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_IP_IS_FRAG
                        index += 1

                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 1
                        value.arr = (c_uint8 * 1)()
                        #0: not fragmented 1: fragmented
                        value.arr[0]=1
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                        attrList[index].value.u8_list = value
                        index += 1

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                        attrList[index].value.handle = matchProfile
                        index += 1

                        attrCount = index
                        rc = ifcs_ctypes.IFCS_STATUS_REASON(
                                ifcs_ctypes.ifcs_acl_match_create(
                                    self.node_id,
                                    pointer(aclMatch1),
                                    attrCount,
                                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                        spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                            log_err("table_type %d, failed to create AclMatch %d (ip is frag) for port %d rc %d"%(table_type, match_number, devport, rc))
                        else:
                            log_dbg(1, "Successfully created AclMatch %d (ip is frag) for port %d"%(match_number, devport))
                            if ace_counter == 0:
                                ing_tbl5_ace1_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            else:
                                ing_tbl5_ace2_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                    match_number += 1

                    #23 match IP_FIRST_FRAG
                    for ace_counter in range(2):
                        if ace_counter == 1:
                            break
                        aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                        attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                        for index in range(3):
                            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                            assert rc == ifcs_ctypes.IFCS_SUCCESS
                        index = 0
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                        attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_IP_FIRST_FRAG
                        index += 1

                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 1
                        value.arr = (c_uint8 * 1)()
                        #0: not first fragment 1: first fragment
                        value.arr[0]=0
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                        attrList[index].value.u8_list = value
                        index += 1

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                        attrList[index].value.handle = matchProfile
                        index += 1

                        attrCount = index
                        rc = ifcs_ctypes.IFCS_STATUS_REASON(
                                ifcs_ctypes.ifcs_acl_match_create(
                                    self.node_id,
                                    pointer(aclMatch1),
                                    attrCount,
                                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                        spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                            log_err("table_type %d, failed to create AclMatch %d (first frag) for port %d rc %d"%(table_type, match_number, devport, rc))
                        else:
                            log_dbg(1, "Successfully created AclMatch %d (first frag) for port %d"%(match_number, devport))
                            if ace_counter == 0:
                                ing_tbl5_ace1_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            else:
                                ing_tbl5_ace2_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                    match_number += 1

                elif table_type == 7:
                    ing_tbl7_ace1_match_hdls = []
                    ing_tbl7_ace2_match_hdls = []
                    #INGRESS
                    match_number = 1
                    # Match Vlan Priority (3 bits, 0-7)
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_VLAN_PRIORITY
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    vlan_priority = sinst_info.port_fwd_inst_list[devport].dot1p
                    value.arr[0]= (vlan_priority & 0x7)
                    #value.arr[0]= ((port_fwd_inst_list[next_devport].l3vni_cookie & 0x300) >> 8)
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls4[devport].append(aclMatch1)
                        match_number += 1

                    # Match Vlan CFI (1 bit, 0-1)
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_VLAN_CFI
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    vlan_cfi = sinst_info.port_fwd_inst_list[devport].cfi
                    value.arr[0]= (vlan_cfi & 0x1)
                    #value.arr[0]= ((port_fwd_inst_list[next_devport].l3vni_cookie & 0x300) >> 8)
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls4[devport].append(aclMatch1)
                        match_number += 1

                    # Match Vlan ID (12 bits)
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_VLAN_ID
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 2
                    value.arr = (c_uint8 * 2)()
                    vlan_id = sinst_info.port_fwd_inst_list[devport].si_vlan
                    value.arr[0]= ((vlan_id >> 8) & 0xf)
                    value.arr[1]= (vlan_id & 0xff)
                    #value.arr[0]= ((port_fwd_inst_list[next_devport].l3vni_cookie & 0x300) >> 8)
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls4[devport].append(aclMatch1)
                        match_number += 1



                    ######################################################
                    #### MATCHES that are different in ACE 1 and ACE2 ####
                    #### should come after the common Matches ############
                    ######################################################

                    for acl_match in sinst_info.ingress_match_list_hdls4[devport]:
                        ing_tbl7_ace1_match_hdls.append(acl_match)
                        ing_tbl7_ace2_match_hdls.append(acl_match)
                        sinst_info.list_of_all_acl_match_hdls.append(acl_match)


                    # Match ether_type

                    for ace_counter in range(2):
                        aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                        attrList = (ifcs_ctypes.ifcs_attr_t * 4)()
                        for index in range(4):
                            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                            assert rc == ifcs_ctypes.IFCS_SUCCESS
                        index = 0
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                        attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_ETHER_TYPE
                        index += 1

                        #set value
                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 2
                        value.arr = (c_uint8 * 2)()
                        if ace_counter == 0:
                            value.arr[0] = 0x8
                            value.arr[1] = 0x0
                        else:
                            value.arr[0] = 0x86
                            value.arr[1] = 0xdd

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                        attrList[index].value.u8_list = value
                        index += 1

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                        attrList[index].value.handle = matchProfile
                        index += 1

                        attrCount = index
                        rc = ifcs_ctypes.IFCS_STATUS_REASON(
                                ifcs_ctypes.ifcs_acl_match_create(
                                    self.node_id,
                                    pointer(aclMatch1),
                                    attrCount,
                                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                        spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                            log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                        else:
                            log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                            if ace_counter == 0:
                                ing_tbl7_ace1_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            else:
                                ing_tbl7_ace2_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            #sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                    match_number += 1

                    # Match IPV6 Source Address (lower 32 bits can be overloaded with IPV4 address)

                    for ace_counter in range(2):
                        aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                        attrList = (ifcs_ctypes.ifcs_attr_t * 4)()
                        for index in range(4):
                            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                            assert rc == ifcs_ctypes.IFCS_SUCCESS
                        index = 0
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                        attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_SOURCE_IPV6_ADDRESS
                        index += 1

                        #set value
                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 16
                        value.arr = (c_uint8 * 16)()
                        if ace_counter == 0:
                            value.arr[0] = 0x0
                            value.arr[1] = 0x0
                            value.arr[2] = 0x0
                            value.arr[3] = 0x0
                            value.arr[4] = 0x0
                            value.arr[5] = 0x0
                            value.arr[6] = 0x0
                            value.arr[7] = 0x0
                            value.arr[8] = 0x0
                            value.arr[9] = 0x0
                            value.arr[10] = 0x0
                            value.arr[11] = 0x0
                            value.arr[12] = ((sinst_info.ip2 >> 24) & 0xFF)
                            value.arr[13] = ((sinst_info.ip2 >> 16) & 0xFF)
                            value.arr[14] = ((sinst_info.ip2 >> 8) & 0xFF)
                            value.arr[15] = ((sinst_info.ip2) & 0xFF)
                        else:
                            for addr_offset in range(16):
                                value.arr[addr_offset] = sinst_info.v6_sip[addr_offset]

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                        attrList[index].value.u8_list = value
                        index += 1

                        #set mask
                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 16
                        value.arr = (c_uint8 * 16)()
                        if ace_counter == 0:
                            value.arr[0] = 0x0
                            value.arr[1] = 0x0
                            value.arr[2] = 0x0
                            value.arr[3] = 0x0
                            value.arr[4] = 0x0
                            value.arr[5] = 0x0
                            value.arr[6] = 0x0
                            value.arr[7] = 0x0
                            value.arr[8] = 0x0
                            value.arr[9] = 0x0
                            value.arr[10] = 0x0
                            value.arr[11] = 0x0
                            value.arr[12] = 0xff
                            value.arr[13] = 0xff
                            value.arr[14] = 0xff
                            value.arr[15] = 0xff
                        else:
                            value.arr[0] = 0xff
                            value.arr[1] = 0xff
                            value.arr[2] = 0xff
                            value.arr[3] = 0xff
                            value.arr[4] = 0xff
                            value.arr[5] = 0xff
                            value.arr[6] = 0xff
                            value.arr[7] = 0xff
                            value.arr[8] = 0xff
                            value.arr[9] = 0xff
                            value.arr[10] = 0xff
                            value.arr[11] = 0xff
                            value.arr[12] = 0xff
                            value.arr[13] = 0xff
                            value.arr[14] = 0xff
                            value.arr[15] = 0xff

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MASK
                        attrList[index].value.u8_list = value
                        index += 1

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                        attrList[index].value.handle = matchProfile
                        index += 1

                        attrCount = index
                        rc = ifcs_ctypes.IFCS_STATUS_REASON(
                                ifcs_ctypes.ifcs_acl_match_create(
                                    self.node_id,
                                    pointer(aclMatch1),
                                    attrCount,
                                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                        spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                            log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                        else:
                            log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                            if ace_counter == 0:
                                ing_tbl7_ace1_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            else:
                                ing_tbl7_ace2_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            #sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                    match_number += 1

                    # Match IPV6 Destination Address (lower 32 bits can be overloaded with IPV4 address)

                    for ace_counter in range(2):
                        aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                        attrList = (ifcs_ctypes.ifcs_attr_t * 4)()
                        for index in range(4):
                            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                            assert rc == ifcs_ctypes.IFCS_SUCCESS
                        index = 0
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                        attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_DESTINATION_IPV6_ADDRESS
                        index += 1

                        #set value
                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 16
                        value.arr = (c_uint8 * 16)()
                        if ace_counter == 0:
                            value.arr[0] = 0x0
                            value.arr[1] = 0x0
                            value.arr[2] = 0x0
                            value.arr[3] = 0x0
                            value.arr[4] = 0x0
                            value.arr[5] = 0x0
                            value.arr[6] = 0x0
                            value.arr[7] = 0x0
                            value.arr[8] = 0x0
                            value.arr[9] = 0x0
                            value.arr[10] = 0x0
                            value.arr[11] = 0x0
                            value.arr[12] = ((sinst_info.ip1 >> 24) & 0xFF)
                            value.arr[13] = ((sinst_info.ip1 >> 16) & 0xFF)
                            value.arr[14] = ((sinst_info.ip1 >> 8) & 0xFF)
                            value.arr[15] = ((sinst_info.ip1) & 0xFF)
                        else:
                            for addr_offset in range(16):
                                value.arr[addr_offset] = sinst_info.v6_dip[addr_offset]

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                        attrList[index].value.u8_list = value
                        index += 1

                        #set mask
                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 16
                        value.arr = (c_uint8 * 16)()
                        if ace_counter == 0:
                            value.arr[0] = 0x0
                            value.arr[1] = 0x0
                            value.arr[2] = 0x0
                            value.arr[3] = 0x0
                            value.arr[4] = 0x0
                            value.arr[5] = 0x0
                            value.arr[6] = 0x0
                            value.arr[7] = 0x0
                            value.arr[8] = 0x0
                            value.arr[9] = 0x0
                            value.arr[10] = 0x0
                            value.arr[11] = 0x0
                            value.arr[12] = 0xff
                            value.arr[13] = 0xff
                            value.arr[14] = 0xff
                            value.arr[15] = 0xff
                        else:
                            value.arr[0] = 0xff
                            value.arr[1] = 0xff
                            value.arr[2] = 0xff
                            value.arr[3] = 0xff
                            value.arr[4] = 0xff
                            value.arr[5] = 0xff
                            value.arr[6] = 0xff
                            value.arr[7] = 0xff
                            value.arr[8] = 0xff
                            value.arr[9] = 0xff
                            value.arr[10] = 0xff
                            value.arr[11] = 0xff
                            value.arr[12] = 0xff
                            value.arr[13] = 0xff
                            value.arr[14] = 0xff
                            value.arr[15] = 0xff

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MASK
                        attrList[index].value.u8_list = value
                        index += 1

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                        attrList[index].value.handle = matchProfile
                        index += 1

                        attrCount = index
                        rc = ifcs_ctypes.IFCS_STATUS_REASON(
                                ifcs_ctypes.ifcs_acl_match_create(
                                    self.node_id,
                                    pointer(aclMatch1),
                                    attrCount,
                                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                        spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                            log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                        else:
                            log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                            if ace_counter == 0:
                                ing_tbl7_ace1_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            else:
                                ing_tbl7_ace2_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            #sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                    match_number += 1

                    #seperate match for ACE
                    for ace_counter in range(2):
                        # Match Ingress L3 TTL (8 bits)
                        match_number = 1
                        aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                        attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                        for index in range(3):
                            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                            assert rc == ifcs_ctypes.IFCS_SUCCESS
                        index = 0
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                        attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_L3_TTL
                        index += 1

                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 1
                        value.arr = (c_uint8 * 1)()
                        if ace_counter == 0:
                            ing_l3_ttl = sinst_info.v4_ttl
                        else:
                            ing_l3_ttl = sinst_info.v6_hoplimit
                        value.arr[0]= (ing_l3_ttl & 0xff)
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                        attrList[index].value.u8_list = value
                        index += 1

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                        attrList[index].value.handle = matchProfile
                        index += 1

                        attrCount = index
                        rc = ifcs_ctypes.IFCS_STATUS_REASON(
                                ifcs_ctypes.ifcs_acl_match_create(
                                    self.node_id,
                                    pointer(aclMatch1),
                                    attrCount,
                                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                        spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                            log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                        else:
                            log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                            if ace_counter == 0:
                                ing_tbl7_ace1_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            else:
                                ing_tbl7_ace2_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                    match_number += 1

                    # Match L3 QOS (8 bits)
                    for ace_counter in range(2):
                        aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                        attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                        for index in range(3):
                            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                            assert rc == ifcs_ctypes.IFCS_SUCCESS
                        index = 0
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                        attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L3_QOS
                        index += 1

                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 1
                        value.arr = (c_uint8 * 1)()
                        if ace_counter == 0:
                            dscp = ((port_fwd_inst_list[devport].dscp) & 0x3f)
                            ecn = ((sinst_info.v4_dscp) & 0x3)
                        else:
                            dscp = ((port_fwd_inst_list[devport].dscp) & 0x3f)
                            ecn = ((sinst_info.v6_tc) & 0x3)

                        log_dbg(1, "############################################# ING L3_QOS dscp:%d  ecn:%d for dev_port:%d"%(dscp, ecn, devport))
                        l3_qos = ((dscp << 2) | ecn)
                        value.arr[0]= (l3_qos & 0xff)
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                        attrList[index].value.u8_list = value
                        index += 1

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                        attrList[index].value.handle = matchProfile
                        index += 1

                        attrCount = index
                        rc = ifcs_ctypes.IFCS_STATUS_REASON(
                                ifcs_ctypes.ifcs_acl_match_create(
                                    self.node_id,
                                    pointer(aclMatch1),
                                    attrCount,
                                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                        spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                            log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                        else:
                            log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                            if ace_counter == 0:
                                ing_tbl7_ace1_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            else:
                                ing_tbl7_ace2_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                    match_number += 1

                elif table_type == 8:
                    ing_tbl8_ace1_match_hdls = []
                    ing_tbl8_ace2_match_hdls = []
                    #INGRESS
                    # match Source MAC
                    match_number = 1
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_SOURCE_MAC_ADDRESS
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 6
                    value.arr = (c_uint8 * 6)()
                    value.arr[0]= src_mac[0]
                    value.arr[1]= src_mac[1]
                    value.arr[2]= src_mac[2]
                    value.arr[3]= src_mac[3]
                    value.arr[4]= src_mac[4]
                    value.arr[5]= src_mac[5]
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls5[devport].append(aclMatch1)
                        match_number += 1

                    # match Destination MAC
                    match_number = 1
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_DESTINATION_MAC_ADDRESS
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 6
                    value.arr = (c_uint8 * 6)()
                    value.arr[0]= dest_mac[0]
                    value.arr[1]= dest_mac[1]
                    value.arr[2]= dest_mac[2]
                    value.arr[3]= dest_mac[3]
                    value.arr[4]= dest_mac[4]
                    value.arr[5]= dest_mac[5]
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls5[devport].append(aclMatch1)
                        match_number += 1

                    # match Source L4 Port (16 bit)
                    match_number = 1
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_SOURCE_L4_PORT
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 2
                    value.arr = (c_uint8 * 2)()
                    src_l4_port = sinst_info.l4_sport
                    value.arr[0]= ((src_l4_port >> 8) & 0xff)
                    value.arr[1]= (src_l4_port & 0xff)
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls5[devport].append(aclMatch1)
                        match_number += 1

                    # match Destination L4 Port (16 bit)
                    '''
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_DESTINATION_L4_PORT
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 2
                    value.arr = (c_uint8 * 2)()
                    dst_l4_port = 0x5678
                    value.arr[0]= ((dst_l4_port >> 8) & 0xff)
                    value.arr[1]= (dst_l4_port & 0xff)
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls5[devport].append(aclMatch1)
                        match_number += 1
                    '''

                    ######################################################
                    #### MATCHES that are different in ACE 1 and ACE2 ####
                    #### should come after the common Matches ############
                    ######################################################

                    for acl_match in sinst_info.ingress_match_list_hdls5[devport]:
                        ing_tbl8_ace1_match_hdls.append(acl_match)
                        ing_tbl8_ace2_match_hdls.append(acl_match)
                        sinst_info.list_of_all_acl_match_hdls.append(acl_match)


                    # Match L4_PROTOCOL (8 bits)

                    for ace_counter in range(2):
                        aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                        attrList = (ifcs_ctypes.ifcs_attr_t * 4)()
                        for index in range(4):
                            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                            assert rc == ifcs_ctypes.IFCS_SUCCESS
                        index = 0
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                        attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L4_PROTOCOL
                        index += 1

                        #set value
                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 1
                        value.arr = (c_uint8 * 1)()
                        if ace_counter == 0:
                            # TCP  6
                            value.arr[0] = 0x6
                        else:
                            # UDP  17
                            value.arr[0] = 0x11

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                        attrList[index].value.u8_list = value
                        index += 1

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                        attrList[index].value.handle = matchProfile
                        index += 1

                        attrCount = index
                        rc = ifcs_ctypes.IFCS_STATUS_REASON(
                                ifcs_ctypes.ifcs_acl_match_create(
                                    self.node_id,
                                    pointer(aclMatch1),
                                    attrCount,
                                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                        spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                            log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                        else:
                            log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                            if ace_counter == 0:
                                ing_tbl8_ace1_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            else:
                                ing_tbl8_ace2_match_hdls.append(aclMatch1)
                                sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            #sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                    match_number += 1

                elif table_type == 1:
                    #EGRESS Table 1
                    match_number = 1
                    #1 match dest mac address
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_DESTINATION_MAC_ADDRESS
                    index += 1

                    #TODO@ACL: confirm dmac
                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 6
                    value.arr = (c_uint8 * 6)()
                    value.arr[0]= dest_mac[0]
                    value.arr[1]= dest_mac[1]
                    value.arr[2]= dest_mac[2]
                    value.arr[3]= dest_mac[3]
                    value.arr[4]= dest_mac[4]
                    value.arr[5]= dest_mac[5]

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d dest mac addr for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d dest mac addr for port %d"%(match_number, devport))
                        sinst_info.egress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #3 match egress sysport
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_EGRESS_SYSPORT
                    index += 1
                    sp_hdl = ifcs_ctypes.ifcs_handle_t()
                    port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[devport].sp_hdl)
                    sp_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)
                    ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_MATCH_ATTR_OBJECT);
                    ifcs_ctypes.ifcs_attr_t_value_handle_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), sp_hdl);
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d egress sysport for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d egress sysport for port %d"%(match_number, devport))
                        sinst_info.egress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #5 match destination ib, destination ibp
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INT_DIB_DIBP
                    index += 1
                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 2
                    value.arr = (c_uint8 * 2)()
                    #get destination IB and IBP
                    ib_obj = _get_ib_from_devport(self.node_id, devport)
                    ib = ib_obj.ib
                    ibp = _get_ibport_from_devport(self.node_id, devport)
                    ib_ibp = self._get_ib_ibp(ib, ibp)
                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 2
                    value.arr = (c_uint8 * 2)()
                    value.arr[0]= ((ib_ibp >> 8) & 0xff)
                    value.arr[1]= (ib_ibp & 0xff)
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.im_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d destination IB and IBP for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d destination IB and IBP for port %d"%(match_number, devport))
                        sinst_info.egress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    match_set = sinst_info.egress_match_list_hdls[devport]

                    for acl_match in sinst_info.egress_match_list_hdls[devport]:
                        sinst_info.list_of_all_acl_match_hdls.append(acl_match)

                elif table_type == 2:
                    #EGRESS Table 2
                    match_number = 1
                    #1 match ingress sysport
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_SYSPORT
                    index += 1
                    sp_hdl = ifcs_ctypes.ifcs_handle_t()
                    sp_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(prev_port_sp)
                    ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_MATCH_ATTR_OBJECT);
                    ifcs_ctypes.ifcs_attr_t_value_handle_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), sp_hdl);
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create egress AclMatch %d ingress sysport for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created egress AclMatch %d ingress sysport for port %d"%(match_number, devport))
                        sinst_info.egress_match_list_hdls2[devport].append(aclMatch1)
                        match_number += 1

                    #3 match source ib, source ibp
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INT_SIB_SIBP
                    index += 1

                    #get source IB and IBP
                    ib_obj = _get_ib_from_devport(self.node_id, prev_devport)
                    ib = ib_obj.ib
                    ibp = _get_ibport_from_devport(self.node_id, prev_devport)

                    ib_ibp = self._get_ib_ibp(ib, ibp)
                    if self.node_device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 1
                        value.arr = (c_uint8 * 1)()
                        value.arr[0]= (ibp & 0x3f)
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                        attrList[index].value.u8_list = value
                        index += 1
                    elif self.node_device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TL10:
                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 2
                        value.arr = (c_uint8 * 2)()
                        value.arr[0]= ((ib_ibp >> 8) & 0xff)
                        value.arr[1]= (ib_ibp & 0xff)
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                        attrList[index].value.u8_list = value
                        index += 1
                    else:
                        assert False, "Not supported on this device type {}".format(self.node_device_type)

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.im_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create egress AclMatch %d sib and sibp for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created egress AclMatch %d sib and sibp for devport %d prev_devport %d IBP %d value %d nxt %d sysport %d"%(match_number, devport, prev_devport, ibp, value.arr[0], nxt, sp_hdl.value))
                        sinst_info.egress_match_list_hdls2[devport].append(aclMatch1)
                        match_number += 1

                    #4 match l3 type
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 4)()
                    for index in range(4):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L3_TYPE
                    index += 1

                    #set value
                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    # 4: ipv4 5: ipv4_ext, 6: ipv6 7:ipv6_ext
                    value.arr[0]=4
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    #set mask
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MASK
                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    value.arr[0]=0x4
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.egress_match_list_hdls2[devport].append(aclMatch1)
                        match_number += 1

                    #5 match source L4 port
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_SOURCE_L4_PORT
                    index += 1
                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 2
                    value.arr = (c_uint8 * 2)()
                    src_l4_port = sinst_info.l4_sport
                    value.arr[0]= ((src_l4_port >> 8) & 0xFF)
                    value.arr[1]= (src_l4_port & 0xFF)
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create egress AclMatch %d source L4 port for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created egress AclMatch %d source L4 port for port %d"%(match_number, devport))
                        sinst_info.egress_match_list_hdls2[devport].append(aclMatch1)
                        match_number += 1

                    #6 match L4 protocol
                    #aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    #attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    #for index in range(3):
                    #    rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                    #    assert rc == ifcs_ctypes.IFCS_SUCCESS
                    #index = 0
                    #attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    #attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L4_PROTOCOL
                    #index += 1
                    #value = ifcs_ctypes.ifcs_u8_list_t()
                    #value.count = 2
                    #value.arr = (c_uint8 * 2)()
                    #TODO@ACL: fill L4 protocol 6: tcp 17: udp
                    #value.arr[0]= 0
                    #value.arr[0]= 17
                    #attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    #attrList[index].value.u8_list = value
                    #index += 1

                    #attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    #attrList[index].value.handle = matchProfile
                    #index += 1

                    #attrCount = index
                    #rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    #        ifcs_ctypes.ifcs_acl_match_create(
                    #            self.node_id,
                    #            pointer(aclMatch1),
                    #            attrCount,
                    #            compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    #if rc != ifcs_ctypes.IFCS_SUCCESS:
                    #    log_err("failed to create egress AclMatch %d L4 protocol for port %d rc %d"%(table_type, match_number, devport, rc))
                    #else:
                    #    log_dbg(1, "Successfully created egress AclMatch %d L4 protocol for port %d"%(match_number, devport))
                    #    sinst_info.egress_match_list_hdls2[devport].append(aclMatch1)
                    #    match_number += 1

                    match_set = sinst_info.egress_match_list_hdls2[devport]

                    for acl_match in sinst_info.egress_match_list_hdls2[devport] :
                        sinst_info.list_of_all_acl_match_hdls.append(acl_match)

                elif table_type == 6:
                    egr_tbl8_ace1_match_hdls = []
                    egr_tbl8_ace2_match_hdls = []
                    match_number = 1
                    # match fwd_layer (1 bit) 0-switching 1-routing
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_FWD_LAYER
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    value.arr[0]= 0x1
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create egress AclMatch %d ingress sysport for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created egress AclMatch %d ingress sysport for port %d"%(match_number, devport))
                        sinst_info.egress_match_list_hdls4[devport].append(aclMatch1)
                        match_number += 1

                    # match nexthop_no_decrement_ttl
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_NEXTHOP_NO_DECREMENT_TTL
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    value.arr[0]= 0x1
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create egress AclMatch %d ingress sysport for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created egress AclMatch %d ingress sysport for port %d"%(match_number, devport))
                        sinst_info.egress_match_list_hdls4[devport].append(aclMatch1)
                        match_number += 1

                    # match INT_IPT_INGRESS_ENABLE (1 bit, val:0x0, mask:0x4)
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 4)()
                    for index in range(4):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INT_IPT_INGRESS_ENABLE
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    value.arr[0]= 0x0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    value.arr[0]= 0x4
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MASK
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.im_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create egress AclMatch %d ingress sysport for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created egress AclMatch %d ingress sysport for port %d"%(match_number, devport))
                        sinst_info.egress_match_list_hdls4[devport].append(aclMatch1)
                        match_number += 1

                    #match SYSTEM_TC_DP (6 bits)
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_SYSTEM_TC_DP
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    tc = ((port_fwd_inst_list[prev_devport].sp_def_tc) & 0xf)
                    dp = ((port_fwd_inst_list[prev_devport].sp_def_dp) & 0x3)
                    system_tc_dp = ((tc << 2) | dp)
                    value.arr[0]= (system_tc_dp & 0x3f)
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create egress AclMatch %d ingress sysport for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created egress AclMatch %d ingress sysport for port %d"%(match_number, devport))
                        sinst_info.egress_match_list_hdls4[devport].append(aclMatch1)
                        match_number += 1

                    # match L3_QOS (8 bits)
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 4)()
                    for index in range(4):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L3_QOS
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    dscp = ((port_fwd_inst_list[devport].dscp) & 0x3f)
                    ecn = ((sinst_info.v4_dscp) & 0x3)

                    log_dbg(1, "############################################# EGR L3_QOS dscp:%d  ecn:%d for dev_port:%d"%(dscp, ecn, devport))
                    l3_qos = ((dscp << 2) | ecn)
                    value.arr[0]= (l3_qos & 0xff)
                    #value.arr[0]= dscp
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    value.arr[0]= 0xFF
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MASK
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create egress AclMatch %d ingress sysport for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created egress AclMatch %d ingress sysport for port %d"%(match_number, devport))
                        sinst_info.egress_match_list_hdls4[devport].append(aclMatch1)
                        match_number += 1

                    # match EGRESS_L3_TTL (8 bits)
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_EGRESS_L3_TTL
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    egress_l3_ttl = sinst_info.v4_ttl
                    value.arr[0]= (egress_l3_ttl & 0xff)
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create egress AclMatch %d ingress sysport for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created egress AclMatch %d ingress sysport for port %d"%(match_number, devport))
                        sinst_info.egress_match_list_hdls4[devport].append(aclMatch1)
                        match_number += 1

                    #3 match egress sysport
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_EGRESS_SYSPORT
                    index += 1
                    sp_hdl = ifcs_ctypes.ifcs_handle_t()
                    port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[devport].sp_hdl)
                    sp_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)
                    ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_MATCH_ATTR_OBJECT);
                    ifcs_ctypes.ifcs_attr_t_value_handle_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), sp_hdl);
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d egress sysport for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d egress sysport for port %d"%(match_number, devport))
                        sinst_info.egress_match_list_hdls4[devport].append(aclMatch1)
                        match_number += 1

                    # match EGRESS_L3_INTERFACE_USER_COOKIE (4 bits)
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 4)()
                    for index in range(4):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_EGRESS_L3_INTERFACE_USER_COOKIE
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    egr_l3_intf_user_cookie = port_fwd_inst_list[devport].intf_egr_cookie
                    value.arr[0]= (egr_l3_intf_user_cookie & 0xf)
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    egr_l3_intf_user_cookie_mask = 0xf
                    value.arr[0]= (egr_l3_intf_user_cookie_mask & 0xf)
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MASK
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create egress AclMatch %d egress l3 interface user cookie for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created egress AclMatch %d egress l3 interface user cookie for port %d"%(match_number, devport))
                        sinst_info.egress_match_list_hdls4[devport].append(aclMatch1)
                        match_number += 1

                    ######################################################
                    #### MATCHES that are different in ACE 1 and ACE2 ####
                    #### should come after the common Matches ############
                    ######################################################

                    for acl_match in sinst_info.egress_match_list_hdls4[devport]:
                        egr_tbl8_ace1_match_hdls.append(acl_match)
                        egr_tbl8_ace2_match_hdls.append(acl_match)

                    # match L3_NEXTHOP_USER_COOKIE (4 bits)
                    for ace_counter in range(2):
                        aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                        attrList = (ifcs_ctypes.ifcs_attr_t * 4)()
                        for index in range(4):
                            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                            assert rc == ifcs_ctypes.IFCS_SUCCESS
                        index = 0
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                        attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L3_NEXTHOP_USER_COOKIE
                        index += 1

                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 1
                        value.arr = (c_uint8 * 1)()
                        if ace_counter == 0:
                            l3_nexthop_user_cookie = port_fwd_inst_list[devport].nh4_picked_cookie
                        else:
                            l3_nexthop_user_cookie = port_fwd_inst_list[devport].nh6_picked_cookie
                        value.arr[0]= (l3_nexthop_user_cookie & 0xf)
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                        attrList[index].value.u8_list = value
                        index += 1

                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 1
                        value.arr = (c_uint8 * 1)()
                        l3_nexthop_user_cookie_mask = 0xf
                        value.arr[0]= (l3_nexthop_user_cookie_mask & 0xf)
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MASK
                        attrList[index].value.u8_list = value
                        index += 1

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                        attrList[index].value.handle = matchProfile
                        index += 1

                        attrCount = index
                        rc = ifcs_ctypes.IFCS_STATUS_REASON(
                                ifcs_ctypes.ifcs_acl_match_create(
                                    self.node_id,
                                    pointer(aclMatch1),
                                    attrCount,
                                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                        spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                            log_err("failed to create egress AclMatch %d l3 nexthop user cookie for port %d rc %d"%(table_type, match_number, devport, rc))
                        else:
                            log_dbg(1, "Successfully created egress AclMatch %d l3 nexthop user cookie for port %d"%(match_number, devport))
                            sinst_info.egress_match_list_hdls4[devport].append(aclMatch1)
                            match_number += 1
                            if ace_counter == 0:
                                egr_tbl8_ace1_match_hdls.append(aclMatch1)
                            else:
                                egr_tbl8_ace2_match_hdls.append(aclMatch1)

                    for acl_match in sinst_info.egress_match_list_hdls4[devport] :
                        sinst_info.list_of_all_acl_match_hdls.append(acl_match)

                elif table_type == 4:
                    #match source ib, source ibp
                    match_number = 1
                    list_of_acl_match_mirror_hdls = []
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 4)()
                    for index in range(4):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INT_SIB_SIBP
                    index += 1

                    #get source IB and IBP
                    sp_hdl = ifcs_ctypes.ifcs_handle_t()
                    port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[devport].sp_hdl)
                    sp_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)

                    ib_obj = _get_ib_from_devport(self.node_id, devport)
                    ib = ib_obj.ib
                    ibp = sinst_info.recirc_ibport
                    ib_ibp = self._get_ib_ibp(ib, ibp)
                    if self.node_device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 1
                        value.arr = (c_uint8 * 1)()
                        value.arr[0]= (ibp & 0x3f)
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                        attrList[index].value.u8_list = value
                        index += 1
                    elif self.node_device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TL10:
                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 2
                        value.arr = (c_uint8 * 2)()
                        value.arr[0]= ((ib_ibp >> 8) & 0xff)
                        value.arr[1]= (ib_ibp & 0xff)
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                        attrList[index].value.u8_list = value
                        index += 1
                        mask = ifcs_ctypes.ifcs_u8_list_t()
                        mask.count = 2
                        mask.arr = (c_uint8 * 2)()
                        mask.arr[0]= L3spst.sibp_only_mask[0]
                        mask.arr[1]= L3spst.sibp_only_mask[1]
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MASK
                        attrList[index].value.u8_list = mask
                        index += 1
                    else:
                        assert False, "Not supported on this device type {}".format(self.node_device_type)

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.im_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create egress AclMatch %d sib and sibp for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created egress AclMatch %d sib and sibp for devport %d prev_devport %d IBP %d value %d nxt %d sysport %d"%(match_number, devport, prev_devport, ibp, value.arr[0], nxt, sp_hdl.value))
                        sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                        list_of_acl_match_mirror_hdls.append(aclMatch1)
                        match_number += 1

                    #match mirror
                    for number_of_matches in range(1):
                        aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                        attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                        for index in range(3):
                            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                            assert rc == ifcs_ctypes.IFCS_SUCCESS
                        index = 0
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                        attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_MIRROR
                        index += 1
                        mirror_hdl = ifcs_ctypes.ifcs_handle_t()
                        mirror_hdl.value = ifcs_ctypes.IFCS_HANDLE_COLLECTOR(mirror_id)
                        ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_MATCH_ATTR_OBJECT);
                        ifcs_ctypes.ifcs_attr_t_value_handle_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), mirror_hdl);
                        index += 1

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                        attrList[index].value.handle = matchProfile
                        index += 1

                        attrCount = index
                        rc = ifcs_ctypes.IFCS_STATUS_REASON(
                                ifcs_ctypes.ifcs_acl_match_create(
                                    self.node_id,
                                    pointer(aclMatch1),
                                    attrCount,
                                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                        spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                            log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                        else:
                            mirror_id += 1
                            log_dbg(1, "Successfully created AclMatch %d Mirror for port %d"%(match_number, devport))
                            sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            list_of_acl_match_mirror_hdls.append(aclMatch1)
                    match_number += 1
                    match_set = list_of_acl_match_mirror_hdls

                    # match destination L4 Port (16 bit)
                    for number_of_matches in range(1):
                        aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                        attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                        for index in range(3):
                            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                            assert rc == ifcs_ctypes.IFCS_SUCCESS
                        index = 0
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                        attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_DESTINATION_L4_PORT
                        index += 1

                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 2
                        value.arr = (c_uint8 * 2)()
                        dst_l4_port = sinst_info.l4_dport_mirror

                        value.arr[0]= ((dst_l4_port >> 8) & 0xff)
                        value.arr[1]= (dst_l4_port & 0xff)
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                        attrList[index].value.u8_list = value
                        index += 1

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                        attrList[index].value.handle = matchProfile
                        index += 1

                        attrCount = index
                        rc = ifcs_ctypes.IFCS_STATUS_REASON(
                                ifcs_ctypes.ifcs_acl_match_create(
                                    self.node_id,
                                    pointer(aclMatch1),
                                    attrCount,
                                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                        spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                            log_err("table_type %d, failed to create AclMatch %d Mirror for port %d rc %d"%(table_type, match_number, devport, rc))
                        else:
                            log_dbg(1, "Successfully created AclMatch %d Mirror for port %d"%(match_number, devport))
                            sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                            list_of_acl_match_mirror_hdls.append(aclMatch1)
                    match_number += 1

                    #match egress sysport
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_EGRESS_SYSPORT
                    index += 1
                    sp_hdl = ifcs_ctypes.ifcs_handle_t()
                    port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[devport].sp_hdl)
                    sp_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)
                    ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_MATCH_ATTR_OBJECT);
                    ifcs_ctypes.ifcs_attr_t_value_handle_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), sp_hdl);
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d egress sysport for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d egress sysport for port %d"%(match_number, devport))
                        sinst_info.list_of_all_acl_match_hdls.append(aclMatch1)
                        list_of_acl_match_mirror_hdls.append(aclMatch1)
                        match_number += 1

                elif table_type == 9:
                    match_number = 1
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_SYSPORT
                    index += 1

                    sp_hdl = ifcs_ctypes.ifcs_handle_t()
                    port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[devport].sp_hdl)
                    sp_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)
                    ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_MATCH_ATTR_OBJECT);
                    ifcs_ctypes.ifcs_attr_t_value_handle_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), sp_hdl);
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d ingress sysport %d for port %d"%(match_number, port_sp, devport))
                        sinst_info.ingress_match_list_hdls6[devport].append(aclMatch1)
                        match_number += 1

                    match_set = sinst_info.ingress_match_list_hdls6[devport]

                    for acl_match in sinst_info.ingress_match_list_hdls6[devport] :
                        sinst_info.list_of_all_acl_match_hdls.append(acl_match)

                elif table_type == 10:
                    match_number = 1
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_SYSPORT
                    index += 1

                    sp_hdl = ifcs_ctypes.ifcs_handle_t()
                    port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[devport].sp_hdl)
                    sp_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)
                    ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_MATCH_ATTR_OBJECT);
                    ifcs_ctypes.ifcs_attr_t_value_handle_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), sp_hdl);
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("table_type %d, failed to create AclMatch %d for port %d rc %d"%(table_type, match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d ingress sysport %d for port %d"%(match_number, port_sp, devport))
                        sinst_info.ingress_match_list_hdls7[devport].append(aclMatch1)
                        match_number += 1

                    match_set = sinst_info.ingress_match_list_hdls7[devport]

                    for acl_match in sinst_info.ingress_match_list_hdls7[devport] :
                        sinst_info.list_of_all_acl_match_hdls.append(acl_match)


                # End of ACL Match filter create
                # NULL ACL Action handle
                log_dbg(1, "Creating ACL ACTION")
                if table_type == 4:
                    action_number = 1

                    #drop action
                    aclAction1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_ACTION_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_ACTION_TYPE_DROP
                    index += 1

                    drop_action = ifcs_ctypes.ifcs_acl_action_value_t();
                    drop_action.drop.green  = ifcs_ctypes.IFCS_ACL_ACTION_ENABLE;
                    drop_action.drop.yellow = ifcs_ctypes.IFCS_ACL_ACTION_DISABLE;
                    drop_action.drop.red    = ifcs_ctypes.IFCS_ACL_ACTION_DISABLE;
                    drop_action.drop.pp_drop_reason = ifcs_ctypes.IFCS_NULL_HANDLE;

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_ACTION_ATTR_VALUE
                    ifcs_ctypes.ifcs_attr_t_value_acl_action_value_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), pointer(drop_action));
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_ACTION_ATTR_ACTION_PROFILE
                    attrList[index].value.handle = actionProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_action_create(
                                self.node_id,
                                pointer(aclAction1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_action_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create egress AclAction %d ingress sysport for port %d rc %d"%(action_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created egress AclAction %d ingress sysport for port %d"%(action_number, devport))
                        sinst_info.list_of_all_acl_action_hdls.append(aclAction1)

                    #mirror action
                    aclAction2 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_ACTION_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_ACTION_TYPE_MIRROR
                    index += 1

                    ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_ACTION_ATTR_OBJECT);
                    ifcs_ctypes.ifcs_attr_t_value_handle_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), sinst_info.collector_set_hdls[cs_index]);
                    cs_index += 1
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_ACTION_ATTR_ACTION_PROFILE
                    attrList[index].value.handle = actionProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_action_create(
                                self.node_id,
                                pointer(aclAction2),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_action_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create egress AclAction %d ingress sysport for port %d rc %d"%(action_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created egress AclAction %d ingress sysport for port %d"%(action_number, devport))
                        sinst_info.list_of_all_acl_action_hdls.append(aclAction2)

                elif table_type == 10:
                    action_number = 2
                    flex_counterset_hdl = self.configAclFlexCounterset(sinst_info)
                    aclAction1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_ACTION_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_ACTION_TYPE_FLEX_COUNTERSET
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_ACTION_ATTR_OBJECT
                    ifcs_ctypes.ifcs_attr_t_value_handle_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), flex_counterset_hdl);
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_ACTION_ATTR_ACTION_PROFILE
                    attrList[index].value.handle = actionProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_action_create(
                                self.node_id,
                                pointer(aclAction1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_action_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create egress AclAction %d ingress sysport for port %d rc %d"%(action_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created egress AclAction %d ingress sysport for port %d"%(action_number, devport))
                        sinst_info.list_of_all_acl_action_hdls.append(aclAction1)


                log_dbg(1, "Creating ACE")
                aceList = []
                if table_type == 0 or table_type == 5 or table_type == 6 or table_type == 7 or table_type == 8:
                    numAces = 2
                elif table_type == 4:
                    if last_port == 1:
                        #2 per port and 2 catch all
                        numAces = 4
                    else:
                        numAces = 2
                else:
                    numAces = 1

                match_index = 0
                for i in range(numAces):
                    ace = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 8)()
                    for index in range(8):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0

                    sinst_info.ace_priority += 1
                    priority = sinst_info.ace_priority
                    attrList[index].id = ifcs_ctypes.IFCS_ACE_ATTR_PRIORITY
                    attrList[index].value.u32 = priority
                    index += 1


                    if table_type == 0 or table_type == 5 or table_type == 7 or table_type == 8:
                        attrList[index].id = ifcs_ctypes.IFCS_ACE_ATTR_SCOPE
                        attrList[index].value.u32 = ifcs_ctypes.IFCS_ACE_ATTR_IB
                        index += 1

                        ib_obj = _get_ib_from_devport(self.node_id, devport)
                        ib = ib_obj.ib

                        attrList[index].id = ifcs_ctypes.IFCS_ACE_ATTR_IB
                        attrList[index].value.u32 = ib
                        index += 1

                        if i == 0:
                            if table_type == 0:
                                match_set = ing_tbl0_ace1_match_hdls
                            elif table_type == 5:
                                match_set = ing_tbl5_ace1_match_hdls
                            elif table_type == 7:
                                match_set = ing_tbl7_ace1_match_hdls
                            else:
                                # table_type == 8
                                match_set = ing_tbl8_ace1_match_hdls
                        else:
                            if table_type == 0:
                                match_set = ing_tbl0_ace2_match_hdls
                            elif table_type == 5:
                                match_set = ing_tbl5_ace2_match_hdls
                            elif table_type == 7:
                                match_set = ing_tbl7_ace2_match_hdls
                            else:
                                # table_type == 8
                                match_set = ing_tbl8_ace2_match_hdls

                    if table_type == 6:
                        if i == 0:
                            match_set = egr_tbl8_ace1_match_hdls
                        else:
                            match_set = egr_tbl8_ace2_match_hdls

                    if table_type == 3 or (table_type == 4 and i == 3):
                        empty_match_set = []
                        attrList[index].id = ifcs_ctypes.IFCS_ACE_ATTR_MATCH_SET
                        matchSetHandleList = ifcs_ctypes.ifcs_handle_list_t()
                        matchSetHandleList.count = len(empty_match_set)
                        matchSetHandleList.list = ( ifcs_ctypes.ifcs_handle_t * matchSetHandleList.count)()
                        tindex = 0
                        for element in empty_match_set:
                            matchSetHandleList.list[tindex] = element
                            tindex += 1
                        attrList[index].value.handle_list = matchSetHandleList
                        index += 1
                    elif table_type == 4 and i == 2:
                        attrList[index].id = ifcs_ctypes.IFCS_ACE_ATTR_MATCH_SET
                        matchSetHandleList = ifcs_ctypes.ifcs_handle_list_t()
                        mirror_match = []
                        match_index -= 4
                        mirror_match.append(list_of_acl_match_mirror_hdls[match_index])
                        match_set = mirror_match
                        matchSetHandleList.count = len(match_set)
                        matchSetHandleList.list = ( ifcs_ctypes.ifcs_handle_t * matchSetHandleList.count)()
                        tindex = 0
                        for element in match_set:
                            matchSetHandleList.list[tindex] = element
                            tindex += 1
                        attrList[index].value.handle_list = matchSetHandleList
                        index += 1
                    elif table_type == 4:
                        attrList[index].id = ifcs_ctypes.IFCS_ACE_ATTR_MATCH_SET
                        matchSetHandleList = ifcs_ctypes.ifcs_handle_list_t()
                        mirror_match = []
                        mirror_match.append(list_of_acl_match_mirror_hdls[match_index])
                        match_index += 1
                        mirror_match.append(list_of_acl_match_mirror_hdls[match_index])
                        match_index += 1
                        match_set = mirror_match
                        matchSetHandleList.count = len(match_set)
                        matchSetHandleList.list = ( ifcs_ctypes.ifcs_handle_t * matchSetHandleList.count)()
                        tindex = 0
                        for element in match_set:
                            matchSetHandleList.list[tindex] = element
                            tindex += 1
                        attrList[index].value.handle_list = matchSetHandleList
                        index += 1
                    else:
                        attrList[index].id = ifcs_ctypes.IFCS_ACE_ATTR_MATCH_SET
                        matchSetHandleList = ifcs_ctypes.ifcs_handle_list_t()
                        matchSetHandleList.count = len(match_set)
                        matchSetHandleList.list = ( ifcs_ctypes.ifcs_handle_t * matchSetHandleList.count)()
                        tindex = 0
                        for element in match_set:
                            matchSetHandleList.list[tindex] = element
                            tindex += 1
                        attrList[index].value.handle_list = matchSetHandleList
                        index += 1

                    action_set = []
                    if table_type == 10:
                        action_set.append(aclAction1)
                    if table_type == 4 and (i == 0 or i == 2):
                        action_set.append(aclAction1)
                    elif table_type == 4 and i == 1:
                        action_set.append(aclAction2)

                    attrList[index].id = ifcs_ctypes.IFCS_ACE_ATTR_ACTION_SET
                    actionSetHandleList = ifcs_ctypes.ifcs_handle_list_t()
                    actionSetHandleList.count = len(action_set)
                    actionSetHandleList.list = ( ifcs_ctypes.ifcs_handle_t * actionSetHandleList.count)()
                    tindex = 0
                    for element in action_set:
                        actionSetHandleList.list[tindex] = element
                        tindex += 1
                    attrList[index].value.handle_list = actionSetHandleList
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_ace_create(
                                self.node_id,
                                pointer(ace),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))


                    spstcommon_handle_device_access_error(rc, "ifcs_ace_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create ACE for %d"%(rc))
                    else:
                        if table_type == 0:
                            sinst_info.ingress_ace_list_hdls[devport].append(ace)
                            sinst_info.ing_ace_list_for_table1.append(ace)
                        elif table_type == 1:
                            sinst_info.egress_ace_list_hdls[devport].append(ace)
                            sinst_info.egr_ace_list_for_table1.append(ace)
                        elif table_type == 2:
                            sinst_info.egress_ace_list_hdls2[devport].append(ace)
                            sinst_info.egr_ace_list_for_table2.append(ace)
                        elif table_type == 3:
                            sinst_info.ingress_ace_list_hdls2[devport].append(ace)
                            sinst_info.ing_ace_list_for_table2.append(ace)
                        elif table_type == 4:
                            sinst_info.egress_ace_list_hdls3[devport].append(ace)
                            sinst_info.egr_ace_list_for_table3.append(ace)
                        elif table_type == 5:
                            sinst_info.ingress_ace_list_hdls3[devport].append(ace)
                            sinst_info.ing_ace_list_for_table3.append(ace)
                        elif table_type == 6:
                            sinst_info.egress_ace_list_hdls4[devport].append(ace)
                            sinst_info.egr_ace_list_for_table4.append(ace)
                        elif table_type == 7:
                            sinst_info.ingress_ace_list_hdls4[devport].append(ace)
                            sinst_info.ing_ace_list_for_table4.append(ace)
                        elif table_type == 8:
                            sinst_info.ingress_ace_list_hdls5[devport].append(ace)
                            sinst_info.ing_ace_list_for_table5.append(ace)
                        elif table_type == 9:
                            sinst_info.ingress_ace_list_hdls6[devport].append(ace)
                            sinst_info.ing_ace_list_for_table6.append(ace)
                        else:
                            sinst_info.ingress_ace_list_hdls7[devport].append(ace)
                            sinst_info.ing_ace_list_for_table7.append(ace)
                        log_dbg(1, "Successfully created all ACEs ")

                if table_type == 4 and last_port == 1:
                    max_acl = 3
                else:
                    max_acl = 1

                for acl_counter in range(max_acl):
                    log_dbg(1, "Creating ACL ")
                    acl = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 6)()
                    for index in range(6):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS

                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_ATTR_SCOPE
                    attrList[index].value.u32 = scope
                    index += 1

                    if table_type == 0 or table_type == 5 or table_type == 7 or table_type == 8:
                        ib_obj = _get_ib_from_devport(self.node_id, devport)
                        ib = ib_obj.ib

                        attrList[index].id = ifcs_ctypes.IFCS_ACL_ATTR_IB
                        attrList[index].value.u32 = ib
                        index += 1

                    attrCount = index

                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_create(
                            self.node_id,
                            pointer(acl),
                            attrCount,
                            compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc, "ifcs_acl_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create ACL for  %d"%(rc))
                    else:
                        if table_type == 0:
                            sinst_info.ingress_acl_list_hdls[devport].append(acl)
                            sinst_info.ing_acl_list_for_table1.append(acl)
                        elif table_type == 1:
                            sinst_info.egress_acl_list_hdls[devport].append(acl)
                            sinst_info.egr_acl_list_for_table1.append(acl)
                        elif table_type == 2:
                            sinst_info.egress_acl_list_hdls2[devport].append(acl)
                            sinst_info.egr_acl_list_for_table2.append(acl)
                        elif table_type == 3:
                            sinst_info.ingress_acl_list_hdls2[devport].append(acl)
                            sinst_info.ing_acl_list_for_table2.append(acl)
                        elif table_type == 4:
                            sinst_info.egress_acl_list_hdls3[devport].append(acl)
                            sinst_info.egr_acl_list_for_table3.append(acl)
                        elif table_type == 5:
                            sinst_info.ingress_acl_list_hdls3[devport].append(acl)
                            sinst_info.ing_acl_list_for_table3.append(acl)
                        elif table_type == 6:
                            sinst_info.egress_acl_list_hdls4[devport].append(acl)
                            sinst_info.egr_acl_list_for_table4.append(acl)
                        elif table_type == 7:
                            sinst_info.ingress_acl_list_hdls4[devport].append(acl)
                            sinst_info.ing_acl_list_for_table4.append(acl)
                        elif table_type == 8:
                            sinst_info.ingress_acl_list_hdls5[devport].append(acl)
                            sinst_info.ing_acl_list_for_table5.append(acl)
                        elif table_type == 9:
                            sinst_info.ingress_acl_list_hdls6[devport].append(acl)
                            sinst_info.ing_acl_list_for_table6.append(acl)
                        else:
                            sinst_info.ingress_acl_list_hdls7[devport].append(acl)
                            sinst_info.ing_acl_list_for_table7.append(acl)
                        log_dbg(1, "Successfully created ACL")

                    log_dbg(1, "Adding ACL to ACL Table")
                    aclhandleList = (ifcs_ctypes.ifcs_handle_t * 1)()
                    aclhandleList[0] = acl
                    memberCount = 1
                    attrCount = 0
                    attrList = (ifcs_ctypes.ifcs_attr_t * 0)()

                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_table_acl_add(
                            self.node_id,
                            aclTable,
                            memberCount,
                            compat_pointer(aclhandleList, ifcs_ctypes.ifcs_handle_t),
                            attrCount,
                            compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))
                    spstcommon_handle_device_access_error(rc, "ifcs_acl_table_acl_add")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to add ACL to ACLTable: %d"%rc)
                    else:
                        log_dbg(1, "Successfully added ACL to ACLTable")

                    if table_type == 0 or table_type == 5 or table_type == 7 or table_type == 8:
                        log_dbg(1, "Add port sharing to ACL")
                        sp_hdl = ifcs_ctypes.ifcs_handle_t()
                        port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[devport].sp_hdl)
                        sp_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)

                        portHandleList = (ifcs_ctypes.ifcs_handle_t * 1)()
                        portHandleList[0] = sp_hdl
                        portCount = 1
                        attrCount = 0
                        attrList = (ifcs_ctypes.ifcs_attr_t * 0)()

                        rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_port_add(
                                self.node_id,
                                acl,
                                portCount,
                                compat_pointer(portHandleList, ifcs_ctypes.ifcs_handle_t),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))
                        spstcommon_handle_device_access_error(rc, "ifcs_acl_port_add")
                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                            log_err("failed to add PORT to ACL: %d"%rc)
                        else:
                            log_dbg(1, "Successfully added PORT to ACL")

                    log_dbg(1, "Adding ACEs to ACL")
                    if table_type == 0:
                        aceList = sinst_info.ingress_ace_list_hdls[devport]
                    elif table_type == 1:
                        aceList = sinst_info.egress_ace_list_hdls[devport]
                    elif table_type == 2:
                        aceList = sinst_info.egress_ace_list_hdls2[devport]
                    elif table_type == 3:
                        aceList = sinst_info.ingress_ace_list_hdls2[devport]
                    elif table_type == 4 and last_port == 0:
                        aceList = sinst_info.egress_ace_list_hdls3[devport]
                    elif table_type == 4 and last_port == 1:
                        if acl_counter == 0:
                            aceList = sinst_info.egress_ace_list_hdls3[devport][0:-2]
                        elif acl_counter == 1:
                            aceList = [sinst_info.egress_ace_list_hdls3[devport][-2]]
                        elif acl_counter == 2:
                            aceList = [sinst_info.egress_ace_list_hdls3[devport][-1]]
                    elif table_type == 5:
                        aceList = sinst_info.ingress_ace_list_hdls3[devport]
                    elif table_type == 6:
                        aceList = sinst_info.egress_ace_list_hdls4[devport]
                    elif table_type == 7:
                        aceList = sinst_info.ingress_ace_list_hdls4[devport]
                    elif table_type == 8:
                        aceList = sinst_info.ingress_ace_list_hdls5[devport]
                    elif table_type == 9:
                        aceList = sinst_info.ingress_ace_list_hdls6[devport]
                    else:
                        aceList = sinst_info.ingress_ace_list_hdls7[devport]

                    acehandleList = (ifcs_ctypes.ifcs_handle_t * len(aceList))()
                    for idx in compat_xrange(len(aceList)):
                        acehandleList[idx] = aceList[idx]
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_ace_add(
                            self.node_id,
                            acl,
                            len(aceList),
                            compat_pointer(acehandleList, ifcs_ctypes.ifcs_handle_t),
                            0,
                            None))
                    spstcommon_handle_device_access_error(rc, "ifcs_acl_ace_add")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to add ACEs to ACL:  %d"%rc)
                    else:
                        log_dbg(1, "Successfully added ACEs to ACL")
                    # catch all entry table has only one ACL and one ACE.
                    # So break out of devport_list loop.
                    if table_type == 3:
                        break

            '''
            if table_type == 1 or table_type == 2:
                log_dbg(1, "Adding catch all Ingress ACE to ACL")
                # NULL ACL match handle
                aclMatch = ifcs_ctypes.ifcs_handle_t()

                # NULL ACL Action handle
                aclAction = ifcs_ctypes.ifcs_handle_t()

                log_dbg(1, "Creating ingress catch all ACE")
                aceList = []
                numAces = 1

                for i in range(numAces):
                    ace = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 6)()
                    for index in range(6):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0

                    sinst_info.ace_priority += 1
                    priority = sinst_info.ace_priority
                    attrList[index].id = ifcs_ctypes.IFCS_ACE_ATTR_PRIORITY
                    attrList[index].value.u32 = priority
                    index += 1

                    match_set = []
                    attrList[index].id = ifcs_ctypes.IFCS_ACE_ATTR_MATCH_SET
                    matchSetHandleList = ifcs_ctypes.ifcs_handle_list_t()
                    matchSetHandleList.count = len(match_set)
                    matchSetHandleList.list = ( ifcs_ctypes.ifcs_handle_t * matchSetHandleList.count)()
                    tindex = 0
                    for element in match_set:
                        matchSetHandleList.list[tindex] = element
                        tindex += 1
                    attrList[index].value.handle_list = matchSetHandleList
                    index += 1

                    action_set = []
                    attrList[index].id = ifcs_ctypes.IFCS_ACE_ATTR_ACTION_SET
                    actionSetHandleList = ifcs_ctypes.ifcs_handle_list_t()
                    actionSetHandleList.count = len(action_set)
                    actionSetHandleList.list = ( ifcs_ctypes.ifcs_handle_t * actionSetHandleList.count)()
                    tindex = 0
                    for element in action_set:
                        actionSetHandleList.list[tindex] = element
                        tindex += 1
                    attrList[index].value.handle_list = actionSetHandleList
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_ace_create(
                                self.node_id,
                                pointer(ace),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))
                    spstcommon_handle_device_access_error(rc, "ifcs_ace_create")

                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to add catch all ingress ACE to ACL:  %d"%rc)
                    else:
                        log_dbg(1, "Successfully added catch all ACE to ACL")
                        if table_type == 1 :
                            sinst_info.egress_ace_list_hdls[devport].append(ace)
                            sinst_info.egr_ace_list_for_table1.append(ace)
                        elif table_type == 2 :
                            sinst_info.egress_ace_list_hdls2[devport].append(ace)
                            sinst_info.egr_ace_list_for_table2.append(ace)
                        else:
                            log_err("Invalid table_type: %d for catch all entry"%table_type)
                        log_dbg(1, "Adding catch all ingress ACE to ACL")
                        aceList.append(ace)

                        acehandleList = (ifcs_ctypes.ifcs_handle_t * len(aceList))()
                        for idx in compat_xrange(len(aceList)):
                            acehandleList[idx] = aceList[idx]
                        rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_ace_add(
                                self.node_id,
                                acl,
                                len(aceList),
                                compat_pointer(acehandleList, ifcs_ctypes.ifcs_handle_t),
                                0,
                                None))
                        spstcommon_handle_device_access_error(rc, "ifcs_acl_ace_add")
                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                             log_err("failed to add catch all ingress ACE to ACL:  %d"%rc)
                        else:
                             log_dbg(1, "Successfully added catch all ingress ACE to ACL")
            '''

    def configAclDeleteAll(self, sinst_info):
        global ingress_delete_acls, egress_delete_acls
        log_dbg(1, "Starting ACL config delete")

        CHECKPOINT_7A = 0
        CHECKPOINT_1A = 1
        CHECKPOINT_1B = 2
        CHECKPOINT_5A = 3
        CHECKPOINT_5B = 4
        ING_CATCH_ALL = 5
        CHECKPOINT_6A = 6
        CHECKPOINT_2A = 7
        CHECKPOINT_4A = 8
        CHECKPOINT_3A = 9
        EGR_CATCH_ALL = 10

        devport_list = sinst_info.devport_list
        port_fwd_inst_list = sinst_info.port_fwd_inst_list

        for devport in devport_list:
############################################################################
#################### ING TABLE 1 ###########################################
############################################################################
            if (len(sinst_info.ingress_ace_list_hdls[devport])) :
                acehandleList = (ifcs_ctypes.ifcs_handle_t * len(sinst_info.ingress_ace_list_hdls[devport]))()
                for loop in compat_xrange(len(sinst_info.ingress_ace_list_hdls[devport])):
                    acehandleList[loop] = sinst_info.ingress_ace_list_hdls[devport][loop]

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_ace_remove(
                        self.node_id,
                        sinst_info.ingress_acl_list_hdls[devport][0],
                        len(sinst_info.ingress_ace_list_hdls[devport]),
                        compat_pointer(acehandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_ace_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACEs from ACL ING TABLE 1: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACES from ACL ING TABLE 1")

                for loop in compat_xrange(len(sinst_info.ingress_ace_list_hdls[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_ace_delete(
                            self.node_id,
                            sinst_info.ingress_ace_list_hdls[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_ace_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to delete ACE from ING TABLE 1: rc=%d"%rc)
                    else:
                        log_dbg(1, "Successfully delete ACE from ING TABLE 1")

                sysporthandleList = (ifcs_ctypes.ifcs_handle_t * 1)()
                sp_hdl = ifcs_ctypes.ifcs_handle_t()
                port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[devport].sp_hdl)
                sp_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)

                sysporthandleList[0] = sp_hdl
                portCount = 1

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_port_remove(
                        self.node_id,
                        sinst_info.ingress_acl_list_hdls[devport][0],
                        portCount,
                        compat_pointer(sysporthandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_port_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove SYSPORT from ACL ING TABLE 1: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed SYSPORT from ACL ING TABLE 1")

                aclhandleList = (ifcs_ctypes.ifcs_handle_t * 1)()
                aclhandleList[0] = sinst_info.ingress_acl_list_hdls[devport][0]
                aclCount = 1

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_table_acl_remove(
                        self.node_id,
                        sinst_info.list_of_acl_table_hdl[CHECKPOINT_1A],
                        aclCount,
                        compat_pointer(aclhandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_table_acl_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACL from ACL ING TABLE 1: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACL from ACL ING TABLE 1")

                for loop in compat_xrange(len(sinst_info.ingress_acl_list_hdls[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_delete(
                            self.node_id,
                            sinst_info.ingress_acl_list_hdls[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_acl_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL from ING TABLE 1: rc=%d"%rc)
                    else:
                         log_dbg(1, "Successfully deleted ACL from ING TABLE 1")
                '''
                log_dbg(1, "Deleting ACL MATCH from ING TABLE 1")
                for loop in compat_xrange(len(sinst_info.ingress_match_list_hdls[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_match_delete(
                            self.node_id,
                            sinst_info.ingress_match_list_hdls[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL MATCH from ING TABLE 1: rc=%d"%rc)
                '''

############################################################################
#################### ING TABLE 2 ###########################################
############################################################################

            if (len(sinst_info.ingress_ace_list_hdls2[devport])) :
                acehandleList = (ifcs_ctypes.ifcs_handle_t * len(sinst_info.ingress_ace_list_hdls2[devport]))()
                for loop in compat_xrange(len(sinst_info.ingress_ace_list_hdls2[devport])):
                    acehandleList[loop] = sinst_info.ingress_ace_list_hdls2[devport][loop]

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_ace_remove(
                        self.node_id,
                        sinst_info.ingress_acl_list_hdls2[devport][0],
                        len(sinst_info.ingress_ace_list_hdls2[devport]),
                        compat_pointer(acehandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_ace_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACEs from ACL ING TABLE 2: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACES from ACL ING TABLE 2")

                for loop in compat_xrange(len(sinst_info.ingress_ace_list_hdls2[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_ace_delete(
                            self.node_id,
                            sinst_info.ingress_ace_list_hdls2[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_ace_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to delete ACE from ING TABLE 2: rc=%d"%rc)
                    else:
                        log_dbg(1, "Successfully deleted ACES from ING TABLE 2")

                aclhandleList = (ifcs_ctypes.ifcs_handle_t * 1)()
                aclhandleList[0] = sinst_info.ingress_acl_list_hdls2[devport][0]
                aclCount = 1

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_table_acl_remove(
                        self.node_id,
                        sinst_info.list_of_acl_table_hdl[ING_CATCH_ALL],
                        aclCount,
                        compat_pointer(aclhandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_table_acl_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACL from ACL ING TABLE 2: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACL from ACL ING TABLE 2")

                for loop in compat_xrange(len(sinst_info.ingress_acl_list_hdls2[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_delete(
                            self.node_id,
                            sinst_info.ingress_acl_list_hdls2[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_acl_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL from ING TABLE 2: rc=%d"%rc)
                    else:
                         log_dbg(1, "Successfully deleted ACL from ING TABLE 2")
                '''
                log_dbg(1, "Deleting ACL MATCH from ING TABLE 2")
                for loop in compat_xrange(len(sinst_info.ingress_match_list_hdls2[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_match_delete(
                            self.node_id,
                            sinst_info.ingress_match_list_hdls2[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL MATCH from ING TABLE 2: rc=%d"%rc)
                '''
############################################################################
#################### EGR TABLE 1 ###########################################
############################################################################

            if (len(sinst_info.egress_ace_list_hdls[devport])) :
                acehandleList = (ifcs_ctypes.ifcs_handle_t * len(sinst_info.egress_ace_list_hdls[devport]))()
                for loop in compat_xrange(len(sinst_info.egress_ace_list_hdls[devport])):
                    acehandleList[loop] = sinst_info.egress_ace_list_hdls[devport][loop]

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_ace_remove(
                        self.node_id,
                        sinst_info.egress_acl_list_hdls[devport][0],
                        len(sinst_info.egress_ace_list_hdls[devport]),
                        compat_pointer(acehandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_ace_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACEs from ACL EGR TABLE 1: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACES from ACL EGR TABLE 1")

                for loop in compat_xrange(len(sinst_info.egress_ace_list_hdls[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_ace_delete(
                            self.node_id,
                            sinst_info.egress_ace_list_hdls[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_ace_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to delete ACE from EGR TABLE 1: rc=%d"%rc)
                    else:
                        log_dbg(1, "Successfully deleted ACES from EGR TABLE 1")

                aclhandleList = (ifcs_ctypes.ifcs_handle_t * 1)()
                aclhandleList[0] = sinst_info.egress_acl_list_hdls[devport][0]
                aclCount = 1

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_table_acl_remove(
                        self.node_id,
                        sinst_info.list_of_acl_table_hdl[CHECKPOINT_2A],
                        aclCount,
                        compat_pointer(aclhandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_table_acl_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACL from ACL EGR TABLE 1: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACL from ACL EGR TABLE 1")

                for loop in compat_xrange(len(sinst_info.egress_acl_list_hdls[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_delete(
                            self.node_id,
                            sinst_info.egress_acl_list_hdls[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_acl_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL from EGR TABLE 1: rc=%d"%rc)
                    else:
                         log_dbg(1, "Successfully deleted ACL from EGR TABLE 1")
                '''
                log_dbg(1, "Deleting ACL MATCH from EGR TABLE 1")
                for loop in compat_xrange(len(sinst_info.egress_match_list_hdls[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_match_delete(
                            self.node_id,
                            sinst_info.egress_match_list_hdls[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL MATCH from EGR TABLE 1: rc=%d"%rc)
                '''
############################################################################
#################### EGR TABLE 2 ###########################################
############################################################################

            if (len(sinst_info.egress_ace_list_hdls2[devport])) :
                acehandleList = (ifcs_ctypes.ifcs_handle_t * len(sinst_info.egress_ace_list_hdls2[devport]))()
                for loop in compat_xrange(len(sinst_info.egress_ace_list_hdls2[devport])):
                    acehandleList[loop] = sinst_info.egress_ace_list_hdls2[devport][loop]

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_ace_remove(
                        self.node_id,
                        sinst_info.egress_acl_list_hdls2[devport][0],
                        len(sinst_info.egress_ace_list_hdls2[devport]),
                        compat_pointer(acehandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_ace_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACEs from ACL EGR TABLE 2: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACES from ACL EGR TABLE 2")

                for loop in compat_xrange(len(sinst_info.egress_ace_list_hdls2[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_ace_delete(
                            self.node_id,
                            sinst_info.egress_ace_list_hdls2[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_ace_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to delete ACE from EGR TABLE 2: rc=%d"%rc)
                    else:
                        log_dbg(1, "Successfully deleted ACES from EGR TABLE 2")

                aclhandleList = (ifcs_ctypes.ifcs_handle_t * 1)()
                aclhandleList[0] = sinst_info.egress_acl_list_hdls2[devport][0]
                aclCount = 1

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_table_acl_remove(
                        self.node_id,
                        sinst_info.list_of_acl_table_hdl[CHECKPOINT_3A],
                        aclCount,
                        compat_pointer(aclhandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_table_acl_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACL from ACL EGR TABLE 2: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACL from ACL EGR TABLE 2")

                for loop in compat_xrange(len(sinst_info.egress_acl_list_hdls2[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_delete(
                            self.node_id,
                            sinst_info.egress_acl_list_hdls2[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_acl_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL from EGR TABLE 2: rc=%d"%rc)
                    else:
                         log_dbg(1, "Successfully deleted ACL from EGR TABLE 2")
                '''
                log_dbg(1, "Deleting ACL MATCH from EGR TABLE 2")
                for loop in compat_xrange(len(sinst_info.egress_match_list_hdls2[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_match_delete(
                            self.node_id,
                            sinst_info.egress_match_list_hdls2[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL MATCH from EGR TABLE 2: rc=%d"%rc)
                '''
############################################################################
#################### EGR TABLE 3 ###########################################
############################################################################

            if (len(sinst_info.egress_ace_list_hdls3[devport])) :
                acehandleList = (ifcs_ctypes.ifcs_handle_t * len(sinst_info.egress_ace_list_hdls3[devport]))()
                n_ace = len(sinst_info.egress_ace_list_hdls3[devport])
                e_ace = 0
                if n_ace > 2:
                    e_ace = n_ace - 2
                    n_ace = 2
                for loop in compat_xrange(n_ace):
                    acehandleList[loop] = sinst_info.egress_ace_list_hdls3[devport][loop]

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_ace_remove(
                        self.node_id,
                        sinst_info.egress_acl_list_hdls3[devport][0],
                        n_ace,
                        compat_pointer(acehandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_ace_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACEs from ACL EGR TABLE 3: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACES from ACL EGR TABLE 3")

                if e_ace != 0:
                    acehandleList[0] = sinst_info.egress_ace_list_hdls3[devport][2]
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_ace_remove(
                            self.node_id,
                            sinst_info.egress_acl_list_hdls3[devport][1],
                            1,
                            compat_pointer(acehandleList, ifcs_ctypes.ifcs_handle_t)))
                    spstcommon_handle_device_access_error(rc, "ifcs_acl_ace_remove")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to remove catch all ACE1 from ACL EGR TABLE 3: rc=%d"%rc)
                    else:
                        log_dbg(1, "Successfully removed catch all ACE1 from ACL EGR TABLE 3")

                    acehandleList[0] = sinst_info.egress_ace_list_hdls3[devport][3]
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_ace_remove(
                            self.node_id,
                            sinst_info.egress_acl_list_hdls3[devport][2],
                            1,
                            compat_pointer(acehandleList, ifcs_ctypes.ifcs_handle_t)))
                    spstcommon_handle_device_access_error(rc, "ifcs_acl_ace_remove")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to remove catch all ACE2 from ACL EGR TABLE 3: rc=%d"%rc)
                    else:
                        log_dbg(1, "Successfully removed catch all ACE2 from ACL EGR TABLE 3")

                for loop in compat_xrange(len(sinst_info.egress_ace_list_hdls3[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_ace_delete(
                            self.node_id,
                            sinst_info.egress_ace_list_hdls3[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_ace_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to delete ACE from EGR TABLE 3: rc=%d"%rc)
                    else:
                        log_dbg(1, "Successfully deleted ACES from EGR TABLE 3")

                n_acl = len(sinst_info.egress_acl_list_hdls3[devport])
                aclhandleList = (ifcs_ctypes.ifcs_handle_t * 3)()
                aclhandleList[0] = sinst_info.egress_acl_list_hdls3[devport][0]
                aclCount = n_acl
                if n_acl > 1:
                    aclhandleList[1] = sinst_info.egress_acl_list_hdls3[devport][1]
                    aclhandleList[2] = sinst_info.egress_acl_list_hdls3[devport][2]

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_table_acl_remove(
                        self.node_id,
                        sinst_info.list_of_acl_table_hdl[EGR_CATCH_ALL],
                        aclCount,
                        compat_pointer(aclhandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_table_acl_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACL from ACL EGR TABLE 3: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACL from ACL EGR TABLE 3")

                for loop in compat_xrange(len(sinst_info.egress_acl_list_hdls3[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_delete(
                            self.node_id,
                            sinst_info.egress_acl_list_hdls3[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_acl_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL from EGR TABLE 3: rc=%d"%rc)
                    else:
                         log_dbg(1, "Successfully deleted ACL from EGR TABLE 3")
                '''
                log_dbg(1, "Deleting ACL MATCH from EGR TABLE 3")
                for loop in compat_xrange(len(sinst_info.egress_match_list_hdls3[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_match_delete(
                            self.node_id,
                            sinst_info.egress_match_list_hdls3[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL MATCH from EGR TABLE 3: rc=%d"%rc)
                '''
############################################################################
#################### ING TABLE 3 ###########################################
############################################################################
            if (len(sinst_info.ingress_ace_list_hdls3[devport])) :
                acehandleList = (ifcs_ctypes.ifcs_handle_t * len(sinst_info.ingress_ace_list_hdls3[devport]))()
                for loop in compat_xrange(len(sinst_info.ingress_ace_list_hdls3[devport])):
                    acehandleList[loop] = sinst_info.ingress_ace_list_hdls3[devport][loop]

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_ace_remove(
                        self.node_id,
                        sinst_info.ingress_acl_list_hdls3[devport][0],
                        len(sinst_info.ingress_ace_list_hdls3[devport]),
                        compat_pointer(acehandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_ace_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACEs from ACL ING TABLE 3: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACES from ACL ING TABLE 3")

                for loop in compat_xrange(len(sinst_info.ingress_ace_list_hdls3[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_ace_delete(
                            self.node_id,
                            sinst_info.ingress_ace_list_hdls3[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_ace_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to delete ACE from ING TABLE 3: rc=%d"%rc)
                    else:
                        log_dbg(1, "Successfully delete ACE from ING TABLE 3")

                sysporthandleList = (ifcs_ctypes.ifcs_handle_t * 1)()
                sp_hdl = ifcs_ctypes.ifcs_handle_t()
                port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[devport].sp_hdl)
                sp_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)

                sysporthandleList[0] = sp_hdl
                portCount = 1

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_port_remove(
                        self.node_id,
                        sinst_info.ingress_acl_list_hdls3[devport][0],
                        portCount,
                        compat_pointer(sysporthandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_port_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove SYSPORT from ACL ING TABLE 3: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed SYSPORT from ACL ING TABLE 3")

                aclhandleList = (ifcs_ctypes.ifcs_handle_t * 1)()
                aclhandleList[0] = sinst_info.ingress_acl_list_hdls3[devport][0]
                aclCount = 1

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_table_acl_remove(
                        self.node_id,
                        sinst_info.list_of_acl_table_hdl[CHECKPOINT_1B],
                        aclCount,
                        compat_pointer(aclhandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_table_acl_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACL from ACL ING TABLE 3: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACL from ACL ING TABLE 3")

                for loop in compat_xrange(len(sinst_info.ingress_acl_list_hdls3[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_delete(
                            self.node_id,
                            sinst_info.ingress_acl_list_hdls3[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_acl_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL from ING TABLE 3: rc=%d"%rc)
                    else:
                         log_dbg(1, "Successfully deleted ACL from ING TABLE 3")
                '''
                log_dbg(1, "Deleting ACL MATCH from ING TABLE 3")
                for loop in compat_xrange(len(sinst_info.ingress_match_list_hdls3[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_match_delete(
                            self.node_id,
                            sinst_info.ingress_match_list_hdls3[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL MATCH from ING TABLE 3: rc=%d"%rc)
                '''
############################################################################
#################### EGR TABLE 4 ###########################################
############################################################################

            if (len(sinst_info.egress_ace_list_hdls4[devport])) :
                acehandleList = (ifcs_ctypes.ifcs_handle_t * len(sinst_info.egress_ace_list_hdls4[devport]))()
                for loop in compat_xrange(len(sinst_info.egress_ace_list_hdls4[devport])):
                    acehandleList[loop] = sinst_info.egress_ace_list_hdls4[devport][loop]

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_ace_remove(
                        self.node_id,
                        sinst_info.egress_acl_list_hdls4[devport][0],
                        len(sinst_info.egress_ace_list_hdls4[devport]),
                        compat_pointer(acehandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_ace_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACEs from ACL EGR TABLE 4: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACES from ACL EGR TABLE 4")

                for loop in compat_xrange(len(sinst_info.egress_ace_list_hdls4[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_ace_delete(
                            self.node_id,
                            sinst_info.egress_ace_list_hdls4[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_ace_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to delete ACE from EGR TABLE 4: rc=%d"%rc)
                    else:
                        log_dbg(1, "Successfully deleted ACES from EGR TABLE 4")

                aclhandleList = (ifcs_ctypes.ifcs_handle_t * 1)()
                aclhandleList[0] = sinst_info.egress_acl_list_hdls4[devport][0]
                aclCount = 1

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_table_acl_remove(
                        self.node_id,
                        sinst_info.list_of_acl_table_hdl[CHECKPOINT_4A],
                        aclCount,
                        compat_pointer(aclhandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_table_acl_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACL from ACL EGR TABLE 4: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACL from ACL EGR TABLE 4")

                for loop in compat_xrange(len(sinst_info.egress_acl_list_hdls4[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_delete(
                            self.node_id,
                            sinst_info.egress_acl_list_hdls4[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_acl_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL from EGR TABLE 4: rc=%d"%rc)
                    else:
                         log_dbg(1, "Successfully deleted ACL from EGR TABLE 4")
                '''
                log_dbg(1, "Deleting ACL MATCH from EGR TABLE 4")
                for loop in compat_xrange(len(sinst_info.egress_match_list_hdls4[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_match_delete(
                            self.node_id,
                            sinst_info.egress_match_list_hdls4[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL MATCH from EGR TABLE 4: rc=%d"%rc)
                '''

############################################################################
#################### ING TABLE 4 ###########################################
############################################################################
            if (len(sinst_info.ingress_ace_list_hdls4[devport])) :
                acehandleList = (ifcs_ctypes.ifcs_handle_t * len(sinst_info.ingress_ace_list_hdls4[devport]))()
                for loop in compat_xrange(len(sinst_info.ingress_ace_list_hdls4[devport])):
                    acehandleList[loop] = sinst_info.ingress_ace_list_hdls4[devport][loop]

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_ace_remove(
                        self.node_id,
                        sinst_info.ingress_acl_list_hdls4[devport][0],
                        len(sinst_info.ingress_ace_list_hdls4[devport]),
                        compat_pointer(acehandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_ace_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACEs from ACL ING TABLE 4: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACES from ACL ING TABLE 4")

                for loop in compat_xrange(len(sinst_info.ingress_ace_list_hdls4[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_ace_delete(
                            self.node_id,
                            sinst_info.ingress_ace_list_hdls4[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_ace_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to delete ACE from ING TABLE 4: rc=%d"%rc)
                    else:
                        log_dbg(1, "Successfully delete ACE from ING TABLE 4")

                sysporthandleList = (ifcs_ctypes.ifcs_handle_t * 1)()
                sp_hdl = ifcs_ctypes.ifcs_handle_t()
                port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[devport].sp_hdl)
                sp_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)

                sysporthandleList[0] = sp_hdl
                portCount = 1

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_port_remove(
                        self.node_id,
                        sinst_info.ingress_acl_list_hdls4[devport][0],
                        portCount,
                        compat_pointer(sysporthandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_port_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove SYSPORT from ACL ING TABLE 4: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed SYSPORT from ACL ING TABLE 4")

                aclhandleList = (ifcs_ctypes.ifcs_handle_t * 1)()
                aclhandleList[0] = sinst_info.ingress_acl_list_hdls4[devport][0]
                aclCount = 1

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_table_acl_remove(
                        self.node_id,
                        sinst_info.list_of_acl_table_hdl[CHECKPOINT_5A],
                        aclCount,
                        compat_pointer(aclhandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_table_acl_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACL from ACL ING TABLE 4: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACL from ACL ING TABLE 4")

                for loop in compat_xrange(len(sinst_info.ingress_acl_list_hdls4[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_delete(
                            self.node_id,
                            sinst_info.ingress_acl_list_hdls4[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_acl_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL from ING TABLE 4: rc=%d"%rc)
                    else:
                         log_dbg(1, "Successfully deleted ACL from ING TABLE 4")
                '''
                log_dbg(1, "Deleting ACL MATCH from ING TABLE 4")
                for loop in compat_xrange(len(sinst_info.ingress_match_list_hdls4[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_match_delete(
                            self.node_id,
                            sinst_info.ingress_match_list_hdls4[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL MATCH from ING TABLE 4: rc=%d"%rc)
                '''

############################################################################
#################### ING TABLE 5 ###########################################
############################################################################
            if (len(sinst_info.ingress_ace_list_hdls5[devport])) :
                acehandleList = (ifcs_ctypes.ifcs_handle_t * len(sinst_info.ingress_ace_list_hdls5[devport]))()
                for loop in compat_xrange(len(sinst_info.ingress_ace_list_hdls5[devport])):
                    acehandleList[loop] = sinst_info.ingress_ace_list_hdls5[devport][loop]

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_ace_remove(
                        self.node_id,
                        sinst_info.ingress_acl_list_hdls5[devport][0],
                        len(sinst_info.ingress_ace_list_hdls5[devport]),
                        compat_pointer(acehandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_ace_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACEs from ACL ING TABLE 5: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACES from ACL ING TABLE 5")

                for loop in compat_xrange(len(sinst_info.ingress_ace_list_hdls5[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_ace_delete(
                            self.node_id,
                            sinst_info.ingress_ace_list_hdls5[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_ace_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to delete ACE from ING TABLE 5: rc=%d"%rc)
                    else:
                        log_dbg(1, "Successfully delete ACE from ING TABLE 5")

                sysporthandleList = (ifcs_ctypes.ifcs_handle_t * 1)()
                sp_hdl = ifcs_ctypes.ifcs_handle_t()
                port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[devport].sp_hdl)
                sp_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)

                sysporthandleList[0] = sp_hdl
                portCount = 1

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_port_remove(
                        self.node_id,
                        sinst_info.ingress_acl_list_hdls5[devport][0],
                        portCount,
                        compat_pointer(sysporthandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_port_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove SYSPORT from ACL ING TABLE 5: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed SYSPORT from ACL ING TABLE 5")

                aclhandleList = (ifcs_ctypes.ifcs_handle_t * 1)()
                aclhandleList[0] = sinst_info.ingress_acl_list_hdls5[devport][0]
                aclCount = 1

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_table_acl_remove(
                        self.node_id,
                        sinst_info.list_of_acl_table_hdl[CHECKPOINT_5B],
                        aclCount,
                        compat_pointer(aclhandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_table_acl_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACL from ACL ING TABLE 5: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACL from ACL ING TABLE 5")

                for loop in compat_xrange(len(sinst_info.ingress_acl_list_hdls5[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_delete(
                            self.node_id,
                            sinst_info.ingress_acl_list_hdls5[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_acl_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL from ING TABLE 5: rc=%d"%rc)
                    else:
                         log_dbg(1, "Successfully deleted ACL from ING TABLE 5")
                '''
                log_dbg(1, "Deleting ACL MATCH from ING TABLE 5")
                for loop in compat_xrange(len(sinst_info.ingress_match_list_hdls5[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_match_delete(
                            self.node_id,
                            sinst_info.ingress_match_list_hdls5[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL MATCH from ING TABLE 5: rc=%d"%rc)
                '''

############################################################################
#################### ING TABLE 6 ###########################################
############################################################################

            if (len(sinst_info.ingress_ace_list_hdls6[devport])) :
                acehandleList = (ifcs_ctypes.ifcs_handle_t * len(sinst_info.ingress_ace_list_hdls6[devport]))()
                for loop in compat_xrange(len(sinst_info.ingress_ace_list_hdls6[devport])):
                    acehandleList[loop] = sinst_info.ingress_ace_list_hdls6[devport][loop]

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_ace_remove(
                        self.node_id,
                        sinst_info.ingress_acl_list_hdls6[devport][0],
                        len(sinst_info.ingress_ace_list_hdls6[devport]),
                        compat_pointer(acehandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_ace_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACEs from ACL ING TABLE 6: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACES from ACL ING TABLE 6")

                for loop in compat_xrange(len(sinst_info.ingress_ace_list_hdls6[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_ace_delete(
                            self.node_id,
                            sinst_info.ingress_ace_list_hdls6[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_ace_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to delete ACE from ING TABLE 6: rc=%d"%rc)
                    else:
                        log_dbg(1, "Successfully deleted ACES from ING TABLE 6")

                aclhandleList = (ifcs_ctypes.ifcs_handle_t * 1)()
                aclhandleList[0] = sinst_info.ingress_acl_list_hdls6[devport][0]
                aclCount = 1

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_table_acl_remove(
                        self.node_id,
                        sinst_info.list_of_acl_table_hdl[CHECKPOINT_6A],
                        aclCount,
                        compat_pointer(aclhandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_table_acl_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACL from ACL ING TABLE 6: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACL from ACL ING TABLE 6")

                for loop in compat_xrange(len(sinst_info.ingress_acl_list_hdls6[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_delete(
                            self.node_id,
                            sinst_info.ingress_acl_list_hdls6[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_acl_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL from ING TABLE 6: rc=%d"%rc)
                    else:
                         log_dbg(1, "Successfully deleted ACL from ING TABLE 6")
                '''
                log_dbg(1, "Deleting ACL MATCH from ING TABLE 6")
                for loop in compat_xrange(len(sinst_info.ingress_match_list_hdls6[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_match_delete(
                            self.node_id,
                            sinst_info.ingress_match_list_hdls6[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL MATCH from ING TABLE 6: rc=%d"%rc)
                '''
############################################################################
#################### ING TABLE 7 (PRE-FWD) #################################
############################################################################

            if (len(sinst_info.ingress_ace_list_hdls7[devport])) :
                acehandleList = (ifcs_ctypes.ifcs_handle_t * len(sinst_info.ingress_ace_list_hdls7[devport]))()
                for loop in compat_xrange(len(sinst_info.ingress_ace_list_hdls7[devport])):
                    acehandleList[loop] = sinst_info.ingress_ace_list_hdls7[devport][loop]

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_ace_remove(
                        self.node_id,
                        sinst_info.ingress_acl_list_hdls7[devport][0],
                        len(sinst_info.ingress_ace_list_hdls7[devport]),
                        compat_pointer(acehandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_ace_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACEs from ACL ING TABLE 7: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACES from ACL ING TABLE 7")

                for loop in compat_xrange(len(sinst_info.ingress_ace_list_hdls7[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_ace_delete(
                            self.node_id,
                            sinst_info.ingress_ace_list_hdls7[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_ace_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to delete ACE from ING TABLE 7: rc=%d"%rc)
                    else:
                        log_dbg(1, "Successfully deleted ACES from ING TABLE 7")

                aclhandleList = (ifcs_ctypes.ifcs_handle_t * 1)()
                aclhandleList[0] = sinst_info.ingress_acl_list_hdls7[devport][0]
                aclCount = 1

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_table_acl_remove(
                        self.node_id,
                        sinst_info.list_of_acl_table_hdl[CHECKPOINT_7A],
                        aclCount,
                        compat_pointer(aclhandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_table_acl_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACL from ACL ING TABLE 7: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACL from ACL ING TABLE 7")

                for loop in compat_xrange(len(sinst_info.ingress_acl_list_hdls7[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_delete(
                            self.node_id,
                            sinst_info.ingress_acl_list_hdls7[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_acl_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL from ING TABLE 7: rc=%d"%rc)
                    else:
                         log_dbg(1, "Successfully deleted ACL from ING TABLE 7")
                '''
                log_dbg(1, "Deleting ACL MATCH from ING TABLE 7")
                for loop in compat_xrange(len(sinst_info.ingress_match_list_hdls7[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_match_delete(
                            self.node_id,
                            sinst_info.ingress_match_list_hdls7[devport][loop]))
                    spstcommon_handle_device_access_error(rc, "ifcs_acl_match_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL MATCH from ING TABLE 7: rc=%d"%rc)
                '''
            # end of devport with configs check
        # end of devport iterartor

        log_dbg(1, "Deleting all ACL MATCH")
        for loop in compat_xrange(len(sinst_info.list_of_all_acl_match_hdls)) :
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_acl_match_delete(
                    self.node_id,
                    sinst_info.list_of_all_acl_match_hdls[loop]))
            spstcommon_handle_device_access_error(rc, "ifcs_acl_match_delete")
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                 log_err("failed to delete ACL MATCH : rc=%d"%rc)

        log_dbg(1, "Deleting all ACL ACTION")
        for loop in compat_xrange(len(sinst_info.list_of_all_acl_action_hdls)) :
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_acl_action_delete(
                    self.node_id,
                    sinst_info.list_of_all_acl_action_hdls[loop]))
            spstcommon_handle_device_access_error(rc, "ifcs_acl_action_delete")
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                 log_err("failed to delete ACL ACTION : rc=%d"%rc)

        #delete flexcounterset
        for fc_hdl in sinst_info.list_of_flex_counterset_hdl:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_flex_counterset_delete(
                    self.node_id,
                    fc_hdl))
            spstcommon_handle_device_access_error(rc, "ifcs_flex_counterset_delete")
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err("failed to remove flex counterset: rc=%d"%rc)
            else:
                log_dbg(1, "Successfully removed flex counterset")

        #delete flexpool
        rc = ifcs_ctypes.IFCS_STATUS_REASON(
            ifcs_ctypes.ifcs_flex_pool_delete(
                self.node_id,
                sinst_info.list_of_flex_pool_hdl[0]))
        spstcommon_handle_device_access_error(rc, "ifcs_flex_pool_delete")
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("failed to remove flex pool: rc=%d"%rc)
        else:
            log_dbg(1, "Successfully removed flex pool")

        log_dbg(1, "Deleting all ACL Tables")
        for loop in compat_xrange(len(sinst_info.list_of_acl_table_hdl)) :
                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_table_delete(
                        self.node_id,
                        sinst_info.list_of_acl_table_hdl[loop]))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_table_delete")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                     log_err("failed to delete ACL Tables: rc=%d"%rc)

        log_dbg(1, "Deleting all Match Profiles")
        for loop in compat_xrange(len(sinst_info.list_of_mp_hdl)) :
                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_match_profile_delete(
                        self.node_id,
                        sinst_info.list_of_mp_hdl[loop]))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_match_profile_delete")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                     log_err("failed to delete all Match Profiles: rc=%d"%rc)

        log_dbg(1, "Deleting all Action Profiles")
        for loop in compat_xrange(len(sinst_info.list_of_ap_hdl)) :
                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_action_profile_delete(
                        self.node_id,
                        sinst_info.list_of_ap_hdl[loop]))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_action_profile_delete")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                     log_err("failed to delete all Action Profiles: rc=%d"%rc)

        log_dbg(1, "Deleting all Compressed IPs")
        for loop in compat_xrange(len(sinst_info.list_of_cip_hdl)) :
                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_compressed_ip_address_delete(
                        self.node_id,
                        sinst_info.list_of_cip_hdl[loop]))
                spstcommon_handle_device_access_error(rc, "ifcs_acl_compressed_ip_address_delete")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                     log_err("failed to delete all Compressed IPs: rc=%d"%rc)

        log_dbg(1, "Deleting all FPFs")
        for loop in compat_xrange(len(sinst_info.list_of_fpf_hdl)) :
                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_fpf_delete(
                        self.node_id,
                        sinst_info.list_of_fpf_hdl[loop]))
                spstcommon_handle_device_access_error(rc, "ifcs_fpf_delete")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                     log_err("failed to delete all FPFs: rc=%d"%rc)

        #ACL handles
        sinst_info.ingress_ace_list_hdls = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.egress_ace_list_hdls = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.egress_ace_list_hdls2 = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.ingress_ace_list_hdls2 = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.egress_ace_list_hdls3 = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.ingress_ace_list_hdls3 = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.egress_ace_list_hdls4 = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.ingress_ace_list_hdls4 = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.ingress_ace_list_hdls5 = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.ingress_ace_list_hdls6 = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.ingress_ace_list_hdls7 = [[] for i in range (MAX_DEV_PORTS)]

        sinst_info.ingress_match_list_hdls = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.egress_match_list_hdls = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.egress_match_list_hdls2 = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.ingress_match_list_hdls2 = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.egress_match_list_hdls3 = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.ingress_match_list_hdls3 = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.egress_match_list_hdls4 = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.ingress_match_list_hdls4 = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.ingress_match_list_hdls5 = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.ingress_match_list_hdls6 = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.ingress_match_list_hdls7 = [[] for i in range (MAX_DEV_PORTS)]

        sinst_info.ingress_acl_list_hdls = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.egress_acl_list_hdls = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.egress_acl_list_hdls2 = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.ingress_acl_list_hdls2 = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.egress_acl_list_hdls3 = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.ingress_acl_list_hdls3 = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.egress_acl_list_hdls4 = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.ingress_acl_list_hdls4 = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.ingress_acl_list_hdls5 = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.ingress_acl_list_hdls6 = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.ingress_acl_list_hdls7 = [[] for i in range (MAX_DEV_PORTS)]

        sinst_info.ing_acl_list_for_table1 = []
        sinst_info.ing_acl_list_for_table2 = []
        sinst_info.egr_acl_list_for_table1 = []
        sinst_info.egr_acl_list_for_table2 = []
        sinst_info.egr_acl_list_for_table3 = []
        sinst_info.ing_acl_list_for_table3 = []
        sinst_info.egr_acl_list_for_table4 = []
        sinst_info.ing_acl_list_for_table4 = []
        sinst_info.ing_acl_list_for_table5 = []
        sinst_info.ing_acl_list_for_table6 = []
        sinst_info.ing_acl_list_for_table7 = []

        sinst_info.ing_ace_list_for_table1 = []
        sinst_info.ing_ace_list_for_table2 = []
        sinst_info.egr_ace_list_for_table1 = []
        sinst_info.egr_ace_list_for_table2 = []
        sinst_info.egr_ace_list_for_table3 = []
        sinst_info.ing_ace_list_for_table3 = []
        sinst_info.egr_ace_list_for_table4 = []
        sinst_info.ing_ace_list_for_table4 = []
        sinst_info.ing_ace_list_for_table5 = []
        sinst_info.ing_ace_list_for_table6 = []
        sinst_info.ing_ace_list_for_table7 = []

        sinst_info.list_of_acl_table_hdl = []
        sinst_info.list_of_mp_hdl = []
        sinst_info.list_of_ap_hdl = []
        sinst_info.list_of_cip_hdl = []
        sinst_info.list_of_fpf_hdl = []

        sinst_info.list_of_all_acl_match_hdls = []

        sinst_info.ace_priority = 100

        log_dbg(1, "ACL config cleanup done")

    def configAclCreateIngress(self, sinst_info):
        self.configAclIpCompression(sinst_info)
        self.configAclFpf(sinst_info, ifcs_ctypes.IFCS_ACL_DIRECTION_INGRESS, ifcs_ctypes.IFCS_FPF_BASE_OFFSET_START_OF_PKT)

        # post-fwd ingress
        if self.node_device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
            self.configAclCreate(10, ifcs_ctypes.IFCS_ACL_LOOKUP_STAGE_PRE_FWD, ifcs_ctypes.IFCS_ACL_SCOPE_NODE, ifcs_ctypes.IFCS_ACL_MATCH_MAX_WIDTH_160_BITS, 128, 1, 10, 0, 0, sinst_info)
        elif self.node_device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TL10:
            self.configAclCreate(10, ifcs_ctypes.IFCS_ACL_LOOKUP_STAGE_PRE_FWD, ifcs_ctypes.IFCS_ACL_SCOPE_NODE, ifcs_ctypes.IFCS_ACL_MATCH_MAX_WIDTH_159_BITS, 128, 1, 10, 0, 0, sinst_info)
        else:
            assert False, "Not supported on this device type {}".format(self.node_device_type)
        self.configAclCreate(0, ifcs_ctypes.IFCS_ACL_LOOKUP_STAGE_POST_FWD, ifcs_ctypes.IFCS_ACL_SCOPE_PER_IB, ifcs_ctypes.IFCS_ACL_MATCH_MAX_WIDTH_320_BITS, 128, 1, 2, 0, 0, sinst_info)
        self.configAclCreate(5, ifcs_ctypes.IFCS_ACL_LOOKUP_STAGE_POST_FWD, ifcs_ctypes.IFCS_ACL_SCOPE_PER_IB, ifcs_ctypes.IFCS_ACL_MATCH_MAX_WIDTH_320_BITS, 128, 1, 3, 0, 0, sinst_info)
        self.configAclCreate(7, ifcs_ctypes.IFCS_ACL_LOOKUP_STAGE_POST_FWD, ifcs_ctypes.IFCS_ACL_SCOPE_PER_IB, ifcs_ctypes.IFCS_ACL_MATCH_MAX_WIDTH_320_BITS, 128, 1, 4, 0, 0, sinst_info)
        self.configAclCreate(8, ifcs_ctypes.IFCS_ACL_LOOKUP_STAGE_POST_FWD, ifcs_ctypes.IFCS_ACL_SCOPE_PER_IB, ifcs_ctypes.IFCS_ACL_MATCH_MAX_WIDTH_320_BITS, 128, 1, 5, 0, 0, sinst_info)
        self.configAclCreate(3, ifcs_ctypes.IFCS_ACL_LOOKUP_STAGE_POST_FWD, ifcs_ctypes.IFCS_ACL_SCOPE_NODE, ifcs_ctypes.IFCS_ACL_MATCH_MAX_WIDTH_80_BITS, 256, 1, 6, 0, 0, sinst_info)
        self.configAclCreate(9, ifcs_ctypes.IFCS_ACL_LOOKUP_STAGE_POST_FWD, ifcs_ctypes.IFCS_ACL_SCOPE_NODE, ifcs_ctypes.IFCS_ACL_MATCH_MAX_WIDTH_80_BITS, 256, 1, 7, 0, 0, sinst_info)


    def configAclCreateEgress(self, sinst_info):
        # post-fwd egress
        self.configAclCreate(1, ifcs_ctypes.IFCS_ACL_LOOKUP_STAGE_POST_FWD, ifcs_ctypes.IFCS_ACL_SCOPE_NODE, ifcs_ctypes.IFCS_ACL_MATCH_MAX_WIDTH_160_BITS, 256, 1, 1, 0, 0, sinst_info)
        self.configAclCreate(6, ifcs_ctypes.IFCS_ACL_LOOKUP_STAGE_POST_FWD, ifcs_ctypes.IFCS_ACL_SCOPE_NODE, ifcs_ctypes.IFCS_ACL_MATCH_MAX_WIDTH_160_BITS, 256, 1, 3, 0, 0, sinst_info)
        self.configAclCreate(2, ifcs_ctypes.IFCS_ACL_LOOKUP_STAGE_POST_FWD, ifcs_ctypes.IFCS_ACL_SCOPE_NODE, ifcs_ctypes.IFCS_ACL_MATCH_MAX_WIDTH_80_BITS, 256, 1, 2, 0, 0, sinst_info)
        self.configAclCreate(4, ifcs_ctypes.IFCS_ACL_LOOKUP_STAGE_POST_FWD, ifcs_ctypes.IFCS_ACL_SCOPE_NODE, ifcs_ctypes.IFCS_ACL_MATCH_MAX_WIDTH_80_BITS, 256, 1, 4, 0, 0, sinst_info)

    def config_show(self, args):
        table = PrintTable()
        header = []
        header.append("Devports")
        header.append("Loopback type")
        header.append("Snake id")
        header.append("Snake type")
        table.add_row(header)
        sinst_info_sorted = sorted(L3spst.sinst_info_runs, key=config_show_sort_key)
        for sinst_info in sinst_info_sorted:
            data = []
            data.append(str(sinst_info.devport_list)[1:-1])
            data.append(str(sinst_info.lb_type))
            data.append(str(sinst_info.id))
            data.append(str(sinst_info.type))
            table.add_row(data)

        table.print_table()
        table.reset_table()
        pass

    def show_acl_stats(self, args):
        global sinst_info
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='L3spst test show_acl_stats', prog='snake show_acl_stats', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=0, help='L3spst id needed if more than one snake configured')

        try:
            res = parser.parse_args(self.arg_list)
        except SystemExit:
            log_err("Parsing failed in show_acl_stats")
            return
        except:
            log_err("Parsing failed in show_acl_stats")
            return "FAILED"

        if res.id:
            if res.id == -1:
                sinst_info = self.get_cur_run_data()
            else:
                find = False
                for instance in L3spst.sinst_info_runs:
                    if instance.id == res.id:
                        sinst_info = instance
                        find = True
                        break
                if find == False:
                    log("L3spst with id",res.id,"doesn't exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in L3spst.sinst_info_runs:
                snake_count += 1
            if snake_count > 1:
                log("More than one snake configured. Use snake id to stop traffic on a specific snake")
                return 'FAILED'
            sinst_info = self.get_cur_run_data()

        ingress_acl_table_catch_all_stats = 0
        egress_acl_table_catch_all_stats = 0
        cp_1a_all_devport_stats = 0
        cp_1b_all_devport_stats = 0
        cp_2a_all_devport_stats = 0
        cp_3a_all_devport_stats = 0
        cp_4a_all_devport_stats = 0
        cp_5a_all_devport_stats = 0
        cp_5b_all_devport_stats = 0
        cp_6a_all_devport_stats = 0
        cp_7a_all_devport_stats = 0
        cp_1a_per_port_stats = [0 for count in range(MAX_DEV_PORTS)]
        cp_1b_per_port_stats = [0 for count in range(MAX_DEV_PORTS)]
        cp_2a_per_port_stats = [0 for count in range(MAX_DEV_PORTS)]
        cp_3a_per_port_stats = [0 for count in range(MAX_DEV_PORTS)]
        cp_4a_per_port_stats = [0 for count in range(MAX_DEV_PORTS)]
        cp_5a_per_port_stats = [0 for count in range(MAX_DEV_PORTS)]
        cp_5b_per_port_stats = [0 for count in range(MAX_DEV_PORTS)]
        cp_6a_per_port_stats = [0 for count in range(MAX_DEV_PORTS)]
        cp_7a_per_port_stats = [0 for count in range(MAX_DEV_PORTS)]
        mirror_created_stats = [0 for count in range(self.num_ibs)]
        mirror_dropped_stats = [0 for count in range(self.num_ibs)]
        mirror_catch_all_stats = [0 for count in range(1)]

        devport_list = sinst_info.devport_list
        count = 0
        mcreate_index = 0
        mdrop_index = 0
        total_index = 0
        for devport in devport_list:
            if (len(sinst_info.ingress_ace_list_hdls[devport])) :
                acehandle = ifcs_ctypes.ifcs_handle_t()
                for loop in compat_xrange(len(sinst_info.ingress_ace_list_hdls[devport])):
                    acehandle = sinst_info.ingress_ace_list_hdls[devport][loop]
                    stats = ace_get_packets(0, acehandle)
                    cp_1a_per_port_stats[devport]  += stats
                    cp_1a_all_devport_stats += stats
                log("ACL CP ING1 1A: Devport {} stats: {} packets".format(devport, cp_1a_per_port_stats[devport]))

            if (len(sinst_info.ingress_ace_list_hdls3[devport])) :
                acehandle = ifcs_ctypes.ifcs_handle_t()
                for loop in compat_xrange(len(sinst_info.ingress_ace_list_hdls3[devport])):
                    acehandle = sinst_info.ingress_ace_list_hdls3[devport][loop]
                    stats = ace_get_packets(0, acehandle)
                    cp_1b_per_port_stats[devport]  += stats
                    cp_1b_all_devport_stats += stats
                log("ACL CP ING2 1B: Devport {} stats: {} packets".format(devport, cp_1b_per_port_stats[devport]))

            if (len(sinst_info.ingress_ace_list_hdls2[devport])) :
                acehandle = ifcs_ctypes.ifcs_handle_t()
                for loop in compat_xrange(len(sinst_info.ingress_ace_list_hdls2[devport])):
                    acehandle = sinst_info.ingress_ace_list_hdls2[devport][loop]
                    ingress_acl_table_catch_all_stats += ace_get_packets(0, acehandle)

            if (len(sinst_info.egress_ace_list_hdls[devport])) :
                acehandle = ifcs_ctypes.ifcs_handle_t()
                for loop in compat_xrange(len(sinst_info.egress_ace_list_hdls[devport])):
                    acehandle = sinst_info.egress_ace_list_hdls[devport][loop]
                    stats = ace_get_packets(0, acehandle)
                    cp_2a_per_port_stats[devport]  += stats
                    cp_2a_all_devport_stats += stats
                log("ACL CP EGR7 2A: Devport {} stats: {} packets".format(devport, cp_2a_per_port_stats[devport]))

            if (len(sinst_info.egress_ace_list_hdls2[devport])) :
                acehandle = ifcs_ctypes.ifcs_handle_t()
                for loop in compat_xrange(len(sinst_info.egress_ace_list_hdls2[devport])):
                    acehandle = sinst_info.egress_ace_list_hdls2[devport][loop]
                    stats = ace_get_packets(0, acehandle)
                    cp_3a_per_port_stats[devport]  += stats
                    cp_3a_all_devport_stats += stats
                log("ACL CP EGR9 3A: Devport {} stats: {} packets".format(devport, cp_3a_per_port_stats[devport]))

            if (len(sinst_info.egress_ace_list_hdls4[devport])) :
                acehandle = ifcs_ctypes.ifcs_handle_t()
                for loop in compat_xrange(len(sinst_info.egress_ace_list_hdls4[devport])):
                    acehandle = sinst_info.egress_ace_list_hdls4[devport][loop]
                    stats = ace_get_packets(0, acehandle)
                    cp_4a_per_port_stats[devport]  += stats
                    cp_4a_all_devport_stats += stats
                log("ACL CP EGR8 4A: Devport {} stats: {} packets".format(devport, cp_4a_per_port_stats[devport]))

            if (len(sinst_info.ingress_ace_list_hdls4[devport])) :
                acehandle = ifcs_ctypes.ifcs_handle_t()
                for loop in compat_xrange(len(sinst_info.ingress_ace_list_hdls4[devport])):
                    acehandle = sinst_info.ingress_ace_list_hdls4[devport][loop]
                    stats = ace_get_packets(0, acehandle)
                    cp_5a_per_port_stats[devport]  += stats
                    cp_5a_all_devport_stats += stats
                log("ACL CP ING3 5A: Devport {} stats: {} packets".format(devport, cp_5a_per_port_stats[devport]))

            if (len(sinst_info.ingress_ace_list_hdls5[devport])) :
                acehandle = ifcs_ctypes.ifcs_handle_t()
                for loop in compat_xrange(len(sinst_info.ingress_ace_list_hdls5[devport])):
                    acehandle = sinst_info.ingress_ace_list_hdls5[devport][loop]
                    stats = ace_get_packets(0, acehandle)
                    cp_5b_per_port_stats[devport]  += stats
                    cp_5b_all_devport_stats += stats
                log("ACL CP ING4 5B: Devport {} stats: {} packets".format(devport, cp_5b_per_port_stats[devport]))

            if (len(sinst_info.ingress_ace_list_hdls6[devport])) :
                acehandle = ifcs_ctypes.ifcs_handle_t()
                for loop in compat_xrange(len(sinst_info.ingress_ace_list_hdls6[devport])):
                    acehandle = sinst_info.ingress_ace_list_hdls6[devport][loop]
                    stats = ace_get_packets(0, acehandle)
                    cp_6a_per_port_stats[devport]  += stats
                    cp_6a_all_devport_stats += stats
                log("ACL CP ING6 6A: Devport {} stats: {} packets".format(devport, cp_6a_per_port_stats[devport]))

            if (len(sinst_info.ingress_ace_list_hdls7[devport])) :
                for loop in compat_xrange(len(sinst_info.ingress_ace_list_hdls7[devport])):
                    flex_counterset_hdl = sinst_info.list_of_flex_counterset_hdl[count]
                    stats = flexstat_get_packets(0, flex_counterset_hdl, sinst_info.port_fwd_inst_list[devport].sp_hdl)
                    cp_7a_per_port_stats[devport]  += stats
                    cp_7a_all_devport_stats += stats
                count += 1
                log("ACL CP PRE0 7A: Devport {} stats: {} packets".format(devport, cp_7a_per_port_stats[devport]))

            if (len(sinst_info.egress_ace_list_hdls3[devport])) :
                acehandle = ifcs_ctypes.ifcs_handle_t()
                for loop in compat_xrange(len(sinst_info.egress_ace_list_hdls3[devport])):
                    acehandle = sinst_info.egress_ace_list_hdls3[devport][loop]
                    # there are 2 aces per recirc-ibport in egress acl table which does mirroring
                    if total_index < self.num_ibs*2:
                        if (total_index % 2) == 0:
                            mirror_dropped_stats[mdrop_index] = ace_get_packets(0, acehandle)
                            mdrop_index += 1
                        else:
                            mirror_created_stats[mcreate_index] = ace_get_packets(0, acehandle)
                            mcreate_index += 1
                            egress_acl_table_catch_all_stats += ace_get_packets(0, acehandle)
                    elif total_index == self.num_ibs*2:
                        mirror_catch_all_stats[0] += ace_get_packets(0, acehandle)
                    else:
                        egress_acl_table_catch_all_stats += ace_get_packets(0, acehandle)
                    total_index += 1

        #update ACE catch all stats
        catch_all = ingress_acl_table_catch_all_stats - cp_1a_all_devport_stats
        log("ACL CP ING1 1A: catch-all stats: {} packets".format(catch_all))

        catch_all = ingress_acl_table_catch_all_stats - cp_1b_all_devport_stats
        log("ACL CP ING2 1B: catch-all stats: {} packets".format(catch_all))

        if sinst_info.mirror_cfg == True:
            catch_all = egress_acl_table_catch_all_stats - cp_2a_all_devport_stats
            log("ACL CP EGR7 2A: catch-all stats: {} packets".format(catch_all))

            catch_all = egress_acl_table_catch_all_stats - cp_3a_all_devport_stats
            log("ACL CP EGR9 3A: catch-all stats: {} packets".format(catch_all))

            catch_all = egress_acl_table_catch_all_stats - cp_4a_all_devport_stats
            log("ACL CP EGR8 4A: catch-all stats: {} packets".format(catch_all))
        else:
            log("ACL CP EGR7 2A: catch-all stats: {} packets".format(0))
            log("ACL CP EGR9 3A: catch-all stats: {} packets".format(0))
            log("ACL CP EGR8 4A: catch-all stats: {} packets".format(0))

        catch_all = ingress_acl_table_catch_all_stats - cp_5a_all_devport_stats
        log("ACL CP ING3 5A: catch-all stats: {} packets".format(catch_all))

        catch_all = ingress_acl_table_catch_all_stats - cp_5b_all_devport_stats
        log("ACL CP ING4 5B: catch-all stats: {} packets".format(catch_all))

        catch_all = ingress_acl_table_catch_all_stats - cp_6a_all_devport_stats
        log("ACL CP ING6 6A: catch-all stats: {} packets".format(catch_all))

        catch_all = ingress_acl_table_catch_all_stats - cp_7a_all_devport_stats
        log("ACL CP PRE0 7A: catch-all stats: {} packets".format(catch_all))

        log("ACL CP EGR10 8A: mirror catch-all stats: {} packets".format(mirror_catch_all_stats[0]))

        #log("ACL MIRROR created stats: [{}, {}, {}, {}, {}, {}] packets".format(mirror_created_stats[0], mirror_created_stats[1], mirror_created_stats[2], mirror_created_stats[3], mirror_created_stats[4], mirror_created_stats[5]))
        #log("ACL MIRROR dropped stats: [{}, {}, {}, {}, {}, {}] packets".format(mirror_dropped_stats[0], mirror_dropped_stats[1], mirror_dropped_stats[2], mirror_dropped_stats[3], mirror_dropped_stats[4], mirror_dropped_stats[5]))
        log("ACL MIRROR created stats: {} packets".format(mirror_created_stats))
        log("ACL MIRROR dropped stats: {} packets".format(mirror_dropped_stats))

        return 'PASS'

    def clear_acl_stats(self, args):
        global sinst_info
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='L3spst test clear_acl_stats', prog='snake clear_acl_stats', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=0, help='L3spst id needed if more than one snake configured')

        try:
            res = parser.parse_args(self.arg_list)
        except SystemExit:
            log_err("Parsing failed in clear_acl_stats")
            return
        except:
            log_err("Parsing failed in clear_acl_stats")
            return "FAILED"

        if res.id:
            if res.id == -1:
                sinst_info = self.get_cur_run_data()
            else:
                find = False
                for instance in L3spst.sinst_info_runs:
                    if instance.id == res.id:
                        sinst_info = instance
                        find = True
                        break
                if find == False:
                    log("L3spst with id",res.id,"doesn't exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in L3spst.sinst_info_runs:
                snake_count += 1
            if snake_count > 1:
                log("More than one snake configured. Use snake id to stop traffic on a specific snake")
                return 'FAILED'
            sinst_info = self.get_cur_run_data()

        for ace in sinst_info.ing_ace_list_for_table1:
            ace_clear_packets_bytes(0, ace)

        for ace in sinst_info.ing_ace_list_for_table2:
            ace_clear_packets_bytes(0, ace)

        for ace in sinst_info.egr_ace_list_for_table1:
            ace_clear_packets_bytes(0, ace)

        for ace in sinst_info.egr_ace_list_for_table2:
            ace_clear_packets_bytes(0, ace)

        for ace in sinst_info.egr_ace_list_for_table3:
            ace_clear_packets_bytes(0, ace)

        for ace in sinst_info.ing_ace_list_for_table3:
            ace_clear_packets_bytes(0, ace)

        for ace in sinst_info.egr_ace_list_for_table4:
            ace_clear_packets_bytes(0, ace)

        for ace in sinst_info.ing_ace_list_for_table4:
            ace_clear_packets_bytes(0, ace)

        for ace in sinst_info.ing_ace_list_for_table5:
            ace_clear_packets_bytes(0, ace)

        for ace in sinst_info.ing_ace_list_for_table6:
            ace_clear_packets_bytes(0, ace)

        for ace in sinst_info.ing_ace_list_for_table7:
            flexstat_clear_packets_bytes(0, sinst_info)

        return 'PASS'

    def unconfig(self, args):
        parser = argparse.ArgumentParser(description='L3spst unconfig', prog='L3spst unconfig', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=None, help='Snake id. Needed if more than one snake configured')

        try:
            res, unknown = parser.parse_known_args(self.arg_list)
        except:
            log_err("Parsing failed in unconfig")
            return 'FAILED'

        if res.id:
            if res.id == -1:
                sinst_info = self.get_cur_run_data()
            else:
                find = False
                for index, instance in enumerate(L3spst.sinst_info_runs):
                    if instance.id == res.id:
                        sinst_info = instance
                        find = True
                        res.id = index
                        break
                if find == False:
                    log_err("Snake with id ", res.id, " does not exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in L3spst.sinst_info_runs:
                snake_count += 1
            if snake_count > 1:
                log_err("More than one snake configured. Use snake id to remove configuration for a specific snake")
                return 'FAILED'
            sinst_info = self.get_cur_run_data()
            res.id = -1

        verbose = sinst_info.verbose

        # deleteing ACL configs
        self.configAclDeleteAll(sinst_info)

        if sinst_info.mirror_cfg == True:
            # Delete Collector Sets
            if verbose:
                log("Deleting Collector Sets")
            err = self.configCollectorSetDelete(sinst_info)
            if err:
                log_err("L3spst test unconfig failed")
                return 'FAILED'

            # Delete Collector
            if verbose:
                log("Deleting Collectors")
            err = self.configCollectorDelete(sinst_info)
            if err:
                log_err("L3spst test unconfig failed")
                return 'FAILED'

            # Delete DCDP
            if verbose:
                log("Deleting DCDP")
            err = self.configDcdpDelete(sinst_info)
            if err:
                log_err("L3spst test unconfig failed")
                return 'FAILED'

            self.mirror_cfg = False

        # Delete V4 route entries
        if verbose:
            log("Deleting V4 route entries")
        err = self.configV4RouteDelete(sinst_info)
        if err:
            log_err("L3spst test unconfig failed")
            return 'FAILED'

        # Delete V6 route entries
        if verbose:
            log("Deleting V6 route entries")
        err = self.configV6RouteDelete(sinst_info)
        if err:
            log_err("L3spst test unconfig failed")
            return 'FAILED'

        # Delete nexthops
        if verbose:
            log("Deleting nexthops")
        err = self.configNexthopDelete(sinst_info)
        if err:
            log_err("L3spst test unconfig failed")
            return 'FAILED'

        # Delete interfaces
        if verbose:
            log("Deleting L3 intfs")
        err = self.configIntfDelete(sinst_info)
        if err:
            log_err("L3spst test unconfig failed")
            return 'FAILED'

        # Delete Qos MAPs/Map Groups
        if verbose:
            log("Deleting Qos maps/map DSCP groups")
        err = self.configQosMapDscpDelete(sinst_info)
        if err:
            log_err("L3spst test unconfig failed")
            return 'FAILED'

        # Delete l3vnis
        if verbose:
            log("Deleting l3vnis")
        err = self.configL3vniDelete(sinst_info)
        if err:
            log_err("L3spst test unconfig failed")
            return 'FAILED'

        # Disable all devports
        err = self.configDevportsDisable(sinst_info)
        if err:
            log_err("L3spst test unconfig failed")
            return 'FAILED'

        # Set devports loopback to NONE
        if verbose:
            log("Setting devports loopback mode to NONE")
        err = self.configDevportsLoopback(sinst_info, 'NONE')
        if err:
            log_err("L3spst test unconfig failed")
            return 'FAILED'

        # Set devports Fwd mode to L2_L3
        if verbose:
            log("Setting devports fwd mode to L2_L3")
        err = self.configSysportSetFwdMode(sinst_info, ifcs_ctypes.IFCS_SYSPORT_FWD_MODE_L2_L3)
        if err:
            log_err("L3spst test unconfig failed")
            return 'FAILED'

        # Remove Sysport params
        if verbose:
            log("Resetting sysport params ")
        err = self.configSysport(sinst_info, 0)
        if err:
            log_err("L3spst test unconfig failed")
            return 'FAILED'

        #Remove Sysport dot1pcfi qos groups
        if verbose:
            log("Resetting sysport dot1pcfig qos groups ")
        err = self.configSysportDot1pCfiMap(sinst_info, 0)
        if err:
            log_err("L3spst test unconfig failed")
            return 'FAILED'

        #Delete Qos dot1pcfi maps/map groups
        if verbose:
            log("Deleting Qos maps/map DSCP groups")
        err = self.configQosMapDot1pCfiDelete(sinst_info)
        if err:
            log_err("L3spst test unconfig failed")
            return 'FAILED'

        # Enable all devports
        err = self.configDevportsEnable(sinst_info)
        if err:
            log_err("L3spst test unconfig failed")
            return 'FAILED'

        sinst_info.state = SNAKE_UNCONFIG

        log("Unconfigured snake id {0}".format(sinst_info.id))

        if res.id != -1:
            del L3spst.sinst_info_runs[res.id]
        else:
            L3spst.sinst_info_runs.pop()

        L3spst.run -= 1

        if self.run == -1:
            
            attr_count = 0
            attr = (ifcs_ctypes.ifcs_attr_t * 3)()
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_THRESHOLD_MODE)
            ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_THRESHOLD_MODE_DYNAMIC)
            attr_count += 1
            rc = ifcs_ctypes.ifcs_cpu_queue_attr_set(self.cli.node_id,
                                                     self.cpu_queue_num,
                                                     attr_count,
                                                     compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
            spstcommon_handle_device_access_error(rc, "ifcs_cpu_queue_attr_set")
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err(
                    "Unconfigure snake id {}: dynamic threshold attribute set failed for cpu queue {} with rc: {}"
                    .format(sinst_info.id, self.cpu_queue_num, rc))
                assert 0, "ERR during cpu_queue threshold attr set; rc: {}".format(
                    rc)

            # Delete the trap on last snake unconfig
            rc = ifcs_ctypes.ifcs_hostif_trap_delete(self.cli.node_id, self.trap_hdl)
            spstcommon_handle_device_access_error(rc, "ifcs_hostif_trap_delete")
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err(
                    "Unconfigure snake id {}: hostif trap delete failed for cpu queue {} with rc: {}"
                    .format(sinst_info.id, self.cpu_queue_num, rc))
                assert 0, "ERR during trap handle create"


        if verbose:
            log("Unconfig done")

        return 'PASS'
