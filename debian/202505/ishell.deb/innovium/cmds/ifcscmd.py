
#-------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------

import shlex
import argparse
import itertools
import datetime
import time
import json
import sys
from utils.log_utils import *
from utils.compat_util import *
from verbosity import *
from cmdmgr import Command
from ctypes import *
from collections import OrderedDict
from inspect import *
from ifcs_cmds.all import *
from ifcs_config import IfcsConfig
from counters import Counters as counters
from rate import Rate as rate
from route import Route as route
from evpn import EVPN as evpn
from ifcs_cmds.cli_types import *
import cliparse
from print_table import PrintTable
ifcs_ctypes = sys.modules['ifcs_ctypes']


class Log(Command):
    def __init__(self, cli):
        self.sub_cmds = {
            'set': self.set,
            'show': self.show,
            'help': self.help
        }
        self.cli = cli
        self.arg_list = []
        self.logfile = get_logfile_name()
        self.form_debug_levels()
        self.form_module_names()
        self.levels = ['off', 'fatal', 'error', 'warn', 'info', 'debug']

    def __del__(self):
        return

    def set(self, args):
        log_dbg(1, "In log/trace level set with args: " + args)

        try:
            cmd = args.split()[2]
        except BaseException:
            log_err("Need to specify log or debug")
            return ifcs_ctypes.IFCS_INVAL

        if cmd == 'log':
            try:
                level = args.split()[3]
                log_level = self.check_and_return_log_level(level)
            except BaseException:
                log_err("Failed to parse log level")
                return ifcs_ctypes.IFCS_PARAM

            if log_level == None:
                return ifcs_ctypes.IFCS_PARAM

            try:
                rc = ifcs_ctypes.ifcs_log_level_set(log_level)
                assert rc == ifcs_ctypes.IFCS_SUCCESS
                log("Set log level to " + level)
            except BaseException:
                log_err("Failed to set log level")

        elif cmd == 'debug':
            try:
                module = args.split()[3]
                level = args.split()[4]
                debug_level = self.check_and_return_debug_level(level)
                module_id = self.check_and_return_module_name(module)
            except BaseException:
                log_err("Failed to parse debug level")
                return ifcs_ctypes.IFCS_PARAM

            if debug_level == None or module_id == None:
                return ifcs_ctypes.IFCS_PARAM

            try:
                rc = ifcs_ctypes.ifcs_debug_level_set(
                    self.cli.node_id, module_id, debug_level)
                assert rc == ifcs_ctypes.IFCS_SUCCESS
                log("Set " + module + " debug level to " + level)
            except BaseException:
                log_err("Failed to set debug level")
        else:
            raise KeyError
        return ifcs_ctypes.IFCS_SUCCESS

    def show_log(self, args):
        if args == 'ifcs show log level':
            log_lvl_set = ifcs_log_level_t()
            ifcs_ctypes.ifcs_log_level_get(pointer(log_lvl_set))
            log(self.levels[int(log_lvl_set.value)])
            return
        clipar = cliparse.CliArgParser()
        clipar.add_keyword('module')
        clipar.add_keyword('level')
        clipar.add_keyword('pattern')
        clipar.add_keyword('logfile')
        ns, pargs = clipar.parse_cli_args(args.split()[3:])


        module = None
        level = None
        log_pattern = None

        if ns.module:
            module = ns.module
        if ns.level:
            level = ns.level
        if ns.pattern:
            log_pattern = ' '.join(ns.pattern)
        if ns.logfile:
            self.logfile = ns.logfile[0]

        log("---------------------")
        log(">> Showing log file: " + self.logfile)
        if module:
            log(">> Module          : " + ' '.join(module).upper())
        if level:
            log(">> Level           : " + ' '.join(level).upper())
        if log_pattern:
            log(">> Pattern         : " + log_pattern)
        log("---------------------")

        with open(self.logfile) as f:
            logs = f.read().splitlines()
        f.close()

        self.display_logs(logs, module, level, log_pattern)
        return

    def form_module_names(self):
        self.module_names  = {}
        for m in getmembers(self.cli.ifcs_ctypes):
            if 'IFCS_MOD' in m[0]:
                self.module_names[m[1]] = m[0]

    def form_debug_levels(self):
        self.debug_levels  = {}
        for m in getmembers(self.cli.ifcs_ctypes):
            if 'IFCS_DEBUG_LEVEL' in m[0]:
                self.debug_levels[m[1]] = m[0]

    def get_debug_level_from_debug(self, debug_level):
        try:
            return self.debug_levels[debug_level]
        except:
            return 'None'

    def get_module_name_from_module(self, module):
        try:
            return self.module_names[module]
        except:
            return 'None'

    def show_debug(self, args):
        if len(args.split()) > 4:
            log_err("Failed to parse debug level")
            return IFCS_PARAM

        try:
            module = args.split()[3]
            module_id = self.check_and_return_module_name(module)
        except:
            module_id = None
            pass

        table = PrintTable()
        debug_level = self.cli.ifcs_ctypes.ifcs_debug_level_t()
        table.add_row(['Module', 'Debug Level'])
        if module_id == None:
            for mod in range(IFCS_MOD_MAX):
                if mod == self.cli.ifcs_ctypes.IFCS_MOD_INVALID:
                    continue

                rc = self.cli.ifcs_ctypes.ifcs_debug_level_get(self.cli.node_id, mod, pointer(debug_level))
                if rc != self.cli.ifcs_ctypes.IFCS_SUCCESS:
                    log_err("Failed to read debug level for module " + self.get_module_name_from_module(mod))
                    return rc
                table.add_row([self.get_module_name_from_module(mod), self.get_debug_level_from_debug(debug_level.value)])
            table.print_table()
        else:
            try:
                rc = ifcs_debug_level_get(
                    self.cli.node_id, module_id, pointer(debug_level))
                if rc != self.cli.ifcs_ctypes.IFCS_SUCCESS:
                    log_err("Failed to read debug level for module: " + self.check_and_return_module_name(module))
                    return rc
            except BaseException:
                log_err("Failed to set debug level")
            table.add_row([self.get_module_name_from_module(module_id), self.get_debug_level_from_debug(debug_level.value)])
            table.print_table()
        return IFCS_SUCCESS

    def show_logfile(self, args):

        log("Log file is: " + self.logfile)
        return

    def show(self, args, filter_option):

        try:
            cmd = args.split()[2]
        except BaseException:
            log_err("Failed to get command")
            return IFCS_INVAL

        show_methods = {

            'log' : self.show_log,
            'debug' : self.show_debug,
            'logfile' : self.show_logfile
        }

        return show_methods[cmd](args)

    def display_logs(self, logs, module, level, pattern):
        display_logs = []
        if not module and not level:
            for line in logs:
                if pattern:
                    p = re.compile(pattern)
                    m = p.search(line)
                    if m:
                        display_logs.append(line)
                else:
                    display_logs.append(line)
        # apply module and level filter
        elif module and level:
            for line in logs:
                addline = False
                try:
                    pos = line.index(']')
                except BaseException:
                    continue
                for mm in range(len(module)):
                    if module[mm].upper() in line[:pos].rstrip("\n"):
                        for ll in range(len(level)):
                            if level[ll].upper() in line[:pos].rstrip("\n"):
                                if pattern:
                                    p = re.compile(pattern)
                                    m = p.search(line)
                                    if m:
                                        addline = True
                                else:
                                    addline = True
                if addline:
                    display_logs.append(line)
        # apply module filter
        elif module:
            for line in logs:
                addline = False
                try:
                    pos = line.index(']')
                except BaseException:
                    continue
                for mm in range(len(module)):
                    if module[mm].upper() in line[:pos].rstrip("\n"):
                        if pattern:
                            p = re.compile(pattern)
                            m = p.search(line)
                            if m:
                                addline = True
                        else:
                            addline = True
                if addline:
                    display_logs.append(line)
        # apply level filter
        elif level:
            for line in logs:
                addline = False
                try:
                    pos = line.index(']')
                except BaseException:
                    continue
                for ll in range(len(level)):
                    if level[ll].upper() in line[:pos].rstrip("\n"):
                        if pattern:
                            p = re.compile(pattern)
                            m = p.search(line)
                            if m:
                                addline = True
                        else:
                            addline = True
                if addline:
                    display_logs.append(line)

        for line in display_logs:
            log(line.rstrip("\n"))

    def help(self, args):
        log_dbg(1, "In log/trace help" + args)
        cmd = args.split()
        if cmd[1] == 'show':
            log("Usage: " + ' '.join(cmd[:3]) + " [ module <mod 1> .. <mod n> ] [ level <lvl 1> .. <lvl m> ] [ logfile <log pathname> ] [ pattern <regEx> ] ")
            log("       module    mod n = module name (node, intf, route, etc...)")
            log("       level     lvl n = module name (info, warn, error, etc...)")
            log("       logfile   log pathname = path to log file  (default is log file corresponding to current IFCS instance)")
            log("       pattern   regEx = regular expression of pattern to match in log")
        return

    def check_and_return_log_level(self, level):
        level_ = "IFCS_LOG_LEVEL_" + level.upper()
        try:
            level = getattr(ifcs_ctypes, level_)
        except Exception as e:
            raise e

        return level

    def check_and_return_module_name(self, module):
        module_ = "IFCS_MOD_" + module.upper()
        try:
            module_id = getattr(ifcs_ctypes, module_)
        except Exception as e:
            raise e

        return module_id

    def check_and_return_debug_level(self, level):
        level_ = "IFCS_DEBUG_LEVEL_" + level.upper()

        try:
            debug_level = getattr(ifcs_ctypes, level_)
        except Exception as e:
            raise e

        return debug_level

class Version(Command):
    def __init__(self, cli):
        self.sub_cmds = {
            'show': self.show,
        }
        self.cli = cli
        self.supported_operands = ["detail"]

    def __del__(self):
        return

    def show(self, args, filter_option):
        major = c_uint32(0)
        minor = c_uint32(0)
        patch = c_uint32(0)
        ifcs_ctypes.ifcs_get_version(pointer(major), pointer(minor), pointer(patch))
        branch = c_uint32(0)
        maint = c_uint32(0)
        debug = c_uint32(0)
        ifcs_ctypes.ifcs_get_version_extended(pointer(branch), pointer(maint), pointer(debug))
        ifcs_date = ifcs_ctypes.ifcs_u8_list_s()
        ifcs_date.count = 64
        ifcs_date.arr = (c_uint8 * 64)(0)
        ifcs_ctypes.ifcs_get_release_date(pointer(ifcs_date))
        date_list=[""] * ifcs_date.count
        for i in range(ifcs_date.count): date_list[i] = chr(ifcs_date.arr[i])
        ifcs_date.count = 64
        ifcs_ctypes.ifcs_get_build_date(pointer(ifcs_date))
        build_date_list=[""] * ifcs_date.count
        for i in range(ifcs_date.count): build_date_list[i] = chr(ifcs_date.arr[i])
        sd_rev = ifcs_ctypes.im_serdes_rev_info_t()
        ifcs_ctypes.im_node_serdes_fw_rev_get(0, pointer(sd_rev))
        table = PrintTable()
        table.add_row(['IFCS Version: ',"%d.%d.%d"%(major.value,minor.value,patch.value)])
        if branch.value != 0 or maint.value != 0 or debug.value != 0:
            # 0 - 64K are normal debug version
            if debug.value < (64 * 1024):
                table.add_row(['IFCS Extended Version: ',"%d.%d.%d"%(branch.value, maint.value, debug.value)])
            # 64K - 128K are Alpha releases
            elif debug.value < (128 * 1024):
                alpha_number = debug.value - (64 * 1024)
                table.add_row(['IFCS Extended Version: ',"%d.%d.Alpha%d"%(branch.value, maint.value, alpha_number)])
            else:
                table.add_row(['IFCS Extended Version: ',"%d.%d"%(branch.value, maint.value)])

        table.add_row(['Release Date: ',"".join(c for c in date_list)])
        table.add_row(['Build Date: ',"".join(c for c in build_date_list)])
        eth_rev_str = compat_bytesToStr(sd_rev.eth_rev_str)
        sbm_rev_str = compat_bytesToStr(sd_rev.sbm_rev_str)
        pcie_rev_str = compat_bytesToStr(sd_rev.pcie_rev_str)
        pmc_rev_str  = compat_bytesToStr(sd_rev.pmc_rev_str)
        if eth_rev_str != '':
            table.add_row(['Eth Serdes FW Rev: ', "%s"%(eth_rev_str)])
        if sbm_rev_str != '':
            table.add_row(['SBM Serdes FW Rev: ', "%s"%(sbm_rev_str)])
        if pcie_rev_str != '':
            table.add_row(['PCIe Serdes FW Rev: ', "%s"%(pcie_rev_str)])
        if pmc_rev_str != '':
            table.add_row(['PMC FW Rev: ', "%s"%(pmc_rev_str)])

        # Show relod log ONLY if last option is 'detail'
        isDetail = False
        arg_list = args.split()
        try:
            lastOption = arg_list[-1]
            if lastOption == 'detail':
                isDetail = True
        except BaseException:
            pass

        if isDetail == False:
            table.print_table()
            table.reset_table()
            return

        def reloadTypeChar(fromVer, toVer):
            returnChar = ''
            if toVer.ver_major > fromVer.ver_major:
                returnChar = 'U'
            elif toVer.ver_major < fromVer.ver_major:
                returnChar = 'D'
            else:
                if toVer.ver_minor > fromVer.ver_minor:
                    returnChar = 'U'
                elif toVer.ver_minor < fromVer.ver_minor:
                    returnChar = 'D'
                else:
                    if toVer.ver_patch > fromVer.ver_patch:
                        returnChar = 'U'
                    elif toVer.ver_patch < fromVer.ver_patch:
                        returnChar = 'D'
                    else:
                        if toVer.ver_branch > fromVer.ver_branch:
                            returnChar = 'U'
                        elif toVer.ver_branch < fromVer.ver_branch:
                            returnChar = 'D'
                        else:
                            if toVer.ver_maintenance > fromVer.ver_maintenance:
                                returnChar = 'U'
                            elif toVer.ver_maintenance < fromVer.ver_maintenance:
                                returnChar = 'D'
                            else:
                                if toVer.ver_debug > fromVer.ver_debug:
                                    returnChar = 'U'
                                elif toVer.ver_debug < fromVer.ver_debug:
                                    returnChar = 'D'
            return returnChar

        # Get cold boot time if it exists
        WB_coldboot_time = ifcs_ctypes.struct_timeval()
        WB_coldboot_time.tv_sec = 0         # Assume this data does not exist
        WB_coldboot_time.tv_usec = 0
        get_wb_coldboot_time(self.cli.node_id, pointer(WB_coldboot_time))       # Get from SDK

        # Retrieve reload data from SDK
        WB_reload_data = ifcs_ctypes.wb_reload_data_t()
        WB_reload_data.wb_nreloads = 0      # Assume this data does not exist
        get_wb_reload_log(self.cli.node_id, pointer(WB_reload_data))
        # Boolean flag for warmboot upgrade/downgrade cases
        upg_downg = False

        if WB_reload_data.wb_nreloads > 0:
            table.add_row(["Warm boots", str(WB_reload_data.wb_nreloads)])

            for index in range(ifcs_ctypes.WB_RECORD_COUNT):

                # If the timestamp is zero, its a blank entry, continue
                reloadLog = WB_reload_data.wb_reload[index]
                if reloadLog.wb_timestamp.tv_sec == 0:
                    continue

                fromVer = WB_reload_data.wb_reload[index].wb_from_version
                fromStr = "%d.%d.%d.%d.%d.%d" % (
                    fromVer.ver_major, fromVer.ver_minor, fromVer.ver_patch,
                    fromVer.ver_branch, fromVer.ver_maintenance, fromVer.ver_debug)

                toVer = WB_reload_data.wb_reload[index].wb_to_version
                toStr = "%d.%d.%d.%d.%d.%d" % (
                    toVer.ver_major, toVer.ver_minor, toVer.ver_patch,
                    toVer.ver_branch, toVer.ver_maintenance, toVer.ver_debug)

                # Key string
                keyStr = "Warm Boot %2d" % (reloadLog.wb_index + 1) # So that we don't show index starting from 0
                dt = datetime.datetime.fromtimestamp(reloadLog.wb_timestamp.tv_sec)
                rt = reloadTypeChar(fromVer, toVer)
                if rt != '':
                    upg_downg = True
                valueStr = "%2s  %20s -> %20s  at  %s" % (rt, fromStr, toStr, dt)
                table.add_row([keyStr, valueStr])

        # Add cold boot time, IF it exists
        if WB_coldboot_time.tv_sec != 0:
            dt = datetime.datetime.fromtimestamp(WB_coldboot_time.tv_sec)
            valueStr = "%s" % (dt)
            table.add_row(["Cold booted", dt])

         # Add Legend given 'U' or 'D' characters are introduced from a warmboot upgrade/downgrade
        if upg_downg != False:
            table.set_footer_size(1)
            table.add_row(["Legend", "U: Upgrade, D: Downgrade"])

        table.print_table()
        table.reset_table()

    def help(self, args):
        log("")
        table = PrintTable()
        table.add_row(["IFCS version Help", "Description"])
        table.add_row(["ifcs show version", "Shows IFCS version"])
        table.add_row([
            "ifcs show version detail",
            "Shows IFCS version, cold and warm boot details"
        ])
        table.set_justification("left")
        table.print_table()
        table.reset_table()
        log("")


# Class implements Ifcs related commands
class Ifcs(Command):
    def __init__(self, cli):
        self.cli = cli
        self.arg_list = []
        super(Ifcs, self).__init__()

        self.sub_cmds = {
            'show': self.show,
            'enable': self.enable,
            'disable': self.disable,
            'clear': self.clear,
            'set': self.set,
            'list': self.list,
            'config': self.config,
            'help': self.help,
            '?': self.help
        }
        self.custom_objs_map = {
            'counters': counters(self.cli),
            'version': Version(self.cli),
            'rate': rate(self.cli),
            'route': route(self.cli),
            'log': Log(self.cli),
            'debug': Log(self.cli),
            'logpat': Log(self.cli),
            'logfile': Log(self.cli),
        }
        self.ifcs_all_objs = IfcsAll(self.cli)
        self.show_ifcs_names = self.ifcs_all_objs.get_ifcs_obj_names() + \
            compat_listkeys(self.custom_objs_map)
        self.clear_ifcs_names = self.show_ifcs_names
        self.set_ifcs_names = self.show_ifcs_names
        self.list_ifcs_names = self.show_ifcs_names
        self.enable_ifcs_names = self.disable_ifcs_names = ['counters']

    def __del__(self):
        return

    def run_cmd(self, args):
        log_dbg(1, "In Ifcs run")
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        try:
            rc = self.sub_cmds[self.arg_list[1]](args)
            return rc
        except KeyError:
            log_dbg(
                1, "KeyError in ifcs [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
            return ifcs_ctypes.IFCS_INVAL
        except ValueError:
            log_dbg(
                1, "ValueError in ifcs [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
            return ifcs_ctypes.IFCS_INVAL
        except BaseException:
            log_dbg(
                1, "OtherError in ifcs [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            if len(self.arg_list) > 3:
                action_str = ""
                base_err_str = "Invalid command: Cannot"
                if 'set' in self.arg_list:
                    action_str = "set"
                else:
                    action_str = "show"
                attribute_str = self.arg_list[3]
                obj_str = self.arg_list[2]
                err_str = base_err_str + " " + action_str + " " + attribute_str + " for " + obj_str
                log_err(err_str)
            else:
                self.help(args)
            return ifcs_ctypes.IFCS_INVAL

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            ''' display possible cmd options'''
            return compat_listkeys(self.sub_cmds)
        elif cmd == text:
            ''' display possible cmd options from text'''
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]
        elif cmd == 'set' and remline and remline == 'log':
            return self.custom_objs_map['log'].levels
        elif cmd == 'show' and remline and remline == 'log':
            return ['level']
        elif remline and remline.split()[0] in self.show_ifcs_names:
            ''' display possible options of each object'''
            try:
                obj = self.getIfcsType(remline.split()[0])
                return [
                    j for j in obj.supported_operands if j.startswith(text)]
            except BaseException:
                return None
        else:
            ''' display possible objects for each command '''
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def complete_show(self, text):
        if text.upper() == text:
            return [i.lower()
                    for i in self.show_ifcs_names if i.upper().startswith(text)]
        else:
            return [i.lower()
                    for i in self.show_ifcs_names if i.lower().startswith(text)]

    def complete_list(self, text):
        if text.upper() == text:
            return [i.lower()
                    for i in self.list_ifcs_names if i.upper().startswith(text)]
        else:
            return [i.lower()
                    for i in self.list_ifcs_names if i.lower().startswith(text)]

    def complete_clear(self, text):
        if text.upper() == text:
            return [i.lower()
                    for i in self.clear_ifcs_names if i.upper().startswith(text)]
        else:
            return [i.lower()
                    for i in self.clear_ifcs_names if i.lower().startswith(text)]

    def complete_set(self, text):
        if text.upper() == text:
            return [i.lower()
                    for i in self.set_ifcs_names if i.upper().startswith(text)]
        else:
            return [i.lower()
                    for i in self.set_ifcs_names if i.lower().startswith(text)]

    def complete_enable(self, text):
        if text.upper() == text:
            return [i.lower()
                    for i in self.enable_ifcs_names if i.upper().startswith(text)]
        else:
            return [i.lower()
                    for i in self.enable_ifcs_names if i.lower().startswith(text)]

    def complete_disable(self, text):
        if text.upper() == text:
            return [i.lower()
                    for i in self.disable_ifcs_names if i.upper().startswith(text)]
        else:
            return [i.lower()
                    for i in self.disable_ifcs_names if i.lower().startswith(text)]

    def getIfcsType(self, ifcs_obj_name):
        '''Get IFCS Type Object'''
        log_dbg(1, "In getIfcsType ifcs_obj_name " + ifcs_obj_name)

        '''First try in ifcs_all objs, then try in custom objects'''
        if ifcs_obj_name == "all":
            return self.ifcs_all_objs

        ifcs_objs = self.ifcs_all_objs.get_ifcs_obj_from_name(ifcs_obj_name)
        if ifcs_objs is None:
            try:
                ifcs_objs = self.custom_objs_map[ifcs_obj_name]
            except BaseException:
                return None

        return ifcs_objs

    # Disable command
    def disable(self, args):
        log_dbg(1, "In ifcs disable with args: " + args)
        ifcs_obj_name, args = self.validate_get_ifcs_info_from_args(args)

        log_dbg(1, " ifcs_obj: " + ifcs_obj_name)
        ifcs_obj = self.getIfcsType(ifcs_obj_name)
        if ifcs_obj is None:
            log_err('Cannot find IFCS Object: ' + ifcs_obj_name)
            raise BaseException('Cannot get IFCS Object {}'.format(ifcs_obj_name))

        log_dbg(1, " args: " + args)
        rc = ifcs_obj.disable(args)
        return ifcs_ctypes.IFCS_SUCCESS

    # Enable command
    def enable(self, args):
        log_dbg(1, "In ifcs enable with args: " + args)
        ifcs_obj_name, args = self.validate_get_ifcs_info_from_args(args)

        log_dbg(1, " ifcs_obj: " + ifcs_obj_name)
        ifcs_obj = self.getIfcsType(ifcs_obj_name)
        if ifcs_obj is None:
            log_err('Cannot find IFCS Object: ' + ifcs_obj_name)
            raise BaseException('Cannot get IFCS Object {}'.format(ifcs_obj_name))

        log_dbg(1, " args: " + args)
        rc = ifcs_obj.enable(args)
        return ifcs_ctypes.IFCS_SUCCESS

    # Clear command
    def clear(self, args):
        log_dbg(1, "In ifcs clear with args: " + args)

        ifcs_obj_name, args = self.validate_get_ifcs_info_from_args(args)

        log_dbg(1, " ifcs_obj: " + ifcs_obj_name)
        ifcs_obj = self.getIfcsType(ifcs_obj_name)
        if ifcs_obj is None:
            log_err('Cannot find IFCS Object: ' + ifcs_obj_name)
            raise BaseException('Cannot get IFCS Object {}'.format(ifcs_obj_name))

        log_dbg(1, " args: " + args)
        rc = ifcs_obj.clear(args)
        return ifcs_ctypes.IFCS_SUCCESS

    # SHOW command
    def show(self, args):
        log_dbg(1, "In Ifcs Show with args: " + args)
        filter_option = ''

        ifcs_obj_name, args = self.validate_get_ifcs_info_from_args(args)

        log_dbg(1, " ifcs_obj: " + ifcs_obj_name)
        ifcs_obj = self.getIfcsType(ifcs_obj_name)
        if ifcs_obj is None:
            log_err('Cannot find IFCS Object: ' + ifcs_obj_name)
            raise BaseException('Cannot get IFCS Object {}'.format(ifcs_obj_name))

        filter_option = {}
        opts = args.split()
        if 'filter' in opts:
            index = opts.index('filter')
            if index + 1 < len(opts):
                filter_option['filter'] = opts[index + 1]
            del opts[index:index+2]

        if 'sort' in opts:
            index = opts.index('sort')
            if index + 1 < len(opts):
                filter_option['sort'] = opts[index + 1].rsplit()[0]
            del opts[index:index+2]
        args = " ".join(opts)

        log_dbg(1, " args: " + args)
        rc = ifcs_obj.show(args, filter_option)
        return ifcs_ctypes.IFCS_SUCCESS

    # SET command
    def set(self, args):
        ''' sets an attribute that an IFCS object supports '''
        log_dbg(1, "In Ifcs set with args: " + args)

        ifcs_obj_name, args = self.validate_get_ifcs_info_from_args(args)

        log_dbg(1, " ifcs_obj: " + ifcs_obj_name)
        ifcs_obj = self.getIfcsType(ifcs_obj_name)
        if ifcs_obj is None:
            log_err('Cannot find IFCS Object: ' + ifcs_obj_name)
            raise BaseException('Cannot get IFCS Object {}'.format(ifcs_obj_name))

        log_dbg(1, " args: " + args)
        rc = ifcs_obj.set(args)
        return rc

    # ------------
    # LIST command
    # ------------
    def list(self, args):
        ''' list attributes that an IFCS object supports '''
        log_dbg(1, "In Ifcs list with args: " + args)

        # get ifcs_obj_name from args after validating
        ifcs_obj_name, args = self.validate_get_ifcs_info_from_args(args)

        # Get IFCS Type
        log_dbg(1, " ifcs_obj: " + ifcs_obj_name)
        ifcs_obj = self.getIfcsType(ifcs_obj_name)
        if ifcs_obj is None:
            log_err('Cannot find IFCS Object: ' + ifcs_obj_name)
            raise BaseException('Cannot get IFCS Object {}'.format(ifcs_obj_name))

        # Perform show  Op
        log_dbg(1, " args: " + args)
        rc = ifcs_obj.list(args)
        return ifcs_ctypes.IFCS_SUCCESS

    def config(self, args):
        ''' Apply the given IFCS config '''
        log_dbg(1, "In Ifcs config with args: " + args)

        ifcs_config = IfcsConfig(self.cli)
        # Invoke the config object
        return ifcs_config.run_cmd(args.split()[2:])

    def show_help_menu(self, args):
        ''' show help menu '''
        log("\n")
        table = PrintTable()
        table.add_row(['IFCS Show Help', 'Description'])
        table.add_row(['attrs', 'Shows all set attributes on <ifcsobj>'])
        table.add_row(['stats', 'Shows all statistics on <ifcsobj>'])
        table.add_row(
            ['all', 'Shows all set attributes on all <ifcsobj> of this type'])
        table.add_row(
            ['brief', 'Shows a brief set of attributes on <ifcsobj>'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        show_help_string = """
Usage::
    Type ifcs show <tab> to see ifcs objects that support show command.
    Type ifcs show ? to see ifcs show help.
"""
        log(show_help_string)
        return

    def clear_help_menu(self, args):
        ''' clear help menu '''

        table = PrintTable()
        table.add_row(['IFCS Clear Help', 'Description'])
        table.add_row(['stats', 'Clears all statistics on <ifcsobj>'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        clear_help_string = """
Usage::
    Type "ifcs clear <ifcs object> stats <ifcs object handle>"

    Example:
        ifcs clear sysport stats <sysport handle>
"""
        log(clear_help_string)
        return

    def set_help_menu(self, args):
        ''' set help menu '''

        log("\n")
        table = PrintTable()
        table.add_row(['IFCS Set Help', 'Description'])
        table.add_row(['Set', 'Set an attribute on <ifcsobj>'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        set_help_string = """
Usage::
    Type "ifcs set <ifcsobj> handle <attribute> value"

    Example:
        ifcs set devport 1 adminstate 0
"""
        log(set_help_string)
        return

    def list_help_menu(self, args):
        ''' list help menu '''

        log("\n")
        table = PrintTable()
        table.add_row(['IFCS list Help', 'Description'])
        table.add_row(['List', 'List all possible attributes on <ifcsobj>'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        list_help_string = """
Usage::
    Type "ifcs list <ifcsobj>"

    Example:
        ifcs list devport
"""
        log(list_help_string)
        return

    def config_help_menu(self, args):
        ''' list help menu '''

        log("\n")
        table = PrintTable()
        table.add_row(['IFCS config Help', 'Description'])
        table.add_row(['Config', 'Execute crud operations from the user provided yaml file'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        config_help_string = """
Usage::
    Type "ifcs config <sample.yaml>"

    Example:
        ifcs config sample.yaml
"""
        log(config_help_string)
        return

    def ifcs_help_menu(self, args):
        ''' ifcs help menu '''

        log("\n")
        table = PrintTable()
        table.add_row(['IFCS Command Help', ' Description'])
        table.add_row(['show', 'Show all the set attributes on ifcs object.'])
        table.add_row(['set', 'Set an attribute on ifcs object.'])
        table.add_row(
            ['clear', 'Clear all statistics on a particular ifcs object.'])
        table.add_row(['list', 'List all attributes on ifcs object.'])
        table.add_row(['config', 'Run crud operations from user provided config yaml'])
        table.add_row(['test', 'Run test commands that this object supports.'])
        table.add_row(['help', 'Show this help menu.'])
        table.add_row(['?', 'Show this help menu.'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        ifcs_help_string = """
Usage::

   Type "ifcs command" followed by <tab> to see ifcs objects that support the command.
"""
        log(ifcs_help_string)

        return ifcs_ctypes.IFCS_SUCCESS

    def help(self, args):
        help_menu = {
            'show': self.show_help_menu,
            'set': self.set_help_menu,
            'clear': self.clear_help_menu,
            'list': self.list_help_menu,
            'config': self.config_help_menu,
            'help': self.ifcs_help_menu,
            '?': self.ifcs_help_menu
        }

        self.arg_list = args.split()
        try:
            obj = self.getIfcsType(self.arg_list[2])
            obj.help(args)
        except BaseException:
            try:
                help_menu[self.arg_list[1]](args)
            except BaseException:
                self.ifcs_help_menu(args)

    #----------------------------
    # Ifcs class helper functions
    #----------------------------
    def check_for_api_class_handle(self, arg):
        try:
            mod = cli_ifcs_mod_map[ifcs_ctypes.IFCS_HANDLE_MODULE(int(arg,0))]
        except:
            return None, None

        try:
           obj = cli_ifcs_obj_map[mod][ifcs_ctypes.IFCS_HANDLE_OBJECT(int(arg,0)) - 1]
        except:
           return None, None

        return obj.lower(), str(arg)

    def validate_get_ifcs_info_from_args(self, args):
        log_dbg(1, "In validate_get_ifcs_info_from_args :" + args)

        arg_list = args.split()
        ifcs_cmd_name = arg_list[1]
        ifcs_obj_name = arg_list[2]

        if ifcs_cmd_name == "clear" and ifcs_obj_name == "stats":
            if len(arg_list) > 3:
                log_err("Unsupported command format")
                self.help(args)
                return ifcs_ctypes.IFCS_UNSUPPORTED
            return "all", args

        if not ifcs_obj_name in self.show_ifcs_names:
            ifcs_obj_name, handle = self.check_for_api_class_handle(ifcs_obj_name)
            if ifcs_obj_name == None:
                log_err("Unsupported Ifcs command class")
                raise KeyError

            args = ' '.join(arg_list[:-1]) + ' ' + ifcs_obj_name + ' ' +str(handle)
            arg_list = args.split()
            ifcs_cmd_name = arg_list[1]
            ifcs_obj_name = arg_list[2]

        log_dbg(1, "ifcs_cmd " + ifcs_cmd_name)
        log_dbg(1, "ifcs_obj " + ifcs_obj_name)
        if ifcs_cmd_name == 'show':
            if ifcs_obj_name not in self.show_ifcs_names:
                log_err("Unsupported Ifcs command class")
                raise KeyError
        elif ifcs_cmd_name == 'set':
            if ifcs_obj_name not in self.set_ifcs_names:
                log_err("Unsupported Ifcs command class")
                raise KeyError
        elif ifcs_cmd_name == 'list':
            if ifcs_obj_name not in self.list_ifcs_names:
                log_err("Unsupported Ifcs command class")
                raise KeyError
        elif ifcs_cmd_name == 'clear':
            if ifcs_obj_name not in self.clear_ifcs_names:
                log_err("Unsupported Ifcs command class")
                raise KeyError
        elif ifcs_cmd_name == 'enable' or ifcs_cmd_name == 'disable':
            if ifcs_obj_name not in self.enable_ifcs_names:
                log_err("Unsupported Ifcs command class")
                raise KeyError

        return ifcs_obj_name, args

# Class implements IM related commands
class Im(Command):
    def __init__(self, cli):
        self.cli = cli
        self.arg_list = []
        super(Im, self).__init__()

        self.sub_cmds = {
            'show': self.show,
            'list': self.list,
            'help': self.help,
            '?': self.help
        }
        self.im_all_objs = ImAll(self.cli)
        self.show_im_names = self.im_all_objs.get_im_obj_names()
        self.list_im_names = self.show_im_names

    def __del__(self):
        return

    def help(self, args):
        help_menu = {
            'show': self.show_help_menu,
            'list': self.list_help_menu,
            'help': self.im_help_menu,
            '?': self.im_help_menu
        }

        self.arg_list = args.split()
        try:
            obj = self.getImType(self.arg_list[2])
            obj.help(args)
        except BaseException:
            try:
                help_menu[self.arg_list[1]](args)
            except BaseException:
                self.im_help_menu(args)

    def run_cmd(self, args):
        self.arg_list = shlex.split(args)
        log_dbg(1, "IM context: " + str(self.arg_list))
        try:
            rc = self.sub_cmds[self.arg_list[1]](args)
            return rc
        except KeyError:
            log_dbg(1, "KeyError in im [{}] run_cmd: {}".format(args, sys.exc_info()))
            self.help(args)
            return ifcs_ctypes.IFCS_INVAL
        except ValueError:
            log_dbg(1, "ValueError in im [{}] run_cmd: {}".format(args, sys.exc_info()))
            self.help(args)
            return ifcs_ctypes.IFCS_INVAL
        except BaseException:
            log_dbg(1, "OtherError in im [{}] run_cmd: {}".format(args, sys.exc_info()))
            if len(self.arg_list) > 3:
                action_str = ""
                base_err_str = "Invalid IM command: Cannot"
                if 'set' in self.arg_list:
                    action_str = "set"
                else:
                    action_str = "show"
                attribute_str = self.arg_list[3]
                obj_str = self.arg_list[2]
                err_str = base_err_str + " " + action_str + " " + attribute_str + " for " + obj_str
                log_err(err_str)
            else:
                self.help(args)
            return ifcs_ctypes.IFCS_INVAL

    def subcomplete(self, text, remline):
 
        return None

    def complete_show(self, text):
        if text.upper() == text:
            return [i.lower()
                    for i in self.show_im_names if i.upper().startswith(text)]
        else:
            return [i.lower()
                    for i in self.show_im_names if i.lower().startswith(text)]

    def complete_list(self, text):
        if text.upper() == text:
            return [i.lower()
                    for i in self.list_im_names if i.upper().startswith(text)]
        else:
            return [i.lower()
                    for i in self.list_im_names if i.lower().startswith(text)]

    def getImType(self, im_obj_name):
        #Get IM Type Object
        log_dbg(1, "In getImType im_obj_name " + im_obj_name)
        # Try in im_all objs
        if im_obj_name == "all":
            return self.im_all_objs

        im_objs = self.im_all_objs.get_im_obj_from_name(im_obj_name)

        return im_objs

    def show(self, args):
        log_dbg(1, "In Im Show with args: " + args)
        filter_option = ''

        im_obj_name, args = self.validate_get_im_info_from_args(args)

        log_dbg(1, " im_obj: " + im_obj_name)
        im_obj = self.getImType(im_obj_name)
        if im_obj is None:
            log_err('Cannot find IM Object: ' + im_obj_name)
            raise BaseException('Cannot get IM Object {}'.format(im_obj_name))

        filter_option = {}
        if 'filter' in args:
            filter_option['filter'] = args.split('filter')[1]
            args = args.split('filter')[0]

        if 'sort' in args:
            filter_option['sort'] = args.split('sort')[1].rsplit()[0]
            args = args.split('sort')[0]

        log_dbg(1, "IM args: " + args)
        rc = im_obj.show(args, filter_option)
        return ifcs_ctypes.IFCS_SUCCESS

    def list(self, args):
        # list attributes that an IM object supports
        log_dbg(1, "In IM list with args: " + args)

        # get im_obj_name from args after validating
        im_obj_name, args = self.validate_get_im_info_from_args(args)

        # Get IM Type
        log_dbg(1, " im_obj: " + im_obj_name)
        im_obj = self.getImType(im_obj_name)
        if im_obj is None:
            log_err('Cannot find IM Object: ' + im_obj_name)
            raise BaseException('Cannot get IM Object {}'.format(im_obj_name))

        # Perform show  Op
        log_dbg(1, "IM args: " + args)
        rc = im_obj.list(args)
        return ifcs_ctypes.IFCS_SUCCESS

    def show_help_menu(self, args):
        ''' show help menu '''
        log("\n")
        table = PrintTable()
        table.add_row(['IM Show Help', 'Description'])
        table.add_row(['attrs', 'Shows attributes of <imobj>'])
        table.add_row(['all', 'Shows attributes of all <imobj> instances of this type'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        show_help_string = """
Usage::
    Type im show <tab> to see im objects that support show command.
    Type im show ? to see im show help.
"""
        log(show_help_string)
        return

    def list_help_menu(self, args):
        ''' list help menu '''

        log("\n")
        table = PrintTable()
        table.add_row(['IM list Help', 'Description'])
        table.add_row(['List', 'List all possible attributes on <imobj>'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        list_help_string = """
Usage::
    Type "im list <imobj>"

    Example:
        im list devport
"""
        log(list_help_string)
        return

    def im_help_menu(self, args):
        ''' im help menu '''

        log("\n")
        table = PrintTable()
        table.add_row(['IM Command Help', ' Description'])
        table.add_row(['show', 'Show all the set attributes on im object.'])
        table.add_row(['list', 'List all attributes on im object.'])
        table.add_row(['help', 'Show this help menu.'])
        table.add_row(['?', 'Show this help menu.'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        im_help_string = """
Usage::

   Type "im command" followed by <tab> to see im objects that support the command.
"""
        log(im_help_string)

        return ifcs_ctypes.IFCS_SUCCESS

    def check_for_api_class_handle(self, arg):
        try:
            mod = cli_ifcs_mod_map[ifcs_ctypes.IFCS_HANDLE_MODULE(int(arg,0))]
        except:
            return None, None

        try:
           obj = cli_ifcs_obj_map[mod][ifcs_ctypes.IFCS_HANDLE_OBJECT(int(arg,0)) - 1]
        except:
           return None, None

        return obj.lower(), str(arg)

    def validate_get_im_info_from_args(self, args):
        log_dbg(1, "In validate_get_im_info_from_args :" + args)

        arg_list = args.split()
        im_cmd_name = arg_list[1]
        im_obj_name = arg_list[2]

        if not im_obj_name in self.show_im_names:
            im_obj_name, handle = self.check_for_api_class_handle(im_obj_name)
            if im_obj_name == None:
                log_err("Unsupported Im command class")
                raise KeyError

            args = ' '.join(arg_list[:-1]) + ' ' + im_obj_name + ' ' +str(handle)
            arg_list = args.split()
            im_cmd_name = arg_list[1]
            im_obj_name = arg_list[2]

        log_dbg(1, "im_cmd " + im_cmd_name)
        log_dbg(1, "im_obj " + im_obj_name)
        if im_cmd_name == 'show':
            if im_obj_name not in self.show_im_names:
                log_err("Unsupported Im command class")
                raise KeyError
        elif im_cmd_name == 'list':
            if im_obj_name not in self.list_im_names:
                log_err("Unsupported Im command class")
                raise KeyError

        return im_obj_name, args
