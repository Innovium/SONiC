/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_l2mc_group_util.h
 * @brief ISAI Util Include file for L2MC_GROUP module
 */


#ifndef __IFCS_SAI_L2MC_GROUP_UTIL_H__
#define __IFCS_SAI_L2MC_GROUP_UTIL_H__

#include "util/ifcs_sai_l2mc_group_util_dep.h"

/*
 * @brief Converts SAI L2MCG object ID to MDG IFCS handle
 *
 * @param [in]  sai_object_id - SAI Object ID
 * @param [out] ifcs_handle_p - Pointer to IFCS MDG handle
 * @return sai_status_t
 */
sai_status_t
isai_im_l2mc_group_stoi_xlate_oid(
    sai_object_id_t sai_object_id,
    ifcs_handle_t   *ifcs_handle_p);

/*
 * @brief Update mc_destination with new local destination
 *        Filter by tunnel nexthop handle
 *        API usecase - when the underlay sys port change is triggered
 *                      by unicast nexthop change or ecmp member remove
 * @param [in]  node_id                -  node_id
 * @param [in]  nh_hdl                 -  Nexthop handle
 * @param [in]  old_port_hdl           -  Old underlay sys port/Lag handle
 * @param [in]  new_port_hdl           -  New underlay sys port/Lag handle
 * @return sai_status_t
 */
sai_status_t
isai_im_l2mc_group_process_tunnel_underlay_port_update(ifcs_node_id_t node_id,
                                              ifcs_handle_t  nh_hdl,
                                              ifcs_handle_t  old_port_hdl,
                                              ifcs_handle_t  new_port_hdl);
/**
 * @brief Get Mc Dest info
 *
 * @param [in]    node_id          - IFCS Node Id
 * @param [in]    mcdest_hdl       - IFCS MCDEST handle
 * @param [out]   local_dst_hdl_p  - Pointer Local destination handle
 * @param [out]   nexthop_hdl_p    - Pointer to Nexthop handle
 * @return sai_status_t
 */
sai_status_t
isai_im_l2mc_group_get_mcdest_info(ifcs_node_id_t node_id,
                           ifcs_handle_t  mcdest_hdl,
                           ifcs_handle_t  *local_dst_hdl_p,
                           ifcs_handle_t  *nexthop_hdl_p);
/*
 * @brief Converts MDG IFCS handle to SAI L2MCG object ID
 *
 * @param [in] node_id       - IFCS Node Id
 * @param [in] mdg_handle - IFCS MDG handle
 * @param [out]  l2mcg_oid_p - Pointer to L2MCG SAI Object ID
 * @return sai_status_t
 */
sai_status_t
isai_im_l2mc_group_itos_xlate_oid(
    ifcs_node_id_t  node_id,
    ifcs_handle_t   mdg_handle,
    sai_object_id_t *l2mcg_oid_p);

/*
 * @brief Get the members count of l2mcg
 *
 * @param [in] node_id       - IFCS Node Id
 * @param [in] mdg_handle    - IFCS MDG handle
 * @param [out]  unit32_t    - Pointer to store the count
 * @return sai_status_t
 */
sai_status_t
isai_im_l2mc_group_get_member_count(
    ifcs_node_id_t   node_id,
    sai_object_id_t  l2mcg_oid,
    uint32_t         *member_cout);
#endif /* __IFCS_SAI_L2MC_GROUP_UTIL_H__ */
