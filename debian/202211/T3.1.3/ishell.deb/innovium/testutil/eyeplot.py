# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import os
import math
from utils.compat_util import *

try:
    import numpy as np
    from scipy import special
    from scipy.optimize import minimize
    import scipy.stats
    numpyScipyAvailable = True
except:
    numpyScipyAvailable = False

def rescale(data, scale, offset=0):
    return [[(p - offset) * scale
             for p in line]
            for line in data]

def clamp(data, data_min, data_max):
    return [[data_min if p < data_min
             else data_max if p > data_max
             else p
             for p in line]
            for line in data]

def minus_log(data):
    return [[-math.log10(p)
             for p in line]
            for line in data]

def print_ascii_eye_plot(data, show_scale, color, invert, columns):
    '''
    data:  list of lists, with where each point is ber: 0..1.  Will plot -log_10(data)
    show_scale: flag to indicate that scale should be shown at bottom
    color: try to use grayscale terminal colors
    invert: invert color scale
    columns: number of text columns to use
    '''
    min_ber = 1e-15   # This value sets low end of scale.
    min_mlog_ber = -math.log10(min_ber)
    mlog_data = minus_log(clamp(data, min_ber, 1))

    if color:
        def color_block(val):
            return '\x1b[48;5;%dm ' % val
        reset_color_str = '\x1b[0m'
        # grayscale colors (Grey3, Grey7...) are 232..255.  Grey0 is 16, Grey100 is 231
        chrlist = [color_block(i) for i in [16] + compat_listrange(232,256) + [231]]
    else:
        chrlist=[' ', '.', ',', ':', '!', 'i', '+', 'x', 'X', 'Y', 'Q', 'Z', 'M', '8', '%', '@']
        reset_color_str = ''

    if not invert:
        chrlist.reverse()

    if columns is None:
        columns = 0
        try:
            # When cli backend runs as demon, there is no tty, so account for this
            _, col_str = os.popen('stty size', 'r').read().split()
            columns = int(col_str)
        except:
            pass
        if columns == 0:
            columns = 200

    pix_width = int(columns / (len(mlog_data[0]) + 2))
    if pix_width < 1:
        pix_width = 1

    for data_line in mlog_data:
        chr_line = [chrlist[int(px * (len(chrlist)-1.0) / min_mlog_ber)] * pix_width for px in data_line]
        log("".join(chr_line), reset_color_str)

    if show_scale:
        scale_width = 64
        full_line = [int(i * min_mlog_ber / scale_width) for i in range(scale_width)]
        chr_line = [chrlist[int(px * (len(chrlist)-1.0) / min_mlog_ber)] for px in full_line]
        log(reset_color_str)
        log("")
        log("Scale:")
        log_no_newline("    ", "".join(chr_line))
        log(reset_color_str)
        xLabels = [(val, '1e-%d' % val) for val in range(2,int(min_mlog_ber),2)]
        xLabelTickLine = list(' ') * (4 + len(chr_line))
        xLabelLine = list(' ') * (4 + len(chr_line))
        for xLabelVal, xLabelStr in xLabels:
            tickOffset = 4 + int(xLabelVal * scale_width / min_mlog_ber)
            xLabelTickLine[tickOffset] = '|'
            labelWidth = len(xLabelStr)
            deltaOffsetForLabel = labelWidth // 2
            lblOffset = tickOffset - deltaOffsetForLabel
            xLabelLine[lblOffset:lblOffset+labelWidth] = xLabelStr
        log(''.join(xLabelTickLine))
        log(''.join(xLabelLine))


def ascii_bathtub(x_vals, errs, samples, yMin, maxExtrap, columns, eye_ranges=[[0,None,-1]], qscale=False):
    outlines = []
    yMax = 1
    # plotYMax/plotYMin ?
    if qscale:
        plotYMax = special.erfcinv(yMin)
        plotYMin = 0
    else:
        plotYMax = 0
        plotYMin = math.log10(yMin)

    if columns is None:
        _, col_str = os.popen('stty size', 'r').read().split()
        columns = int(col_str)
        if columns == 0:
            columns = 200
    columns = int(columns) - 9  # leave space for labels

    if len(x_vals) <= columns:
        ptsPerColumn = 1
    else:
        ptsPerColumn = (len(x_vals) + columns - 1) // columns
    columns = (len(x_vals) + ptsPerColumn - 1) // ptsPerColumn

    if qscale:
        rows = 40
    else:
        rows = int((plotYMax - plotYMin) * 4) + 1

    def x_to_px(x):
        return int(interp(x, x_vals[0], x_vals[-1], 0, columns-1) + .5)

    def px_to_x(px):
        return interp(px, 0, columns-1, x_vals[0], x_vals[-1])

    def y_to_py(y):
        if qscale:
            if y > 1e-20:
                q = special.erfcinv(y)
                return int(round(interp(q, plotYMin, plotYMax, rows-1, 0)))
            else:
                return plot
        else:
            return int(round(interp(math.log10(y), plotYMin, plotYMax, rows-1, 0)))

    def py_to_y(py):
        s = interp(py, rows-1, 0, plotYMin, plotYMax)
        if qscale:
            return special.erfc(s)
        else:
            return 10**s

    # canvas[y][x] is our set of pixel values.
    #   note: [[' '] * columns] * rows would make each row reference the same list
    canvas = [[' '] * columns for i in range(rows)]

    px_vals = compat_listrange(len(x_vals)) # x axis in pixels
    for leftmost, ctr, rightmost in eye_ranges:
        if ctr is None:
            width = len(x_vals[leftmost:rightmost])
            ctr = leftmost + (width//2)
        first_extrap_row = y_to_py(maxExtrap[1])

        # "e" values: extrapolated
        if qscale:
            epys = compat_listrange(0, first_extrap_row)
        else:
            epys = compat_listrange(first_extrap_row, rows)
        eys = [py_to_y(py) for py in epys]
        left_exs = bathtub_extrapolate_left(x_vals[leftmost:ctr], errs[leftmost:ctr], samples[leftmost:ctr], maxExtrap, eys)
        right_exs = bathtub_extrapolate_right(x_vals[ctr:rightmost], errs[ctr:rightmost], samples[ctr:rightmost], maxExtrap, eys)

        for left_x, right_x, py in zip(left_exs, right_exs, epys):
            if left_x > right_x:
                break
            if left_x > x_vals[0] and left_x < x_vals[-1]:
                canvas[py][x_to_px(left_x)] = ':'
            if right_x > x_vals[0] and right_x < x_vals[-1]:
                canvas[py][x_to_px(right_x)] = ':'

    # overlay the actual data points so they're on top of any extrapolated values
    for (x, e, s) in zip(x_vals, errs, samples):
        y = 1.0 * e / s
        if y >= yMin and y <= 1:
            canvas[y_to_py(y)][x_to_px(x)] = '*'

    pltStrs = [''.join(line) for line in canvas]

    # add y labels
    baseYLabel = '       |'
    yLabelByLine = [baseYLabel] * len(pltStrs)
    if qscale:
        for q in range(int(plotYMin), int(plotYMax)+1):
            py = y_to_py(special.erfc(q))
            yLabelByLine[py] = ('%5.2f' % q) + " -┼"
    else:
        for logY in range(int(plotYMin), plotYMax+1):
            py = y_to_py(10**logY)
            yLabelByLine[py] = ('1e%-3d' % logY) + " -┼"

    for l,s in zip(yLabelByLine, pltStrs):
        outlines += [l + s]

    # build up the x Label lines
    yLabelLen = len(baseYLabel)
    xLabelTickLine = list(' ') * (yLabelLen-1) + ['╰'] + list('-') * columns + list(' ')
    xLabelLine = list(' ') * (yLabelLen + columns)

    for xFrac in [0, .25, .5, .75, 1]:
        x = x_vals[-1] * xFrac + x_vals[0] * (1-xFrac)
        tickOffset = yLabelLen + x_to_px(x)
        xLabelTickLine[tickOffset] = '┼'
        label = '%.2f' % x
        labelWidth = len(label)
        deltaOffsetForLabel = labelWidth // 2
        lblOffset = tickOffset - deltaOffsetForLabel
        xLabelLine[lblOffset:lblOffset+labelWidth] = label
    outlines += [''.join(xLabelTickLine)]
    outlines += [''.join(xLabelLine)]
    return outlines

def print_ascii_bathtub(x_vals, errs, samples, yMin, maxExtrap, columns, eye_ranges=[[0,None,-1]]):
    for o in ascii_bathtub(x_vals, errs, samples, yMin, maxExtrap, columns, eye_ranges):
        log(o)

def bathtub_widths(x_vals, errs, samples, maxExtrap, ber_levels, eye_ranges=[[0,None,-1]]):
    all_widths = []
    for leftmost, ctr, rightmost in eye_ranges:
        if ctr is None:
            width = len(x_vals[leftmost:rightmost])
            ctr = leftmost + (width//2)
        left_exs = bathtub_extrapolate_left(x_vals[leftmost:ctr], errs[leftmost:ctr], samples[leftmost:ctr], maxExtrap, ber_levels)
        right_exs = bathtub_extrapolate_right(x_vals[ctr:rightmost], errs[ctr:rightmost], samples[ctr:rightmost], maxExtrap, ber_levels)

        widths = []
        for left_x, right_x, py in zip(left_exs, right_exs, ber_levels):
            widths += [max(right_x - left_x, 0)]
        all_widths += [widths]
    return all_widths

def print_size_table(bers, labels, values):
    columns = []
    col = ['BER'] + ['%.0e' % b for b in bers]
    width = 2 + max([len(x) for x in col])
    ccol = [x.center(width) for x in col]
    columns += [ccol]

    for l,v in zip(labels, values):
        col = [l] + ["%6.02f" % x for x in v]
        width = 2 + max([len(x) for x in col])
        ccol = [x.center(width) for x in col]
        columns += [ccol]

    rows = zip(*columns)
    for r in rows:
        log(':'.join(r))

# Extrapolation of BER values, using Dual-Dirac model (so Gaussian tails of timing/voltage errors)

# Get mean/stddev of Gaussian tail by fitting a line to the Q-scale (inverse erfc) values
# Note: this filters out 0-values of errs/BER, since those are at infinity
def linfit_qscale(x, errs, samples):
    bers = 1.0 * errs / samples
    idxs = (bers>0)
    q = special.erfcinv(2*bers[idxs])
    # fit x as a function of q, so intercept is x intercept, slope is x scaling (sqrt(2)*sigma)
    slope, intercept, r_value, p_value, std_err = scipy.stats.linregress(q, x[idxs])
    return slope, intercept


# Calculate -ln(L), L=Likelihood of data
# rate (BER) at a given x given by complement of error function (erfc)
# errors at x = BER * scaling (i.e. total number of samples)
# Prob of measurement given by binomial distribution with rate & # of errors
def minusloglikelihood(erfc_params, data):
    sigma, mu = erfc_params[0], erfc_params[1]
    x = data[0]
    errs = data[1]
    samples = data[2]

    r = .5 * special.erfc((x-mu)/sigma)  # Expected BER rate at each point of x
    lgP = sum(scipy.stats.binom.logpmf(errs, samples, r))
    return -lgP

# Get mean/stddev of Gaussian tail by Maximum Likelihood
def maxlike(x, errs, samples):
    if not numpyScipyAvailable:
        log('Numpy/Scipy not available: no extrapolation')
        return None
    # get starting poing by using linear fit
    s,m = linfit_qscale(x, errs, samples)

    result = minimize(minusloglikelihood, np.array([s, m]), method='Nelder-Mead', args=[x, errs, samples])
    if result.success:
        return result.x[0], result.x[1]
    else:
        log('Failed to get MaxLike fit for extrapolated BER, using linear')
        return s,m

fittail = maxlike   # change to linfit_qscale if needed

# Get the indices for the tail on the edge of the eye.  Eye is presumed on the right, with BER values ~1 at idx 0 and 0 at last idx.
# we restrict to < max_ber_limit[0] if possible, but go up to max_ber_limit[1] if needed to get two nonzero values
def bathtub_extract_tail_idxs(x, y, max_ber_limit=[1e-5, 1e-2]):
    idxs = []
    num_nonzero = 0
    for ridx, val in enumerate(reversed(y)):
        if val <= max_ber_limit[0] or (val <= max_ber_limit[1] and num_nonzero < 2):
            idxs += [len(y)-ridx-1]
            if val > 0:
                num_nonzero += 1
        else:
            break
    if num_nonzero >= 2:
        return idxs
    else:
        return []

def interp(x, x0, x1, y0, y1):
    # given x between x0 and x1, return the interpolated y value between y0 and y1
    frac = 1.0*(x-x0)/(x1-x0)
    return y1 * frac + y0 * (1.0 - frac)

def bathtub_extrapolate_left(x, errs, samples, max_ber_limit, ber_thresh):
    if not numpyScipyAvailable:
        log('Numpy/Scipy not available: no extrapolation')
        return None
    # returns x values for specified BERs.  max_ber_limit goes to bathtub_extract_tail_idxs (above)
    x = np.array(x)
    errs = np.array(errs)
    samples = np.array(samples)
    bers = 1.0*errs/samples
    rev_x = x[::-1]
    rev_bers = bers[::-1]
    tail = bathtub_extract_tail_idxs(x, bers, max_ber_limit)
    if len(tail):
        # Find the level at which we should start using extrapolated values rather than raw data:
        ber_extrap_level = 1000.0 / max(samples)
        s, m = fittail(x[tail], errs[tail], samples[tail])
        min_extrap_rev_idx = np.argmax(rev_bers >= ber_extrap_level)  # find last measured point with BER > ber_extrap_level
        min_extrap_x = rev_x[min_extrap_rev_idx]
    else:
        ber_extrap_level = 0  # just try to interpolate on raw values for everything
        min_extrap_x = x[0]-1
    ber_intercepts = []
    for ber in ber_thresh:
        if ber >= ber_extrap_level:
            # don't use extrapolated values, just use interpolation of raw data
            idx = np.argmax(rev_bers >= ber)
            if idx == 0:
                if bers[0] < ber:
                    # no value greater, so just use the outer limit
                    ber_intercepts += [x[0]]
                else:
                    # first value is greater, so return one step past the end
                    ber_intercepts += [2 * x[-1] - x[-2]]
            else:
                if rev_bers[idx-1] == 0:
                    this_x = rev_x[idx]
                else:
                    this_x = interp(math.log10(ber), math.log10(rev_bers[idx-1]), math.log10(rev_bers[idx]), rev_x[idx-1], rev_x[idx])
                ber_intercepts += [this_x]
                min_extrap_x = max(min_extrap_x, this_x)  # don't let any of the below values stray to the left of this interpolated value
        else:
            ber_intercepts += [max(special.erfcinv(2*ber) * s + m, min_extrap_x)]
    return ber_intercepts

def bathtub_extrapolate_right(x, errs, samples, max_ber_limit, ber_thresh):
    if not numpyScipyAvailable:
        log('Numpy/Scipy not available: no extrapolation')
        return None
    x = np.array(x)
    errs = np.array(errs)
    samples = np.array(samples)
    flipped_ber_intercepts = bathtub_extrapolate_left(-x[::-1], errs[::-1], samples[::-1], max_ber_limit, ber_thresh)
    return [-x for x in flipped_ber_intercepts]
