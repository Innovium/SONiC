/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_my_mac_util.h
 * @brief ISAI Util Include file for MY_MAC module
 */


#ifndef __IFCS_SAI_MY_MAC_UTIL_H__
#define __IFCS_SAI_MY_MAC_UTIL_H__

#include "util/ifcs_sai_my_mac_util_dep.h"

sai_status_t
isai_im_my_mac_get_list(ifcs_node_id_t node_id,
                        uint32_t       *num_entries,
                        sai_object_id_t *my_mac_list);
#endif
