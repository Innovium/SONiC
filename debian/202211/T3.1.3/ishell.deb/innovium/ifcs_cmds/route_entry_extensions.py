
#-------------------------------------------------------------------------------
# * Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
# *-----------------------------------------------------------------------------
#-------------------------------------------------------------------------------

from ctypes import *
from ifcs_cmds.cli_types import *
from itertools import *
from time import *
from utils.compat_util import *
from verbosity import log, log_dbg
from ifcs_cmds.route_entry import *
from print_table import PrintTable
import sys
import socket
import struct
ifcs_ctypes=sys.modules['ifcs_ctypes']

key_type_dict = {
    ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_L3VNI : "ip_dest_l3vni",
    ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_ONLY : "ip_dest_only",
}

def get_ip_dest_from_route_entry(route_entry):
    ip_addr = " * "
    ip_mask = " * "

    if route_entry.contents.key_type == ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_ONLY:
        if route_entry.contents.key.ip_dest_only.ip_dest.addr_family == ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4:
            ip_addr = socket.inet_ntoa(struct.pack( '!L',
                        route_entry.contents.key.ip_dest_only.ip_dest.addr.ipv4))
            ip_mask = socket.inet_ntoa(struct.pack( '!L',
                        route_entry.contents.key.ip_dest_only.ip_dest.mask.ipv4))
        else:
            ip_addr = socket.inet_ntop(socket.AF_INET6,
                    route_entry.contents.key.ip_dest_only.ip_dest.addr.ipv6)
            ip_mask = socket.inet_ntop(socket.AF_INET6,
                    route_entry.contents.key.ip_dest_only.ip_dest.mask.ipv6)
    else:
        if route_entry.contents.key.ip_dest_l3vni.ip_dest.addr_family == ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4:
            ip_addr = socket.inet_ntoa(struct.pack( '!L',
                        route_entry.contents.key.ip_dest_l3vni.ip_dest.addr.ipv4))
            ip_mask = socket.inet_ntoa(struct.pack( '!L',
                        route_entry.contents.key.ip_dest_l3vni.ip_dest.mask.ipv4))
        else:
            ip_addr = socket.inet_ntop(socket.AF_INET6,
                    route_entry.contents.key.ip_dest_l3vni.ip_dest.addr.ipv6)
            ip_mask = socket.inet_ntop(socket.AF_INET6,
                    route_entry.contents.key.ip_dest_l3vni.ip_dest.mask.ipv6)

    return ip_addr, ip_mask


def bulk_get_all_route_entry_keys_raw(cli_obj, filter_key_p=None):

    def myCallback(node_id, key_count, key_p, user_data):
        try:
            if key_count > 0:
                key_objs = (ifcs_ctypes.ifcs_route_entry_key_t * key_count)()
                memmove(
                    compat_pointer(key_objs,
                                   ifcs_ctypes.ifcs_route_entry_key_t), key_p,
                    sizeof(key_objs))
                all_keys.append((key_count, key_objs))
            else:
                all_keys.append((key_count, None))
        except Exception as e:
            cb_error.append("{}".format(e))

    all_keys = []
    cb_error = []
    rc = ifcs_ctypes.IFCS_SUCCESS

    callback_type = CFUNCTYPE(ifcs_ctypes.UNCHECKED(None),
                              ifcs_ctypes.ifcs_node_id_t, c_uint32,
                              POINTER(ifcs_ctypes.ifcs_route_entry_key_t),
                              POINTER(None))
    callback = callback_type(myCallback)
    callback_p = compat_funcPointer(
        callback, ifcs_ctypes.ifcs_route_entry_bulk_get_all_user_cb_t)

    try:
        rc = ifcs_ctypes.ifcs_route_entry_bulk_get_all(cli_obj.cli.node_id,
                                                       filter_key_p, callback_p,
                                                       None, None)
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("Failed to get all route_entry rc: {}".format(
                cli_obj.status_to_string(rc)))
            return rc, 0, None
        elif len(cb_error):
            log_err("Failed to get all route_entry : call-back error {}".format(
                cb_error[0]))
            rc = ifcs_ctypes.IFCS_INVAL
            return rc, 0, None
        log_dbg(
            1, "route_entry bulk get all: key count: {}".format(all_keys[0][0]))
    except Exception as e:
        log_err("Failed to get all route_entry : {} ".format(e))
        raise e
    return rc, all_keys[0][0], all_keys[0][1]


def show_route_entry_extension_brief(args, route_entry):

    def _bulk_get_route_entry(key_idx, num_keys):
        route_entry_key_count = c_uint32(num_keys)
        route_entry_keys_p = compat_pointerAtIndex(
            all_keys, ifcs_ctypes.ifcs_route_entry_key_t, key_idx)

        actual_attr_counts = (c_uint32 * num_keys)()
        actual_attr_counts_p = compat_pointer(actual_attr_counts, c_uint32)

        actual_count = c_uint32(0)
        actual_count_p = pointer(actual_count)

        status_vals = [ifcs_ctypes.IFCS_INVAL] * num_keys
        status = (ifcs_ctypes.ifcs_status_t * num_keys)(*status_vals)
        status_p = compat_pointer(status, ifcs_ctypes.ifcs_status_t)

        rc = ifcs_ctypes.ifcs_route_entry_bulk_attr_get(
            route_entry.cli.node_id, api_params_p, route_entry_key_count,
            route_entry_keys_p, attr_count_p, attr_list_pp,
            actual_attr_counts_p, actual_count_p, status_p)
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_dbg(
                1,
                "route entry bulk attr get failed, rc: {}, actual count: {}, key idx: {}, key count: {}"
                .format(rc, actual_count.value, key_idx, num_keys))
            log_err("Failed to get route_entry in bulk, rc: {}".format(
                route_entry.status_to_string(rc)))
            return rc
        if (actual_count.value == 0):
            # Not an error as all entries might have been deleted
            log_dbg(
                1,
                "route entry bulk attr get with zero actual count returned, key idx: {}, key count: {}"
                .format(key_idx, num_keys))
            return ifcs_ctypes.IFCS_SUCCESS

        attr_ids_len = len(attr_ids)
        for idx in range(num_keys):
            if status[idx] == ifcs_ctypes.IFCS_NOTFOUND:
                # Not an error as entry might have got deleted
                continue
            elif status[idx] != ifcs_ctypes.IFCS_SUCCESS:
                log_dbg(
                    1,
                    "route entry bulk attr get failed at idx: {}, key idx: {}, key count: {}, rc: {}"
                    .format(idx, key_idx, num_keys, status[idx]))
                log_err("Failed to get route_entry rc: {}".format(
                    route_entry.status_to_string(status[idx])))
                return status[idx]
            elif actual_attr_counts[idx] != attr_count[
                    idx] or actual_attr_counts[idx] != attr_ids_len:
                log_dbg(
                    1,
                    "route entry bulk attr get at idx: {}, key idx: {}, key count: {}, actual attr count: {} vs expected count: {}"
                    .format(idx, key_idx, num_keys, actual_attr_counts[idx],
                            attr_count[idx]))
                log_err("Failed to get all attributes for route_entry")
                return ifcs_ctypes.IFCS_PARAM

            attr_one = attr_list[idx]
            if attr_one[0].id == ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_NEXTHOP:
                nexthop = attr_one[0].value.handle
                if nexthop in nexthop_vals:
                    nexthop = nexthop_vals[nexthop]
                else:
                    cur_nexthop = nexthop
                    nexthop = route_entry.handle_to_str(nexthop)
                    nexthop_vals[cur_nexthop] = nexthop
            if attr_one[1].id == ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_FWD_POLICY:
                fwd_action = route_entry.enum_to_str(
                    'fwd_action', attr_one[1].value.fwd_policy.fwd_action)
            if attr_one[2].id == ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_CTC_POLICY:
                trap_handle = attr_one[2].value.ctc_policy.trap_handle
                if trap_handle in trap_handle_vals:
                    trap_handle = trap_handle_vals[trap_handle]
                else:
                    cur_trap_handle = trap_handle
                    trap_handle = route_entry.handle_to_str(trap_handle)
                    trap_handle_vals[cur_trap_handle] = trap_handle
                ctc_action = route_entry.enum_to_str(
                    'copy_to_cpu', attr_one[2].value.ctc_policy.ctc_action)
            if attr_one[3].id == ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_USER_COOKIE:
                user_cookie = attr_one[3].value.u32
            if attr_one[4].id == ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_TTL_CHECK_PROFILE:
                ttl_check_profile = attr_one[4].value.u32

            key_ptr = compat_pointerAtIndex(all_keys,
                                            ifcs_ctypes.ifcs_route_entry_key_t,
                                            key_idx + idx)
            key_type = key_type_dict[key_ptr.contents.key_type]
            l3vni = key_ptr.contents.key.ip_dest_l3vni.l3vni
            if l3vni in l3vni_vals:
                l3vni = l3vni_vals[l3vni]
            else:
                cur_l3vni = l3vni
                l3vni = route_entry.get_l3vni_from_route_entry(key_ptr)
                l3vni_vals[cur_l3vni] = l3vni
            ip_addr, ip_mask = get_ip_dest_from_route_entry(key_ptr)

            # Save sort key and data
            all_data.append((key_ptr.contents.key.ip_dest_l3vni.l3vni, [
                key_type, ip_addr, ip_mask, l3vni, fwd_action, ctc_action,
                trap_handle, nexthop, user_cookie, ttl_check_profile
            ]))
        return ifcs_ctypes.IFCS_SUCCESS

    log_dbg(1, " Inside route_entry extension brief show")

    # Get key
    try:
        rc, all_key_count, all_keys = bulk_get_all_route_entry_keys_raw(
            route_entry)
    except Exception as e:
        log_err(" Failed to get all route_entry : {0} ".format(e))
        raise e

    table = PrintTable()
    field_names = [
        'key_type', 'ip_addr', 'ip_mask', 'l3vni', 'fwd_action', 'ctc_action',
        'trap', 'nexthop', 'user_cookie', 'ttl_check_profile'
    ]
    table.add_row(field_names)
    log("Total route_entry count: {0} ".format(all_key_count))
    if all_key_count == 0:
        table.print_table(brief=True)
        table.reset_table()
        log("Total route_entry count: 0\n")
        return

    # Prepare to get entries in bulk
    batch_size = 1000
    if all_key_count < batch_size:
        batch_size = all_key_count
    key_batches = [
        (idx,
         batch_size if idx + batch_size <= all_key_count else all_key_count -
         idx) for idx in range(0, all_key_count, batch_size)
    ]

    api_params = ifcs_ctypes.ifcs_api_params_t()
    ifcs_ctypes.ifcs_api_params_t_init(pointer(api_params))
    ifcs_ctypes.ifcs_api_params_t_flags_set(
        pointer(api_params), ifcs_ctypes.IFCS_API_PARAM_FLAGS_CONTINUE_ON_ERROR)
    api_params_p = pointer(api_params)

    attr_ids = [
        ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_NEXTHOP,
        ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_FWD_POLICY,
        ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_CTC_POLICY,
        ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_USER_COOKIE,
        ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_TTL_CHECK_PROFILE
    ]
    attr_ids_len = len(attr_ids)

    attr_count_vals = [attr_ids_len] * batch_size
    attr_count = (c_uint32 * batch_size)(*attr_count_vals)
    attr_count_p = compat_pointer(attr_count, c_uint32)
    attr_list = (POINTER(ifcs_ctypes.ifcs_attr_t) * batch_size)()
    for idx in range(batch_size):
        attr_one = (ifcs_ctypes.ifcs_attr_t * attr_ids_len)()
        for idx2 in range(attr_ids_len):
            attr_one[idx2].id = attr_ids[idx2]
        attr_list[idx] = attr_one
    attr_list_pp = compat_pointer(attr_list, POINTER(ifcs_ctypes.ifcs_attr_t))

    trap_handle_vals = {}
    nexthop_vals = {}
    l3vni_vals = {}
    all_data = []

    # Get entries in bulk
    for start_idx, key_count in key_batches:
        rc = _bulk_get_route_entry(start_idx, key_count)
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_dbg(
                1,
                "Error processing key batch in show route_entry, start idx {}, key count {}"
                .format(start_idx, key_count))
            log_err("Failed to get attributes for route_entry")
            raise KeyError

    all_route_entry = sorted(all_data, key=lambda x: x[0])
    for entry in all_route_entry:
        table.add_row(entry[1])
    table.print_table(brief=True)
    table.reset_table()
    log("Total route_entry count: {0} \n".format(len(all_route_entry)))
    return


def show_route_entry_extension_usage_helper(route_entry, filter_option):
    usage_p = ifcs_ctypes.ifcs_usage_t()

    if filter_option not in ['v4_prefix', 'v6_prefix', 'v4_host', 'v6_host', 'v4_fallback', 'v6_fallback', 'srp2', 'srp1', 'pth']:
        log_err("Invalid filter option {0}".format(filter_option))
        return

    ip_dest = ifcs_ctypes.ifcs_ip_prefix_t()
    ifcs_ctypes.ifcs_ip_prefix_t_init(pointer(ip_dest))

    if 'v4' in filter_option:
        ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)
    else: # v6 filter
        ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

    route_key = ifcs_ctypes.ifcs_route_entry_key_t()
    ifcs_ctypes.ifcs_route_entry_key_t_init(pointer(route_key))
    if 'fallback' in filter_option:
        ifcs_ctypes.ifcs_route_entry_key_t_key_type_set(pointer(route_key), ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_ONLY)
        ifcs_ctypes.ifcs_route_entry_key_t_ip_dest_only_set(pointer(route_key), route_key.key.ip_dest_only)
        ifcs_ctypes.ifcs_route_entry_key_ip_dest_only_t_ip_dest_set(pointer(route_key.key.ip_dest_only), pointer(ip_dest))
    else: # IP_DEST_L3VNI
        ifcs_ctypes.ifcs_route_entry_key_t_key_type_set(pointer(route_key), ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_L3VNI)
        ifcs_ctypes.ifcs_route_entry_key_t_ip_dest_l3vni_set(pointer(route_key), route_key.key.ip_dest_l3vni)
        ifcs_ctypes.ifcs_route_entry_key_ip_dest_l3vni_t_ip_dest_set(pointer(route_key.key.ip_dest_l3vni), pointer(ip_dest))

    attr = ifcs_ctypes.ifcs_attr_t()
    ifcs_ctypes.ifcs_attr_t_id_set(pointer(attr), ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_USAGE_GET_ROUTE_TYPE)

    if 'prefix' in filter_option:
        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_PREFIX)
    elif 'host' in filter_option:
        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_HOST)
    elif 'srp2' in filter_option:
        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_SRP2)
    elif 'srp1' in filter_option:
        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_SRP1)
    elif 'pth' in filter_option:
        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_PTH)

    if 'fallback' in filter_option:
        rc = ifcs_ctypes.ifcs_route_entry_usage_get(0, pointer(route_key), 0, None, pointer(usage_p))
    else:
        rc = ifcs_ctypes.ifcs_route_entry_usage_get(0, pointer(route_key), 1, pointer(attr), pointer(usage_p))
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err(
            "Failed to get all {0} route_entry rc: {1}".format(filter_option,
                convert_error_code_to_string(rc)))
        return

    # If max is zero, we need not display it
    if usage_p.max == 0:
        return

    log("Usage for {0} route entries".format(filter_option))

    table = PrintTable()
    table.add_row(["Current", "Max"])
    table.add_row([usage_p.current, usage_p.max])
    table.print_table()
    table.reset_table()
    log("\n")

    return


def show_route_entry_extension_usage(arg1, arg2, route_entry):
    log_dbg(1, " Inside extension usage show")

    if route_entry.filter_option == {}:
        for filter_option in ['v4_prefix', 'v6_prefix', 'v4_host', 'v6_host', 'v4_fallback', 'v6_fallback', 'srp2', 'srp1', 'pth']:
            show_route_entry_extension_usage_helper(route_entry, filter_option)
            log("\n")
    else:
        filter_option = (route_entry.filter_option['filter']).strip()
        show_route_entry_extension_usage_helper(route_entry, filter_option)

    return
