
#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import argparse
import shlex

#from ctypes import *
#from ifcs_ctypes import *
from testutil import eyeplot
import serdes_eth_cmn

# fixme: move away from "import *" below
from testutil.condor import *
import sys,traceback
from utils.compat_util import *

valid_speed_lookup = {10:       10.3125,
                      10.3125:  10.3125,
                      25:       25.78125,
                      25.78125: 25.78125,
                      50:       53.12500,
                      53:       53.12500,
                      53.12500: 53.12500}
valid_speed_list = list(set(compat_listvalues(valid_speed_lookup)))


def cli_firmware(lane, args):
    if args.filename is None:
        # Check if custom fw is loaded

        serdes_eth_cmn.print_lane_id(lane)
        if (serdes_check_custom_fw_loaded(lane)):
            hash_code,date,crc = serdes_check_custom_fw_loaded(lane)
            # Print data
            #print("Custom FW Info")
            log("Firmware CRC :  %s" % crc)
            log("Firmware date: 0x%x (%s)" % (date[0], date[1]))
            log("Firmware hash: %s" % hash_code)
            log("Firmware rev : %s_%s" % (date[1],hash_code))
        else:
            # Get data from SDK
            sd_rev = im_serdes_rev_info_t()
            rc = im_node_serdes_fw_rev_get(0, pointer(sd_rev))
            if rc != IFCS_SUCCESS:
                log_err("Failed to get serdes rev info\n");
                return

            d = datetime.date(1970, 1, 1) + datetime.timedelta(sd_rev.fw_date)
            date_str = "%04d%02d%02d" % (d.year, d.month, d.day)
            log("Firmware CRC : 0x%x" % sd_rev.fw_crc)
            log("Firmware date: 0x%x (%s)" % (sd_rev.fw_date, date_str))
            log("Firmware hash: 0x%x" % sd_rev.fw_hash_code)
            log("Firmware rev : %s"   % sd_rev.eth_rev_str)

    else:
        serdes_fw_load(args.filename, lane)

def cli_status(lane, args):
    serdes_eth_cmn.print_lane_id(lane)
    if args.reset_ber:
        prbs_rst(lane)
        time.sleep(.1)

    rx_monitor_capture(lane, rst=0)

    actual_data_rate, actual_baud_rate, fvco, pll_n, pll_fracn, pll_cap, div4 = get_pll(lane=lane)

    adap_count = fw_tuning_counter(lane=lane)
    [tx_pre2,tx_pre1,tx_main,tx_post1,tx_post2] = get_tx_taps(lane=lane)
    ctle_val,ctle1,ctle2 = ctle(lane=lane)
    ctle_f = ctle_fine(lane=lane)
    dacq_reg = rregBits(params(lane).dac_sel_addr, params(lane).dac_sel_bit_loc, lane)
    tx_tap_str = '%g, %g, %g, %g, %g' % (tx_pre2, tx_pre1, tx_main, tx_post1, tx_post2)
    channel_est = fw_channel_estimate(lane=lane)
    of_count, hf_count = fw_channel_of_hf(lane=lane)

    [ctle_gain1_bin,ffe_gain1_bin,ctle_gain2_bin,ffe_gain2_bin] = dc_gain(lane=lane)
    edge1 = rregLane(edge1_addr, lane)
    ext_rch    = rregLane(ext_rch_en_addr,  lane)
    ctle_gains = '%d, %d' % (ctle_gain1_bin, ctle_gain2_bin)
    ffe_gains = '%d, %d' % (ffe_gain1_bin, ffe_gain2_bin)

    berstr = 'Off'
    if get_ber_valid(lane):
        ber, ber_time = get_ber_since_reset(lane)
        if ber is None:
            berstr = 'Overflow'
        else:
            berstr = '%-5.1e' % ber
            if ber_time < 5:
                berstr += ' in %.1fs' % ber_time
            else:
                berstr += ' in %ds' % ber_time

    phy_status = 'PHY RDY' if get_phy_rdy(lane) else 'PHY DOWN'
    sig_detect = 'SIGNAL' if get_sig_detect(lane) else 'NO SIG'
    tot_status = (phy_status + ', ' + sig_detect)
    tx_out_str = get_tx_type(lane)
    if tx_idle_get(lane):
        tx_out_str = 'Disabled [%s]' % tx_out_str

    if optical_status(lane):
        optical_str = 'On'
    else:
        optical_str = 'Off'
    los_str = los_holdoff_status(lane)

    out_left = []
    out_right = []

    log('--'*12)
    # "%-18s: %-20s"
    out_left += [['Encoding', get_mode(lane)]] ; out_right += [['Data Rate(Gbps)', '%-9.5f' % actual_data_rate]]
    out_left += [['Status', tot_status]]       ; out_right += [['Adapt Count', '%d' % fw_tuning_counter(lane=lane)]]
    out_left += [['DAC', dacq_reg]]            ; out_right += [['Tx Taps', tx_tap_str]]

    if get_mode(lane) == 'pam4':
        f0, f1     = get_pam4_dfe(lane=lane)
        fm1 = ((rregBits(pam4_tap_addr,pam4_tap_bit_loc,lane))+64)%128 - 64
        ffe_pol1 = rregBits(ffe_pol_addr,ffe_po11_bit_loc,lane)
        ffe_pol2 = rregBits(ffe_pol_addr,ffe_po12_bit_loc,lane)
        ffe_pol3 = rregBits(ffe_pol_addr,ffe_po13_bit_loc,lane)
        ffe_pol4 = rregBits(ffe_pol_addr,ffe_po14_bit_loc,lane)
        ffe_pol    = rregLane(ffe_pol_addr,    lane)
        delta1 = delta_ph(lane = lane)
        edge1      = rregLane(edge1_addr,       lane)
        att = attenuator(lane=lane)
        ctle_gains += ' / %d' % att

        [ffe_tap1_bin,ffe_tap234,ffe_tap2_bin,ffe_tap34,ffe_tap3_bin,ffe_tap4_bin] = ffe_taps(lane=lane)
        prefec_cnt = rx_mon_prefec_cnt[lane]
        postfec_cnt = rx_mon_postfec_cnt[lane]
        prefec_ber = '%.2e' % rx_mon_prefec_ber[lane]
        postfec_ber = '%.2e' % rx_mon_postfec_ber[lane]
        ffe_tap_str = '%02X, %02X, %02X, %02X, %02X, %02X' % (ffe_tap1_bin,ffe_tap2_bin,ffe_tap3_bin,ffe_tap4_bin,ffe_tap34,ffe_tap234)
        dfe_tap_str = '%.2f, %.2f, %.2f' % (f0, f1, fm1/64.0)
        f13 = f1over3(lane=lane)
        tx_msblsb = get_tx_msblsb(lane)
        rx_msblsb = get_rx_msblsb(lane)

        out_left += [['Eye0', rx_mon_eye0.get(lane, -1)]]  ; out_right += [['Tx/Rx Polarity', '%d/%d' % (get_tx_polarity(lane), get_rx_polarity(lane))]]
        out_left += [['Eye1', rx_mon_eye1.get(lane, -1)]]  ; out_right += [['FFE Taps', ffe_tap_str]]
        out_left += [['Eye2', rx_mon_eye2.get(lane, -1)]]  ; out_right += [['FFE Tap Polarity', '%d, %d, %d, %d' % (ffe_pol1,ffe_pol2,ffe_pol3,ffe_pol4)]]

        out_left += [['CTLE Gains / Attn', ctle_gains]]    ; out_right += [['CTLE Idx,1,2,F', '%d, %d, %d, %d' % (ctle_val, ctle1, ctle2, ctle_f)]]
        out_left += [['FFE Gains', ffe_gains]]             ; out_right += [['ChanEst, Of, Hf', '%f, %d, %d' % (channel_est, of_count, hf_count)]]
        out_left += [['DFE F0,F1,Fm1', dfe_tap_str]]       ; out_right += [['F13, Delta, Edges', '%d, %d, %04X' % (f13, delta1, edge1)]]

        out_left += [['','']]                              ; out_right += [['Tx/Rx PRBS msblsb', '%d/%d' % (tx_msblsb, rx_msblsb)]]
        out_left += [['PreFEC Cnt', prefec_cnt]]           ; out_right += [['PostFEC Cnt', postfec_cnt]]
        out_left += [['PreFEC BER', prefec_ber]]           ; out_right += [['PostFEC BER', postfec_ber]]
    else:  # NRZ
        delta1, f1, f2, f3 = get_nrz_dfe(lane)
        dfe_tap_str = '%d, %d, %d' % (f1,f2,f3)
        # scaled dfe values: f1 * (dacq_reg * 50 + 200) / 64

        out_left += [['Eye0', rx_mon_eye0[lane]]]          ; out_right += [['Tx/Rx Polarity', '%d/%d' % (get_tx_polarity(lane), get_rx_polarity(lane))]]
        out_left += [['CTLE Gains', ctle_gains]]           ; out_right += [['CTLE Idx,1,2,F', '%d, %d, %d, %d' % (ctle_val, ctle1, ctle2, ctle_f)]]
        out_left += [['FFE Gains', ffe_gains]]             ; out_right += [['ChanEst, Of, Hf', '%f, %d, %d' % (channel_est, of_count, hf_count)]]
        out_left += [['DFE F1,F2,F3', dfe_tap_str]]        ; out_right += [['Delta, Edges', '%d, %04X' % (delta1, edge1)]]

    out_right += [['Tx Data', tx_out_str]]             ; out_left += [['Rx Match', get_rx_pat_match(lane)]] ;
    out_left += [['Rx Match Err Cnt', get_prbs_cnt_raw(lane)]] ; out_right += [['PRBS BER', berstr]]
    out_left += [['Optical Mode', optical_str]]        ; out_right += [['LOS Holdoff', los_str]]

    def add_colon(elems):
        if len(elems[0]) > 0 or len(elems[1]) > 0:
            return '%-18s: %-20s' % (elems[0], elems[1])
        else:
            return '%-18s  %-20s' % ('','')

    for (left, right) in zip(out_left, out_right):
        log(add_colon(left), add_colon(right))

    if get_mode(lane) == 'pam4':
        isi = dump_isi(lane)
        log('ISI: ' + ', '.join(map(str, isi)))
    else:
        isi = dump_nrz_isi(lane)
        log('NRZ ISI: ' + ', '.join(map(str, isi)))
    log("")

def cli_bathtub_multi_start(lanes, args):
    if not (args.plot or args.sizes or args.collect):
        raise ValueError('*** Must specify at least one of -C, -s, or -p')
    if args.collect:
        eye_mon_collect_multi(lanes, depth=args.collect, is_vert_bathtub=(not args.horizontal))

def cli_bathtub(lane, args):
    if not (args.plot or args.sizes):
        return  # was only collect, so don't print empty labels

    serdes_eth_cmn.print_lane_id(lane)

    if get_mode(lane) == 'pam4':
        centers = [('Top ', em_separator(lane)[0] + 1), ('Center ', em_separator(lane)[2] + 1), ('Bottom ', em_separator(lane)[4] + 1)]
        x_offset = -63
        hi_ctr_idx = em_separator(lane)[0] - x_offset
        sep_hi = em_separator(lane)[1] - x_offset
        mid_ctr_idx = em_separator(lane)[2] - x_offset
        sep_lo = em_separator(lane)[3] - x_offset
        lo_ctr_idx = em_separator(lane)[4] - x_offset
        eye_ranges = [[0, hi_ctr_idx, sep_hi], [sep_hi+1, mid_ctr_idx, sep_lo], [sep_lo+1, lo_ctr_idx, -1]]
    else:  # NRZ
        centers = [('', 0)]
        eye_ranges = [[0, None, -1]]

    outplots = []
    titles = []
    sizes = []
    if args.sizes is not None:
        bers = [10.0**(-abs(level)) for level in args.sizes]

    if args.horizontal:
        for c_lbl, c_pos in centers:
            x, errs, samples = horiz_bathtub_data(lane, c_pos, args.save)
            if x is None:
                log("No valid bathtub data for lane (use --collect)")
                return
            if args.plot is not None:
                outplots += [eyeplot.ascii_bathtub(x, errs, samples, 10**-abs(args.plot), [1e-5, 1e-2], columns=args.cols, qscale=args.q_scale)]
            if args.sizes is not None:
                titles += [c_lbl + 'Width (UI)']
                sizes += eyeplot.bathtub_widths(x, errs, samples, [1e-5, 1e-2], bers)
    else:  # vertical
        x, errs, samples = vert_bathtub_data(lane, False)
        if x is None:
            log("No valid bathtub data for lane (use --collect)")
            return
        if args.plot is not None:
            outplots += [eyeplot.ascii_bathtub(x, errs, samples, 10**-abs(args.plot), [1e-5, 1e-2], columns=args.cols, eye_ranges=eye_ranges, qscale=args.q_scale)]
        if args.sizes is not None:
            titles = [c_lbl + 'Height (mV)' for c_lbl, c_pos in centers]
            sizes = eyeplot.bathtub_widths(x, errs, samples, [1e-5, 1e-2], bers, eye_ranges=eye_ranges)

    if args.plot is not None:
        for lines in zip(*outplots):   # transpose columns to rows/lines
            log("    ".join(lines))
        if args.sizes:
            log("")

    if args.sizes is not None:
        eyeplot.print_size_table(bers, titles, sizes)

def cli_eye_multi_start(lanes, args):
    if not (args.plot or args.sizes or args.collect):
        raise ValueError('*** Must specify at least one of -C, -s, or -p')
    if args.collect:
        eye_mon_collect_multi(lanes, depth=args.collect)

def cli_eye(lane, args):
    if not (args.plot or args.sizes):
        return  # was only collect, so don't print empty labels
    log("")
    serdes_eth_cmn.print_lane_id(lane)
    log("----------------------")

    eye_data = get_eye_data(lane)
    if eye_data is None:
        log("No valid eye data for lane (use --collect)")
        return

    if args.plot:
        eyeplot.print_ascii_eye_plot(eye_data, True, color=(args.color != 'none'), invert=args.invert, columns=args.cols)
        log('')

    if args.save is not None:
        for line in eye_data:
            for pt in line:
                args.save.write('%.2e ' % pt)
            args.save.write('\n')
        args.save.flush()

    if args.sizes is not None:
        bers = [10.0**(-abs(level)) for level in args.sizes]

        if get_mode(lane) == 'pam4':
            centers = [('Top ', em_separator(lane)[0] + 1), ('Center ', em_separator(lane)[2] + 1), ('Bottom ', em_separator(lane)[4] + 1)]
            x_offset = -63
            hi_ctr_idx = em_separator(lane)[0] - x_offset
            sep_hi = em_separator(lane)[1] - x_offset
            mid_ctr_idx = em_separator(lane)[2] - x_offset
            sep_lo = em_separator(lane)[3] - x_offset
            lo_ctr_idx = em_separator(lane)[4] - x_offset
            eye_ranges = [[0, hi_ctr_idx, sep_hi], [sep_hi+1, mid_ctr_idx, sep_lo], [sep_lo+1, lo_ctr_idx, -1]]
        else:  # NRZ
            centers = [('', 0)]
            eye_ranges = [[0, None, -1]]
        x, errs, samples = vert_bathtub_data(lane, False)
        heights = eyeplot.bathtub_widths(x, errs, samples, [1e-5, 1e-2], bers, eye_ranges=eye_ranges)
        titles = []
        sizes = []
        for c_lbl, c_pos in centers:
            x, errs, samples = horiz_bathtub_data(lane, c_pos, False)
            if x is None:
                log('No Horizontal eye/bathtub data')
                return
            titles += [c_lbl + 'Width (UI)']
            sizes += eyeplot.bathtub_widths(x, errs, samples, [1e-5, 1e-2], bers)

            titles += [c_lbl + 'Height (mV)']
            sizes += [heights.pop(0)]

        eyeplot.print_size_table(bers, titles, sizes)

def cli_ber_multi_start(lanes, args):
    global ber_vals
    ber_vals = get_ber_multi(lanes, rst=args.reset, accum_time=args.time, print_status=True)

def cli_ber(lane, args):
    prbs_accum_time, prbs_error_cnt, ber_val3, log_ber3, lane_status = ber_vals[lane]
    serdes_eth_cmn.print_lane_id(lane, no_linefeed=True)
    log("  Lane [status: %s] BER (%ds) %7.1e " % (lane_status_str[lane_status], prbs_accum_time, ber_val3))

def cli_read(lane, args):
    #print args
    serdes_eth_cmn.print_lane_id(lane)
    if args.wide:
        for idx in range(args.num):
            val = rreg32Lane(args.addr + idx * 2, lane=lane)
            log('%04x: %08x' % (args.addr + idx, val))
    else:
        for idx in range(args.num):
            val = rregLane(args.addr + idx, lane=lane)
            log('%04x: %04x' % (args.addr + idx, val))

def cli_readbits(lane, args):
    #print args
    serdes_eth_cmn.print_lane_id(lane)
    outval = 0
    outlist = ''
    for idx in range(args.num):
        # val = rregBits(args.addr + offset, args.bits[::-1], lane=lane)
        val = rregLane(args.addr + idx, lane=lane)
        for bit_idx in args.bits:
            bitval = (val >> bit_idx) & 1
            outval = outval << 1 | bitval
            outlist += '%d' % bitval
        log("%04x%s: 'b%s : 0x%x" % (args.addr + idx, str(args.bits), outlist, outval))

def cli_writebits(lane, args):
    #print args
    regval = rregLane(args.addr, lane=lane)
    val_to_stuff = args.value
    for bit_idx in args.bits[::-1]:  # work low->high, and peel bits off of (val_to_stuff & 1)
        bitmask = (1 << bit_idx)
        if val_to_stuff & 1:
            regval = regval | bitmask
        else:
            regval = (regval & (0xffff - bitmask))

        val_to_stuff = val_to_stuff >> 1
    log('%04x: %04x' % (args.addr, regval))
    wregLane(args.addr, regval, lane=lane)

def cli_write(lane, args):
    #print args
    wregLane(args.addr, args.value, lane=lane)

def cli_config(lane, args):
    verbose = args.verbose
    args.verbose = None

    if all(v is None for v in vars(args).values()):
        # no arguments passed: just show the current config
        serdes_eth_cmn.print_lane_id(lane)
        pll(lane=lane, verbose=verbose)
        return
    #print vars(args)
    #print [v for v in vars(args).values()]

    #mgmt.print_writes = True

    tx_idx = 0

    if args.tx_enable is not None:
        tx_idle_set(not args.tx_enable, lane=lane)

    if args.tx_loopback:
        rx_tx_serial_loopback(True, lane=lane)
    elif args.tx_core or args.tx_test or args.tx_pattern:
        if get_rx_tx_serial_loopback(lane):
            rx_tx_serial_loopback(False, lane=lane)

    if args.tx_core:
        set_tx_test(False, lane=lane)

    change_speed = (args.speed is not None) or (args.div4 is not None)

    orig_speed, _, _, _, _, _, orig_div4 = get_pll(lane=lane)

    if args.speed is None:
        args.speed = orig_speed
    if args.div4 is None:
        if change_speed:
            args.div4 = 1  # default to div4 being on, if unspecified and setting speed
        else:
            args.div4 = orig_div4
    if args.rx_input is None:
        args.rx_input = get_rx_input_mode(lane)
    if args.rx_precode is None:
        args.rx_precode = get_rx_precode(lane)
    if args.tx_precode is None:
        args.tx_precode = get_tx_precode(lane)
    if args.rx_graycode is None:
        args.rx_graycode = get_rx_graycode(lane)
    if args.tx_graycode is None:
        args.tx_graycode = get_tx_graycode(lane)
    if args.rx_polarity is None:
        args.rx_polarity = get_rx_polarity(lane)
    if args.tx_polarity is None:
        args.tx_polarity = get_tx_polarity(lane)
    if args.tx_msblsb is None:
        args.tx_msblsb = get_tx_msblsb(lane)
    if args.rx_msblsb is None:
        args.rx_msblsb = get_rx_msblsb(lane)
    if args.optical is None:
        args.optical = optical_status(lane)
    if args.los_holdoff is None:
        args.los_holdoff = (los_holdoff_status(lane) != 'Off')

    orig_pre2, orig_pre1, orig_main, orig_post1, orig_post2 = get_tx_taps(lane)
    pre2 = args.pre2 if args.pre2 is not None else orig_pre2
    pre1 = args.pre1 if args.pre1 is not None else orig_pre1
    main = args.main if args.main is not None else orig_main
    post1 = args.post1 if args.post1 is not None else orig_post1
    post2 = args.post2 if args.post2 is not None else orig_post2

    if args.reset:
        soft_reset(lane)

    if ((args.pre2 is not None) or (args.pre1 is not None) or
        (args.main is not None) or (args.post1 is not None) or
        (args.post2 is not None) or args.reset):
        set_tx_taps_safe(pre2, pre1, main, post1, post2, lane=lane)

    # find the key in fw_data_rate_map closest to the target data rate

    int_rate = min(compat_listkeys(fw_data_rate_map), key=lambda x:abs(x - args.speed))
    fw_data_rate = fw_data_rate_map[int_rate]

    set_tx_graycode(args.tx_graycode, lane)
    set_rx_graycode(args.rx_graycode, lane)
    set_tx_precode(args.tx_precode, lane)
    set_rx_precode(args.rx_precode, lane)

    if args.rx_check:
        set_rx_prbs(args.rx_check, lane=lane)

    if args.rx_input == 'dc':
        wregBits(0xF7, [12], 0, lane)
    elif args.rx_input == 'ac':
        wregBits(0xF7, [12], 1, lane)

    if args.tune == 'off' or args.tune == 'bounce':
        wregBits(0x980F, [15], 0, lane) # Clear go bit
        #wregBits(0x8440, [15], 0, lane) # Disables AN/LT lane swapping

    # Tuning: NRZ write 8001, PAM4 write 9e01 , stop tuning via bit 15
    if change_speed:
        serdes_eth_cmn.print_lane_id(lane)

        log("----------------------")
        if int_rate <=28:   # NRZ
            half_rate = 1 if int_rate <= 16 else 0
            config_nrz_tx(tx_idx, half_rate=half_rate, lane=lane)  # This enables PRBS so we need to put this first
            fw_cmd(0x80C0, detail=fw_data_rate, expected_response=8, lane=lane)
            config_nrz_fw_rx(optical_mode=args.optical, lane=lane)
            pll(rate=args.speed, div4=args.div4, lane=lane, verbose=verbose)

        else:  # changing speeds, PAM4
            config_pam4_tx(tx_idx, lane)        # This enables PRBS so we need to put this first
            config_pam4_fw_rx(optical_mode=args.optical, lane=lane) # This clears polarity, so before connection
            fw_cmd(0x80D0, detail=fw_data_rate, expected_response=8, lane=lane)
            pll(rate=args.speed, div4=args.div4, lane=lane, verbose=verbose)

    set_tx_polarity(args.tx_polarity, lane)
    set_rx_polarity(args.rx_polarity, lane)
    set_tx_msblsb(args.tx_msblsb, lane)
    set_rx_msblsb(args.rx_msblsb, lane)

    if args.tx_test:
        set_tx_prbs(args.tx_test, lane=lane)
        set_tx_test(True, lane=lane)

    if args.tx_pattern:
        set_tx_pattern(args.tx_pattern, lane=lane)
        set_tx_prbs('PATTERN', lane=lane)
        set_tx_test(True, lane=lane)

    if change_speed or args.rx_check:
        prbs_rst(lane)

    if args.tune == 'on' or args.tune == 'bounce':
        # bit 15 is 'go'.  We should maybe have finer-grained control over other bits (auto-CTLE, etc)
        if get_mode(lane) == 'pam4':
            wregLane(0x980f, 0x9e01, lane=lane)
        else:
            wregLane(0x980f, 0x8001, lane=lane)
        fw_show_tuning(True, True, lane=lane)

    optical_set(args.optical, lane)
    los_holdoff_set(args.los_holdoff, lane)

def cli_dump_isi(lane, args):
    serdes_eth_cmn.print_lane_id(lane)
    log(dump_isi(lane=lane))
def cli_dump_nrz_isi(lane, args):
    serdes_eth_cmn.print_lane_id(lane)
    log(dump_nrz_isi(lane=lane))
def cli_dump_exit_code(lane, args):
    serdes_eth_cmn.print_lane_id(lane)
    log(dump_exit_code(lane=lane))
def cli_dump_ths(lane, args):
    serdes_eth_cmn.print_lane_id(lane)
    log(dump_ths(lane=lane))
def cli_dump_ffe(lane, args):
    serdes_eth_cmn.print_lane_id(lane)
    log(dump_ffe(lane=lane))
def cli_dump_ffe_wt(lane, args):
    serdes_eth_cmn.print_lane_id(lane)
    log(dump_ffe_wt(lane=lane))
def cli_dump_an(lane, args):
    serdes_eth_cmn.print_lane_id(lane)
    log(AN_dump_fw(lane=lane))
def cli_dump_fw_reg(lane, args):
    serdes_eth_cmn.print_lane_id(lane)
    log(fw_reg(lane=lane))
def cli_get_dfe(lane, args):
    serdes_eth_cmn.print_lane_id(lane)
    if get_mode(lane) == 'pam4':
        log(get_pam4_dfe(lane))
    else:
        log(get_nrz_dfe(lane))

def cli_get_fw_reg(lane, args):
    serdes_eth_cmn.print_lane_id(lane)
    retval = get_fw_reg(args.index, lane, args.section)
    log("FW reg read: index = %d, section = %d, val = 0x%04x" %(args.index, args.section, retval))

def cli_set_fw_reg(lane, args):
    serdes_eth_cmn.print_lane_id(lane)
    set_fw_reg(args.index, args.value, lane, args.section)
    retval = get_fw_reg(args.index, lane, args.section)
    log("FW reg: index = %d, section = %d, val = 0x%04x" %(args.index, args.section, retval))

def cli_pt_debug(lane, args):
    serdes_eth_cmn.print_lane_id(lane)
    start_idx = args.index #don't modify args
    for i in range(args.num):
        dbg_val = PT_debug(args.section, start_idx, lane)
        log("PT_debug: Index=%d, section=%d, val = 0x%04x" %(args.index, args.section, dbg_val))
        start_idx = start_idx + 1

def valid_speed_parser(speed_str):
    try:
        return valid_speed_lookup[float(speed_str)]
    except:
        raise argparse.ArgumentTypeError('value not in %s' % valid_speed_list)

def add_parser(parser):
    eth_tl5_funcs = {
        "firmware": (None, cli_firmware),
        "status": (None, cli_status),
        "config": (None, cli_config),
        "bathtub": (cli_bathtub_multi_start, cli_bathtub),
        "eye": (cli_eye_multi_start, cli_eye),
        "ber": (cli_ber_multi_start, cli_ber)
    }
    subparsers = serdes_eth_cmn.add_parser(parser, eth_tl5_funcs, valid_speed_parser, "condor")

    parser_vendor = subparsers.add_parser('vendor', help='SerDes vendor-specific commands')
    subparser_vendor = parser_vendor.add_subparsers()
    parser_read = subparser_vendor.add_parser('read', help='read SerDes register')
    parser_read.add_argument('addr', type=serdes_eth_cmn.Hex, help='address')
    parser_read.add_argument('--num', '-n', type=int, default=1, help='number of entries to read')
    parser_read.add_argument('--wide', '-w', action='store_true', help='32-bit read')
    parser_read.set_defaults(func=serdes_eth_cmn.multi_callback(None, cli_read))

    parser_readbits = subparser_vendor.add_parser('readbits', help='read bits from register')
    parser_readbits.add_argument('addr', type=serdes_eth_cmn.Hex, help='address')
    parser_readbits.add_argument('bits', type=serdes_eth_cmn.parse_list, help='bits to read, e.g: 3-1 or 7,5')
    parser_readbits.add_argument('--num', '-n', type=int, default=1, help='number of entries to read')
    parser_readbits.set_defaults(func=serdes_eth_cmn.multi_callback(None, cli_readbits))

    parser_write = subparser_vendor.add_parser('write', help='write SerDes register')
    parser_write.add_argument('addr', type=serdes_eth_cmn.Hex, help='address')
    parser_write.add_argument('value', type=serdes_eth_cmn.Hex, help='value')
    parser_write.set_defaults(func=serdes_eth_cmn.multi_callback(None, cli_write))

    parser_writebits = subparser_vendor.add_parser('writebits', help='write SerDes register')
    parser_writebits.add_argument('addr', type=serdes_eth_cmn.Hex, help='address')
    parser_writebits.add_argument('bits', type=serdes_eth_cmn.parse_list, help='bits to write')
    parser_writebits.add_argument('value', type=serdes_eth_cmn.Hex, help='value to unpack into those bits')
    parser_writebits.set_defaults(func=serdes_eth_cmn.multi_callback(None, cli_writebits))

    parser_di = subparser_vendor.add_parser('isi', help='Dump utils')
    parser_di.set_defaults(func=serdes_eth_cmn.multi_callback(None, cli_dump_isi))
    parser_dni = subparser_vendor.add_parser('nrz-isi', help='Dump utils')
    parser_dni.set_defaults(func=serdes_eth_cmn.multi_callback(None, cli_dump_nrz_isi))
    parser_dec = subparser_vendor.add_parser('exit-code', help='Dump utils')
    parser_dec.set_defaults(func=serdes_eth_cmn.multi_callback(None, cli_dump_exit_code))
    parser_dt = subparser_vendor.add_parser('ths', help='Dump utils')
    parser_dt.set_defaults(func=serdes_eth_cmn.multi_callback(None, cli_dump_ths))
    parser_df = subparser_vendor.add_parser('ffe', help='Dump utils')
    parser_df.set_defaults(func=serdes_eth_cmn.multi_callback(None, cli_dump_ffe))
    parser_dfw = subparser_vendor.add_parser('ffe-wt', help='Dump utils')
    parser_dfw.set_defaults(func=serdes_eth_cmn.multi_callback(None, cli_dump_ffe_wt))
    parser_da = subparser_vendor.add_parser('an', help='Dump utils')
    parser_da.set_defaults(func=serdes_eth_cmn.multi_callback(None, cli_dump_an))
    parser_dfr = subparser_vendor.add_parser('fw-reg', help='Dump utils')
    parser_dfr.set_defaults(func=serdes_eth_cmn.multi_callback(None, cli_dump_fw_reg))
    parser_dfe = subparser_vendor.add_parser('dfe', help='Dump utils')
    parser_dfe.set_defaults(func=serdes_eth_cmn.multi_callback(None, cli_get_dfe))
    parser_dgfw = subparser_vendor.add_parser('get_fw_reg', help='get FW register')
    parser_dgfw.add_argument('index', type=serdes_eth_cmn.Hex, help='index')
    parser_dgfw.add_argument('section', type=serdes_eth_cmn.Hex, help='section')
    parser_dgfw.set_defaults(func=serdes_eth_cmn.multi_callback(None, cli_get_fw_reg))
    parser_dsfw = subparser_vendor.add_parser('set_fw_reg', help='set FW register')
    parser_dsfw.add_argument('index', type=serdes_eth_cmn.Hex, help='index')
    parser_dsfw.add_argument('section', type=serdes_eth_cmn.Hex, help='section')
    parser_dsfw.add_argument('value', type=serdes_eth_cmn.Hex, help='write value')
    parser_dsfw.set_defaults(func=serdes_eth_cmn.multi_callback(None, cli_set_fw_reg))
    parser_dptd = subparser_vendor.add_parser('pt_debug', help='PT debug')
    parser_dptd.add_argument('index', type=serdes_eth_cmn.Hex, help='index')
    parser_dptd.add_argument('section', type=serdes_eth_cmn.Hex, help='section')
    parser_dptd.add_argument('--num', '-n', type=int, default=1, help='number of entries to read')
    parser_dptd.set_defaults(func=serdes_eth_cmn.multi_callback(None, cli_pt_debug))


# for direct use from python
def run_cmd(arglist):
    try:
        arglist = ['--help' if a == 'help' else a for a in arglist]  # replace any 'help' arguments with '--help'

        parser = argparse.ArgumentParser(prog='diagtest serdes eth')
        add_parser(parser)
        args = parser.parse_args(arglist)
        args.func(args)
    except ValueError as ex:
        log("Value Error: %s" % ":".join(ex.args))
    except Exception as ex:
        traceback.print_exc(file=sys.stdout)
        log("exception: ", type(ex).__name__, ex.args)
    except:
        pass
