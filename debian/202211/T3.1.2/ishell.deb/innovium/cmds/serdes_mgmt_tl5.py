#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------
""" Management port serdes operations """

import argparse
import sys,traceback
import copy
import time
import ifcs_ctypes as ifcs
from utils.compat_util import *

if COMPAT_PY2:
    from exceptions import IOError

try:
    from cmdmgr import Command
    from testutil import pci
except:
    pass

from testutil import sierra

# crunch the N specified bits down to the low N bits (ordered N-1..0), and return them
def get_bits(val, bitlist):
    output = 0
    for bit in bitlist:
        output = output << 1
        if bit is not None:
            output = output | ((val >> bit) & 1)
    return output

# Transport specific functions for K2 MPIC

def k2_serdes_addr_to_sw(serdes_addr):
    if serdes_addr & 0x8000:
        # note: could avoid inversion of bit 14 if dbg_addr[0] were 0, I think
        serdes_addr = serdes_addr ^ (1<<14)
        dbg_addr = get_bits(serdes_addr, [11, 10, 9, None]) | 1
        sw_addr = get_bits(serdes_addr, [15, 14, 13, 12, 8, 7, 6, 5, 4, 3, 2, 1, 0, None])
    else:
        dbg_addr = get_bits(serdes_addr, [12, 11, 10, None]) | 1
        sw_addr = get_bits(serdes_addr, [15, 14, 13, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, None])

    return sw_addr, dbg_addr

def k2_sw_addr_to_pci(sw_addr):
    return sw_addr + 0x14000

def k2_sw_addr_to_serdes(sw_addr):
    # assumption: dbg_addr = 0x01
    if sw_addr & (1<<13):
        serdes_addr = get_bits(sw_addr, [13, 12, 11, 10, None, None, None, 9, 8, 7, 6, 5, 4, 3, 2, 1])
        serdes_addr = serdes_addr ^ (1<<14)
    else:
        serdes_addr = get_bits(sw_addr, [13, 12, 11, None, None, None, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1])
    return serdes_addr

def k2_pci_addr_to_sw(pci_addr):
    return pci_addr - 0x14000

def base_serdes_read_k2(serdes_addr):
    sw_addr, _ = k2_serdes_addr_to_sw(serdes_addr)
    pci_addr = k2_sw_addr_to_pci(sw_addr)
    val = pci.read16(pci_addr)
    return val

def base_serdes_write_k2(serdes_addr, val):
    sw_addr, _ = k2_serdes_addr_to_sw(serdes_addr)
    pci_addr = k2_sw_addr_to_pci(sw_addr)
    pci.write16(pci_addr, val)

# Transport specific functions for TL10 MPIC
def base_serdes_read_tl10(serdes_addr):
    sts = pci.read_fields("MPIC_STS_APB_ACCESS")
    if not sts["req_rdy_f"]:
        raise IOError("APB bus in use")
    pci.write_fields("MPIC_DO_APB_ACCESS", addr_f = serdes_addr)
    pci.write_fields("MPIC_DO_APB_ACCESS_CTRL", write_f = 0)
    for _ in list(range(10)):
        sts = pci.read_fields("MPIC_STS_APB_ACCESS")
        if sts["rsp_err_f"]:
            raise IOError("APB bus transaction failed")
        if sts["rsp_vld_f"]:
            return sts["rsp_data_f"]
    raise IOError("APB bus transaction stalled")

def base_serdes_write_tl10(serdes_addr, value):
    sts_apb_access = pci.read_fields("MPIC_STS_APB_ACCESS")
    if not sts_apb_access["req_rdy_f"]:
        raise IOError("APB bus in use")
    pci.write_fields("MPIC_DO_APB_ACCESS", addr_f = serdes_addr, wr_data_f = value)
    pci.write_fields("MPIC_DO_APB_ACCESS_CTRL", write_f = 1)
    sts = pci.read_fields("MPIC_STS_APB_ACCESS")
    if sts["rsp_err_f"]:
        raise IOError("APB bus transaction failed")
    if sts["rsp_vld_f"]:
        return
    raise IOError("APB bus transaction stalled")

# For both K2 and TL10: the ability to reset all management ports

def toggle_port_enable():
    # find all aux ports that are enabled, and bounce them
    for dp in [33,34]:
        ret = ifcs.ifcs_status_t()
        attr = ifcs.ifcs_attr_t()
        actual_count = ifcs.c_uint32(0)

        attr.id = ifcs.IFCS_DEVPORT_ATTR_TYPE
        ret = ifcs.ifcs_devport_attr_get(0, dp, 1, ifcs.pointer(attr), ifcs.pointer(actual_count))

        assert ret == ifcs.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
        if attr.value.u32 == ifcs.IFCS_DEVPORT_TYPE_AUX:
            attr.id = ifcs.IFCS_DEVPORT_ATTR_ADMIN_STATE
            ret = ifcs.ifcs_devport_attr_get(0, dp, 1, ifcs.pointer(attr), ifcs.pointer(actual_count))
            assert ret == ifcs.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
            if attr.value.u32 == 1:  # is in admin state, so bounce it
                attr_count = 1
                attr_list_p = (ifcs.ifcs_attr_t * attr_count)()
                attr_list_p[0].id = ifcs.IFCS_DEVPORT_ATTR_ADMIN_STATE
                attr_list_p[0].value.u32 = 0
                # Set port enabled state
                ret = ifcs.ifcs_devport_attr_set (0, dp, attr_count, ifcs.pointer(attr_list_p));
                assert ret == ifcs.IFCS_SUCCESS, "failed to disable port %d : ret = [%d]" % (dp, ret)
                time.sleep(1)
                attr_list_p[0].value.u32 = 1
                # Set port enabled state
                ret = ifcs.ifcs_devport_attr_set (0, dp, attr_count, ifcs.pointer(attr_list_p));
                assert ret == ifcs.IFCS_SUCCESS, "failed to enable port %d : ret = [%d]" % (dp, ret)

def bounce_port_if_aux(node_id, dp, attr_count, attr_list, user_data):
    ret = ifcs.ifcs_status_t()
    attr = ifcs.ifcs_attr_t()
    actual_count = ifcs.c_uint32(0)

    attr.id = ifcs.IFCS_DEVPORT_ATTR_TYPE
    ret = ifcs.ifcs_devport_attr_get(0, dp, 1, ifcs.pointer(attr), ifcs.pointer(actual_count))

    assert ret == ifcs.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
    if attr.value.u32 == ifcs.IFCS_DEVPORT_TYPE_AUX:
        attr.id = ifcs.IFCS_DEVPORT_ATTR_ADMIN_STATE
        ret = ifcs.ifcs_devport_attr_get(0, dp, 1, ifcs.pointer(attr), ifcs.pointer(actual_count))
        assert ret == ifcs.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
        if attr.value.u32 == 1:  # is in admin state, so bounce it
            log("  Toggling enable of devport %d" % dp)
            attr_count = 1
            attr_list_p = (ifcs.ifcs_attr_t * attr_count)()
            attr_list_p[0].id = ifcs.IFCS_DEVPORT_ATTR_ADMIN_STATE
            attr_list_p[0].value.u32 = 0
            # Set port enabled state
            ret = ifcs.ifcs_devport_attr_set (0, dp, attr_count, ifcs.pointer(attr_list_p));
            assert ret == ifcs.IFCS_SUCCESS, "failed to disable port %d : ret = [%d]" % (dp, ret)
            time.sleep(1)
            attr_list_p[0].value.u32 = 1
            # Set port enabled state
            ret = ifcs.ifcs_devport_attr_set (0, dp, attr_count, ifcs.pointer(attr_list_p));
            assert ret == ifcs.IFCS_SUCCESS, "failed to enable port %d : ret = [%d]" % (dp, ret)

def toggle_port_enable():
    callback_type = ifcs.CFUNCTYPE(
        ifcs.UNCHECKED(None),
        ifcs.ifcs_node_id_t,
        ifcs.ifcs_devport_t,
        ifcs.c_uint32,
        ifcs.POINTER(ifcs.ifcs_attr_t),
        ifcs.POINTER(None))
    bounce_callback = callback_type(bounce_port_if_aux)
    ifcs.ifcs_devport_get_all(0, 0, None, compat_funcPointer(bounce_callback, ifcs.ifcs_devport_user_cb_t), None, None)

def get_phy(node_id):
    NUM_LANES_TL10 = 2
    device_type = ifcs.im_nmgr_node_device_type_get(node_id)
    if device_type == ifcs.IM_NMGR_NODE_DEVICE_TYPE_TL10:
        phy = sierra.Sierra(NUM_LANES_TL10, base_serdes_read_tl10, base_serdes_write_tl10, toggle_port_enable, 7)
        phy.is_k2 = False
        return phy
    raise KeyError("Device type %d not implemented for serdes_mgmt" % device_type)

# end Transport-specific

def speed_get(lane):
    mpic_enable = pci.read_fields('MPIC%d_ENABLE' % lane)
    if mpic_enable['rx_f'] == 0 and mpic_enable['tx_f'] == 0:
        return 0
    elif mpic_enable['speed_mode_f']:
        return 10
    else:
        return 1

default_lane_list = [0]
def get_lane_list(args):
    global default_lane_list
    if args.lane is not None:
        default_lane_list = args.lane
    for lane in default_lane_list:
        if len(default_lane_list) > 1:
            if lane != default_lane_list[0]:
                log('')  # empty line between lanes
            log('Mgmt Lane %d' % lane)
        yield lane

# Intended for use with argparse: convert a string to a list of integers:
# '5' => [5], '3,8,2' => [3, 8, 2], '4-6' => [4,5,6]
def parse_list(s):
    out = []
    for item in s.split(','):
        if ':' in item:
            itemlist = item.split(':', 2)
        elif '-' in item:
            itemlist = item.split('-', 2)
        else:
            itemlist = [item]
        first = int(itemlist[0], 0)
        if len(itemlist) == 1:
            out.append(int(itemlist[0], 0))
        elif len(itemlist) == 2:
            last = int(itemlist[1], 0)
            for x in range(first, last+1):
                out.append(x)
        else:
            raise ValueError("Error parsing list argument")
    return out

def Hex(s):
    return int(s,16)

def cli_status(args):
    phy = get_phy(0)
    for lane in get_lane_list(args):
        speed = speed_get(lane)
        phy_status = phy.status_str(lane)
        log('Lane: %d  Speed: %dGbps %s' % (lane, speed, phy_status))

def cli_creq_diag(args):
    phy = get_phy(0)
    for lane in get_lane_list(args):
        phy.cli_creq_diag(lane, args)

def cli_deq_diag(args):
    phy = get_phy(0)
    for lane in get_lane_list(args):
        phy.cli_deq_diag(lane, args)

def cli_bathtub(args):
    phy = get_phy(0)
    for lane in get_lane_list(args):
        if speed_get(lane) == 1:
            sample_scaling = 1
        else:
            sample_scaling = 2   # At 10G-KR, sampler can read up to 2 errors per sample
        phy.cli_bathtub(lane, sample_scaling, args)

def cli_eye(args):
    phy = get_phy(0)
    for lane in get_lane_list(args):
        if speed_get(lane) == 1:
            sample_scaling = 1
        else:
            sample_scaling = 2  # At 10G-KR, sampler can read up to ~2 errors per sample
        phy.cli_eye(lane, sample_scaling, args)

def cli_read(args):
    phy = get_phy(0)
    if phy.is_k2:
        for lane in get_lane_list(args):
            if args.bus == 'mpic':
                sw_addr = args.addr
                serdes_addr = sw_addr_to_serdes(sw_addr)
            else:
                if args.bus == 'addlane':
                    serdes_addr = sierra.add_lane_to_serdes_addr(args.addr, lane)
                else:
                    serdes_addr = args.addr
                sw_addr, dbg_addr = serdes_addr_to_sw(serdes_addr)
                if dbg_addr != 1:
                    log("dbg_addr is not 0x01.  Need to improve CLI for that")
                    return

            base_pci_addr = sw_addr_to_pci(sw_addr)
            base_serdes_addr = sw_addr_to_serdes(sw_addr)

            use_32bit = ((base_serdes_addr & 0xc000) == 0x8000)    # this is in the 'reserved' serdes space, and is thus an MPIC-local register
            if use_32bit:
                width_str = '32-bit'
                stride = 4
            else:
                width_str = '16-bit'
                stride = 2

            for offset in range(args.range):
                pci_addr = base_pci_addr + offset * stride
                sw_addr = pci_addr_to_sw(pci_addr)
                serdes_addr = sw_addr_to_serdes(sw_addr)
                if args.dry_run:
                    log('would %s read %s %04x[%d] [%04x:%04x:%08x]' % (width_str, args.bus, args.addr, offset, serdes_addr, sw_addr, pci_addr))
                else:
                    if use_32bit:
                        val = pci.read32(pci_addr)
                        log('%04x (%s) [%04x:%08x]: %08x' % (serdes_addr, width_str, sw_addr, pci_addr, val))
                    else:
                        val = pci.read16(pci_addr)
                        log('%04x (%s) [%04x:%08x]: %04x' % (serdes_addr, width_str, sw_addr, pci_addr, val))
    else: # not k2
        use_32bit = ((args.addr & 0xc000) == 0x8000)    # this is in the 'reserved' serdes space, and is thus an MPIC-local register
        if use_32bit:
            stride = 4
        else:
            stride = 2
        if args.lane is not None:
            for lane in args.lane:
                for offset in range(args.range):
                    addr = args.addr + offset * stride
                    addr_with_lane = sierra.add_lane_to_serdes_addr(addr, lane)
                    val = phy.serdes_read(addr, lane)
                    log('%04x[%d] (%04x): %04x' % (addr, lane, addr_with_lane, val))
        else:
            for offset in range(args.range):
                addr = args.addr + offset * stride
                val = phy.serdes_read(addr)
                log('%04x: %04x' % (args.addr, val))

def cli_write(args):
    phy = get_phy(0)
    if phy.is_k2:
        for lane in get_lane_list(args):
            if args.bus == 'mpic':
                sw_addr = args.addr
                serdes_addr = sw_addr_to_serdes(sw_addr)
            else:
                if args.lane is not None:
                    serdes_addr = sierra.add_lane_to_serdes_addr(args.addr, lane)
                else:
                    serdes_addr = args.addr
                sw_addr, dbg_addr = serdes_addr_to_sw(serdes_addr)
                if dbg_addr != 1:
                    log("dbg_addr is not 0x01.  Need to improve CLI for that")
                    return

            pci_addr = sw_addr_to_pci(sw_addr)
            use_32bit = ((serdes_addr & 0xc000) == 0x8000)    # this is in the 'reserved' serdes space, and is thus an MPIC-local register
            if use_32bit:
                width_str = '32-bit'
            else:
                width_str = '16-bit'

            if args.dry_run:
                log('would %s write %s %04x [%04x:%04x:%08x] : %04x' % (width_str, args.bus, args.addr, serdes_addr, sw_addr, pci_addr, args.value))
            else:
                log('Write %s %s %04x [%04x:%04x:%08x] : %04x' % (width_str, args.bus, args.addr, serdes_addr, sw_addr, pci_addr, args.value))
                if use_32bit:
                    pci.write32(pci_addr, args.value)
                else:
                    pci.write16(pci_addr, args.value)
    else:  # is not k2
        if args.bus == 'addlane':
            addr_with_lane = sierra.add_lane_to_serdes_addr(args.addr, args.lane)
            log('Write %04x[%d] (%04x): %04x' % (args.addr, args.lane, addr_with_lane, args.value))
            phy.serdes_write(args.addr, args.value, lane=args.lane)
        else:
            log('Write %04x: %04x' % (args.addr, args.value))
            phy.serdes_write(args.addr, args.value)

def cli_translate(args):
    for lane in get_lane_list(args):
        if args.pci is not None:
            pci_addr = args.pci
            sw_addr = k2_pci_addr_to_sw(pci_addr)
            serdes_addr = k2_sw_addr_to_serdes(sw_addr)
        elif args.mpic is not None:
            sw_addr = args.mpic
            pci_addr = k2_sw_addr_to_pci(sw_addr)
            serdes_addr = k2_sw_addr_to_serdes(sw_addr)
        else:
            if args.serdes is not None:
                serdes_addr = sierra.add_lane_to_serdes_addr(args.serdes, lane)
            elif args.raw_serdes is not None:
                serdes_addr = args.raw_serdes
            sw_addr, dbg = k2_serdes_addr_to_sw(serdes_addr)
            pci_addr = k2_sw_addr_to_pci(sw_addr)
            if dbg != 1:
                log('WARNING: dbg of %02x' % dbg)
        log('Serdes %04x :: MPIC %04x :: PCI %08x' % (serdes_addr, sw_addr, pci_addr))

def cli_config(orig_args):
    phy = get_phy(0)
    for lane in get_lane_list(orig_args):
        args = copy.deepcopy(orig_args)  # for multi-lane calls, don't overwrite the referenced args
        verbose = args.verbose
        args.verbose = None
        args.lane = None
        args.func = None
        phy.cli_config(lane, verbose, args)

def cli_ber(args):
    phy = get_phy(0)
    for lane in get_lane_list(args):
        data_rate = 1e9 * speed_get(lane)
        phy.show_ber(lane, args.time, data_rate)

def cli_process(args):
    phy = get_phy(0)
    if args.verbose:
        orig_log_reg_ops = sierra.log
        sierra.log = True
    f = args.file
    f.seek(0)
    for line in f:
        time.sleep(.01)
        no_comment = line.split('//')[0].split('#')[0][:-1]
        splitcmd = no_comment.split()
        if args.verbose:
            log(line[:-1])

        if len(splitcmd) < 2:
            continue
        cmd = splitcmd[0].upper()
        addr = int(splitcmd[1], 0)
        if len(splitcmd) >= 3:
            val = int(splitcmd[2], 0)
        else:
            val = None

        if cmd == 'WRITE':
            phy.serdes_write(addr, val)
        elif cmd == 'READ':
            read_val = phy.serdes_read(addr)
            if val != None and read_val != val:
                log('**** Read 0x%04x: got 0x%04x, expected 0x%04x' % (addr, read_val, val))
        elif cmd == 'WAIT':
            time.sleep(addr / 1000.0)
        else:
            log("Unexpected cmd '%s' in line '%s'" % (cmd, line))
    if args.verbose:
        sierra.log = orig_log_reg_ops

def cli_process_csv(args):
    phy = get_phy(0)
    if args.verbose:
        orig_log_reg_ops = sierra.log
        sierra.log = True
    f = args.file
    f.seek(0)
    for line in f:
        time.sleep(.01)
        # remove everything after //, or after #, and remove last character (the newline):
        no_comment = line.split('//')[0].split('#')[0][:-1]
        splitcmd = no_comment.split(",")
        if args.verbose:
            log(line[:-1])

        if len(splitcmd) < 3:
            continue
        addr = int(splitcmd[1], 0)
        val = int(splitcmd[2], 0)
        phy.serdes_write(addr, val)
    if args.verbose:
        sierra.log = orig_log_reg_ops

def add_parser(parser):
    parser.add_argument('--lane', type=parse_list, default=None)

    subparsers = parser.add_subparsers(help='All numerical arguments in hex')

    parser_status = subparsers.add_parser('status', help='show status')
    parser_status.set_defaults(func=cli_status)

    parser_read = subparsers.add_parser('read', help='read SerDes register')
    parser_read.add_argument('addr', type=Hex, help='address')
    parser_read.add_argument('--bus', '-b', type=str, choices=['serdes', 'addlane', 'mpic'], default='serdes')
    parser_read.add_argument('--dry-run', '-d', dest='dry_run', action='store_true')
    parser_read.add_argument('--range', type=int, default=1, help='number of entries to read')
    parser_read.set_defaults(func=cli_read)

    parser_write = subparsers.add_parser('write', help='write SerDes register')
    parser_write.add_argument('addr', type=Hex, help='address')
    parser_write.add_argument('value', type=Hex, help='value')
    parser_write.add_argument('--bus', '-b', type=str, choices=['serdes', 'addlane', 'mpic'], default='serdes')
    parser_write.add_argument('--dry-run', '-d', dest='dry_run', action='store_true')
    parser_write.set_defaults(func=cli_write)

    parser_creq = subparsers.add_parser('creq', help='CREQ debug')
    parser_creq.add_argument('diagidx', type=parse_list)
    parser_creq.set_defaults(func=cli_creq_diag)

    parser_deq = subparsers.add_parser('deq', help='DEQ debug')
    parser_deq.add_argument('diagidx', type=parse_list)
    parser_deq.set_defaults(func=cli_deq_diag)

    parser_eye = subparsers.add_parser('eye', help='Eye plot')
    parser_eye.add_argument('-C', '--collect', nargs='?', type=int, default=0, const=6, metavar='DEPTH', help='collect eye data (default depth 6)')
    parser_eye.add_argument('-p', '--plot', action='store_true', help='display eye plot')
    parser_eye.add_argument('-s', '--sizes', nargs='?', type=parse_list, default=None, const=[8, 12, 15],
                            help='print size at specified depths (default 8,12,15)')
    parser_eye.add_argument('-c', '--color', type=str.lower, choices=['gray', 'none'], default='normal')
    parser_eye.add_argument('-i', '--invert', action='store_true', help='invert color scale')
    parser_eye.add_argument('-S', '--save', type=argparse.FileType('w'), default=None, help='save data to file')
    parser_eye.add_argument('-v', '--verbose', action='store_true')
    parser_eye.add_argument('-q', '--quiet', action='store_true')
    parser_eye.add_argument('--cols', type=int, default=None, help='columns in textual plot')
    parser_eye.set_defaults(func=cli_eye)

    parser_bathtub = subparsers.add_parser('bathtub', help='Bathtub plot')
    parser_bathtub.add_argument('-H', '--horizontal', action='store_true', help='horizontal bathtub (default is vertical)')
    parser_bathtub.add_argument('-C', '--collect', nargs='?', type=int, const=7, metavar='DEPTH', help='collect bathtub data (default depth 7)')
    parser_bathtub.add_argument('-p', '--plot', nargs='?', type=int, default=None, const=14, metavar='DEPTH', help='plot bathtub [DEPTH: default 14]')
    parser_bathtub.add_argument('-s', '--sizes', nargs='?', type=parse_list, default=None, const=[8, 12, 15],
                            help='print size at specified depths (default 8,12,15)')
    parser_bathtub.add_argument('-S', '--save', type=argparse.FileType('w'), default=None, help='save data to file')
    parser_bathtub.add_argument('-v', '--verbose', action='store_true')
    parser_bathtub.add_argument('-q', '--quiet', action='store_true')
    parser_bathtub.add_argument('--cols', type=int, default=None, help='columns in textual plot')
    parser_bathtub.set_defaults(func=cli_bathtub)

    parser_ber = subparsers.add_parser('ber', help = 'show ber')
    parser_ber.add_argument('--time', type=int, default=5, help='maximum time for BER in seconds (def. 5)')
    parser_ber.set_defaults(func=cli_ber)

    parser_config = subparsers.add_parser('config', help='set configuration')
    # parser_config.add_argument('--speed', type=float)
    tx_type_group = parser_config.add_mutually_exclusive_group(required=False)
    #tx_type_group.add_argument('--tx-core', dest='tx_core', default=None, action='store_true', help='Disable test patterns, transmit normal data')
    parser_config.add_argument('--pre1', nargs='?', type=int, const=1000, default=None, help='Pre1 Tap value (default: restore serdes-generated value))')
    parser_config.add_argument('--main', nargs='?', type=int, const=1000, default=None, help='Main Tap value (default: restore serdes-generated value))')
    parser_config.add_argument('--post1', nargs='?', type=int, const=1000, default=None, help='Post1 Tap value (default: restore serdes-generated value))')
    parser_config.add_argument('--tx-margin', dest='tx_margin', nargs='?', type=int, const=1000, default=None, help='Tx margin value (default: restore serdes-generated value))')
    tx_type_group.add_argument('--tx-test', dest='tx_test', type=str.upper, choices=['PRBS7', 'PRBS15', 'PRBS23', 'PRBS31', 'OFF'])
    #tx_type_group.add_argument('--tx-pattern', dest='tx_pattern', type=Hex, help='Custom Tx test pattern, e.g. 0xaaaaaaaaaaaaaaaa')
    #tx_type_group.add_argument('--rx-tx-loopback', dest='rx_tx_loopback', action='store_true', help='Loop Rx out to Tx')
    #parser_config.add_argument('--tx-enable', dest='tx_enable', type=distutils.util.strtobool)
    #parser_config.add_argument('--tx-polarity', dest='tx_polarity', metavar='<bool>', type=distutils.util.strtobool)
    parser_config.add_argument('--verbose', '-v', default=None, action='store_true')
    #parser_config.add_argument('--rx-enable', dest='rx_enable', type=distutils.util.strtobool)    # no good method to do this right now
    #parser_config.add_argument('--rx-polarity', dest='rx_polarity', metavar='<bool>', type=distutils.util.strtobool)
    parser_config.add_argument('--rx-check', dest='rx_check', type=str.upper, choices=['PRBS7', 'PRBS15', 'PRBS23', 'PRBS31', 'OFF'])
    parser_config.set_defaults(func=cli_config)

    parser_process = subparsers.add_parser('process', help='process a serdes transaction log')
    parser_process.add_argument('file', type=argparse.FileType('r'), help='filename')
    parser_process.add_argument('--verbose', '-v', default=False, action='store_true')
    parser_process.set_defaults(func=cli_process)

    parser_process = subparsers.add_parser('csv', help='process a serdes csv file')
    parser_process.add_argument('file', type=argparse.FileType('r'), help='filename')
    parser_process.add_argument('--verbose', '-v', default=False, action='store_true')
    parser_process.set_defaults(func=cli_process_csv)

# for direct use from python
def run_cmd(arglist):
    try:
        while '##' in arglist or '#' in arglist or '//' in arglist:
            arglist.pop()
        arglist = ['--help' if a == 'help' else a for a in arglist]  # replace any 'help' arguments with '--help'

        parser = argparse.ArgumentParser(prog='diagtest serdes mgmt')
        add_parser(parser)
        args = parser.parse_args(arglist)
        rc = args.func(args)
        if rc == None:
            rc = ifcs.IFCS_SUCCESS
        return rc
    except ValueError as ex:
        log("Value Error: %s" % ":".join(ex.args))
    except Exception as ex:
        traceback.print_exc(file=sys.stdout)
        log("exception: ", type(ex).__name__, ex.args)
    except:
        log_dbg(1, "Error in serdes_mgmt_tl5 run_cmd: {}".format(sys.exc_info()))

    return ifcs.IFCS_INVAL