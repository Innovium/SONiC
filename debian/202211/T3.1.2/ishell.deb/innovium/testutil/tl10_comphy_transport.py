#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2023
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

import time
import ifcs_ctypes as ifcs
import ifcs_ctypes_tl10 as ifcs_tl10
from verbosity import log
from testutil import penrw as pen

APB_READ = 0
APB_WRITE = 1

def sd_reg_read(lanetriple, addr):
    ib, pic, laneidx = lanetriple
    if laneidx < 4:
        apbidx = 0
    else:
        apbidx = 1
    rsp_data = ifcs.c_uint(0)
    ifcs.im_devport_apb_access(0, ib, pic, apbidx, APB_READ,
                               addr, 0, ifcs.byref(rsp_data))
    return rsp_data.value

def sd_reg_write(lanetriple, addr, val):
    ib, pic, laneidx = lanetriple
    if laneidx < 4:
        apbidx = 0
    else:
        apbidx = 1
    rsp_data = ifcs.c_uint(0)
    ifcs.im_devport_apb_access(0, ib, pic, apbidx, APB_WRITE,
                               addr, val, ifcs.byref(rsp_data))

def issue_picmc_cmd(ib, pic, cmd, arg0=0, arg1=0, arg2=0):
    fields = [(ifcs.CMD_RESP_F, cmd), (ifcs.ARG0_F, arg0), (ifcs.ARG1_F, arg1), (ifcs.ARG2_F, arg2)]
    pen.write_pen(ifcs.PMC_CMD, 0, fields, ib=ib, pic=pic)
    for _ in list(range(100)):
        cmd_fields = pen.read_pen(ifcs.PMC_CMD, 0, ib=ib, pic=pic)
        if cmd_fields[0][1] != cmd:
            if cmd_fields[0][1] != 0:
                raise ValueError("Unexpected PICMC response: %d" % cmd_fields[0][1])
            break
        time.sleep(.1)
    else:
        raise Exception("Timed out waiting for PICMC response")

def serdes_idx_to_port(lanetriple):
    ib, pic, laneidx = lanetriple
    for p in range(8):
        fields = pen.read_platform_pen(ifcs_tl10.PMC_PORT_CFG, p, ib=ib, pic=pic)
        if fields[2][1] == laneidx:
            return p
    raise ValueError("No port for physical lane %d/%d/%d" % (ib, pic, laneidx))

def set_test_mode(lanetriple, enabled, speed, pll_on, tx_on, rx_on):
    ib, pic, laneidx = lanetriple
    fields = pen.read_platform_pen(ifcs_tl10.PMC_SERDES_CFG, laneidx, ib=ib, pic=pic)
    fields += [[ifcs_tl10.TEST_MODE_EN_F, int(enabled)]]
    if pll_on is not None:
        fields += [[ifcs_tl10.TEST_MODE_PLL_EN_F, int(pll_on)]]
    if tx_on is not None:
        try:
            fields += [[ifcs_tl10.TX_EN_F, int(tx_on)]]
        except:
            fields += [[ifcs_tl10.TX_OUTPUT_EN_F, int(tx_on)]]
    if rx_on is not None:
        fields += [[ifcs_tl10.RX_EN_F, int(rx_on)]]
    pen.write_platform_pen(ifcs_tl10.PMC_SERDES_CFG, laneidx, fields, ib=ib, pic=pic)

    # Load updated Serdes Cfg
    issue_picmc_cmd(ib, pic, ifcs_tl10.PMC_CMD_CMD_RESP_F_FW_CMD_UPDATE_SERDES_CFG, laneidx, laneidx)

def set_tx_prbs(lanetriple, prbs_mode):
    ib, pic, laneidx = lanetriple
    fields = pen.read_platform_pen(ifcs_tl10.PMC_SERDES_CFG, laneidx, ib=ib, pic=pic)
    if prbs_mode is None:
        fields += [(ifcs_tl10.PRBS_TX_EN_F, 0)]
    else:
        fields += [(ifcs_tl10.PRBS_POLY_ID_F, prbs_mode),
                   (ifcs_tl10.PRBS_TX_EN_F, 1)]
    pen.write_platform_pen(ifcs_tl10.PMC_SERDES_CFG, laneidx, fields, ib=ib, pic=pic)
    # Load updated Serdes Cfg
    issue_picmc_cmd(ib, pic, ifcs_tl10.PMC_CMD_CMD_RESP_F_FW_CMD_UPDATE_SERDES_CFG, laneidx, laneidx)

def set_rx_prbs(lanetriple, prbs_mode):
    ib, pic, laneidx = lanetriple
    fields = pen.read_platform_pen(ifcs_tl10.PMC_SERDES_CFG, laneidx, ib=ib, pic=pic)
    if prbs_mode is None:
        fields += [(ifcs_tl10.PRBS_RX_EN_F, 0)]
    else:
        fields += [(ifcs_tl10.PRBS_POLY_ID_F, prbs_mode),
                   (ifcs_tl10.PRBS_RX_EN_F, 1)]
    pen.write_platform_pen(ifcs_tl10.PMC_SERDES_CFG, laneidx, fields, ib=ib, pic=pic)
    # Load updated Serdes Cfg
    issue_picmc_cmd(ib, pic, ifcs_tl10.PMC_CMD_CMD_RESP_F_FW_CMD_UPDATE_SERDES_CFG, laneidx, laneidx)

def set_disable_restart(lanetriple, disable_restart):
    ib, pic, laneidx = lanetriple
    portidx = serdes_idx_to_port(lanetriple)
    port_cfg_fields = pen.read_platform_pen(ifcs_tl10.PMC_PORT_CFG, portidx, ib=ib, pic=pic)
    port_cfg_fields += [(ifcs_tl10.DISABLE_RESTART_F, disable_restart)]
    pen.write_platform_pen(ifcs_tl10.PMC_PORT_CFG, portidx, port_cfg_fields, ib=ib, pic=pic)
    issue_picmc_cmd(ib, pic, ifcs_tl10.PMC_CMD_CMD_RESP_F_FW_CMD_UPDATE_PORT_CFG, portidx, portidx)

def get_rx_state(lanetriple):
    ib, pic, laneidx = lanetriple
    eq_status_fields = pen.read_platform_pen(ifcs_tl10.PMC_SERDES_EQ_STATUS, laneidx, ib=ib, pic=pic)
    eq_time = eq_status_fields[2][1]  # 0 => not successfully equalized.  <10 sec (1e7) => maybe unstable
    if eq_time < 0:  # read_platform_pen is returning a signed value, so compensate
        eq_time += 1<<31
    if eq_time == 0:
        eq_state = "No signal"
    elif eq_time < 10.0e6:  # < 10 seconds
        eq_state = "Recent EQ"
    else:
        eq_state = "OK"

    portidx = serdes_idx_to_port(lanetriple)
    port_state_fields = pen.read_platform_pen(ifcs_tl10.PMC_PORT_STATE, portidx, ib=ib, pic=pic)

    # temporary: check for older fwpens
    if ifcs_tl10.PMC_PORT_STATE_FSM_STATE_F_PORT_UP < 190:
        disabled_max = ifcs_tl10.PMC_PORT_STATE_FSM_STATE_F_PORT_DISABLED
    else:
        disabled_max = 31

    if port_state_fields[0][1] <= disabled_max:
        eq_state = "Disabled"
    elif port_state_fields[0][1] < ifcs_tl10.PMC_PORT_STATE_FSM_STATE_F_PORT_UP:
        eq_state = "Down"

    serdes_cfg_fields = pen.read_platform_pen(ifcs_tl10.PMC_SERDES_CFG, laneidx, ib=ib, pic=pic)
    if serdes_cfg_fields[10][1] == 0:  # PRBS_RX_EN_F
        rx_prbs = "DATA"
    else:
        rx_prbs = "PRBS"
    return eq_state, rx_prbs

def get_rx_eq_history(lanetriple):
    ib, pic, laneidx = lanetriple
    eq_status_fields = pen.read_platform_pen(ifcs_tl10.PMC_SERDES_EQ_STATUS, laneidx, ib=ib, pic=pic)
    total_count = eq_status_fields[0][1]
    bounce_count = eq_status_fields[1][1]
    time_usec = eq_status_fields[2][1]
    if time_usec < 0:  # read_platform_pen is returning a signed value, so compensate
        time_usec += 1<<32

    if time_usec >= 1e9:
        time_usec = 999990000
    return total_count, bounce_count, time_usec * 1.0 / 1.0e6
