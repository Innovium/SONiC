#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------
""" Operations for Sierra PHY """

import sys
import time
from testutil import eyeplot
from utils.compat_util import *

regs_16 = {
    "PHY_ISO_CMN_CTRL": 0xC008,
    "PHY_PMA_LN_ISOLATION_CTRL": 0xE00E,
    "PHY_PMA_ISOLATION_CTRL": 0xE00F,
    "PHY_PMA_ISO_XCVR_CTRL": 0xF003,
    "PHY_PMA_ISO_CMN_CTRL": 0xE004,
    "PHY_PMA_ISO_CMN_PLLLC_CTRL": 0xE005,
    "PHY_PMA_ISO_PWRST_CTRL": 0xF00B,
    "PHY_ISO_LINK_CFG": 0xD00A,
    "PHY_PMA_ISO_LINK_MODE": 0xF00A,
    "TX_BIST_CONTROLS_PREG": 0x4078,
    "RX_BIST_CONTROLS_PREG": 0x41a8,
    "PHY_PMA_XCVR_CTRL": 0xf000,
    "RX_BIST_ERR_COUNT": 0x41ab,
    "PHY_PMA_ISO_TX_DMPH_LO": 0xf006,
    "PHY_PMA_ISO_TX_DMPH_HI": 0xf007,
    "PHY_PMA_ISO_RX_EQ_CTRL": 0xf00d,
    "RX_BIST_SYNCCNT_PREG": 0x41a9,
    "DRVCTRL_CM1_OVRD_PREG": 0x4066,
    "DRVCTRL_C0_OVRD_PREG": 0x4067,
    "DRVCTRL_CP1_OVRD_PREG": 0x4068,
    "DRVCTRL_C0M_OVRD_PREG": 0x4069,
    "DRVCTRL_CM1_CV_PREG": 0x406b,
    "DRVCTRL_C0_CV_PREG": 0x406c,
    "DRVCTRL_CP1_CV_PREG": 0x406d,
    "DRVCTRL_C0M_CV_PREG": 0x406e,
    "CLKPATH_BIASTRIM_PREG": 0x404b,
    "DFE_BIASTRIM_PREG": 0x404c,
    "DEQ_DIAG_SEL": 0x40c2,
    "DEQ_DIAG_READ": 0x40c3,
    "RX_CREQ_DIAG_SEL_PREG": 0x4094,
    "RX_CREQ_DIAG_READ": 0x4094,
    "DEQ_PICTRL_PREG": 0x4161,
    "DEQ_PICTRL_PREG__HIRES_OFFSET": 5,
    "DEQ_PICTRL_PREG__HIRES_WIDTH": 5,
    "DEQ_PICTRL_PREG__STEPSIZE_OFFSET": 3,
    "DEQ_PICTRL_PREG__STEPSIZE_WIDTH": 2,
    "DEQ_PICTRL_PREG__SETTLE_OFFSET": 0,
    "DEQ_PICTRL_PREG__SETTLE_WIDTH": 3,
    "DEQ_EYESURF_CTRL_PREG": 0x41a4,
    "DEQ_EYESURF_CTRL_PREG__TIME_OFFSET": 12,
    "DEQ_EYESURF_CTRL_PREG__TIME_WIDTH": 4,
    "DEQ_EYESURF_CTRL_PREG__VALID_OFFSET": 11,
    "DEQ_EYESURF_CTRL_PREG__VALID_WIDTH": 1,
    "DEQ_EYESURF_CTRL_PREG__START_OFFSET": 10,
    "DEQ_EYESURF_CTRL_PREG__START_WIDTH": 1,
    "DEQ_EYESURF_CTRL_PREG__MODE_OFFSET": 9,
    "DEQ_EYESURF_CTRL_PREG__MODE_WIDTH": 1,
    "DEQ_EYESURF_CTRL_PREG__EPIADJ_OFFSET": 0,
    "DEQ_EYESURF_CTRL_PREG__EPIADJ_WIDTH": 7,
    "DEQ_EYESURF_VTH_PREG": 0x41a5,
    "DEQ_EYESURF_ACCUMA": 0x41a6,
    "DEQ_EYESURF_ACCUMB": 0x41a7,
}

regs_7 = {
    "PHY_ISO_CMN_CTRL": 0xC008,
    "PHY_PMA_LN_ISOLATION_CTRL": 0xE00E,
    "PHY_PMA_ISOLATION_CTRL": 0xE00F,
    "PHY_PMA_ISO_XCVR_CTRL": 0xF003,
    "PHY_PMA_ISO_CMN_CTRL": 0xE004,
    "PHY_PMA_ISO_CMN_PLLLC_CTRL": 0xE005,
    "PHY_PMA_ISO_PWRST_CTRL": 0xF00B,
    "PHY_ISO_LINK_CFG": 0xD00A,
    "PHY_PMA_ISO_LINK_MODE": 0xF00A,
    "TX_BIST_CONTROLS_PREG": 0x4078,
    "RX_BIST_CONTROLS_PREG": 0x41a8,
    "PHY_PMA_XCVR_CTRL": 0xf000,
    "RX_BIST_ERR_COUNT": 0x41ab,
    "PHY_PMA_ISO_TX_DMPH_LO": 0xf006,
    "PHY_PMA_ISO_TX_DMPH_HI": 0xf007,
    "PHY_PMA_ISO_RX_EQ_CTRL": 0xf00d,
    "RX_BIST_SYNCCNT_PREG": 0x41a9,
    "DRVCTRL_CM1_OVRD_PREG": 0x4066,
    "DRVCTRL_C0_OVRD_PREG": 0x4067,
    "DRVCTRL_CP1_OVRD_PREG": 0x4068,
    "DRVCTRL_C0M_OVRD_PREG": 0x4069,
    "DRVCTRL_CM1_CV_PREG": 0x406b,
    "DRVCTRL_C0_CV_PREG": 0x406c,
    "DRVCTRL_CP1_CV_PREG": 0x406d,
    "DRVCTRL_C0M_CV_PREG": 0x406e,
    "CLKPATH_BIASTRIM_PREG": 0x404b,
    "DFE_BIASTRIM_PREG": 0x404c,
    "DEQ_DIAG_SEL": 0x4164,
    "DEQ_DIAG_READ": 0x4165,
    "RX_CREQ_DIAG_SEL_PREG": 0x4094,
    "RX_CREQ_DIAG_READ": 0x4094,
    "DEQ_EPIPWR_CTRL_PREG": 0x40ca,
    "DEQ_EYESURF_CTRL_PREG": 0x41a0,
    "DEQ_EYESURF_CTRL_PREG__TIME_OFFSET": 11,
    "DEQ_EYESURF_CTRL_PREG__TIME_WIDTH": 5,
    "DEQ_EYESURF_CTRL_PREG__START_OFFSET": 10,
    "DEQ_EYESURF_CTRL_PREG__START_WIDTH": 1,
    "DEQ_EYESURF_CTRL_PREG__MODE_OFFSET": 9,
    "DEQ_EYESURF_CTRL_PREG__MODE_WIDTH": 1,
    "DEQ_EYESURF_CTRL_PREG__VALID_OFFSET": 8,
    "DEQ_EYESURF_CTRL_PREG__VALID_WIDTH": 1,
    "DEQ_EYESURF_CTRL_PREG__EPIADJ_OFFSET": 0,
    "DEQ_EYESURF_CTRL_PREG__EPIADJ_WIDTH": 7,
    "DEQ_EYESURF_VTH_PREG": 0x41a1,
    "DEQ_EYESURF_ACCUMA": 0x41a2,
    "DEQ_EYESURF_ACCUMB": 0x41a3,
}

MAX_ITER_COUNT = 10000

PHY_CMN = 0  # common registers already include any 'lane bits', so equivalent to lane=0

rx_prbs_val = {
    'PRBS7':  0x0800,
    'PRBS15': 0x0900,
    'PRBS23': 0x0a00,
    'PRBS31': 0x0b00}

tx_prbs_val = {
    'PRBS7':  0x10,
    'PRBS15': 0x12,
    'PRBS23': 0x14,
    'PRBS31': 0x16 }

# crunch the N specified bits down to the low N bits (ordered N-1..0), and return them
def get_bits(val, bitlist):
    output = 0
    for bit in bitlist:
        output = output << 1
        if bit is not None:
            output = output | ((val >> bit) & 1)
    return output

def add_lane_to_serdes_addr(addr, lane):
    if (addr & 0xd000) == 0xd000:  # PHY macro, lane addressed
        return addr + lane * 0x0100
    if (addr & 0xe000) == 0x4000:  # PMA lane module reg
        return addr + lane * 0x0200
    # not lane-indexed:
    return addr

class Sierra(object):
    def __init__(self, num_lanes, read_reg, write_reg, toggle_enable, version):
        self.num_lanes = num_lanes
        self.base_read = read_reg
        self.base_write = write_reg
        self.toggle_port_enable = toggle_enable
        self.version = version
        if version == 16:
            self.regs = regs_16
        else:
            self.regs = regs_7
        self.eye_data, self.eye_errs, self.eye_samples = {}, {}, {}
        self.vert_bathtub_errs, self.vert_bathtub_samples = {}, {}
        self.horiz_bathtub_errs, self.horiz_bathtub_samples = {}, {}
        self.iso_set = set()
        self.log = False

    def serdes_read(self, addr, lane=0, silent=False):
        if type(addr) == str:
            addr = self.regs[addr]
        serdes_addr = add_lane_to_serdes_addr(addr,lane)
        val = self.base_read(serdes_addr)
        if self.log and not silent:
            log('  serdes_read %04x: %04x' % (serdes_addr, val))
        return val

    def serdes_write(self, addr, val, lane=PHY_CMN):
        if type(addr) == str:
            addr = self.regs[addr]
        serdes_addr = add_lane_to_serdes_addr(addr,lane)
        if self.log:
            log('  serdes_write %04x: %04x' % (serdes_addr, val))
        self.base_write(serdes_addr, val)

    def serdes_modify(self, addr, val, mask, lane=0):
        if type(addr) == str:
            addr = self.regs[addr]
        prev_val = self.serdes_read(addr, lane)
        new_val = ((prev_val & (0xffff ^ mask)) | (val & mask))
        self.serdes_write(addr, new_val, lane)

    # Note: all unspecified fields will be written as zero
    def serdes_write_fields(self, reg, fields, lane=PHY_CMN):
        val = 0
        for f in list(fields.keys()):
            offset = self.regs[reg + "__" + f + "_OFFSET"]
            width = self.regs[reg + "__" + f + "_WIDTH"]
            val |= ((fields[f] & ((1 << width) - 1)) << offset)
        self.serdes_write(reg, val, lane)

    def serdes_read_field(self, reg, field, lane=PHY_CMN):
        full_val = serdes_read(reg, lane)
        offset = self.regs[reg + "__" + field + "_OFFSET"]
        width = self.regs[reg + "__" + field + "_WIDTH"]
        return (full_val >> offset) & ((1 << width) - 1)

    def tx_eq_get(self, lane):
        # pre1: cm1, main: c0  post: cp1  margin: C0M
        pre = self.serdes_read("DRVCTRL_CM1_CV_PREG", lane)
        main = self.serdes_read("DRVCTRL_C0_CV_PREG", lane)
        post = self.serdes_read("DRVCTRL_CP1_CV_PREG", lane)
        margin = self.serdes_read("DRVCTRL_C0M_CV_PREG", lane)
        return pre, main, post, margin

    def tx_eq_override_get(self, lane):
        override_pre = self.serdes_read("DRVCTRL_CM1_OVRD_PREG", lane)
        override_active_pre = get_bits(override_pre, [8])

        override_main = self.serdes_read("DRVCTRL_C0_OVRD_PREG", lane)
        override_active_main = get_bits(override_main, [8])

        override_post = self.serdes_read("DRVCTRL_CP1_OVRD_PREG", lane)
        override_active_post = get_bits(override_post, [8])

        override_margin = self.serdes_read("DRVCTRL_C0M_OVRD_PREG", lane)
        override_active_margin = get_bits(override_margin, [8])
        return override_active_pre, override_active_main, override_active_post, override_active_margin

    def set_tx_prbs(self, prbs, lane):
        if prbs == 'OFF':
            self.update_iso(remove=('t%d'%lane))
            self.serdes_write(TX_BIST_CONTROLS_PREG, 0, lane)
        else:
            self.update_iso(add=('t%d'%lane))

            self.serdes_write("PHY_PMA_ISO_TX_DMPH_LO", 0x1901, lane)  # Tx de-emphasis lo & mid
            self.serdes_write("PHY_PMA_ISO_TX_DMPH_HI", 0x000a, lane)  # Tx de-emphasis hi

            self.serdes_write("TX_BIST_CONTROLS_PREG", tx_prbs_val[prbs], lane)
            self.serdes_write("TX_BIST_CONTROLS_PREG", tx_prbs_val[prbs] | 1, lane)

    def get_tx_prbs(self, lane):
        val = self.serdes_read("TX_BIST_CONTROLS_PREG", lane) & 0x16
        name = next((name for name, regval in tx_prbs_val.items() if regval == val), None)
        if name is None:
            return 'Unknown'
        else:
            return name

    def inject_tx_prbs_err(self, lane):
        val = self.serdes_read("TX_BIST_CONTROLS_PREG", lane)
        self.serdes_write(TX_BIST_CONTROLS_PREG, val | (1<<8), lane)

    def set_rx_prbs(self, prbs, lane):
        if prbs == 'OFF':
            self.update_iso(remove=('r%d'%lane))
        else:
            self.update_iso(add=('r%d'%lane))

            self.serdes_write("PHY_PMA_ISO_RX_EQ_CTRL", 0x3001, lane)
            self.serdes_write("PHY_PMA_ISO_RX_EQ_CTRL", 0x300a, lane)
            self.serdes_write("RX_BIST_SYNCCNT_PREG", 0x0200, lane)     # count needed for sync/lock

            self.serdes_write("RX_BIST_CONTROLS_PREG", rx_prbs_val[prbs], lane)
            self.serdes_write("RX_BIST_CONTROLS_PREG", rx_prbs_val[prbs] | 0x10, lane) # reset Rx BIST errors
            self.serdes_write("RX_BIST_CONTROLS_PREG", rx_prbs_val[prbs], lane)        # clear the reset
            self.serdes_write("RX_BIST_CONTROLS_PREG", rx_prbs_val[prbs] | 1, lane)    # start Rx BIST

    def get_rx_prbs(self, lane):
        val = self.serdes_read("RX_BIST_CONTROLS_PREG", lane) & 0x0b00
        name = next((name for name, regval in rx_prbs_val.items() if regval == val), None)
        if name is None:
            return 'Unknown'
        else:
            return name

    def get_bist_sync(self, lane):
        return (self.serdes_read("PHY_PMA_XCVR_CTRL", lane) & (1<<1) != 0)

    def get_prbs_errs(self, lane):
        return self.serdes_read("RX_BIST_ERR_COUNT", lane)

    def get_lane_iso_status(self, lane):
        iso_status = self.serdes_read("PHY_PMA_LN_ISOLATION_CTRL")
        return ((iso_status & (1<<lane)) != 0)

    def enter_power_state(self, lane, pwr_bits, in_reset=False):
        #log("enter power state %02x (in_reset: %s)" % (pwr_bits, in_reset))
        self.serdes_write("PHY_PMA_ISO_PWRST_CTRL", 0xc000 | pwr_bits, lane)
        time.sleep(.1)
        if not in_reset:
            ack = False
            iterations = 0
            for _ in range(MAX_ITER_COUNT):
                ack_bits = ((self.serdes_read("PHY_PMA_ISO_PWRST_CTRL", lane, silent=True) & 0x3f00) >> 8)
                if ack_bits == pwr_bits:
                    # a non-silent read, in case we're verbose:
                    self.serdes_read("PHY_PMA_ISO_PWRST_CTRL", lane)
                    break
            else:
                log('Timeout:  PHY_PMA_ISO_PWRST_CTRL to %02x, stuck with: %04x' % (pwr_bits, self.serdes_read("PHY_PMA_ISO_PWRST_CTRL", lane)))
            #print 'Iterations for Power state ack: %d' % iterations
        self.serdes_write("PHY_PMA_ISO_PWRST_CTRL", 0xc000, lane)

    def update_iso(self, add=None, remove=None):
        before = self.iso_set.copy()
        if add is not None:
            self.iso_set.add(add)
        if remove is not None:
            self.iso_set.discard(remove)
        if len(before) == 0 and len(self.iso_set) > 0:
            self.enable_iso()
        elif len(before) > 0 and len(self.iso_set) == 0:
            self.disable_iso()

    def enable_iso(self):
        log('Enabling isolation mode on all serdes lanes')
        all_lanes = compat_listrange(self.num_lanes)
        iso_bitmap = 0
        for lane in all_lanes:
            iso_bitmap |= (1<<lane)
        self.serdes_write("PHY_ISO_CMN_CTRL", 0x0000)                          # assert PHY_RESET
        self.serdes_write("PHY_PMA_LN_ISOLATION_CTRL", iso_bitmap)             # select lanes in isolation
        self.serdes_write("PHY_PMA_ISOLATION_CTRL",    0xd000)                 # select PMA isolaton mode and enable isolation
        for lane in all_lanes:
            self.serdes_write("PHY_PMA_ISO_XCVR_CTRL",     0x0001, lane)       # enable lane when in PMA ISO
        self.serdes_write("PHY_PMA_ISO_CMN_CTRL",      0x3102)                 # COMMON RESET AND SELECT DIG_DIV FOR COMMON CLOCK
        self.serdes_write("PHY_PMA_ISO_CMN_PLLLC_CTRL",0x0001)                 # SET COMMON PLL MODE,ENABLE CMN PLL
        for lane in all_lanes:
            self.serdes_write("PHY_PMA_ISO_PWRST_CTRL",    0xc000, lane)
            self.serdes_write("PHY_ISO_LINK_CFG",          0x8000, lane)
            self.serdes_write("PHY_PMA_ISO_LINK_MODE",     0x1002, lane)       # set data width, mode
            self.enter_power_state(lane, 0x3, in_reset=True)                 # enter a2

            self.serdes_write("PHY_PMA_ISO_XCVR_CTRL",     0x0181, lane)       # release link reset,enable xcvr_pllclk

        time.sleep(.1)
        for lane in all_lanes:
            self.serdes_write("PHY_PMA_ISO_XCVR_CTRL",     0x0183, lane)       # enable PMA rx termination

        self.serdes_write("PHY_ISO_CMN_CTRL",          0x0001)                 # release PHY_RESET
        self.serdes_write("PHY_PMA_ISO_CMN_CTRL",      0x3303)                 # release CMN_RESET
        time.sleep(.1) # XXX  Without this delay, we get more errors / no sync

        # wait for common ready
        pwr_en_ack = False
        iterations = 0
        for _ in range(MAX_ITER_COUNT):
            if (self.serdes_read("PHY_PMA_ISO_CMN_CTRL", silent=True) & 0x2000) == 0x2000:
                break
        else:
            log('Timeout:  PHY_PMA_ISO_CMN_CTRL: %04x' % self.serdes_read("PHY_PMA_ISO_CMN_CTRL"))

        for lane in all_lanes:
            self.enter_power_state(lane, 0x1, in_reset = False)              # enter a0

    def disable_iso(self):
        log('Disabling isolation mode on all serdes lanes')
        all_lanes = compat_listrange(self.num_lanes)
        self.serdes_write("PHY_ISO_CMN_CTRL",              0x0000)             # assert PHY_RESET
        self.serdes_write("PHY_PMA_LN_ISOLATION_CTRL",     0x0000)             # remove all lanes from isolation bitmap
        self.serdes_write("PHY_PMA_ISOLATION_CTRL",        0x0000)             # disable isolation
        for lane in all_lanes:
            self.serdes_write("PHY_PMA_ISO_XCVR_CTRL",     0x0000, lane)       # clear lane in PMA ISO
        self.serdes_write("PHY_PMA_ISO_CMN_CTRL",          0x0001)             # clear to reset value
        self.serdes_write("PHY_PMA_ISO_CMN_PLLLC_CTRL",    0x0000)             # clear to reset value
        for lane in all_lanes:
            self.serdes_write("PHY_PMA_ISO_PWRST_CTRL",    0x0000, lane)       # clear to reset value
        time.sleep(.1)
        for lane in all_lanes:
            self.serdes_write("PHY_ISO_LINK_CFG",          0x0000, lane)       # clear to reset value
            self.serdes_write("PHY_PMA_ISO_LINK_MODE",     0x1000, lane)       # clear to reset value
        self.serdes_write("PHY_ISO_CMN_CTRL",              0x0001)             # de-assert PHY_RESET
        time.sleep(.5)
        self.toggle_port_enable()

    # get error counts over a specified time interval for EYE BER:
    def get_eye_errs(self, lane, pi, lg2_samples):
        ctrl_fields = {"TIME": (lg2_samples-1), "MODE": 1, "START": 0, "EPIADJ": pi}
        self.serdes_write_fields("DEQ_EYESURF_CTRL_PREG", ctrl_fields, lane=lane)
        ctrl_fields["START"] = 1
        self.serdes_write_fields("DEQ_EYESURF_CTRL_PREG", ctrl_fields, lane=lane)

        for _ in range(1000):
            if self.serdes_read_field("DEQ_EYESURF_CTRL_PREG", "VALID", lane=lane):
                break
        else:
            raise Exception("Timeout waiting for serdes eye data")

        pos = self.serdes_read("DEQ_EYESURF_ACCUMA")
        neg = self.serdes_read("DEQ_EYESURF_ACCUMB")

        ctrl_fields["START"] = 0
        self.serdes_write_fields("DEQ_EYESURF_CTRL_PREG", ctrl_fields, lane=lane)
        return pos,neg


    # get BER at specified time offset, using get_eye_errs with various time intervals
    #   'pi' units are 64*UI, so 32 is typical limit
    #   'ber_thresh' is BER threshold: 7 => 10^-7
    #   'sample_scaling' is 2 for 10G-KR, since it gets two error samples per interval
    #   Returns error count, and number of samples.  BER is count/samples

    def get_eye_point(self, lane, pi, ber_thresh, sample_scaling):
        # we can set the sample length, so start with short samples and go to longer
        # use the longest interval that doesn't saturate the counter
        pos_done, neg_done = False, False
        max_samples = 100 * 10**ber_thresh / sample_scaling  # so we get ~100 samples at ber thresh, or ~10% error at threshold
        for lg2_samples in [8, 12, 14, 16]:
            this_pos, this_neg = self.get_eye_errs(lane, pi, lg2_samples)

            # Don't use saturated values.  The shortest interval can't saturate, so we'll always have at least one good one
            if this_pos < 0x3ff:
                pos = this_pos
                pos_samples = 1<<lg2_samples
            else:
                pos_done = True

            if this_neg < 0x3ff:
                neg = this_neg
                neg_samples = 1<<lg2_samples
            else:
                neg_done = True
            if pos_done and neg_done:
                return pos, pos_samples*sample_scaling, neg, neg_samples*sample_scaling

        itit = 0
        while (pos < 100 and pos_samples < max_samples and not pos_done) or (neg < 100 and neg_samples < max_samples and not neg_done):
            this_pos, this_neg = self.get_eye_errs(lane, pi, 16)
            if not pos_done:
                pos += this_pos
                pos_samples += (1<<16)
            if not neg_done:
                neg += this_neg
                neg_samples += (1<<16)

        return pos, pos_samples*sample_scaling, neg, neg_samples*sample_scaling

    def collect_eye_data(self, lane, lg_depth, sample_scaling, quiet=False, verbose=False):
        skip_core = True
        pi_step = 2
        v_step = 2
        if verbose:
            start_time = time.time()
        if self.version == 16:
            self.serdes_write(0x40ca, 0x8190, lane=lane)
        self.serdes_write_fields("DEQ_PICTRL_PREG", {"HIRES": 1, "STEPSIZE": 0, "SETTLE": 3}, lane=lane)
        time.sleep(.01)
        self.serdes_write_fields("DEQ_EYESURF_CTRL_PREG", {"TIME": 0xf, "MODE": 1}, lane=lane)
        time.sleep(.01)
        eye_errs, eye_samples = [], []
        for vt in range(0, 97, v_step):  # v threshold in ~3mV units
            self.serdes_write ("DEQ_EYESURF_VTH_PREG", vt, lane=lane)
            time.sleep(.01)
            left_pos_err_line, left_neg_err_line = [], []
            left_pos_samples_line, left_neg_samples_line = [], []
            core_samples = 0
            for pi in range(-32, 33, pi_step):
                pos, pos_samples, neg, neg_samples = self.get_eye_point(lane, pi, lg_depth, sample_scaling)
                #print('Left:', pos, pos_samples, neg, neg_samples)
                left_pos_err_line += [pos]
                left_pos_samples_line += [pos_samples]
                left_neg_err_line += [neg]
                left_neg_samples_line += [neg_samples]
                in_eye = (pos == 0 and neg == 0)
                left_eye_wall = pi
                if in_eye and skip_core:
                    core_samples = pos_samples
                    break
            right_pos_err_line, right_neg_err_line = [], []
            right_pos_samples_line, right_neg_samples_line = [], []
            right_eye_wall = 32 + pi_step
            for pi in range(32, left_eye_wall, -pi_step):
                pos, pos_samples, neg, neg_samples = self.get_eye_point(lane, pi, lg_depth, sample_scaling)
                #print('Right:', pos, pos_samples, neg, neg_samples)
                right_pos_err_line = [pos] + right_pos_err_line
                right_pos_samples_line = [pos_samples] + right_pos_samples_line
                right_neg_err_line = [neg] + right_neg_err_line
                right_neg_samples_line = [neg_samples] + right_neg_samples_line
                in_eye = (pos == 0 and neg == 0)
                right_eye_wall = pi
                if in_eye and skip_core:
                    core_samples = neg_samples
                    break
            num_in_eye = (right_eye_wall - left_eye_wall)/pi_step - 1
            neg_err_line = left_neg_err_line + [0]*num_in_eye + right_neg_err_line
            neg_samples_line = left_neg_samples_line + [core_samples] * num_in_eye + right_neg_samples_line
            pos_err_line = left_pos_err_line + [0]*num_in_eye + right_pos_err_line
            pos_samples_line = left_pos_samples_line + [core_samples] * num_in_eye + right_pos_samples_line

            if vt == 0:
                eye_errs = [pos_err_line]
                eye_samples =  [pos_samples_line]
            else:
                eye_errs = [neg_err_line] + eye_errs + [pos_err_line]
                eye_samples = [neg_samples_line] + eye_samples + [pos_samples_line]

            if not quiet:
                sys.stdout.write('.') ; sys.stdout.flush()

        self.serdes_write_fields ("DEQ_EYESURF_CTRL_PREG", {"TIME": 0xf, "MODE": 0}, lane=lane)
        if self.version == 16:
            self.serdes_write(0x40CA, 0x0190, lane=lane)

        width = len(eye_errs[0])
        half_width = (width-1) // 2
        height = len(eye_errs)
        half_height = (height-1) // 2

        horiz_bathtub_errs = eye_errs[half_height][:]
        horiz_bathtub_samples = eye_samples[half_height][:]

        vert_bathtub_errs, vert_bathtub_samples = [], []
        for i in range(height):
            vert_bathtub_errs += [eye_errs[i][half_width]]
            vert_bathtub_samples += [eye_samples[i][half_width]]

        if not quiet:
            log('')

        eye_data = eye_errs[:]
        for hidx, line in enumerate(eye_errs):
            eye_data[hidx] = line[:]
            for vidx, err in enumerate(line):
                eye_data[hidx][vidx] = (1.0 * err) / eye_samples[hidx][vidx]

        if verbose:
            elapsed_time = time.time() - start_time
            log('Depth %d, elapsed time: %s' % (lg_depth, str(elapsed_time)))

        self.eye_data[lane] = eye_data
        self.horiz_bathtub_errs[lane] = horiz_bathtub_errs
        self.horiz_bathtub_samples[lane] = horiz_bathtub_samples
        self.vert_bathtub_errs[lane] = vert_bathtub_errs
        self.vert_bathtub_samples[lane] = vert_bathtub_samples

    def collect_horiz_bathtub_data(self, lane, lg_depth, sample_scaling, quiet=False, verbose=False):
        skip_core = True
        pi_step = 2
        if verbose:
            start_time = time.time()
        self.serdes_write(0x40ca, 0x8190, lane=lane)
        self.serdes_write (0x4161, 0x0023, lane=lane)
        time.sleep(.01)
        self.serdes_write (0x41A4, 0xF200, lane=lane)
        time.sleep(.01)
        vt = 0
        self.serdes_write (0x41A5, vt, lane=lane)
        time.sleep(.01)
        left_pos_err_line = []
        left_pos_samples_line = []
        core_samples = 0
        for pi in range(-32, 33, pi_step):
            pos, pos_samples, _, _ = self.get_eye_point(lane, pi, lg_depth, sample_scaling)
            if not quiet:
                sys.stdout.write('.') ; sys.stdout.flush()
            left_pos_err_line += [pos]
            left_pos_samples_line += [pos_samples]
            in_eye = (pos == 0)
            left_eye_wall = pi
            if in_eye and skip_core:
                core_samples = pos_samples
                break

        right_pos_err_line = []
        right_pos_samples_line = []
        right_eye_wall = 32 + pi_step
        for pi in range(32, left_eye_wall, -pi_step):
            pos, pos_samples, _, _ = self.get_eye_point(lane, pi, lg_depth, sample_scaling)
            if not quiet:
                sys.stdout.write('.') ; sys.stdout.flush()
            right_pos_err_line = [pos] + right_pos_err_line
            right_pos_samples_line = [pos_samples] + right_pos_samples_line
            in_eye = (pos == 0)
            right_eye_wall = pi
            if in_eye and skip_core:
                core_samples = pos_samples
                break
        num_in_eye = (right_eye_wall - left_eye_wall)/pi_step - 1
        pos_err_line = left_pos_err_line + [0]*num_in_eye + right_pos_err_line
        pos_samples_line = left_pos_samples_line + [core_samples] * num_in_eye + right_pos_samples_line

        self.serdes_write(0x41A4, 0xF000, lane=lane)
        self.serdes_write(0x40CA, 0x0190, lane=lane)

        if not quiet:
            log('')

        if verbose:
            elapsed_time = time.time() - start_time
            log('Depth %d, elapsed time: %s' % (lg_depth, str(elapsed_time)))
        self.horiz_bathtub_errs[lane] = pos_err_line
        self.horiz_bathtub_samples[lane] = pos_samples_line

    def collect_vert_bathtub_data(self, lane, lg_depth, sample_scaling, quiet=False, verbose=False):
        skip_core = True
        v_step = 2
        if verbose:
            start_time = time.time()
        self.serdes_write(0x40ca, 0x8190, lane=lane)
        self.serdes_write (0x4161, 0x0023, lane=lane)
        time.sleep(.01)
        self.serdes_write (0x41A4, 0xF200, lane=lane)
        time.sleep(.01)
        pi = 0

        pos_err_line, neg_err_line = [], []
        pos_samp_line, neg_samp_line = [], []
        in_core = False
        for vt in range(96, -1, -v_step):  # v threshold in ~3mV units
            if not in_core:
                self.serdes_write(0x41A5, vt, lane=lane)
                time.sleep(.01)
                pos, pos_samples, neg, neg_samples = self.get_eye_point(lane, pi, lg_depth, sample_scaling)
                if skip_core and pos == 0 and neg == 0:
                    in_core = True
            pos_err_line = [pos] + pos_err_line
            pos_samp_line = [pos_samples] + pos_samp_line
            if vt != 0:
                neg_err_line += [neg]
                neg_samp_line += [neg_samples]
            if not quiet:
                sys.stdout.write('.') ; sys.stdout.flush()
        err_line = neg_err_line + pos_err_line
        samp_line = neg_samp_line + pos_samp_line

        self.serdes_write(0x41A4, 0xF000, lane=lane)
        self.serdes_write(0x40CA, 0x0190, lane=lane)

        if not quiet:
            log('')

        if verbose:
            elapsed_time = time.time() - start_time
            log('Depth %d, elapsed time: %s' % (lg_depth, str(elapsed_time)))

        self.vert_bathtub_errs[lane] = err_line
        self.vert_bathtub_samples[lane] = samp_line

    def cli_eye(self, lane, sample_scaling, args):
        if args.collect:
            self.collect_eye_data(lane, abs(args.collect), sample_scaling, quiet=args.quiet, verbose=args.verbose)
        elif lane not in self.eye_data:
            log('No eye data for lane %d' % lane)
            return

        if args.save is not None:
            for line in self.eye_data[lane]:
                for pt in line:
                    args.save.write('%.2e ' % pt)
                args.save.write('\n')
            args.save.flush()

        if args.plot:
            eyeplot.print_ascii_eye_plot(self.eye_data[lane], True, color=(args.color != 'none'), invert=args.invert, columns=args.cols)
            if args.sizes is not None:
                log("")
        if args.sizes is not None:
            v_step = 2
            pi_step = 2
            bers = [10.0**(-abs(level)) for level in args.sizes]
            vts = [vt * 3.0 for vt in range(-96, 97, v_step)]
            heights = eyeplot.bathtub_widths(vts, self.vert_bathtub_errs[lane], self.vert_bathtub_samples[lane], [1e-4, 1e-2], bers)

            pis = [p/64.0*100.0 for p in range(-32, 33, pi_step)] # time offset in UI/64 -> % UI
            widths = eyeplot.bathtub_widths(pis, self.horiz_bathtub_errs[lane], self.horiz_bathtub_samples[lane], [1e-4, 1e-2], bers)
            eyeplot.print_size_table(bers, ['Width (%UI)', 'Height (mV)'], widths + heights)

    def cli_bathtub(self, lane, sample_scaling, args):
        if args.horizontal:
            pi_step = 2

            if args.collect:
                self.collect_horiz_bathtub_data(lane, abs(args.collect), sample_scaling)
            elif lane not in self.horiz_bathtub_samples:
                log('No horizontal bathtub data for lane %d' % lane)
                return

            if args.plot is not None:
                pis = [p/64.0*100.0 for p in range(-32, 33, pi_step)] # time offset in UI/64 -> % UI
                plot_depth = 10**(-abs(args.plot))
                eyeplot.print_ascii_bathtub(pis, self.horiz_bathtub_errs[lane], self.horiz_bathtub_samples[lane], plot_depth, [1e-4, 1e-2], args.cols)
                if args.sizes is not None:
                    log("")

            if args.sizes is not None:
                bers = [10.0**(-abs(level)) for level in args.sizes]
                pis = [p/64.0*100.0 for p in range(-32, 33, pi_step)] # time offset in UI/64 -> % UI
                widths = eyeplot.bathtub_widths(pis, self.horiz_bathtub_errs[lane], self.horiz_bathtub_samples[lane], [1e-4, 1e-2], bers)
                eyeplot.print_size_table(bers, ['Width (%UI)'], widths)

        else:  # vertical
            v_step = 2
            if args.collect:
                self.collect_vert_bathtub_data(lane, abs(args.collect), sample_scaling)
            else:
                if lane not in self.vert_bathtub_samples:
                    log('No vertical bathtub data for lane %d' % lane)
                    return

            if args.save is not None:
                for e,s in zip(self.vert_bathtub_errs, self.vert_bathtub_samples):
                    args.save.write('%d  %d  %.2e\n' % (e, s, 1.0*e/s))
                args.save.flush()

            if args.plot is not None:
                vts = [vt * 3.0 for vt in range(-96, 97, v_step)]
                plot_depth = 10**(-abs(args.plot))
                eyeplot.print_ascii_bathtub(vts, self.vert_bathtub_errs[lane], self.vert_bathtub_samples[lane], plot_depth, [1e-4, 1e-2], args.cols)
                if args.sizes is not None:
                    log("")

            if args.sizes is not None:
                bers = [10.0**(-abs(level)) for level in args.sizes]
                vts = [vt * 3.0 for vt in range(-96, 97, v_step)]
                heights = eyeplot.bathtub_widths(vts, self.vert_bathtub_errs[lane], self.vert_bathtub_samples[lane], [1e-4, 1e-2], bers)
                eyeplot.print_size_table(bers, ['Height (mV)'], heights)


    def show_ber(self, lane, collection_time, data_rate):
        if not self.get_lane_iso_status(lane):
            log("Lane %d not in isolation" % lane)
            return
        if not self.get_bist_sync(lane):
            log("Lane %d not synced" % lane)
            return
        bist_ctrl = self.serdes_read("RX_BIST_CONTROLS_PREG", lane)
        total_errors = 0
        max_ber = .1
        print_status = False
        accum_time = collection_time
        start_time = time.time()
        last_print_time = start_time
        this_time = start_time
        errs = 0
        self.serdes_write("RX_BIST_CONTROLS_PREG", bist_ctrl | 0x10, lane) # reset Rx BIST errors

        while (this_time - start_time < accum_time and errs < 0xffff):
            errs = self.get_prbs_errs(lane)
            this_time = time.time()
            if this_time - last_print_time > 1 and print_status:
                sys.stdout.write('.') ; sys.stdout.flush()
                last_print_time = this_time
        if print_status:
            sys.stdout.write('\n') ; sys.stdout.flush()

        ber = errs / ((this_time - start_time) * data_rate)
        log("Lane %d BER: %0.3e" % (lane, ber))

    def status_str(self, lane):
        # Get Tx Taps
        pre, main, post, margin = self.tx_eq_get(lane)
        pre_fixed, main_fixed, post_fixed, margin_fixed = self.tx_eq_override_get(lane)
        pre_status = '*' if pre_fixed else ''
        main_status = '*' if main_fixed else ''
        post_status = '*' if post_fixed else ''
        margin_status = '*' if margin_fixed else ''

        # Get Rx
        clkpath_preg = self.serdes_read("CLKPATH_BIASTRIM_PREG", lane)
        clk_ctle_main = get_bits(clkpath_preg, [8,7,6])
        clk_ctle_ind = get_bits(clkpath_preg, [5,4,3])
        clk_samp_ind = get_bits(clkpath_preg, [2,1,0])

        dfe_preg = self.serdes_read("DFE_BIASTRIM_PREG", lane)
        dfe_smp = get_bits(dfe_preg, [15,14,13,12])
        dfe_idac = get_bits(dfe_preg, [11,10,9,8])
        dfe_sum = get_bits(dfe_preg, [7,6,5,4])
        dfe_amp = get_bits(dfe_preg, [3,2,1,0])

        # Get ISO state
        if self.get_lane_iso_status(lane):
            out = 'Mode: ISO\n'
        else:
            out = 'Mode: Normal\n'
        out += 'Tx  Pre1: %d%s,  Main: %d%s,  Post: %d%s,  Margin: %d%s\n' % (pre, pre_status, main, main_status, post, post_status, margin, margin_status)
        out += 'Rx  Clk CTLE: %d %d %d   DFE: %d %d %d %d\n' % (clk_ctle_main, clk_ctle_ind, clk_samp_ind, dfe_smp, dfe_idac, dfe_sum, dfe_amp)
        return out

    def cli_config(self, lane, verbose, args):
        initial_log_reg_ops = self.log
        if verbose:
            self.log = True

        if all(v is None for v in vars(args).values()):
            # no arguments passed: just show the current config
            if self.get_lane_iso_status(lane):
                log("Lane %d in isolation state" % lane)
                log("Tx: %s, Rx: %s" % (self.get_tx_prbs(lane), self.get_rx_prbs(lane)))
                log("Rx Sync: %d,  Err Count: 0x%04x" % (get_bist_sync(lane), get_prbs_errs(lane)))
            else:
                log("Lane %d in normal state" % lane)
            self.log = initial_log_reg_ops
            return

        if args.tx_test:
            self.set_tx_prbs(args.tx_test, lane)

        if args.rx_check:
            self.set_rx_prbs(args.rx_check, lane)
        self.log = initial_log_reg_ops

        if args.pre1 is not None:
            if args.pre1 == 1000:
                self.serdes_write("DRVCTRL_CM1_OVRD_PREG", 0, lane)
            else:
                self.serdes_write("DRVCTRL_CM1_OVRD_PREG", 0x0100 | (args.pre1 & 0x7f), lane)

        if args.main is not None:
            if args.main == 1000:
                self.serdes_write("DRVCTRL_C0_OVRD_PREG", 0, lane)
            else:
                self.serdes_write("DRVCTRL_C0_OVRD_PREG", 0x0100 | (args.main & 0x7f), lane)

        if args.post1 is not None:
            if args.post1 == 1000:
                self.serdes_write("DRVCTRL_CP1_OVRD_PREG", 0, lane)
            else:
                self.serdes_write("DRVCTRL_CP1_OVRD_PREG", 0x0100 | (args.post1 & 0x7f), lane)

        if args.tx_margin is not None:
            if args.tx_margin == 1000:
                self.serdes_write("DRVCTRL_C0M_OVRD_PREG", 0, lane)
            else:
                self.serdes_write("DRVCTRL_C0M_OVRD_PREG", 0x0100 | (args.tx_margin & 0x7f), lane)

    def cli_creq_diag(self, lane, args):
        for idx in args.diagidx:
            self.serdes_write("RX_CREQ_DIAG_SEL_PREG", 0x0000 + idx, lane)
            self.serdes_write("RX_CREQ_DIAG_SEL_PREG", 0x0400 + idx, lane)
            time.sleep(.5)
            val = self.serdes_read("RX_CREQ_DIAG_READ", lane)
            log('lane %d CREQ 0x%x: %04x' % (lane, idx, val))

    def cli_deq_diag(self, lane, args):
        for idx in args.diagidx:
            self.serdes_write("DEQ_DIAG_SEL", 0x0000 + idx, lane)
            time.sleep(.5)
            val = self.serdes_read("DEQ_DIAG_READ", lane)
            log('lane %d DEQ 0x%x: %04x' % (lane, idx, val))
