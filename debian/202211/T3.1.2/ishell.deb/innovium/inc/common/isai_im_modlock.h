/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file isai_modlock.h
 * @brief Header file that "calculates" the lock needed by a module
 *        Safe for recursive includes.
 *
 */

#include <sys/syscall.h>
#ifdef __ISAI_IM_MODLOCK_H__
#error "isai_im_modlock.h can only be included from the .c file"
#endif

#define __ISAI_IM_MODLOCK_H__

#include "common/isai_im_modlockdef.h"


#ifndef    ISAI_MODULE_LOCK_ACL
#define    ISAI_MODULE_LOCK_ACL    0
#endif

#ifndef    ISAI_MODULE_LOCK_BRIDGE
#define    ISAI_MODULE_LOCK_BRIDGE    0
#endif

#ifndef    ISAI_MODULE_LOCK_BUFFER
#define    ISAI_MODULE_LOCK_BUFFER    0
#endif

#ifndef    ISAI_MODULE_LOCK_DEBUG_COUNTER
#define    ISAI_MODULE_LOCK_DEBUG_COUNTER    0
#endif

#ifndef    ISAI_MODULE_LOCK_FDB
#define    ISAI_MODULE_LOCK_FDB    0
#endif

#ifndef    ISAI_MODULE_LOCK_HASH
#define    ISAI_MODULE_LOCK_HASH    0
#endif

#ifndef    ISAI_MODULE_LOCK_HOSTIF
#define    ISAI_MODULE_LOCK_HOSTIF    0
#endif

#ifndef    ISAI_MODULE_LOCK_ISOLATION_GROUP
#define    ISAI_MODULE_LOCK_ISOLATION_GROUP    0
#endif

#ifndef    ISAI_MODULE_LOCK_L2MC_GROUP
#define    ISAI_MODULE_LOCK_L2MC_GROUP    0
#endif

#ifndef    ISAI_MODULE_LOCK_LAG
#define    ISAI_MODULE_LOCK_LAG    0
#endif

#ifndef    ISAI_MODULE_LOCK_MIRROR
#define    ISAI_MODULE_LOCK_MIRROR    0
#endif

#ifndef    ISAI_MODULE_LOCK_NEIGHBOR
#define    ISAI_MODULE_LOCK_NEIGHBOR    0
#endif

#ifndef    ISAI_MODULE_LOCK_NEXTHOP
#define    ISAI_MODULE_LOCK_NEXTHOP    0
#endif

#ifndef    ISAI_MODULE_LOCK_NEXTHOPGROUP
#define    ISAI_MODULE_LOCK_NEXTHOPGROUP    0
#endif

#ifndef    ISAI_MODULE_LOCK_POLICER
#define    ISAI_MODULE_LOCK_POLICER    0
#endif

#ifndef    ISAI_MODULE_LOCK_PORT
#define    ISAI_MODULE_LOCK_PORT    0
#endif

#ifndef    ISAI_MODULE_LOCK_QOSMAP
#define    ISAI_MODULE_LOCK_QOSMAP    0
#endif

#ifndef    ISAI_MODULE_LOCK_QUEUE
#define    ISAI_MODULE_LOCK_QUEUE    0
#endif

#ifndef    ISAI_MODULE_LOCK_ROUTE
#define    ISAI_MODULE_LOCK_ROUTE    0
#endif

#ifndef    ISAI_MODULE_LOCK_ROUTER
#define    ISAI_MODULE_LOCK_ROUTER    0
#endif

#ifndef    ISAI_MODULE_LOCK_ROUTERINTF
#define    ISAI_MODULE_LOCK_ROUTERINTF    0
#endif


#ifndef    ISAI_MODULE_LOCK_SAMPLEPACKET
#define    ISAI_MODULE_LOCK_SAMPLEPACKET    0
#endif

#ifndef    ISAI_MODULE_LOCK_SCHEDULER
#define    ISAI_MODULE_LOCK_SCHEDULER    0
#endif

#ifndef    ISAI_MODULE_LOCK_SCHEDULER_GROUP
#define    ISAI_MODULE_LOCK_SCHEDULER_GROUP    0
#endif

#ifndef    ISAI_MODULE_LOCK_STP
#define    ISAI_MODULE_LOCK_STP    0
#endif

#ifndef    ISAI_MODULE_LOCK_SWITCH
#define    ISAI_MODULE_LOCK_SWITCH    0
#endif

#ifndef    ISAI_MODULE_LOCK_TUNNEL
#define    ISAI_MODULE_LOCK_TUNNEL    0
#endif

#ifndef    ISAI_MODULE_LOCK_VLAN
#define    ISAI_MODULE_LOCK_VLAN    0
#endif

#ifndef    ISAI_MODULE_LOCK_WRED
#define    ISAI_MODULE_LOCK_WRED    0
#endif

#ifndef    ISAI_MODULE_LOCK_QOS_COMMON
#define    ISAI_MODULE_LOCK_QOS_COMMON    0
#endif

#ifndef    ISAI_MODULE_LOCK_UDF
#define    ISAI_MODULE_LOCK_UDF    0
#endif

#define ISAI_LOCAL_MOD_LOCK_MASK    (~((1ULL << ISAI_LOCAL_MOD_LOCK_PRIO) - 1))


#define ISAI_MOD_LOCK_BITMAP                                                    \
    (((isai_ii_modlock_t)ISAI_MODULE_LOCK_ACL << ISAI_II_MOD_LOCK_PRIO_ACL) |   \
                                                                                \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_BRIDGE <<                             \
        ISAI_II_MOD_LOCK_PRIO_BRIDGE) |                                         \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_BUFFER <<                             \
        ISAI_II_MOD_LOCK_PRIO_BUFFER) |                                         \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_DEBUG_COUNTER <<                      \
        ISAI_II_MOD_LOCK_PRIO_DEBUG_COUNTER) |                                  \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_FDB << ISAI_II_MOD_LOCK_PRIO_FDB) |   \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_HASH << ISAI_II_MOD_LOCK_PRIO_HASH) | \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_HOSTIF <<                             \
        ISAI_II_MOD_LOCK_PRIO_HOSTIF) |                                         \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_ISOLATION_GROUP <<                    \
        ISAI_II_MOD_LOCK_PRIO_ISOLATION_GROUP) |                                \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_L2MC_GROUP <<                         \
        ISAI_II_MOD_LOCK_PRIO_L2MC_GROUP) |                                     \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_LAG << ISAI_II_MOD_LOCK_PRIO_LAG) |   \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_MIRROR <<                             \
        ISAI_II_MOD_LOCK_PRIO_MIRROR) |                                         \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_NEIGHBOR <<                           \
        ISAI_II_MOD_LOCK_PRIO_NEIGHBOR) |                                       \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_NEXTHOP <<                            \
        ISAI_II_MOD_LOCK_PRIO_NEXTHOP) |                                        \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_NEXTHOPGROUP <<                       \
        ISAI_II_MOD_LOCK_PRIO_NEXTHOPGROUP) |                                   \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_POLICER <<                            \
        ISAI_II_MOD_LOCK_PRIO_POLICER) |                                        \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_PORT << ISAI_II_MOD_LOCK_PRIO_PORT) | \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_QOSMAP <<                             \
        ISAI_II_MOD_LOCK_PRIO_QOSMAP) |                                         \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_QUEUE <<                              \
        ISAI_II_MOD_LOCK_PRIO_QUEUE) |                                          \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_ROUTE <<                              \
        ISAI_II_MOD_LOCK_PRIO_ROUTE) |                                          \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_ROUTER <<                             \
        ISAI_II_MOD_LOCK_PRIO_ROUTER) |                                         \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_ROUTERINTF <<                         \
        ISAI_II_MOD_LOCK_PRIO_ROUTERINTF) |                                     \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_SAMPLEPACKET <<                       \
        ISAI_II_MOD_LOCK_PRIO_SAMPLEPACKET) |                                   \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_SCHEDULER <<                          \
        ISAI_II_MOD_LOCK_PRIO_SCHEDULER) |                                      \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_SCHEDULER_GROUP <<                    \
        ISAI_II_MOD_LOCK_PRIO_SCHEDULER_GROUP) |                                \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_STP << ISAI_II_MOD_LOCK_PRIO_STP) |   \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_SWITCH <<                             \
        ISAI_II_MOD_LOCK_PRIO_SWITCH) |                                         \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_TUNNEL <<                             \
        ISAI_II_MOD_LOCK_PRIO_TUNNEL) |                                         \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_VLAN << ISAI_II_MOD_LOCK_PRIO_VLAN) | \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_WRED << ISAI_II_MOD_LOCK_PRIO_WRED) | \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_UDF << ISAI_II_MOD_LOCK_PRIO_UDF) | \
     ((isai_ii_modlock_t)ISAI_MODULE_LOCK_QOS_COMMON << ISAI_II_MOD_LOCK_PRIO_QOS_COMMON)   \
    )

#define ISAI_MOD_LOCK(switch_id, tid)                                     \
    ({                                                                    \
        sai_status_t __rc;                                                \
        if ((__rc =                                                       \
                 isai_im_nmgr_mod_lock(switch_id,                         \
                                       ISAI_LOCAL_MOD_LOCK_PRIO, tid)) != \
            SAI_STATUS_SUCCESS) {                                         \
            return __rc;                                                  \
        }                                                                 \
    }                                                                     \
    )

#define ISAI_MOD_UNLOCK(switch_id, tid) \
    isai_im_nmgr_mod_unlock(switch_id, ISAI_LOCAL_MOD_LOCK_PRIO, tid)


#if 0
#define SINGLE_LOCK(switch_id) \
    isai_im_nmgr_single_lock(switch_id, ISAI_LOCAL_MOD_LOCK_PRIO)

#define SINGLE_UNLOCK(switch_id) \
    isai_im_nmgr_single_unlock(switch_id, ISAI_LOCAL_MOD_LOCK_PRIO)
#endif

#define ISAI_MOD_LOCK_REGION(switch_id)         \
    uint8_t __local_inside_mod_lock;            \
    int     tid;                                \
    sai_object_id_t __mod_lock_switch_id;       \
    tid = (int)syscall(__NR_gettid);            \
    for (__local_inside_mod_lock = 0,           \
         __mod_lock_switch_id = switch_id,      \
         ISAI_MOD_LOCK(__mod_lock_switch_id, tid);   \
         __local_inside_mod_lock < 1;           \
         ISAI_MOD_UNLOCK(__mod_lock_switch_id, tid), \
         __local_inside_mod_lock = 1)

#if 0

/* Add this to MOD_LOCK_REGION when we start supporting
 * SINGLE_LOCK_REGION
 */
const int __mod_lock_type = 1;
#endif

#if 0
#define SINGLE_LOCK_REGION(switch_id)                             \
    uint8_t __local_inside_mod_lock;                              \
    sai_object_id_t __mod_lock_switch_id __attribute__((unused)); \
    const int       __mod_lock_type __attribute__((unused)) = 2;  \
    for (__local_inside_mod_lock = 0,                             \
         __mod_lock_switch_id = switch_id,                        \
         SINGLE_LOCK(switch_id);                                  \
         __local_inside_mod_lock < 1;                             \
         SINGLE_UNLOCK(switch_id),                                \
         __local_inside_mod_lock = 1)
#endif

#define MOD_LOCK_EXIT    continue

#define __MOD_UNLOCK \
    MOD_UNLOCK(__mod_lock_switch_id);
#if 0
if (__mod_lock_type == 1) {              \
    MOD_UNLOCK(__mod_lock_switch_id);    \
} else {                                 \
    SINGLE_UNLOCK(__mod_lock_switch_id); \
}
#endif

#define MOD_UNLOCK_RETURN(RC) \
    __MOD_UNLOCK              \
    return RC;

#define MOD_UNLOCK_GOTO(label) \
    __MOD_UNLOCK               \
    goto label;

#define MOD_UNLOCK_RETURN_ERR_ON_ERR(x, err_str)                                \
    do {                                                                        \
        int ret = x;                                                            \
        if (ret != IFCS_SUCCESS) {                                              \
            __MOD_UNLOCK                                                        \
            IM_LOG(ILM_NODE, IFCS_LOG_LEVEL_FATAL, "%s. Ret %d", err_str, ret); \
            return ret;                                                         \
        }                                                                       \
    } while (0)
