/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_rpf_group.h
 * @brief ISAI IM Include file for RPF_GROUP module
 */


#ifndef __IFCS_SAI_RPF_GROUP_H__
#define __IFCS_SAI_RPF_GROUP_H__


#define ISAI_MODULE_LOCK_RPF_GROUP    1ULL


#include "isai_im_nmgr.h"
#include "ifcs_sai_switch.h"
#include "ifcs_sai_ipmc.h"
#endif /* __IFCS_SAI_RPF_GROUP_H__ */
