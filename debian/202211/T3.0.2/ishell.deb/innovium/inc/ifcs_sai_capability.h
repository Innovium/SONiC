/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_capability.h
 * @brief Definition for SAI Capability query api for all modules
 */


#ifndef __IFCS_IFCS_SAI_CAPABILITY_H__
#define __IFCS_IFCS_SAI_CAPABILITY_H__

#include <sai.h>
#include "ifcs_sai_shim_log.h"

/*
 * @brief Helper function to fill values in the 'stats
 * capability' structure
 *
 * @param [in/out] stats_capability - Pointer to fill in stat
 *                                    capability info
 * @param [in] stat_enum            - supported stat id
 * @param [in] stat_modes           - supported statistic modes
 * @param [in] object_type          - SAI object type
 * @return void
 */
void
sai_api_query_stats_capability_assign(sai_stat_capability_t *stats_capability,
                                      sai_stat_id_t         stat_enum,
                                      uint32_t              stat_modes,
                                      sai_object_type_t     object_type);

/*
 * @brief Retrieve per enum value stat capability for objects of type
 * SAI_OBJECT_TYPE_INGRESS_PRIORITY_GROUP
 *
 * @param [in] object_type          - SAI object type
 * @param [in/out] stats_capability - Pointer to fill in stat
 *                                    capability info
 * @return sai_status_t
 */
sai_status_t
sai_api_query_ingress_priority_group_stats_capability(
    sai_object_type_t          object_type,
    sai_stat_capability_list_t *stats_capability);

/*
 * @brief Retrieve per enum value stat capability for objects of type
 * SAI_OBJECT_TYPE_BUFFER_POOL
 *
 * @param [in] object_type          - SAI object type
 * @param [in/out] stats_capability - Pointer to fill in stat
 *                                    capability info
 * @return sai_status_t
 */
sai_status_t
sai_api_query_buffer_pool_stats_capability(
    sai_object_type_t          object_type,
    sai_stat_capability_list_t *stats_capability);

/*
 * @brief Retrieve per enum value stat capability for objects of type
 * SAI_OBJECT_TYPE_POLICER
 *
 * @param [in] object_type          - SAI object type
 * @param [in/out] stats_capability - Pointer to fill in stat
 *                                    capability info
 * @return sai_status_t
 */
sai_status_t
sai_api_query_policer_stats_capability(sai_object_type_t          object_type,
                                       sai_stat_capability_list_t *stats_capability);

/*
 * @brief Retrieve per enum value stat capability for objects of type
 * SAI_OBJECT_TYPE_PORT
 *
 * @param [in] object_type          - SAI object type
 * @param [in/out] stats_capability - Pointer to fill in stat
 *                                    capability info
 * @return sai_status_t
 */
sai_status_t
sai_api_query_port_stats_capability(sai_object_type_t          object_type,
                                    sai_stat_capability_list_t *stats_capability);

/*
 * @brief Retrieve per enum value stat capability for objects of type
 * SAI_OBJECT_TYPE_QUEUE
 *
 * @param [in] object_type          - SAI object type
 * @param [in/out] stats_capability - Pointer to fill in stat
 *                                    capability info
 * @return sai_status_t
 */
sai_status_t
sai_api_query_queue_stats_capability(sai_object_type_t          object_type,
                                     sai_stat_capability_list_t *stats_capability);

/*
 * @brief Retrieve per enum value stat capability for objects of type
 * SAI_OBJECT_TYPE_ROUTER_INTERFACE
 *
 * @param [in] object_type          - SAI object type
 * @param [in/out] stats_capability - Pointer to fill in stat
 *                                    capability info
 * @return sai_status_t
 */
sai_status_t
sai_api_query_router_interface_stats_capability(
    sai_object_type_t          object_type,
    sai_stat_capability_list_t *stats_capability);

/*
 * @brief Retrieve per enum value stat capability for objects of type
 * SAI_OBJECT_TYPE_VLAN
 *
 * @param [in] object_type          - SAI object type
 * @param [in/out] stats_capability - Pointer to fill in stat
 *                                    capability info
 * @return sai_status_t
 */
sai_status_t
sai_api_query_vlan_stats_capability(sai_object_type_t          object_type,
                                    sai_stat_capability_list_t *stats_capability);

/**
 * @brief Query statistics capability for statistics bound at object level
 *
 * @param[in] switch_id SAI Switch object id
 * @param[in] object_type SAI object type
 * @param[inout] stats_capability List of implemented enum values,
 *    and the statistics modes (bit mask) supported per value
 *
 * @return #SAI_STATUS_SUCCESS on success,
 *         #SAI_STATUS_BUFFER_OVERFLOW if lists size insufficient,
 *         failure status code on error
 */
sai_status_t
sai_query_stats_capability(
    _In_ sai_object_id_t               switch_id,
    _In_ sai_object_type_t             object_type,
    _Inout_ sai_stat_capability_list_t *stats_capability);

#endif /* __IFCS_IFCS_SAI_CAPABILITY_H__ */
