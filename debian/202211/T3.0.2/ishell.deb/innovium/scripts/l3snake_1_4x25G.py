#
#------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#------------------------------------------------------------------------------
#

import os
import sys
from ctypes import *
from ifcs_ctypes import *
from utils.common_util import strToList
from verbosity import log
from utils.compat_util import *

MAX_DEV_PORT = 129

################################################################################
# Synopsis:
# This test case can be used for L3 snake test or for line rate test on SVK.
#
# Usage:
# 1. Start CLI with 128 port config file
#    ./inno_cli.sh -c board.config_126x100G_2x50G__1x100G_4x25G
# 2. node create 0
# 3. type "console"
# 4. from l3snake_1_4x25G import *
# 5. l3snake_config()
#    At this stage all devports, sysports, l3vnis, interfaces, nexthops and
#    routes are created and configured.
# 6. exit() from script and perform test.
# 7. Once testing is done, do step 3,4 and issue
#    l3snake_unconfig() to negate all the configuration done in step 5.
################################################################################

'''
L3Snake Class - Initialize and Setup the switch for L3Snake.

Configuration involves:
    1. Devports configuration
        a. Devport 1 is connected to Ixia
        c. Devport 2-127 are in External Loopback
    2. Sysports configured as L3PORT
    3. 128 VRFs (L3VNIs) created.
    4. L3 Interfaces created one per Sysport
    5. Nexthops created one per L3 interface
    6. Host Route entries (VRF, IP) -> NH (Intf, Dest Sysport) created.
       Packet snakes with below Routes:
       Route entry (VRF1, IP) -> NH1(Intf1, SP2)
       Route entry (VRF2, IP) -> NH2(Intf2, SP3)
       ..
       Route entry (VRF128, IP) -> NH0(Intf0, SP1)

It can also do "unconfig" to remove all above configurations.
'''
class L3snake():

    def __init__(self, p='all', lb=None):
        self.node_id = 0

        # If port range not given, default to all ports
        if p == 'all':
            max_dev_port = self.get_max_devport()
            p            = '1-%d'%(max_dev_port)

        '''
            Decode '-' and ',' seperated ports range to a list
            eg: '1-4,7-9' to [1,2,3,4,7,8,9]
        '''
        self.port_list             =   strToList(p)
        self.num_ports             =   len(self.port_list)
        self.ixia_conn_list        =   [1]
        #self.pma_fifo_list         =   self.ixia_conn_list[:]
        #self.pma_fifo_list[:]      =   [ele+1 for ele in self.pma_fifo_list]
        #self.addtnl_pma_fifo_list  =   [64]
        #self.pma_fifo_list    +=  self.addtnl_pma_fifo_list
        self.pma_fifo_list         = []

        if lb:
            if (lb.upper() == 'PCS'):
                self.loopback_type = IFCS_DEVPORT_LOOPBACK_PCS
            elif (lb.upper() == 'PMA'):
                self.loopback_type = IFCS_DEVPORT_LOOPBACK_PMA
            else:
                self.loopback_type = IFCS_DEVPORT_LOOPBACK_NONE
        else:
            self.loopback_type = IFCS_DEVPORT_LOOPBACK_NONE

        self.sysport_hdls = [0] * MAX_DEV_PORT
        self.l3vni_hdls   = [0] * MAX_DEV_PORT
        self.intf_hdls    = [0] * MAX_DEV_PORT
        self.nh_hdls      = [0] * MAX_DEV_PORT
        self.intfmac1     = (0x00, 0x03, 0x00, 0x00, 0x00, 0x01)
        self.intfmac2     = (0x00, 0x05, 0x00, 0x00, 0x00, 0x01)
        log("L3 Snake test: Ports {0}\n".format(p))

    def get_max_devport(self):
        def myCallback(node_id, arg, attr_count, attr_list, user_data):
            devport = arg
            devport_list.append(devport)

        devport_list = []

        callback_type = CFUNCTYPE(UNCHECKED(None),
                                  ifcs_node_id_t,
                                  ifcs_devport_t,
                                  c_uint32,
                                  POINTER(ifcs_attr_t),
                                  POINTER(None))
        callback = callback_type(myCallback)

        attr = ifcs_attr_t()
        ifcs_attr_t_init(pointer(attr))
        ifcs_attr_t_id_set(pointer(attr), IFCS_DEVPORT_ATTR_TYPE)
        ifcs_attr_t_value_u32_set(pointer(attr), IFCS_DEVPORT_TYPE_ETH)

        rc = ifcs_devport_get_all(self.node_id, 1, pointer(attr), compat_funcPointer(callback, ifcs_devport_user_cb_t), None, None)
        assert rc == IFCS_SUCCESS, "Devport get all failed: rc {0}".format(rc)

        return (len(devport_list))

    def configDevportGetSysportHandle(self, devport):
        '''
            Utility function that takes a devport
            and returns the handle to its corresponding
            sysport
        '''
        attr        =  ifcs_attr_t()
        count       =  ctypes.c_uint32()
        attr.id     =  IFCS_DEVPORT_ATTR_SYSPORT
        attr_count  =  1
        rc = ifcs_devport_attr_get(self.node_id, devport, attr_count, pointer(attr),
                                   pointer(count))
        if rc != IFCS_SUCCESS:
            log("Failed to get sysport for devport %d" % devport)
            return

        return attr.value.handle

    def configDevportSetAdminState(self, devport, admin_state):
        '''
            Utility function to configure devport's admin_state
        '''
        if (devport in self.ixia_conn_list):
            # Get num num_lanes
            attr           = ifcs_attr_t()
            attr.id        = IFCS_DEVPORT_ATTR_NUM_LANES
            attr_p         = pointer(attr)
            actual_count   = ctypes.c_uint32()
            actual_count_p = pointer(actual_count)

            rc = ifcs_devport_attr_get(self.node_id,
                                       devport,
                                       1,
                                       attr_p,
                                       actual_count_p)
            assert rc == IFCS_SUCCESS, "ifcs_devport_attr_get NUM_LANES failed: rc ".format(rc)
            num_lanes = attr.value.u32
            lane_mask = ((1 << num_lanes) - 1)

            # Based on num_lanes set below
            attr_list   =   (ifcs_attr_t * 10)()
            rc          =   ifcs_attr_t_init(compat_pointer(attr_list, ifcs_attr_t))
            assert rc == IFCS_SUCCESS
            attr_count  =   0

            attr_list[attr_count].id            = IFCS_DEVPORT_ATTR_LANE_MASK
            attr_list[attr_count].value.u32     = lane_mask
            attr_count += 1

            attr_list[attr_count].id            = IFCS_DEVPORT_ATTR_TX_EQ_PRE1
            TxEqPre1                            = ifcs_i8_list_s()
            TxEqPre1.count                      = num_lanes
            TxEqPre1.arr                        = (c_byte * TxEqPre1.count)()
            for i in range(TxEqPre1.count):
                TxEqPre1.arr[i]                 = ctypes.c_int8(int(10));
            attr_list[attr_count].value.i8_list = TxEqPre1
            attr_count += 1

            attr_list[attr_count].id            = IFCS_DEVPORT_ATTR_TX_EQ_PRE2
            TxEqPre2                            = ifcs_i8_list_s()
            TxEqPre2.count                      = num_lanes
            TxEqPre2.arr                        = (c_byte * TxEqPre2.count)()
            for i in range(TxEqPre2.count):
                TxEqPre2.arr[i]                 = ctypes.c_int8(int(-3));
            attr_list[attr_count].value.i8_list = TxEqPre2
            attr_count += 1

            attr_list[attr_count].id            = IFCS_DEVPORT_ATTR_TX_EQ_POST
            TxEqPost                            = ifcs_i8_list_s()
            TxEqPost.count                      = num_lanes
            TxEqPost.arr                        = (c_byte * TxEqPost.count)()
            for i in range(TxEqPost.count):
                TxEqPost.arr[i]                 = ctypes.c_int8(int(4));
            attr_list[attr_count].value.i8_list = TxEqPost
            attr_count += 1

            rc = ifcs_devport_attr_set(self.node_id,
                                       devport,
                                       attr_count,
                                       compat_pointer(attr_list, ifcs_attr_t))
            assert rc == IFCS_SUCCESS, "ifcs_devport_attr_set ADMIN_STATE failed: rc ".format(rc)


        # Enable devport
        attr_list = (ifcs_attr_t * 3)()
        rc = ifcs_attr_t_init(compat_pointer(attr_list, ifcs_attr_t))
        assert rc == IFCS_SUCCESS

        attr_count = 0
        attr_list[attr_count].id         = IFCS_DEVPORT_ATTR_ADMIN_STATE
        attr_list[attr_count].value.data = admin_state
        attr_count += 1

        if admin_state == IFCS_BOOL_TRUE:
            attr_list[attr_count].id        = IFCS_DEVPORT_ATTR_RX_EQ_FINE_TUNE
            attr_list[attr_count].value.u32 = IFCS_DEVPORT_SERDES_RX_EQ_FINE_TUNE_CONTINUOUS
            attr_count += 1

        rc = ifcs_devport_attr_set(self.node_id,
                                   devport,
                                   attr_count,
                                   compat_pointer(attr_list, ifcs_attr_t))
        assert rc == IFCS_SUCCESS, "ifcs_devport_attr_set ADMIN_STATE failed: rc ".format(rc)

    def configDevportSetLoopback(self, lb=IFCS_DEVPORT_LOOPBACK_NONE, force_all=0):
        '''
            Utility function to set devports loopback type.
            Port 2 is always set to PCS
            Other ports are set to given loopback type
        '''
        log("Configure devports loopback mode")

        # Set devport loopback mode
        try:
            for i in range(self.num_ports):
                port = int(self.port_list[i])
                attr = ifcs_attr_t()
                rc   = ifcs_attr_t_init(pointer(attr))
                assert rc == IFCS_SUCCESS
                attr.id = IFCS_DEVPORT_ATTR_LOOPBACK

                if force_all == 0:
                    if (port in self.ixia_conn_list):
                        attr.value.data = IFCS_DEVPORT_LOOPBACK_NONE
                    # if Port in ILB connection list, set appropriate LB type
                    elif port in self.pma_fifo_list:
                        attr.value.data = IFCS_DEVPORT_LOOPBACK_PCS
                    else:
                        attr.value.data = lb
                else:
                        attr.value.data = lb

                attr_count = 1
                rc = ifcs_devport_attr_set(self.node_id,
                                           port,
                                           attr_count,
                                           pointer(attr))
                assert rc == IFCS_SUCCESS, "ifcs_devport_attr_set LOOPBACK failed: rc %d port %d" %s(rc, port)
        except:
             log("Hit except (Devport loopback) enable")
             pass

        log("   Configured devports loopback mode successfully ")

    def configSysportSetFwdMode(self, mode=IFCS_SYSPORT_FWD_MODE_L3_ONLY):
        '''
            Utility function to set sysports FWD MODE to L3_ONLY
        '''
        log("Configure sysports as L3PORT")
        #Set sysport's PORT_FWD_MODE to given mode
        for i in range(self.num_ports):
            port                 = int(self.port_list[i])
            self.sysport_hdls[i] = self.configDevportGetSysportHandle(port)
            attr                 = ifcs_attr_t()
            rc = ifcs_attr_t_init(pointer(attr))
            assert rc == IFCS_SUCCESS

            # Get PORT_FWD_MODE
            attr.id        = IFCS_SYSPORT_ATTR_PORT_FWD_MODE
            actual_count   = ctypes.c_uint32()
            actual_count_p = pointer(actual_count)

            rc = ifcs_sysport_attr_get(self.node_id,
                                       self.sysport_hdls[i],
                                       1,
                                       pointer(attr),
                                       actual_count_p)
            if attr.value.u32 == mode:
                #print ("sysport %d already in L3_ONLY mode" %(i))
                continue

            # Set PORT_FWD_MODE
            attr.value.u32 = mode
            attr_count = 1
            rc = ifcs_sysport_attr_set(self.node_id,
                                       self.sysport_hdls[i],
                                       attr_count,
                                       pointer(attr))
            assert rc == IFCS_SUCCESS, "sysport setAttr failed: port: {0}, rc :{1}".format(
                     port, rc)

        log("   Configured sysports as L3PORT successfully")

    def configDevportsEnable(self):
        #Set devport admin state back to UP
        log("Enabling devports")
        for i in range(self.num_ports):
            port = int(self.port_list[i])
            self.configDevportSetAdminState(port, IFCS_BOOL_TRUE)
        log("   Enabled devports successfully")

    def configDevportsDisable(self):
        #Set devport admin state to DOWN
        #print ("Disabling devports")
        for i in range(self.num_ports):
            port = int(self.port_list[i])
            self.configDevportSetAdminState(port, IFCS_BOOL_FALSE)
        #print ("   Disabled devports successfully")

    def configL3vniCreate(self):
        '''
            Utility function to create one L3VNI per port
        '''
        log("Creating L3VNIs")
        for i in range(0,self.num_ports):
            attr         = ifcs_attr_t();
            attr_count   = 0
            handle       = ifcs_handle_t();
            handle.value = IFCS_HANDLE_L3VNI(i+1)
            rc = ifcs_l3vni_create(self.node_id,
                                   pointer(handle),
                                   attr_count,
                                   pointer(attr))
            assert rc == IFCS_SUCCESS, "Failed to create l3vni " + str(i) + "ret: " + str(rc)
            self.l3vni_hdls[i] = handle

        log("   Created L3VNIs successfully")

    def configIntfCreate(self):
        '''
            Utility function to create L3 Interfaces
        '''
        log("Creating L3 interfaces")

        flag = True
        for i in range(self.num_ports):
            if flag is True:
                transportMac=self.intfmac1
                flag = False
            else:
                transportMac=self.intfmac2
                flag = True

            attr_list  = (ifcs_attr_t * 10)()
            attr_count = 0
            attr_list[attr_count].id           = IFCS_INTF_ATTR_TYPE
            attr_list[attr_count].value.u32    = IFCS_INTF_TYPE_L3PORT
            attr_count += 1

            attr_list[attr_count].id           = IFCS_INTF_ATTR_FORWARDING_INSTANCE
            attr_list[attr_count].value.handle = self.l3vni_hdls[i]
            attr_count += 1

            attr_list[attr_count].id           = IFCS_INTF_ATTR_TRANSPORT_INSTANCE
            attr_list[attr_count].value.handle = self.sysport_hdls[i]
            attr_count += 1

            attr_list[attr_count].id           = IFCS_INTF_ATTR_TRANSPORT_MAC
            attr_list[attr_count].value.mac    = transportMac
            attr_count += 1

            attr_list[attr_count].id           = IFCS_INTF_ATTR_IPV4_UNICAST_ENABLE
            attr_list[attr_count].value.data   = True
            attr_count += 1

            handle = ifcs_handle_t();
            handle.value = IFCS_NULL_HANDLE
            rc = ifcs_intf_create(self.node_id, pointer(handle), attr_count, attr_list)
            assert rc == IFCS_SUCCESS, "Failed to create intf " + str(i) + "ret: " + str(rc)
            self.intf_hdls[i] = handle

        log("   Created L3 interfaces successfully")

    def configNexthopCreate(self):
        '''
            Utility function to create Nexthops
        '''
        log("Creating Nexthops")
        flag = True
        for i in range(self.num_ports):
            if flag is False:
                dest_mac=self.intfmac1
                flag = True
            else:
                dest_mac=self.intfmac2
                flag = False

            attr_list = (ifcs_attr_t * 10)()
            attr_count = 0
            attr_list[attr_count].id           = IFCS_NEXTHOP_ATTR_INTF
            attr_list[attr_count].value.handle = self.intf_hdls[i]
            attr_count += 1

            attr_list[attr_count].id           = IFCS_NEXTHOP_ATTR_DEST_MAC
            attr_list[attr_count].value.mac    = dest_mac
            attr_count += 1

            attr_list[attr_count].id           = IFCS_NEXTHOP_ATTR_LOCAL_DESTINATION
            attr_list[attr_count].value.handle = self.sysport_hdls[i]
            attr_count += 1

            handle       = ifcs_handle_t();
            handle.value = IFCS_NULL_HANDLE
            rc = ifcs_nexthop_create(self.node_id,
                                     pointer(handle),
                                     attr_count,
                                     attr_list)
            assert rc == IFCS_SUCCESS, "Failed to create nexthop " + str(i) + "ret: " + str(rc)
            self.nh_hdls[i] = handle

        log("   Created Nexthops successfully")

    def configRouteCreate(self):
        '''
            Utility function to create Route entries
        '''

        fwd_policy             =  ifcs_fwd_policy_t()
        fwd_policy.fwd_action  =  IFCS_FWD_ACTION_FORWARD
        #configure same ip in all VRF aka L3VNI
        ipSubnet  = ifcs_ip_addr_t()
        mask      = ifcs_ip_addr_t()
        ipSubnet.ipv4  =  0x0c000001
        mask.ipv4      =  0xffffffff

        #Last route should map to port1 nh
        port1_nh = self.num_ports - 1
        log("Creating Route entries")
        for i in range(self.num_ports):
            if i == port1_nh:
                nh4_1 = self.nh_hdls[0]
            else:
                nh4_1 = self.nh_hdls[i+1]

            # Create key
            ip_dest = ifcs_ip_prefix_t()
            ifcs_ip_prefix_t_init(pointer(ip_dest));
            ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), IFCS_IP_ADDR_FAMILY_IPV4);
            ifcs_ip_prefix_t_addr_set(pointer(ip_dest), pointer(ipSubnet));
            ifcs_ip_prefix_t_mask_set(pointer(ip_dest), pointer(mask));

            route_entry_key = ifcs_route_entry_key_t()
            ifcs_route_entry_key_t_init(pointer(route_entry_key))
            ifcs_route_entry_key_t_key_type_set(pointer(route_entry_key),
                    IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_L3VNI)
            ifcs_route_entry_key_t_ip_dest_l3vni_set(pointer(route_entry_key),
                    route_entry_key.key.ip_dest_l3vni)
            ifcs_route_entry_key_ip_dest_l3vni_t_l3vni_set(pointer(route_entry_key.key.ip_dest_l3vni),
                    self.l3vni_hdls[i])
            ifcs_route_entry_key_ip_dest_l3vni_t_ip_dest_set(pointer(route_entry_key.key.ip_dest_l3vni),
                    pointer(ip_dest))

            attr_list                              =   (ifcs_attr_t * 10)()
            attr_count                             =   0
            attr_list[attr_count].id               =   IFCS_ROUTE_ENTRY_ATTR_NEXTHOP
            attr_list[attr_count].value.handle     =   nh4_1
            attr_count +=  1

            attr_list[attr_count].id               =   IFCS_ROUTE_ENTRY_ATTR_FWD_POLICY
            attr_list[attr_count].value.fwd_policy =   fwd_policy
            attr_count +=  1

            rc =   ifcs_route_entry_create(self.node_id,
                                           pointer(route_entry_key),
                                           attr_count,
                                           attr_list)
            assert rc == IFCS_SUCCESS, "Failed to create route entry " + str(i) + "ret: " + str(rc)

        log("   Created Route entries successfully")

    def configRouteDelete(self):
        def myCallback(node_id, arg, attr_count, attr_list, user_data):
            key_obj = ifcs_route_entry_key_t()
            memmove(pointer(key_obj), arg, sizeof(key_obj))
            route_entry_list.append(pointer(key_obj))

        route_entry_list = []

        callback_type = CFUNCTYPE(UNCHECKED(None),
                                  ifcs_node_id_t,
                                  POINTER(ifcs_route_entry_key_t),
                                  c_uint32,
                                  POINTER(ifcs_attr_t),
                                  POINTER(None))
        callback = callback_type(myCallback)

        log("Deleting Route entries")
        rc = ifcs_route_entry_get_all(self.node_id, None, 0, None, compat_funcPointer(callback, ifcs_route_entry_user_cb_t), None, None)
        assert rc == IFCS_SUCCESS, "Route entry get all failed: rc {0}".format(rc)

        for route in route_entry_list:
            rc = ifcs_route_entry_delete(self.node_id,
                                         route)
            assert rc == IFCS_SUCCESS, "Route entry delete failed: rc {0}".format(rc)
        log("   Deleted Route entries successfully")

    def configNexthopDelete(self):
        def myCallback(node_id, arg, attr_count, attr_list, user_data):
            nexthop = arg
            nexthop_list.append(nexthop)

        nexthop_list = []

        callback_type = CFUNCTYPE(UNCHECKED(None),
                                  ifcs_node_id_t,
                                  ifcs_handle_t,
                                  c_uint32,
                                  POINTER(ifcs_attr_t),
                                  POINTER(None))
        callback = callback_type(myCallback)

        log("Deleting nexthops")
        rc = ifcs_nexthop_get_all(self.node_id, 0, None, compat_funcPointer(callback, ifcs_nexthop_user_cb_t), None, None)
        assert rc == IFCS_SUCCESS, "Nexthop get all failed: rc {0}".format(rc)

        for handle in nexthop_list:
            rc = ifcs_nexthop_delete(self.node_id,
                                     handle)
            assert rc == IFCS_SUCCESS, "Nexthop:{0} delete failed: rc {1} ".format(handle, rc)
        log("   Deleted nexthops successfully")

    def configIntfDelete(self):
        def myCallback(node_id, arg, attr_count, attr_list, user_data):
            intf = arg
            intf_list.append(intf)

        intf_list = []

        callback_type = CFUNCTYPE(UNCHECKED(None),
                                  ifcs_node_id_t,
                                  ifcs_handle_t,
                                  c_uint32,
                                  POINTER(ifcs_attr_t),
                                  POINTER(None))
        callback = callback_type(myCallback)

        log("Deleting interfaces")
        rc = ifcs_intf_get_all(self.node_id, 0, None, compat_funcPointer(callback, ifcs_intf_user_cb_t), None, None)
        assert rc == IFCS_SUCCESS, "Interface get all failed: rc {0}".format(rc)

        for handle in intf_list:
            rc = ifcs_intf_delete(self.node_id,
                                  handle)
        log("   Deleted interfaces successfully")

    def configL3vniDelete(self):
        def myCallback(node_id, arg, attr_count, attr_list, user_data):
            l3vni = arg
            l3vni_list.append(l3vni)

        l3vni_list = []

        callback_type = CFUNCTYPE(UNCHECKED(None),
                                  ifcs_node_id_t,
                                  ifcs_handle_t,
                                  c_uint32,
                                  POINTER(ifcs_attr_t),
                                  POINTER(None))
        callback = callback_type(myCallback)

        log("Deleting L3VNIs")
        rc = ifcs_l3vni_get_all(self.node_id, 0, None, compat_funcPointer(callback, ifcs_l3vni_user_cb_t), None, None)
        assert rc == IFCS_SUCCESS, "L3vni get all failed: rc ".format(rc)

        for handle in l3vni_list:
            rc = ifcs_l3vni_delete(self.node_id,
                                   handle)
            assert rc == IFCS_SUCCESS, "L3vni:{0} failed: rc {1} ".format(handle, rc)
        log("   Deleted L3VNIs successfully")

    def config(self):
        # Configure Devports loopback mode
        self.configDevportSetLoopback(lb=self.loopback_type)

        # Disable all Devports
        self.configDevportsDisable()

        # Configure Sysports as L3ONLY
        self.configSysportSetFwdMode()

        # Enable all Devports
        self.configDevportsEnable()

        # Create VRFs (L3VNI)
        self.configL3vniCreate()

        # Create L3 Interfaces (One per Sysport)
        self.configIntfCreate()

        # Create Nexthops (One per L3 interface)
        self.configNexthopCreate()

        # Create Host Route entries (VRF, IP) -> NH (Intf, Dest Sysport)
        self.configRouteCreate()

    def unconfig(self):
        # Delete route entries
        self.configRouteDelete()

        # Delete nexthops
        self.configNexthopDelete()

        # Delete interfaces
        self.configIntfDelete()

        # Delete l3vnis
        self.configL3vniDelete()

        # Configure devports loopback back to None
        self.configDevportSetLoopback(lb=IFCS_DEVPORT_LOOPBACK_NONE, force_all=1)

def l3snake_config(p='all', lb=None):
    obj = L3snake(p, lb)
    obj.config()

def l3snake_unconfig():
    obj = L3snake()
    obj.unconfig()
