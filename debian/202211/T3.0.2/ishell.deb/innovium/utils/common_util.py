#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

from ctypes import memset, c_uint
import random
import ifcs_ctypes
import datetime
 
from utils.compat_util import *

def set_seed(seed) :
    log("SEED = "+str(seed))
    random.seed(seed)

def get_uniq_list(start, end, size):
    lst = random.sample(range(start,end),size)
    log([hex(i) for i in lst])
    return lst

def get_random(start, end):
    return random.randint(start,end)

def get_rand() :
    return random.randint(0,2**32)

def get_rand_list(start,end,size):
    lst = size*[0]
    for i in range (0, size):
        lst[i] = get_random(start, end)
    return lst

def pkt_hexdump(pkt):
    hexpacket = []
    for i in pkt:
       #hexpacket.append(hex(ord(i)))
       if COMPAT_PY2:
            hexpacket.append("0x{:02x}".format(ord(i)))
       if COMPAT_PY3:
            hexpacket.append("0x{:02x}".format(i))
    return hexpacket

def pkt_converttohex(pkt):
    hexpacket = []
    for i in pkt:
       #hexpacket.append(hex(ord(i)))
       if COMPAT_PY2:
            hexpacket.append("{:02x}".format(ord(i)))
       if COMPAT_PY3:
            hexpacket.append("{:02x}".format(i))
       jhex = ' '.join(hexpacket)
    return jhex

def pkt_intdump(pkt):
    intpacket = []
    for i in pkt:
       if COMPAT_PY2:
            intpacket.append(int(ord(i)))
       if COMPAT_PY3:
            intpacket.append(int(i))
    return intpacket


def get_rand_blist(size):
    return get_rand_list(0,256,size)

def build_fwd_policy_attr(attr_id = None, fwd_policy = None, ctc_policy = None, mirror_policy = None, trap_handle = None, mirror_action = None, mirror_container = None, mirror_handle = None, traffic_monitor_action = None, traffic_monitor_container = None, collector_set = None, sampling_rate = None):
    assert (attr_id is not None), "Attr id not provided"
    attr = ifcs_ctypes.ifcs_attr_t()
    #memset(pointer(attr.value.pkt_policy), 0, sizeof(ifcs_packet_policy_t))
    memset(pointer(attr.value), 0, sizeof(ifcs_ctypes.ifcs_attr_value_t))
    attr.id = attr_id
    if (fwd_policy is not None):
        attr.value.fwd_policy.fwd_action = fwd_policy
        attr.value.fwd_policy.pp_drop_reason = ifcs_ctypes.IFCS_NULL_HANDLE
    if (ctc_policy is not None):
        assert (trap_handle is not None), "Trap handle is not provided"
        attr.value.ctc_policy.ctc_action = ctc_policy
        attr.value.ctc_policy.trap_handle = trap_handle
    if (mirror_action is not None):
        assert (mirror_handle is not None), "Mirror handle is not provided"
        assert (mirror_action is not None), "Mirror action is not provided"
        if (mirror_action == ifcs_ctypes.IFCS_MIRROR_ACTION_ENABLE):
            assert (mirror_container is not None), "Mirror container is not provided"
            attr.value.mirror_policy.mirror_container = mirror_container
        attr.value.mirror_policy.mirror_action = mirror_action
        attr.value.mirror_policy.mirror_handle = mirror_handle
    if (traffic_monitor_action is not None):
        assert (collector_set is not None), "Collector set handle is not provided"
        assert (traffic_monitor_action is not None), "Collector set action is not provided"
        if (traffic_monitor_action == ifcs_ctypes.IFCS_TRAFFIC_MONITOR_ACTION_ENABLE):
            assert (traffic_monitor_container is not None), "Traffic monitor container is not provided"
            attr.value.traffic_monitor_policy.traffic_monitor_container = traffic_monitor_container
        attr.value.traffic_monitor_policy.traffic_monitor_action = traffic_monitor_action
        attr.value.traffic_monitor_policy.collector_set = collector_set
        if (sampling_rate is not None):
            attr.value.traffic_monitor_policy.sampling_rate = sampling_rate
    return attr

def build_fwd_policy_attr_value(fwd_policy = None, ctc_policy = None, mirror_policy = None, trap_handle = None, mirror_action = None, mirror_container = None, mirror_handle = None):
    #value = ifcs_ctypes.ifcs_packet_policy_t()
    value = ifcs_ctypes.ifcs_attr_value_t()
    if (fwd_policy is not None):
        if type(fwd_policy) is ifcs_ctypes.struct_ifcs_fwd_policy_s:
            value.fwd_policy = fwd_policy
        else:
            value.fwd_policy.fwd_action = fwd_policy
    if (ctc_policy is not None):
        if type(ctc_policy) is ifcs_ctypes.struct_ifcs_ctc_policy_s:
            value.ctc_policy = ctc_policy
        else:
            assert (trap_handle is not None), "Trap handle is not provided"
            value.ctc_policy.ctc_action = ctc_policy
            value.ctc_policy.trap_handle = trap_handle

    if (mirror_action is not None):
        assert (mirror_handle is not None), "Mirror handle is not provided"
        assert (mirror_action is not None), "Mirror action is not provided"
        if (mirror_action == ifcs_ctypes.IFCS_MIRROR_ACTION_ENABLE):
            assert (mirror_container is not None), "Mirror container is not provided"
            value.mirror_policy.mirror_container = mirror_container
        value.mirror_policy.mirror_action = mirror_action
        value.mirror_policy.mirror_handle = mirror_handle
    return value


# Used in auto generated python ifcs objects to form
# attribute list before passing to actual SDK API
def build_attr_list(passed_attr_list):

    attr_list = (ifcs_ctypes.ifcs_attr_t * len(passed_attr_list))()
    index = 0

    for attr in passed_attr_list:
        attr_list[index].id = attr[2]
        if attr[1] == "ifcs_mac_t":
            attr_list[index].value.mac = attr[0]
        elif attr[1] in ["ifcs_ip_prefix_t","ifcs_ip_address_t"]:
            attr_list[index].value.ip_addr.addr_family = attr[0][0]
            if attr[0][0]== ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4:
                attr_list[index].value.ip_addr.addr.ipv4 = attr[0][1]
            else:
                attr_list[index].value.ip_addr.addr.ipv6 = attr[0][1]
            if attr[1] == "ifcs_ip_prefix_t":
                if attr[0][0] == ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4:
                    attr_list[index].value.mask.ipv6 = attr[0][2]
                else:
                    attr_list[index].value.mask.ipv6 = attr[0][2]
        elif attr[1] == "fwd_policy":
             memset(pointer(attr_list[index].value.fwd_policy), 0, \
                 sizeof(ifcs_ctypes.ifcs_fwd_policy_t))
             if attr[0][0] is not None:
                 attr_list[index].value.pkt_policy.fwd_policy = attr[0][0]
             if attr[0][1] is not None:
                 attr_list[index].value.pkt_policy.ctc_policy = attr[0][1]
        elif attr[1] == "ifcs_handle_t":
            attr_list[index].value.u32 = attr[0].getHandle()
        else:
            attr_list[index].value.u32 = attr[0]
        index += 1

    return compat_pointer(attr_list, ifcs_ctypes.ifcs_attr_t)

# Used to expand a range. For e.g expands 1-3,8,10-12 to [1,2,3,8,10,11,12]
# Can be used with prefix as well which is optional. For e.g Lag1-3, ['Lag']
# will be expanded to ['Lag1'],['Lag2'],['Lag3']. 'Lag1-3,SP1-2', ['Lag','SP']
# will expand to ['Lag1','Lag2','Lag3','SP1','SP2']

def strToList(inputstr, commonStrs=['']):
    returnlist = []
    if type(inputstr) is int:
        return [inputstr]
    inputlist = inputstr.split(",")
    for element in inputlist:
        element = element.strip()
        commonStrFound = False
        for commonStr in commonStrs:
            if element.startswith(commonStr):
                commonStrFound = True
                break
        if not commonStrFound:
            commontStr = ''
        elementlist = element.lstrip(commonStr).split("-")
        if len(elementlist) == 1:
            returnlist.append(commonStr+elementlist[0])
        else:
            for index in range(int(elementlist[0]),int(elementlist[1])+1):
                returnlist.append('{0}{1}'.format(commonStr,index))

    return returnlist

# get list of handles from ifcs_handle_list structure
def getHandlesFromIfcsHandleList(handleList):

    returnList = []
    for index in range(handleList.count):
        returnList.append(handleList.list[index])
    return returnList

# build ip address from family,address
def build_ipaddr_attr(ipFamily, ipAddr, ipMask = None):

    if ipMask is not None:
        ipAddrStruct = ifcs_ctypes.ifcs_ip_prefix_t()
        if ipFamily == ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4:
           ipAddrStruct.mask.ipv4 = ipMask
        else:
           ipAddrStruct.mask.ipv6 = ipMask
    else:
        ipAddrStruct = ifcs_ctypes.ifcs_ip_address_t()
    ipAddrStruct.addr_family = ipFamily
    if ipFamily == ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4:
        ipAddrStruct.addr.ipv4 = ipAddr
    else:
        ipAddrStruct.addr.ipv6 = ipAddr
    return ipAddrStruct

def setLagStpState(nodeId, stpObj, lagObj, stpState, expRc=None):
    ports = lagObj.getMembers()
    stpObj.addPorts(ports, memberCount=len(ports), expRc = expRc)
    for i in range(len(ports)):
        stpObj.setPortStpState(ports[i], stpState)

# Pen hash command helper function
def perform_pen_hash_cmd(node_id, ib, pen, cmd, key, data, entry):

    """ Setups Entry based on Key and Data List and issue Hash Command
    pen HASH Pen
    cmd Hash Command
    Key is list of elements: (efield, mkid, fld, fld_type, value)
    Data is list of elements: (efield, epp, fld, fld_type, value)

    In case the Field is not a Efield, set mkid/epp = -1

    Returns: (commandStatus, Index, Bucket MetaData)
    """

    index = c_uint(0)
    bkt_meta = c_uint(0)

    #print 'Key: ', key
    #print 'data: ', data

    #Set Key
    for i in range(len(key)):
        efield, mkid, fld, fld_type, val = key[i]
        if fld_type == ifcs_ctypes.TENTRY_FLD_TYPE_UINT32:
            value = pointer(val)
        else:
            value = val
        if mkid == -1:
            rc = ifcs_ctypes.tentry_set_item(node_id, ifcs_ctypes.device_pen_map(node_id, pen), ifcs_ctypes.device_fld_map(node_id, efield),
                    fld_type, entry, value)
        else:
            rc = ifcs_ctypes.tentry_set_efield_item(node_id, ifcs_ctypes.device_pen_map(node_id, pen), ifcs_ctypes.device_fld_map(node_id, efield),
                    1, ifcs_ctypes.device_fld_map(0, fld), mkid, fld_type, entry, value)
    #Set Data
    for i in range(len(data)):
        efield, epp, fld, fld_type, val = data[i]
        if fld_type == ifcs_ctypes.TENTRY_FLD_TYPE_UINT32:
            value = pointer(val)
        else:
            value = val
        if epp == -1:
            rc = ifcs_ctypes.tentry_set_item(node_id, ifcs_ctypes.device_pen_map(node_id, pen), ifcs_ctypes.device_fld_map(node_id, efield),
                fld_type, entry, value)
        else:
            rc = ifcs_ctypes.tentry_set_efield_item(node_id, ifcs_ctypes.device_pen_map(node_id, pen), ifcs_ctypes.device_fld_map(node_id, efield),
                    0, ifcs_ctypes.device_fld_map(0, fld), epp, fld_type, entry, value)

    rc = ifcs_ctypes.node_isn_pen_hash_cmd(node_id, ib, ifcs_ctypes.device_pen_map(node_id, pen), cmd, ifcs_ctypes.ISN_DSB_HASH_NONE, pointer(index), pointer(bkt_meta), entry)
    return (rc, index.value, bkt_meta.value)

#Specific to vizibility
def get_avg_microburst_rate():
    event_rate = [i for i in range(122,100000,1)]
    return event_rate

def get_avg_pkt_microburst():

    #Setting the burst size to 1024
    #or use formula to get burst size . i.e.   rate * 8192/1000000
    avg_pkt_burst = [1024,1024]
    return avg_pkt_burst

def whattime():
    log(datetime.datetime.now())

def get_hdc_latency(hdc_latency,device_type=2):
    if device_type == 0:
            appnote_a = 2047
            appnote_b = 10
            appnote_c = 31
            appnote_d = 224
            appnote_e = 5
            appnote_f = 928
            appnote_g = 0
    elif device_type == 1:
            appnote_a = 2047
            appnote_b = 10
            appnote_c = 31
            appnote_d = 224
            appnote_e = 5
            appnote_f = 1488
            appnote_g = 0
    elif device_type == 5 or device_type == 6 or device_type == 7 or device_type == 8:
            appnote_a = 2047
            appnote_b = 11
            appnote_c = 511
            appnote_d = 7
            appnote_e = 0
            appnote_f = 1600
            appnote_g = 3
    else:
            INFO("FAIL!!! device class: {} is not defined in APPNOTE".format(device_type))
            return False

    viz_hop_latency = int(hdc_latency)
    latency = (viz_hop_latency * appnote_f)/100

    return latency

def get_ipt_latency(pkt_src,pkt_dst,device_type=0):

    if device_type == 0:
        appnote_a = 2047
        appnote_b = 7
        appnote_c = 65535
        appnote_d = 58
        appnote_e = 4
        appnote_f = 25
    elif device_type == 1:
        appnote_a = 2047
        appnote_b = 7
        appnote_c = 65535
        appnote_d = 93
        appnote_e = 4
        appnote_f = 45
    elif device_type == 5:
        appnote_a = 2047
        appnote_b = 7
        appnote_c = 65535
        appnote_d = 100
        appnote_e = 4
        appnote_f = 21
    elif device_type == 6:
        appnote_a = 2047
        appnote_b = 7
        appnote_c = 65535
        appnote_d = 100
        appnote_e = 4
        appnote_f = 24
    elif device_type == 7:
        appnote_a = 2047
        appnote_b = 7
        appnote_c = 65535
        appnote_d = 100
        appnote_e = 4
        appnote_f = 33
    elif device_type == 8:
        appnote_a = 2047
        appnote_b = 7
        appnote_c = 65535
        appnote_d = 100
        appnote_e = 4
        appnote_f = 44
    else:
        INFO("FAIL!!! device class: {} is not defined in APPNOTE".format(device_type))
        return False
    pkt_src_time = int(pkt_src)
    pkt_dst_time = int(pkt_dst)
    if pkt_src_time >  pkt_dst_time:
        hop_latency = int((((pkt_dst_time + (1 << 20)) - pkt_src_time ) << appnote_e) * appnote_d/100.0 - appnote_f)
    else:
        hop_latency = int(((pkt_dst_time  - pkt_src_time ) << appnote_e) * appnote_d/100.0 - appnote_f)

    return hop_latency

def is_number(s):
    if s.isdigit():
        return True
    elif re.match(r'^0x[\da-fA-F]+$', s):
        return True
    else:
        return False
