#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import bincopy
from utils.compat_util import *
from verbosity import log

def hexdump(a):
    b = bytearray(a)
    addr = 0
    for group in compat_izip_longest(*[iter(b)]*16):
        log_no_newline("%04x: " % addr)
        addr += 16
        for val in group:
            if val is not None:
                log_no_newline("%02x" % val)
        log("")

def hexdumpstr(a):
    b = bytearray(a)
    addr = 0
    out = ''
    for group in compat_izip_longest(*[iter(b)]*16):
        out += ("%04x:" % addr)
        addr += 16
        for val in group:
            if val is not None:
                out += (" %02x" % val)
        out += '\n'
    return out

def hexdump_ascii(a):
    binfile = bincopy.BinFile()
    binfile.add_binary(a, 0)
    log(binfile.as_hexdump())

def fmt_num(num, suffix='', base=1000):
    num = float(num)
    units = ['','K','M','G','T']
    for unit in units:
        if abs(num) < base or unit == units[-1]:
            return "%3.3f%s%s" % (num, unit, suffix)
        num /= base
