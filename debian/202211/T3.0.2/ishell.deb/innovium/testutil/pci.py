
#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

from ctypes import *
from ifcs_ctypes import *

def read32(addr):

    node_id = 0
    # Get the class object
    _class = im_nmgr_get_class(node_id)

    # Read the PCIe reg
    regval = c_uint32(0)
    rc = _class.contents.pci_reg_read32(node_id, addr, byref(regval));
    assert rc == IFCS_SUCCESS, "pci reg read failed: rc = " + str(rc)
    return regval.value


def write32(addr, regval):

    node_id = 0
    # Get the class object
    _class = im_nmgr_get_class(node_id)

    # Write to the reg
    rc = _class.contents.pci_reg_write32(node_id, addr, regval);
    assert rc == IFCS_SUCCESS, "pci reg read failed: rc = " + str(rc)

def read16(addr):

    node_id = 0
    # Get the class object
    _class = im_nmgr_get_class(node_id)

    # Read the PCIe reg
    regval = c_uint16(0)
    rc = _class.contents.pci_reg_read16(node_id, addr, byref(regval));
    assert rc == IFCS_SUCCESS, "pci reg read failed: rc = " + str(rc)
    return regval.value


def write16(addr, regval):

    node_id = 0
    # Get the class object
    _class = im_nmgr_get_class(node_id)

    # Write to the reg
    rc = _class.contents.pci_reg_write16(node_id, addr, regval);
    assert rc == IFCS_SUCCESS, "pci reg read failed: rc = " + str(rc)

def get_reg_struct(regname):
    # Note: should be done per-node, but would need to add node param
    # through the whole call chain
    prefix_map = {IM_NMGR_NODE_DEVICE_TYPE_TERALYNX: "tl_",
                  IM_NMGR_NODE_DEVICE_TYPE_K2: "k2_" }

    prefix = prefix_map[im_nmgr_node_device_type_get(0)]

    try:
        reg_struct = eval('struct_' + prefix + regname.lower())
    except:
        reg_struct = eval('struct_' + regname.lower())
    return reg_struct

def learn_intr_miss_cnt(node_id):
    # Get the class object
    _class = im_nmgr_get_class(node_id)

    # Read the PCIe reg
    intr_miss_cnt = pci_intr_miss(0)
    rc = _class.contents.pci_intr_miss_stats(node_id, byref(intr_miss_cnt));
    assert rc == IFCS_SUCCESS, "pci intr miss count get failed: rc = " + str(rc)
    return intr_miss_cnt.lrn_intr_miss

def field_mask_and_shift(regname, fieldname):
    reg_struct = get_reg_struct(regname)
    fieldname = fieldname.lower()

    shift = 0
    for field in reg_struct._fields_:
        fieldwidth = field[2]
        if field[0].lower() == fieldname:
            # this is our field.  Make the mask and return
            mask = ((0xffffffff >> (32 - fieldwidth)) << shift)
            return (mask, shift)
            break
        # not our field.
        shift += fieldwidth
    assert 0, "register field {}.{} not found".format(regname, fieldname)

def read_fields(regname):
    pci_offset = eval(regname.upper())
    reg_struct = get_reg_struct(regname)
    out = {}
    remainingbits = read32(pci_offset)
    for field in reg_struct._fields_:
        fieldname = field[0]
        fieldwidth = field[2]
        out[fieldname] = remainingbits & (0xffffffff >> (32 - fieldwidth))
        remainingbits = remainingbits >> fieldwidth
    return out

# syntax: write_fields('REG', field1=1, field2=5, ...)
def write_fields(regname, **fields):
    pci_offset = eval(regname.upper())
    reg_struct = get_reg_struct(regname)

    regval = read32(pci_offset)
    for fieldname, v in fields.items():
        if type(v) is str:
            fieldval = int(v, 0)
        else:
            fieldval = v
        fieldname = fieldname.lower()
        mask, shift = field_mask_and_shift(regname, fieldname)

        assert ((fieldval << shift) & ~mask) == 0, \
            "Field value {} too large for field {}.{}".format(fieldval, regname,fieldname)
        regval &= ~mask
        regval |= fieldval << shift
    write32(pci_offset, regval)
