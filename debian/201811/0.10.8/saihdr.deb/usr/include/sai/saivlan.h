

#if !defined (__SAIVLAN_H_)
#define __SAIVLAN_H_

#include <saitypes.h>




#define SAI_VLAN_COUNTER_SET_DEFAULT 0


typedef enum _sai_vlan_tagging_mode_t
{
    SAI_VLAN_TAGGING_MODE_UNTAGGED,

    SAI_VLAN_TAGGING_MODE_TAGGED,

    SAI_VLAN_TAGGING_MODE_PRIORITY_TAGGED

} sai_vlan_tagging_mode_t;


typedef enum _sai_vlan_mcast_lookup_key_type_t
{
    SAI_VLAN_MCAST_LOOKUP_KEY_TYPE_MAC_DA,

    SAI_VLAN_MCAST_LOOKUP_KEY_TYPE_XG,

    SAI_VLAN_MCAST_LOOKUP_KEY_TYPE_SG,

    SAI_VLAN_MCAST_LOOKUP_KEY_TYPE_XG_AND_SG

} sai_vlan_mcast_lookup_key_type_t;


typedef enum _sai_vlan_flood_control_type_t
{
    
    SAI_VLAN_FLOOD_CONTROL_TYPE_ALL,

    
    SAI_VLAN_FLOOD_CONTROL_TYPE_NONE,

    
    SAI_VLAN_FLOOD_CONTROL_TYPE_L2MC_GROUP,

} sai_vlan_flood_control_type_t;


typedef enum _sai_vlan_attr_t
{
    
    SAI_VLAN_ATTR_START,

    
    SAI_VLAN_ATTR_VLAN_ID = SAI_VLAN_ATTR_START,

    
    SAI_VLAN_ATTR_MEMBER_LIST,

    
    SAI_VLAN_ATTR_MAX_LEARNED_ADDRESSES,

    
    SAI_VLAN_ATTR_STP_INSTANCE,

    
    SAI_VLAN_ATTR_LEARN_DISABLE,

    
    SAI_VLAN_ATTR_IPV4_MCAST_LOOKUP_KEY_TYPE,

    
    SAI_VLAN_ATTR_IPV6_MCAST_LOOKUP_KEY_TYPE,

    
    SAI_VLAN_ATTR_UNKNOWN_NON_IP_MCAST_OUTPUT_GROUP_ID,

    
    SAI_VLAN_ATTR_UNKNOWN_IPV4_MCAST_OUTPUT_GROUP_ID,

    
    SAI_VLAN_ATTR_UNKNOWN_IPV6_MCAST_OUTPUT_GROUP_ID,

    
    SAI_VLAN_ATTR_UNKNOWN_LINKLOCAL_MCAST_OUTPUT_GROUP_ID,

    
    SAI_VLAN_ATTR_INGRESS_ACL,

    
    SAI_VLAN_ATTR_EGRESS_ACL,

    
    SAI_VLAN_ATTR_META_DATA,

    
    SAI_VLAN_ATTR_UNKNOWN_UNICAST_FLOOD_CONTROL_TYPE,

    
    SAI_VLAN_ATTR_UNKNOWN_UNICAST_FLOOD_GROUP,

    
    SAI_VLAN_ATTR_UNKNOWN_MULTICAST_FLOOD_CONTROL_TYPE,

    
    SAI_VLAN_ATTR_UNKNOWN_MULTICAST_FLOOD_GROUP,

    
    SAI_VLAN_ATTR_BROADCAST_FLOOD_CONTROL_TYPE,

    
    SAI_VLAN_ATTR_BROADCAST_FLOOD_GROUP,

    
    SAI_VLAN_ATTR_END,

    
    SAI_VLAN_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_VLAN_ATTR_CUSTOM_IGMP_SNOOPING_ENABLE,

    
    SAI_VLAN_ATTR_TAM_OBJECT,

    
    SAI_VLAN_ATTR_CUSTOM_RANGE_END

} sai_vlan_attr_t;


typedef enum _sai_vlan_member_attr_t
{
    
    SAI_VLAN_MEMBER_ATTR_START,

    
    SAI_VLAN_MEMBER_ATTR_VLAN_ID = SAI_VLAN_MEMBER_ATTR_START,

    
    SAI_VLAN_MEMBER_ATTR_BRIDGE_PORT_ID,

    
    SAI_VLAN_MEMBER_ATTR_VLAN_TAGGING_MODE,

    
    SAI_VLAN_MEMBER_ATTR_END,

    
    SAI_VLAN_MEMBER_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_VLAN_MEMBER_ATTR_CUSTOM_RANGE_END

} sai_vlan_member_attr_t;


typedef enum _sai_vlan_stat_t
{
    SAI_VLAN_STAT_IN_OCTETS,
    SAI_VLAN_STAT_IN_PACKETS,
    SAI_VLAN_STAT_IN_UCAST_PKTS,
    SAI_VLAN_STAT_IN_NON_UCAST_PKTS,
    SAI_VLAN_STAT_IN_DISCARDS,
    SAI_VLAN_STAT_IN_ERRORS,
    SAI_VLAN_STAT_IN_UNKNOWN_PROTOS,
    SAI_VLAN_STAT_OUT_OCTETS,
    SAI_VLAN_STAT_OUT_PACKETS,
    SAI_VLAN_STAT_OUT_UCAST_PKTS,
    SAI_VLAN_STAT_OUT_NON_UCAST_PKTS,
    SAI_VLAN_STAT_OUT_DISCARDS,
    SAI_VLAN_STAT_OUT_ERRORS,
    SAI_VLAN_STAT_OUT_QLEN

} sai_vlan_stat_t;


typedef sai_status_t (*sai_create_vlan_fn)(
        _Out_ sai_object_id_t *vlan_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_vlan_fn)(
        _In_ sai_object_id_t vlan_id);


typedef sai_status_t (*sai_set_vlan_attribute_fn)(
        _In_ sai_object_id_t vlan_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_vlan_attribute_fn)(
        _In_ sai_object_id_t vlan_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_create_vlan_member_fn)(
        _Out_ sai_object_id_t *vlan_member_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_vlan_member_fn)(
        _In_ sai_object_id_t vlan_member_id);


typedef sai_status_t (*sai_set_vlan_member_attribute_fn)(
        _In_ sai_object_id_t vlan_member_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_vlan_member_attribute_fn)(
        _In_ sai_object_id_t vlan_member_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_get_vlan_stats_fn)(
        _In_ sai_object_id_t vlan_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_get_vlan_stats_ext_fn)(
        _In_ sai_object_id_t vlan_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _In_ sai_stats_mode_t mode,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_clear_vlan_stats_fn)(
        _In_ sai_object_id_t vlan_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids);


typedef struct _sai_vlan_api_t
{
    sai_create_vlan_fn                  create_vlan;
    sai_remove_vlan_fn                  remove_vlan;
    sai_set_vlan_attribute_fn           set_vlan_attribute;
    sai_get_vlan_attribute_fn           get_vlan_attribute;
    sai_create_vlan_member_fn           create_vlan_member;
    sai_remove_vlan_member_fn           remove_vlan_member;
    sai_set_vlan_member_attribute_fn    set_vlan_member_attribute;
    sai_get_vlan_member_attribute_fn    get_vlan_member_attribute;
    sai_bulk_object_create_fn           create_vlan_members;
    sai_bulk_object_remove_fn           remove_vlan_members;
    sai_get_vlan_stats_fn               get_vlan_stats;
    sai_get_vlan_stats_ext_fn           get_vlan_stats_ext;
    sai_clear_vlan_stats_fn             clear_vlan_stats;

} sai_vlan_api_t;


#endif 
