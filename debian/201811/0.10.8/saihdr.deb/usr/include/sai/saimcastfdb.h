

#if !defined (__SAIMCASTFDB_H_)
#define __SAIMCASTFDB_H_

#include <saitypes.h>




typedef struct _sai_mcast_fdb_entry_t
{
    
    sai_object_id_t switch_id;

    
    sai_mac_t mac_address;

    
    sai_object_id_t bv_id;

} sai_mcast_fdb_entry_t;


typedef enum _sai_mcast_fdb_entry_attr_t
{
    
    SAI_MCAST_FDB_ENTRY_ATTR_START,

    
    SAI_MCAST_FDB_ENTRY_ATTR_GROUP_ID = SAI_MCAST_FDB_ENTRY_ATTR_START,

    
    SAI_MCAST_FDB_ENTRY_ATTR_PACKET_ACTION,

    
    SAI_MCAST_FDB_ENTRY_ATTR_META_DATA,

    
    SAI_MCAST_FDB_ENTRY_ATTR_END,

    
    SAI_MCAST_FDB_ENTRY_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_MCAST_FDB_ENTRY_ATTR_CUSTOM_RANGE_END

} sai_mcast_fdb_entry_attr_t;


typedef sai_status_t (*sai_create_mcast_fdb_entry_fn)(
        _In_ const sai_mcast_fdb_entry_t *mcast_fdb_entry,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_mcast_fdb_entry_fn)(
        _In_ const sai_mcast_fdb_entry_t *mcast_fdb_entry);


typedef sai_status_t (*sai_set_mcast_fdb_entry_attribute_fn)(
        _In_ const sai_mcast_fdb_entry_t *mcast_fdb_entry,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_mcast_fdb_entry_attribute_fn)(
        _In_ const sai_mcast_fdb_entry_t *mcast_fdb_entry,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef struct _sai_mcast_fdb_api_t
{
    sai_create_mcast_fdb_entry_fn                     create_mcast_fdb_entry;
    sai_remove_mcast_fdb_entry_fn                     remove_mcast_fdb_entry;
    sai_set_mcast_fdb_entry_attribute_fn              set_mcast_fdb_entry_attribute;
    sai_get_mcast_fdb_entry_attribute_fn              get_mcast_fdb_entry_attribute;

} sai_mcast_fdb_api_t;


#endif 
