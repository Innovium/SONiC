

#if !defined (__SAILAG_H_)
#define __SAILAG_H_

#include <saitypes.h>




typedef enum _sai_lag_attr_t
{
    
    SAI_LAG_ATTR_START,

    
    SAI_LAG_ATTR_PORT_LIST = SAI_LAG_ATTR_START,

    

    
    SAI_LAG_ATTR_INGRESS_ACL,

    
    SAI_LAG_ATTR_EGRESS_ACL,

    
    SAI_LAG_ATTR_PORT_VLAN_ID,

    
    SAI_LAG_ATTR_DEFAULT_VLAN_PRIORITY,

    
    SAI_LAG_ATTR_DROP_UNTAGGED,

    
    SAI_LAG_ATTR_DROP_TAGGED,

    
    SAI_LAG_ATTR_END,

    
    SAI_LAG_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_LAG_ATTR_CUSTOM_RANGE_END

} sai_lag_attr_t;


typedef sai_status_t (*sai_create_lag_fn)(
        _Out_ sai_object_id_t *lag_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_lag_fn)(
        _In_ sai_object_id_t lag_id);


typedef sai_status_t (*sai_set_lag_attribute_fn)(
        _In_ sai_object_id_t lag_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_lag_attribute_fn)(
        _In_ sai_object_id_t lag_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef enum _sai_lag_member_attr_t
{
    
    SAI_LAG_MEMBER_ATTR_START,

    
    SAI_LAG_MEMBER_ATTR_LAG_ID = SAI_LAG_MEMBER_ATTR_START,

    
    SAI_LAG_MEMBER_ATTR_PORT_ID,

    
    SAI_LAG_MEMBER_ATTR_EGRESS_DISABLE,

    
    SAI_LAG_MEMBER_ATTR_INGRESS_DISABLE,

    
    SAI_LAG_MEMBER_ATTR_END,

    
    SAI_LAG_MEMBER_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_LAG_MEMBER_ATTR_CUSTOM_RANGE_END

} sai_lag_member_attr_t;


typedef sai_status_t (*sai_create_lag_member_fn)(
        _Out_ sai_object_id_t *lag_member_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_lag_member_fn)(
        _In_ sai_object_id_t lag_member_id);


typedef sai_status_t (*sai_set_lag_member_attribute_fn)(
        _In_ sai_object_id_t lag_member_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_lag_member_attribute_fn)(
        _In_ sai_object_id_t lag_member_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef struct _sai_lag_api_t
{
    sai_create_lag_fn                create_lag;
    sai_remove_lag_fn                remove_lag;
    sai_set_lag_attribute_fn         set_lag_attribute;
    sai_get_lag_attribute_fn         get_lag_attribute;
    sai_create_lag_member_fn         create_lag_member;
    sai_remove_lag_member_fn         remove_lag_member;
    sai_set_lag_member_attribute_fn  set_lag_member_attribute;
    sai_get_lag_member_attribute_fn  get_lag_member_attribute;
    sai_bulk_object_create_fn        create_lag_members;
    sai_bulk_object_remove_fn        remove_lag_members;
} sai_lag_api_t;


#endif 
