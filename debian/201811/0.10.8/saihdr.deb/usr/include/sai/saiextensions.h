

#ifndef __SAIEXTENSIONS_H_
#define __SAIEXTENSIONS_H_

#include <saitypes.h>


#include "saitypesextensions.h"
#include "saiswitchextensions.h"


#include "saiexperimentalbmtor.h"


typedef enum _sai_api_extensions_t
{
    SAI_API_EXTENSIONS_RANGE_START = SAI_API_MAX,

    SAI_API_BMTOR = SAI_API_EXTENSIONS_RANGE_START,

    

    SAI_API_EXTENSIONS_RANGE_START_END

} sai_api_extensions_t;

#endif 
