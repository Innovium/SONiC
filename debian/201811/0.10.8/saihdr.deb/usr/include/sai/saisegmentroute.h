

#if !defined (__SAISEGMENTROUTE_H_)
#define __SAISEGMENTROUTE_H_

#include <saitypes.h>




typedef enum _sai_segmentroute_sidlist_type_t
{
    
    SAI_SEGMENTROUTE_SIDLIST_TYPE_INSERT,

    
    SAI_SEGMENTROUTE_SIDLIST_TYPE_ENCAPS,

    
    SAI_SEGMENTROUTE_SIDLIST_TYPE_CUSTOM_RANGE_BASE = 0x10000000

} sai_segmentroute_sidlist_type_t;


typedef enum _sai_segmentroute_sidlist_attr_t
{
    
    SAI_SEGMENTROUTE_SIDLIST_ATTR_START = 0x00000000,

    
    SAI_SEGMENTROUTE_SIDLIST_ATTR_TYPE = SAI_SEGMENTROUTE_SIDLIST_ATTR_START,

    
    SAI_SEGMENTROUTE_SIDLIST_ATTR_TLV_LIST,

    
    SAI_SEGMENTROUTE_SIDLIST_ATTR_SEGMENT_LIST,

    
    SAI_SEGMENTROUTE_SIDLIST_ATTR_END,

    
    SAI_SEGMENTROUTE_SIDLIST_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_SEGMENTROUTE_SIDLIST_ATTR_CUSTOM_RANGE_END
} sai_segmentroute_sidlist_attr_t;


typedef sai_status_t (*sai_create_segmentroute_sidlist_fn)(
        _Out_ sai_object_id_t *segmentroute_sidlist_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_segmentroute_sidlist_fn)(
        _In_ sai_object_id_t segmentroute_sidlist_id);


typedef sai_status_t (*sai_set_segmentroute_sidlist_attribute_fn)(
        _In_ sai_object_id_t segmentroute_sidlist_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_segmentroute_sidlist_attribute_fn)(
        _In_ sai_object_id_t segmentroute_sidlist_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef struct _sai_segmentroute_api_t
{
    sai_create_segmentroute_sidlist_fn        create_segmentroute_sidlist;
    sai_remove_segmentroute_sidlist_fn        remove_segmentroute_sidlist;
    sai_set_segmentroute_sidlist_attribute_fn set_segmentroute_sidlist_attribute;
    sai_get_segmentroute_sidlist_attribute_fn get_segmentroute_sidlist_attribute;
    sai_bulk_object_create_fn                 create_segmentroute_sidlists;
    sai_bulk_object_remove_fn                 remove_segmentroute_sidlists;
} sai_segmentroute_api_t;


#endif 
