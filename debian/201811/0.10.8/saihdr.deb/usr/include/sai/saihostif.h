

#if !defined (__SAIHOSTIF_H_)
#define __SAIHOSTIF_H_

#include <saitypes.h>




#define SAI_HOSTIF_NAME_SIZE 16


typedef enum _sai_hostif_trap_group_attr_t
{
    
    SAI_HOSTIF_TRAP_GROUP_ATTR_START,

    
    SAI_HOSTIF_TRAP_GROUP_ATTR_ADMIN_STATE = SAI_HOSTIF_TRAP_GROUP_ATTR_START,

    
    SAI_HOSTIF_TRAP_GROUP_ATTR_QUEUE,

    
    SAI_HOSTIF_TRAP_GROUP_ATTR_POLICER,

    
    SAI_HOSTIF_TRAP_GROUP_ATTR_END,

    
    SAI_HOSTIF_TRAP_GROUP_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_HOSTIF_TRAP_GROUP_ATTR_CUSTOM_RANGE_END

} sai_hostif_trap_group_attr_t;


typedef sai_status_t (*sai_create_hostif_trap_group_fn)(
        _Out_ sai_object_id_t *hostif_trap_group_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_hostif_trap_group_fn)(
        _In_ sai_object_id_t hostif_trap_group_id);


typedef sai_status_t (*sai_set_hostif_trap_group_attribute_fn)(
        _In_ sai_object_id_t hostif_trap_group_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_hostif_trap_group_attribute_fn)(
        _In_ sai_object_id_t hostif_trap_group_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef enum _sai_hostif_trap_type_t
{
    
    SAI_HOSTIF_TRAP_TYPE_START = 0x00000000,

    

    

    
    SAI_HOSTIF_TRAP_TYPE_STP = SAI_HOSTIF_TRAP_TYPE_START,

    
    SAI_HOSTIF_TRAP_TYPE_LACP = 0x00000001,

    
    SAI_HOSTIF_TRAP_TYPE_EAPOL = 0x00000002,

    
    SAI_HOSTIF_TRAP_TYPE_LLDP = 0x00000003,

    
    SAI_HOSTIF_TRAP_TYPE_PVRST = 0x00000004,

    
    SAI_HOSTIF_TRAP_TYPE_IGMP_TYPE_QUERY = 0x00000005,

    
    SAI_HOSTIF_TRAP_TYPE_IGMP_TYPE_LEAVE = 0x00000006,

    
    SAI_HOSTIF_TRAP_TYPE_IGMP_TYPE_V1_REPORT = 0x00000007,

    
    SAI_HOSTIF_TRAP_TYPE_IGMP_TYPE_V2_REPORT = 0x00000008,

    
    SAI_HOSTIF_TRAP_TYPE_IGMP_TYPE_V3_REPORT = 0x00000009,

    
    SAI_HOSTIF_TRAP_TYPE_SAMPLEPACKET = 0x0000000a,

    
    SAI_HOSTIF_TRAP_TYPE_UDLD = 0x0000000b,

    
    SAI_HOSTIF_TRAP_TYPE_CDP = 0x0000000c,

    
    SAI_HOSTIF_TRAP_TYPE_VTP = 0x0000000d,

    
    SAI_HOSTIF_TRAP_TYPE_DTP = 0x0000000e,

    
    SAI_HOSTIF_TRAP_TYPE_PAGP = 0x0000000f,

    
    SAI_HOSTIF_TRAP_TYPE_PTP = 0x00000010,

    
    SAI_HOSTIF_TRAP_TYPE_PTP_TX_EVENT = 0x00000011,

    
    SAI_HOSTIF_TRAP_TYPE_SWITCH_CUSTOM_RANGE_BASE = 0x00001000,

    

    
    SAI_HOSTIF_TRAP_TYPE_ARP_REQUEST = 0x00002000,

    
    SAI_HOSTIF_TRAP_TYPE_ARP_RESPONSE = 0x00002001,

    
    SAI_HOSTIF_TRAP_TYPE_DHCP = 0x00002002,

    
    SAI_HOSTIF_TRAP_TYPE_OSPF = 0x00002003,

    
    SAI_HOSTIF_TRAP_TYPE_PIM = 0x00002004,

    
    SAI_HOSTIF_TRAP_TYPE_VRRP = 0x00002005,

    
    SAI_HOSTIF_TRAP_TYPE_DHCPV6 = 0x00002006,

    
    SAI_HOSTIF_TRAP_TYPE_OSPFV6 = 0x00002007,

    
    SAI_HOSTIF_TRAP_TYPE_VRRPV6 = 0x00002008,

    
    SAI_HOSTIF_TRAP_TYPE_IPV6_NEIGHBOR_DISCOVERY = 0x00002009,

    
    SAI_HOSTIF_TRAP_TYPE_IPV6_MLD_V1_V2 = 0x0000200a,

    
    SAI_HOSTIF_TRAP_TYPE_IPV6_MLD_V1_REPORT = 0x0000200b,

    
    SAI_HOSTIF_TRAP_TYPE_IPV6_MLD_V1_DONE = 0x0000200c,

    
    SAI_HOSTIF_TRAP_TYPE_MLD_V2_REPORT = 0x0000200d,

    
    SAI_HOSTIF_TRAP_TYPE_UNKNOWN_L3_MULTICAST = 0x0000200e,

    
    SAI_HOSTIF_TRAP_TYPE_ROUTER_CUSTOM_RANGE_BASE = 0x00003000,

    

    
    SAI_HOSTIF_TRAP_TYPE_IP2ME = 0x00004000,

    
    SAI_HOSTIF_TRAP_TYPE_SSH = 0x00004001,

    
    SAI_HOSTIF_TRAP_TYPE_SNMP = 0x00004002,

    
    SAI_HOSTIF_TRAP_TYPE_BGP = 0x00004003,

    
    SAI_HOSTIF_TRAP_TYPE_BGPV6 = 0x00004004,

    
    SAI_HOSTIF_TRAP_TYPE_LOCAL_IP_CUSTOM_RANGE_BASE = 0x00005000,

    

    
    SAI_HOSTIF_TRAP_TYPE_L3_MTU_ERROR = 0x00006000,

    
    SAI_HOSTIF_TRAP_TYPE_TTL_ERROR = 0x00006001,

    
    SAI_HOSTIF_TRAP_TYPE_STATIC_FDB_MOVE = 0x00006002,

    

    
    SAI_HOSTIF_TRAP_TYPE_PIPELINE_DISCARD_EGRESS_BUFFER = 0x00007000,

    
    SAI_HOSTIF_TRAP_TYPE_PIPELINE_DISCARD_WRED = 0x00007001,

    
    SAI_HOSTIF_TRAP_TYPE_PIPELINE_DISCARD_ROUTER = 0x00007002,

    
    SAI_HOSTIF_TRAP_TYPE_CUSTOM_EXCEPTION_RANGE_BASE = 0x00008000,

    
    SAI_HOSTIF_TRAP_TYPE_END = 0x00009000

} sai_hostif_trap_type_t;


typedef enum _sai_hostif_trap_attr_t
{
    
    SAI_HOSTIF_TRAP_ATTR_START,

    
    SAI_HOSTIF_TRAP_ATTR_TRAP_TYPE = SAI_HOSTIF_TRAP_ATTR_START,

    
    SAI_HOSTIF_TRAP_ATTR_PACKET_ACTION,

    
    SAI_HOSTIF_TRAP_ATTR_TRAP_PRIORITY,

    
    SAI_HOSTIF_TRAP_ATTR_EXCLUDE_PORT_LIST,

    
    SAI_HOSTIF_TRAP_ATTR_TRAP_GROUP,

    
    SAI_HOSTIF_TRAP_ATTR_MIRROR_SESSION,

    
    SAI_HOSTIF_TRAP_ATTR_END,

    
    SAI_HOSTIF_TRAP_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_HOSTIF_TRAP_ATTR_CUSTOM_RANGE_END

} sai_hostif_trap_attr_t;


typedef sai_status_t (*sai_create_hostif_trap_fn)(
        _Out_ sai_object_id_t *hostif_trap_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_hostif_trap_fn)(
        _In_ sai_object_id_t hostif_trap_id);


typedef sai_status_t (*sai_set_hostif_trap_attribute_fn)(
        _In_ sai_object_id_t hostif_trap_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_hostif_trap_attribute_fn)(
        _In_ sai_object_id_t hostif_trap_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef enum _sai_hostif_user_defined_trap_type_t
{
    
    SAI_HOSTIF_USER_DEFINED_TRAP_TYPE_START = 0x00000000,

    
    SAI_HOSTIF_USER_DEFINED_TRAP_TYPE_ROUTER = SAI_HOSTIF_USER_DEFINED_TRAP_TYPE_START,

    
    SAI_HOSTIF_USER_DEFINED_TRAP_TYPE_NEIGHBOR,

    
    SAI_HOSTIF_USER_DEFINED_TRAP_TYPE_NEIGH = SAI_HOSTIF_USER_DEFINED_TRAP_TYPE_NEIGHBOR,

    
    SAI_HOSTIF_USER_DEFINED_TRAP_TYPE_ACL,

    
    SAI_HOSTIF_USER_DEFINED_TRAP_TYPE_FDB,

    
    SAI_HOSTIF_USER_DEFINED_TRAP_TYPE_CUSTOM_RANGE_BASE = 0x00001000,

    
    SAI_HOSTIF_USER_DEFINED_TRAP_TYPE_END,

} sai_hostif_user_defined_trap_type_t;


typedef enum _sai_hostif_user_defined_trap_attr_t
{
    
    SAI_HOSTIF_USER_DEFINED_TRAP_ATTR_START,

    
    SAI_HOSTIF_USER_DEFINED_TRAP_ATTR_TYPE = SAI_HOSTIF_USER_DEFINED_TRAP_ATTR_START,

    
    SAI_HOSTIF_USER_DEFINED_TRAP_ATTR_TRAP_PRIORITY,

    
    SAI_HOSTIF_USER_DEFINED_TRAP_ATTR_TRAP_GROUP,

    
    SAI_HOSTIF_USER_DEFINED_TRAP_ATTR_END,

    
    SAI_HOSTIF_USER_DEFINED_TRAP_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_HOSTIF_USER_DEFINED_TRAP_ATTR_CUSTOM_RANGE_END

} sai_hostif_user_defined_trap_attr_t;


typedef sai_status_t (*sai_create_hostif_user_defined_trap_fn)(
        _Out_ sai_object_id_t *hostif_user_defined_trap_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_hostif_user_defined_trap_fn)(
        _In_ sai_object_id_t hostif_user_defined_trap_id);


typedef sai_status_t (*sai_set_hostif_user_defined_trap_attribute_fn)(
        _In_ sai_object_id_t hostif_user_defined_trap_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_hostif_user_defined_trap_attribute_fn)(
        _In_ sai_object_id_t hostif_user_defined_trap_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef enum _sai_hostif_type_t
{
    
    SAI_HOSTIF_TYPE_NETDEV,

    
    SAI_HOSTIF_TYPE_FD

} sai_hostif_type_t;


typedef enum _sai_hostif_vlan_tag_t
{
    
    SAI_HOSTIF_VLAN_TAG_STRIP,

    
    SAI_HOSTIF_VLAN_TAG_KEEP,

    
    SAI_HOSTIF_VLAN_TAG_ORIGINAL,

} sai_hostif_vlan_tag_t;


typedef enum _sai_hostif_attr_t
{
    
    SAI_HOSTIF_ATTR_START,

    
    SAI_HOSTIF_ATTR_TYPE = SAI_HOSTIF_ATTR_START,

    
    SAI_HOSTIF_ATTR_OBJ_ID,

    
    SAI_HOSTIF_ATTR_NAME,

    
    SAI_HOSTIF_ATTR_OPER_STATUS,

    
    SAI_HOSTIF_ATTR_QUEUE,

    
    SAI_HOSTIF_ATTR_VLAN_TAG,

    
    SAI_HOSTIF_ATTR_END,

    
    SAI_HOSTIF_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_HOSTIF_ATTR_CUSTOM_RANGE_END

} sai_hostif_attr_t;


typedef sai_status_t (*sai_create_hostif_fn)(
        _Out_ sai_object_id_t *hostif_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_hostif_fn)(
        _In_ sai_object_id_t hostif_id);


typedef sai_status_t (*sai_set_hostif_attribute_fn)(
        _In_ sai_object_id_t hostif_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_hostif_attribute_fn)(
        _In_ sai_object_id_t hostif_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef enum _sai_hostif_table_entry_type_t
{
    
    SAI_HOSTIF_TABLE_ENTRY_TYPE_PORT,

    
    SAI_HOSTIF_TABLE_ENTRY_TYPE_LAG,

    
    SAI_HOSTIF_TABLE_ENTRY_TYPE_VLAN,

    
    SAI_HOSTIF_TABLE_ENTRY_TYPE_TRAP_ID,

    
    SAI_HOSTIF_TABLE_ENTRY_TYPE_WILDCARD

} sai_hostif_table_entry_type_t;


typedef enum _sai_hostif_table_entry_channel_type_t
{
    
    SAI_HOSTIF_TABLE_ENTRY_CHANNEL_TYPE_CB,

    
    SAI_HOSTIF_TABLE_ENTRY_CHANNEL_TYPE_FD,

    
    SAI_HOSTIF_TABLE_ENTRY_CHANNEL_TYPE_NETDEV_PHYSICAL_PORT,

    
    SAI_HOSTIF_TABLE_ENTRY_CHANNEL_TYPE_NETDEV_LOGICAL_PORT,

    
    SAI_HOSTIF_TABLE_ENTRY_CHANNEL_TYPE_NETDEV_L3

} sai_hostif_table_entry_channel_type_t;


typedef enum _sai_hostif_table_entry_attr_t
{
    
    SAI_HOSTIF_TABLE_ENTRY_ATTR_START,

    
    SAI_HOSTIF_TABLE_ENTRY_ATTR_TYPE = SAI_HOSTIF_ATTR_START,

    
    SAI_HOSTIF_TABLE_ENTRY_ATTR_OBJ_ID,

    
    SAI_HOSTIF_TABLE_ENTRY_ATTR_TRAP_ID,

    
    SAI_HOSTIF_TABLE_ENTRY_ATTR_CHANNEL_TYPE,

    
    SAI_HOSTIF_TABLE_ENTRY_ATTR_HOST_IF,

    
    SAI_HOSTIF_TABLE_ENTRY_ATTR_END,

    
    SAI_HOSTIF_TABLE_ENTRY_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_HOSTIF_TABLE_ENTRY_ATTR_CUSTOM_RANGE_END

} sai_hostif_table_entry_attr_t;


typedef sai_status_t (*sai_create_hostif_table_entry_fn)(
        _Out_ sai_object_id_t *hostif_table_entry_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_hostif_table_entry_fn)(
        _In_ sai_object_id_t hostif_table_entry_id);


typedef sai_status_t (*sai_set_hostif_table_entry_attribute_fn)(
        _In_ sai_object_id_t hostif_table_entry_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_hostif_table_entry_attribute_fn)(
        _In_ sai_object_id_t hostif_table_entry_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef enum _sai_hostif_tx_type_t
{
    
    SAI_HOSTIF_TX_TYPE_PIPELINE_BYPASS,

    
    SAI_HOSTIF_TX_TYPE_PIPELINE_LOOKUP,

    
    SAI_HOSTIF_TX_TYPE_CUSTOM_RANGE_BASE = 0x10000000

} sai_hostif_tx_type_t;


typedef enum _sai_hostif_packet_attr_t
{
    
    SAI_HOSTIF_PACKET_ATTR_START,

    
    SAI_HOSTIF_PACKET_ATTR_HOSTIF_TRAP_ID = SAI_HOSTIF_PACKET_ATTR_START,

    
    SAI_HOSTIF_PACKET_ATTR_INGRESS_PORT,

    
    SAI_HOSTIF_PACKET_ATTR_INGRESS_LAG,

    
    SAI_HOSTIF_PACKET_ATTR_HOSTIF_TX_TYPE,

    
    SAI_HOSTIF_PACKET_ATTR_EGRESS_PORT_OR_LAG,

    
    SAI_HOSTIF_PACKET_ATTR_BRIDGE_ID,

    
    SAI_HOSTIF_PACKET_ATTR_TIMESTAMP,

    
    SAI_HOSTIF_PACKET_ATTR_END,

    
    SAI_HOSTIF_PACKET_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_HOSTIF_PACKET_ATTR_CUSTOM_RANGE_END

} sai_hostif_packet_attr_t;


typedef sai_status_t (*sai_recv_hostif_packet_fn)(
        _In_ sai_object_id_t hostif_id,
        _Inout_ sai_size_t *buffer_size,
        _Out_ void *buffer,
        _Inout_ uint32_t *attr_count,
        _Out_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_send_hostif_packet_fn)(
        _In_ sai_object_id_t hostif_id,
        _In_ sai_size_t buffer_size,
        _In_ const void *buffer,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef void (*sai_packet_event_notification_fn)(
        _In_ sai_object_id_t switch_id,
        _In_ sai_size_t buffer_size,
        _In_ const void *buffer,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef struct _sai_hostif_api_t
{
    sai_create_hostif_fn                           create_hostif;
    sai_remove_hostif_fn                           remove_hostif;
    sai_set_hostif_attribute_fn                    set_hostif_attribute;
    sai_get_hostif_attribute_fn                    get_hostif_attribute;
    sai_create_hostif_table_entry_fn               create_hostif_table_entry;
    sai_remove_hostif_table_entry_fn               remove_hostif_table_entry;
    sai_set_hostif_table_entry_attribute_fn        set_hostif_table_entry_attribute;
    sai_get_hostif_table_entry_attribute_fn        get_hostif_table_entry_attribute;
    sai_create_hostif_trap_group_fn                create_hostif_trap_group;
    sai_remove_hostif_trap_group_fn                remove_hostif_trap_group;
    sai_set_hostif_trap_group_attribute_fn         set_hostif_trap_group_attribute;
    sai_get_hostif_trap_group_attribute_fn         get_hostif_trap_group_attribute;
    sai_create_hostif_trap_fn                      create_hostif_trap;
    sai_remove_hostif_trap_fn                      remove_hostif_trap;
    sai_set_hostif_trap_attribute_fn               set_hostif_trap_attribute;
    sai_get_hostif_trap_attribute_fn               get_hostif_trap_attribute;
    sai_create_hostif_user_defined_trap_fn         create_hostif_user_defined_trap;
    sai_remove_hostif_user_defined_trap_fn         remove_hostif_user_defined_trap;
    sai_set_hostif_user_defined_trap_attribute_fn  set_hostif_user_defined_trap_attribute;
    sai_get_hostif_user_defined_trap_attribute_fn  get_hostif_user_defined_trap_attribute;
    sai_recv_hostif_packet_fn                      recv_hostif_packet;
    sai_send_hostif_packet_fn                      send_hostif_packet;
} sai_hostif_api_t;


#endif 
