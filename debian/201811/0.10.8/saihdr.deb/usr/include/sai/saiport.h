

#if !defined (__SAIPORT_H_)
#define __SAIPORT_H_

#include <saitypes.h>




typedef enum _sai_port_type_t
{
    
    SAI_PORT_TYPE_LOGICAL,

    
    SAI_PORT_TYPE_CPU,

} sai_port_type_t;


typedef enum _sai_port_oper_status_t
{
    
    SAI_PORT_OPER_STATUS_UNKNOWN,

    
    SAI_PORT_OPER_STATUS_UP,

    
    SAI_PORT_OPER_STATUS_DOWN,

    
    SAI_PORT_OPER_STATUS_TESTING,

    
    SAI_PORT_OPER_STATUS_NOT_PRESENT

} sai_port_oper_status_t;


typedef struct _sai_port_oper_status_notification_t
{
    
    sai_object_id_t port_id;

    
    sai_port_oper_status_t port_state;

} sai_port_oper_status_notification_t;


typedef enum _sai_port_flow_control_mode_t
{
    
    SAI_PORT_FLOW_CONTROL_MODE_DISABLE,

    
    SAI_PORT_FLOW_CONTROL_MODE_TX_ONLY,

    
    SAI_PORT_FLOW_CONTROL_MODE_RX_ONLY,

    
    SAI_PORT_FLOW_CONTROL_MODE_BOTH_ENABLE,

} sai_port_flow_control_mode_t;


typedef enum _sai_port_internal_loopback_mode_t
{
    
    SAI_PORT_INTERNAL_LOOPBACK_MODE_NONE,

    
    SAI_PORT_INTERNAL_LOOPBACK_MODE_PHY,

    
    SAI_PORT_INTERNAL_LOOPBACK_MODE_MAC

} sai_port_internal_loopback_mode_t;


typedef enum _sai_port_media_type_t
{
    
    SAI_PORT_MEDIA_TYPE_NOT_PRESENT,

    
    SAI_PORT_MEDIA_TYPE_UNKNOWN,

    
    SAI_PORT_MEDIA_TYPE_FIBER,

    
    SAI_PORT_MEDIA_TYPE_COPPER,
} sai_port_media_type_t;


typedef enum _sai_port_breakout_mode_type_t
{
    
    SAI_PORT_BREAKOUT_MODE_TYPE_1_LANE = 0,

    
    SAI_PORT_BREAKOUT_MODE_TYPE_2_LANE = 1,

    
    SAI_PORT_BREAKOUT_MODE_TYPE_4_LANE = 2,

    
    SAI_PORT_BREAKOUT_MODE_TYPE_MAX
} sai_port_breakout_mode_type_t;


typedef enum _sai_port_fec_mode_t
{
    
    SAI_PORT_FEC_MODE_NONE,

    
    SAI_PORT_FEC_MODE_RS,

    
    SAI_PORT_FEC_MODE_FC,
} sai_port_fec_mode_t;


typedef enum _sai_port_priority_flow_control_mode_t
{
    
    SAI_PORT_PRIORITY_FLOW_CONTROL_MODE_COMBINED,

    
    SAI_PORT_PRIORITY_FLOW_CONTROL_MODE_SEPARATE,

} sai_port_priority_flow_control_mode_t;


typedef enum _sai_port_attr_t
{
    
    SAI_PORT_ATTR_START,

    

    
    SAI_PORT_ATTR_TYPE = SAI_PORT_ATTR_START,

    
    SAI_PORT_ATTR_OPER_STATUS,

    
    SAI_PORT_ATTR_SUPPORTED_BREAKOUT_MODE_TYPE,

    
    SAI_PORT_ATTR_CURRENT_BREAKOUT_MODE_TYPE,

    
    SAI_PORT_ATTR_QOS_NUMBER_OF_QUEUES,

    
    SAI_PORT_ATTR_QOS_QUEUE_LIST,

    
    SAI_PORT_ATTR_QOS_NUMBER_OF_SCHEDULER_GROUPS,

    
    SAI_PORT_ATTR_QOS_SCHEDULER_GROUP_LIST,

    
    SAI_PORT_ATTR_SUPPORTED_SPEED,

    
    SAI_PORT_ATTR_SUPPORTED_FEC_MODE,

    
    SAI_PORT_ATTR_SUPPORTED_HALF_DUPLEX_SPEED,

    
    SAI_PORT_ATTR_SUPPORTED_AUTO_NEG_MODE,

    
    SAI_PORT_ATTR_SUPPORTED_FLOW_CONTROL_MODE,

    
    SAI_PORT_ATTR_SUPPORTED_ASYMMETRIC_PAUSE_MODE,

    
    SAI_PORT_ATTR_SUPPORTED_MEDIA_TYPE,

    
    SAI_PORT_ATTR_REMOTE_ADVERTISED_SPEED,

    
    SAI_PORT_ATTR_REMOTE_ADVERTISED_FEC_MODE,

    
    SAI_PORT_ATTR_REMOTE_ADVERTISED_HALF_DUPLEX_SPEED,

    
    SAI_PORT_ATTR_REMOTE_ADVERTISED_AUTO_NEG_MODE,

    
    SAI_PORT_ATTR_REMOTE_ADVERTISED_FLOW_CONTROL_MODE,

    
    SAI_PORT_ATTR_REMOTE_ADVERTISED_ASYMMETRIC_PAUSE_MODE,

    
    SAI_PORT_ATTR_REMOTE_ADVERTISED_MEDIA_TYPE,

    
    SAI_PORT_ATTR_REMOTE_ADVERTISED_OUI_CODE,

    
    SAI_PORT_ATTR_NUMBER_OF_INGRESS_PRIORITY_GROUPS,

    
    SAI_PORT_ATTR_INGRESS_PRIORITY_GROUP_LIST,

    
    SAI_PORT_ATTR_EYE_VALUES,

    
    SAI_PORT_ATTR_OPER_SPEED,

    

    
    SAI_PORT_ATTR_HW_LANE_LIST,

    
    SAI_PORT_ATTR_SPEED,

    
    SAI_PORT_ATTR_FULL_DUPLEX_MODE,

    
    SAI_PORT_ATTR_AUTO_NEG_MODE,

    
    SAI_PORT_ATTR_ADMIN_STATE,

    
    SAI_PORT_ATTR_MEDIA_TYPE,

    
    SAI_PORT_ATTR_ADVERTISED_SPEED,

    
    SAI_PORT_ATTR_ADVERTISED_FEC_MODE,

    
    SAI_PORT_ATTR_ADVERTISED_HALF_DUPLEX_SPEED,

    
    SAI_PORT_ATTR_ADVERTISED_AUTO_NEG_MODE,

    
    SAI_PORT_ATTR_ADVERTISED_FLOW_CONTROL_MODE,

    
    SAI_PORT_ATTR_ADVERTISED_ASYMMETRIC_PAUSE_MODE,

    
    SAI_PORT_ATTR_ADVERTISED_MEDIA_TYPE,

    
    SAI_PORT_ATTR_ADVERTISED_OUI_CODE,

    
    SAI_PORT_ATTR_PORT_VLAN_ID,

    
    SAI_PORT_ATTR_DEFAULT_VLAN_PRIORITY,

    
    SAI_PORT_ATTR_DROP_UNTAGGED,

    
    SAI_PORT_ATTR_DROP_TAGGED,

    
    SAI_PORT_ATTR_INTERNAL_LOOPBACK_MODE,

    
    SAI_PORT_ATTR_FEC_MODE,

    
    SAI_PORT_ATTR_UPDATE_DSCP,

    
    SAI_PORT_ATTR_MTU,

    
    SAI_PORT_ATTR_FLOOD_STORM_CONTROL_POLICER_ID,

    
    SAI_PORT_ATTR_BROADCAST_STORM_CONTROL_POLICER_ID,

    
    SAI_PORT_ATTR_MULTICAST_STORM_CONTROL_POLICER_ID,

    
    SAI_PORT_ATTR_GLOBAL_FLOW_CONTROL_MODE,

    
    SAI_PORT_ATTR_INGRESS_ACL,

    
    SAI_PORT_ATTR_EGRESS_ACL,

    
    SAI_PORT_ATTR_INGRESS_MIRROR_SESSION,

    
    SAI_PORT_ATTR_EGRESS_MIRROR_SESSION,

    
    SAI_PORT_ATTR_INGRESS_SAMPLEPACKET_ENABLE,

    
    SAI_PORT_ATTR_EGRESS_SAMPLEPACKET_ENABLE,

    
    SAI_PORT_ATTR_POLICER_ID,

    
    SAI_PORT_ATTR_QOS_DEFAULT_TC,

    
    SAI_PORT_ATTR_QOS_DOT1P_TO_TC_MAP,

    
    SAI_PORT_ATTR_QOS_DOT1P_TO_COLOR_MAP,

    
    SAI_PORT_ATTR_QOS_DSCP_TO_TC_MAP,

    
    SAI_PORT_ATTR_QOS_DSCP_TO_COLOR_MAP,

    
    SAI_PORT_ATTR_QOS_TC_TO_QUEUE_MAP,

    
    SAI_PORT_ATTR_QOS_TC_AND_COLOR_TO_DOT1P_MAP,

    
    SAI_PORT_ATTR_QOS_TC_AND_COLOR_TO_DSCP_MAP,

    
    SAI_PORT_ATTR_QOS_TC_TO_PRIORITY_GROUP_MAP,

    
    SAI_PORT_ATTR_QOS_PFC_PRIORITY_TO_PRIORITY_GROUP_MAP,

    
    SAI_PORT_ATTR_QOS_PFC_PRIORITY_TO_QUEUE_MAP,

    
    SAI_PORT_ATTR_QOS_SCHEDULER_PROFILE_ID,

    
    SAI_PORT_ATTR_QOS_INGRESS_BUFFER_PROFILE_LIST,

    
    SAI_PORT_ATTR_QOS_EGRESS_BUFFER_PROFILE_LIST,

    
    SAI_PORT_ATTR_PRIORITY_FLOW_CONTROL_MODE,

    
    SAI_PORT_ATTR_PRIORITY_FLOW_CONTROL,

    
    SAI_PORT_ATTR_PRIORITY_FLOW_CONTROL_RX,

    
    SAI_PORT_ATTR_PRIORITY_FLOW_CONTROL_TX,

    
    SAI_PORT_ATTR_META_DATA,

    
    SAI_PORT_ATTR_EGRESS_BLOCK_PORT_LIST,

    
    SAI_PORT_ATTR_HW_PROFILE_ID,

    
    SAI_PORT_ATTR_EEE_ENABLE,

    
    SAI_PORT_ATTR_EEE_IDLE_TIME,

    
    SAI_PORT_ATTR_EEE_WAKE_TIME,

    
    SAI_PORT_ATTR_PORT_POOL_LIST,

    
    SAI_PORT_ATTR_ISOLATION_GROUP,

    
    SAI_PORT_ATTR_PKT_TX_ENABLE,

    
    SAI_PORT_ATTR_TAM_OBJECT,

    
    SAI_PORT_ATTR_SERDES_PREEMPHASIS,

    
    SAI_PORT_ATTR_SERDES_IDRIVER,

    
    SAI_PORT_ATTR_SERDES_IPREDRIVER,

    
    SAI_PORT_ATTR_END,

    
    SAI_PORT_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_PORT_ATTR_CUSTOM_RANGE_END

} sai_port_attr_t;


typedef enum _sai_port_stat_t
{
    
    SAI_PORT_STAT_IF_IN_OCTETS,

    
    SAI_PORT_STAT_IF_IN_UCAST_PKTS,

    
    SAI_PORT_STAT_IF_IN_NON_UCAST_PKTS,

    
    SAI_PORT_STAT_IF_IN_DISCARDS,

    
    SAI_PORT_STAT_IF_IN_ERRORS,

    
    SAI_PORT_STAT_IF_IN_UNKNOWN_PROTOS,

    
    SAI_PORT_STAT_IF_IN_BROADCAST_PKTS,

    
    SAI_PORT_STAT_IF_IN_MULTICAST_PKTS,

    
    SAI_PORT_STAT_IF_IN_VLAN_DISCARDS,

    
    SAI_PORT_STAT_IF_OUT_OCTETS,

    
    SAI_PORT_STAT_IF_OUT_UCAST_PKTS,

    
    SAI_PORT_STAT_IF_OUT_NON_UCAST_PKTS,

    
    SAI_PORT_STAT_IF_OUT_DISCARDS,

    
    SAI_PORT_STAT_IF_OUT_ERRORS,

    
    SAI_PORT_STAT_IF_OUT_QLEN,

    
    SAI_PORT_STAT_IF_OUT_BROADCAST_PKTS,

    
    SAI_PORT_STAT_IF_OUT_MULTICAST_PKTS,

    
    SAI_PORT_STAT_ETHER_STATS_DROP_EVENTS,

    
    SAI_PORT_STAT_ETHER_STATS_MULTICAST_PKTS,

    
    SAI_PORT_STAT_ETHER_STATS_BROADCAST_PKTS,

    
    SAI_PORT_STAT_ETHER_STATS_UNDERSIZE_PKTS,

    
    SAI_PORT_STAT_ETHER_STATS_FRAGMENTS,

    
    SAI_PORT_STAT_ETHER_STATS_PKTS_64_OCTETS,

    
    SAI_PORT_STAT_ETHER_STATS_PKTS_65_TO_127_OCTETS,

    
    SAI_PORT_STAT_ETHER_STATS_PKTS_128_TO_255_OCTETS,

    
    SAI_PORT_STAT_ETHER_STATS_PKTS_256_TO_511_OCTETS,

    
    SAI_PORT_STAT_ETHER_STATS_PKTS_512_TO_1023_OCTETS,

    
    SAI_PORT_STAT_ETHER_STATS_PKTS_1024_TO_1518_OCTETS,

    
    SAI_PORT_STAT_ETHER_STATS_PKTS_1519_TO_2047_OCTETS,

    
    SAI_PORT_STAT_ETHER_STATS_PKTS_2048_TO_4095_OCTETS,

    
    SAI_PORT_STAT_ETHER_STATS_PKTS_4096_TO_9216_OCTETS,

    
    SAI_PORT_STAT_ETHER_STATS_PKTS_9217_TO_16383_OCTETS,

    
    SAI_PORT_STAT_ETHER_STATS_OVERSIZE_PKTS,

    
    SAI_PORT_STAT_ETHER_RX_OVERSIZE_PKTS,

    
    SAI_PORT_STAT_ETHER_TX_OVERSIZE_PKTS,

    
    SAI_PORT_STAT_ETHER_STATS_JABBERS,

    
    SAI_PORT_STAT_ETHER_STATS_OCTETS,

    
    SAI_PORT_STAT_ETHER_STATS_PKTS,

    
    SAI_PORT_STAT_ETHER_STATS_COLLISIONS,

    
    SAI_PORT_STAT_ETHER_STATS_CRC_ALIGN_ERRORS,

    
    SAI_PORT_STAT_ETHER_STATS_TX_NO_ERRORS,

    
    SAI_PORT_STAT_ETHER_STATS_RX_NO_ERRORS,

    
    SAI_PORT_STAT_IP_IN_RECEIVES,

    
    SAI_PORT_STAT_IP_IN_OCTETS,

    
    SAI_PORT_STAT_IP_IN_UCAST_PKTS,

    
    SAI_PORT_STAT_IP_IN_NON_UCAST_PKTS,

    
    SAI_PORT_STAT_IP_IN_DISCARDS,

    
    SAI_PORT_STAT_IP_OUT_OCTETS,

    
    SAI_PORT_STAT_IP_OUT_UCAST_PKTS,

    
    SAI_PORT_STAT_IP_OUT_NON_UCAST_PKTS,

    
    SAI_PORT_STAT_IP_OUT_DISCARDS,

    
    SAI_PORT_STAT_IPV6_IN_RECEIVES,

    
    SAI_PORT_STAT_IPV6_IN_OCTETS,

    
    SAI_PORT_STAT_IPV6_IN_UCAST_PKTS,

    
    SAI_PORT_STAT_IPV6_IN_NON_UCAST_PKTS,

    
    SAI_PORT_STAT_IPV6_IN_MCAST_PKTS,

    
    SAI_PORT_STAT_IPV6_IN_DISCARDS,

    
    SAI_PORT_STAT_IPV6_OUT_OCTETS,

    
    SAI_PORT_STAT_IPV6_OUT_UCAST_PKTS,

    
    SAI_PORT_STAT_IPV6_OUT_NON_UCAST_PKTS,

    
    SAI_PORT_STAT_IPV6_OUT_MCAST_PKTS,

    
    SAI_PORT_STAT_IPV6_OUT_DISCARDS,

    
    SAI_PORT_STAT_GREEN_WRED_DROPPED_PACKETS,

    
    SAI_PORT_STAT_GREEN_WRED_DROPPED_BYTES,

    
    SAI_PORT_STAT_YELLOW_WRED_DROPPED_PACKETS,

    
    SAI_PORT_STAT_YELLOW_WRED_DROPPED_BYTES,

    
    SAI_PORT_STAT_RED_WRED_DROPPED_PACKETS,

    
    SAI_PORT_STAT_RED_WRED_DROPPED_BYTES,

    
    SAI_PORT_STAT_WRED_DROPPED_PACKETS,

    
    SAI_PORT_STAT_WRED_DROPPED_BYTES,

    
    SAI_PORT_STAT_ECN_MARKED_PACKETS,

    
    SAI_PORT_STAT_ETHER_IN_PKTS_64_OCTETS,

    
    SAI_PORT_STAT_ETHER_IN_PKTS_65_TO_127_OCTETS,

    
    SAI_PORT_STAT_ETHER_IN_PKTS_128_TO_255_OCTETS,

    
    SAI_PORT_STAT_ETHER_IN_PKTS_256_TO_511_OCTETS,

    
    SAI_PORT_STAT_ETHER_IN_PKTS_512_TO_1023_OCTETS,

    
    SAI_PORT_STAT_ETHER_IN_PKTS_1024_TO_1518_OCTETS,

    
    SAI_PORT_STAT_ETHER_IN_PKTS_1519_TO_2047_OCTETS,

    
    SAI_PORT_STAT_ETHER_IN_PKTS_2048_TO_4095_OCTETS,

    
    SAI_PORT_STAT_ETHER_IN_PKTS_4096_TO_9216_OCTETS,

    
    SAI_PORT_STAT_ETHER_IN_PKTS_9217_TO_16383_OCTETS,

    
    SAI_PORT_STAT_ETHER_OUT_PKTS_64_OCTETS,

    
    SAI_PORT_STAT_ETHER_OUT_PKTS_65_TO_127_OCTETS,

    
    SAI_PORT_STAT_ETHER_OUT_PKTS_128_TO_255_OCTETS,

    
    SAI_PORT_STAT_ETHER_OUT_PKTS_256_TO_511_OCTETS,

    
    SAI_PORT_STAT_ETHER_OUT_PKTS_512_TO_1023_OCTETS,

    
    SAI_PORT_STAT_ETHER_OUT_PKTS_1024_TO_1518_OCTETS,

    
    SAI_PORT_STAT_ETHER_OUT_PKTS_1519_TO_2047_OCTETS,

    
    SAI_PORT_STAT_ETHER_OUT_PKTS_2048_TO_4095_OCTETS,

    
    SAI_PORT_STAT_ETHER_OUT_PKTS_4096_TO_9216_OCTETS,

    
    SAI_PORT_STAT_ETHER_OUT_PKTS_9217_TO_16383_OCTETS,

    
    SAI_PORT_STAT_IN_CURR_OCCUPANCY_BYTES,

    
    SAI_PORT_STAT_IN_WATERMARK_BYTES,

    
    SAI_PORT_STAT_IN_SHARED_CURR_OCCUPANCY_BYTES,

    
    SAI_PORT_STAT_IN_SHARED_WATERMARK_BYTES,

    
    SAI_PORT_STAT_OUT_CURR_OCCUPANCY_BYTES,

    
    SAI_PORT_STAT_OUT_WATERMARK_BYTES,

    
    SAI_PORT_STAT_OUT_SHARED_CURR_OCCUPANCY_BYTES,

    
    SAI_PORT_STAT_OUT_SHARED_WATERMARK_BYTES,

    
    SAI_PORT_STAT_IN_DROPPED_PKTS,

    
    SAI_PORT_STAT_OUT_DROPPED_PKTS,

    
    SAI_PORT_STAT_PAUSE_RX_PKTS,

    
    SAI_PORT_STAT_PAUSE_TX_PKTS,

    
    SAI_PORT_STAT_PFC_0_RX_PKTS,

    
    SAI_PORT_STAT_PFC_0_TX_PKTS,

    
    SAI_PORT_STAT_PFC_1_RX_PKTS,

    
    SAI_PORT_STAT_PFC_1_TX_PKTS,

    
    SAI_PORT_STAT_PFC_2_RX_PKTS,

    
    SAI_PORT_STAT_PFC_2_TX_PKTS,

    
    SAI_PORT_STAT_PFC_3_RX_PKTS,

    
    SAI_PORT_STAT_PFC_3_TX_PKTS,

    
    SAI_PORT_STAT_PFC_4_RX_PKTS,

    
    SAI_PORT_STAT_PFC_4_TX_PKTS,

    
    SAI_PORT_STAT_PFC_5_RX_PKTS,

    
    SAI_PORT_STAT_PFC_5_TX_PKTS,

    
    SAI_PORT_STAT_PFC_6_RX_PKTS,

    
    SAI_PORT_STAT_PFC_6_TX_PKTS,

    
    SAI_PORT_STAT_PFC_7_RX_PKTS,

    
    SAI_PORT_STAT_PFC_7_TX_PKTS,

    
    SAI_PORT_STAT_PFC_0_RX_PAUSE_DURATION,

    
    SAI_PORT_STAT_PFC_0_TX_PAUSE_DURATION,

    
    SAI_PORT_STAT_PFC_1_RX_PAUSE_DURATION,

    
    SAI_PORT_STAT_PFC_1_TX_PAUSE_DURATION,

    
    SAI_PORT_STAT_PFC_2_RX_PAUSE_DURATION,

    
    SAI_PORT_STAT_PFC_2_TX_PAUSE_DURATION,

    
    SAI_PORT_STAT_PFC_3_RX_PAUSE_DURATION,

    
    SAI_PORT_STAT_PFC_3_TX_PAUSE_DURATION,

    
    SAI_PORT_STAT_PFC_4_RX_PAUSE_DURATION,

    
    SAI_PORT_STAT_PFC_4_TX_PAUSE_DURATION,

    
    SAI_PORT_STAT_PFC_5_RX_PAUSE_DURATION,

    
    SAI_PORT_STAT_PFC_5_TX_PAUSE_DURATION,

    
    SAI_PORT_STAT_PFC_6_RX_PAUSE_DURATION,

    
    SAI_PORT_STAT_PFC_6_TX_PAUSE_DURATION,

    
    SAI_PORT_STAT_PFC_7_RX_PAUSE_DURATION,

    
    SAI_PORT_STAT_PFC_7_TX_PAUSE_DURATION,

    
    SAI_PORT_STAT_PFC_0_ON2OFF_RX_PKTS,

    
    SAI_PORT_STAT_PFC_1_ON2OFF_RX_PKTS,

    
    SAI_PORT_STAT_PFC_2_ON2OFF_RX_PKTS,

    
    SAI_PORT_STAT_PFC_3_ON2OFF_RX_PKTS,

    
    SAI_PORT_STAT_PFC_4_ON2OFF_RX_PKTS,

    
    SAI_PORT_STAT_PFC_5_ON2OFF_RX_PKTS,

    
    SAI_PORT_STAT_PFC_6_ON2OFF_RX_PKTS,

    
    SAI_PORT_STAT_PFC_7_ON2OFF_RX_PKTS,

    
    SAI_PORT_STAT_DOT3_STATS_ALIGNMENT_ERRORS,

    
    SAI_PORT_STAT_DOT3_STATS_FCS_ERRORS,

    
    SAI_PORT_STAT_DOT3_STATS_SINGLE_COLLISION_FRAMES,

    
    SAI_PORT_STAT_DOT3_STATS_MULTIPLE_COLLISION_FRAMES,

    
    SAI_PORT_STAT_DOT3_STATS_SQE_TEST_ERRORS,

    
    SAI_PORT_STAT_DOT3_STATS_DEFERRED_TRANSMISSIONS,

    
    SAI_PORT_STAT_DOT3_STATS_LATE_COLLISIONS,

    
    SAI_PORT_STAT_DOT3_STATS_EXCESSIVE_COLLISIONS,

    
    SAI_PORT_STAT_DOT3_STATS_INTERNAL_MAC_TRANSMIT_ERRORS,

    
    SAI_PORT_STAT_DOT3_STATS_CARRIER_SENSE_ERRORS,

    
    SAI_PORT_STAT_DOT3_STATS_FRAME_TOO_LONGS,

    
    SAI_PORT_STAT_DOT3_STATS_INTERNAL_MAC_RECEIVE_ERRORS,

    
    SAI_PORT_STAT_DOT3_STATS_SYMBOL_ERRORS,

    
    SAI_PORT_STAT_DOT3_CONTROL_IN_UNKNOWN_OPCODES,

    
    SAI_PORT_STAT_EEE_TX_EVENT_COUNT,

    
    SAI_PORT_STAT_EEE_RX_EVENT_COUNT,

    
    SAI_PORT_STAT_EEE_TX_DURATION,

    
    SAI_PORT_STAT_EEE_RX_DURATION,

} sai_port_stat_t;


typedef sai_status_t (*sai_create_port_fn)(
        _Out_ sai_object_id_t *port_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_port_fn)(
        _In_ sai_object_id_t port_id);


typedef sai_status_t (*sai_set_port_attribute_fn)(
        _In_ sai_object_id_t port_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_port_attribute_fn)(
        _In_ sai_object_id_t port_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_get_port_stats_fn)(
        _In_ sai_object_id_t port_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_get_port_stats_ext_fn)(
        _In_ sai_object_id_t port_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _In_ sai_stats_mode_t mode,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_clear_port_stats_fn)(
        _In_ sai_object_id_t port_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids);


typedef sai_status_t (*sai_clear_port_all_stats_fn)(
        _In_ sai_object_id_t port_id);


typedef void (*sai_port_state_change_notification_fn)(
        _In_ uint32_t count,
        _In_ const sai_port_oper_status_notification_t *data);


typedef enum _sai_port_pool_attr_t
{
    
    SAI_PORT_POOL_ATTR_START,

    
    SAI_PORT_POOL_ATTR_PORT_ID = SAI_PORT_POOL_ATTR_START,

    
    SAI_PORT_POOL_ATTR_BUFFER_POOL_ID,

    
    SAI_PORT_POOL_ATTR_QOS_WRED_PROFILE_ID,

    
    SAI_PORT_POOL_ATTR_END,

    
    SAI_PORT_POOL_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_PORT_POOL_ATTR_CUSTOM_RANGE_END

} sai_port_pool_attr_t;


typedef enum _sai_port_pool_stat_t
{
    
    SAI_PORT_POOL_STAT_IF_OCTETS,

    
    SAI_PORT_POOL_STAT_GREEN_WRED_DROPPED_PACKETS,

    
    SAI_PORT_POOL_STAT_GREEN_WRED_DROPPED_BYTES,

    
    SAI_PORT_POOL_STAT_YELLOW_WRED_DROPPED_PACKETS,

    
    SAI_PORT_POOL_STAT_YELLOW_WRED_DROPPED_BYTES,

    
    SAI_PORT_POOL_STAT_RED_WRED_DROPPED_PACKETS,

    
    SAI_PORT_POOL_STAT_RED_WRED_DROPPED_BYTES,

    
    SAI_PORT_POOL_STAT_WRED_DROPPED_PACKETS,

    
    SAI_PORT_POOL_STAT_WRED_DROPPED_BYTES,

    
    SAI_PORT_POOL_STAT_GREEN_WRED_ECN_MARKED_PACKETS,

    
    SAI_PORT_POOL_STAT_GREEN_WRED_ECN_MARKED_BYTES,

    
    SAI_PORT_POOL_STAT_YELLOW_WRED_ECN_MARKED_PACKETS,

    
    SAI_PORT_POOL_STAT_YELLOW_WRED_ECN_MARKED_BYTES,

    
    SAI_PORT_POOL_STAT_RED_WRED_ECN_MARKED_PACKETS,

    
    SAI_PORT_POOL_STAT_RED_WRED_ECN_MARKED_BYTES,

    
    SAI_PORT_POOL_STAT_WRED_ECN_MARKED_PACKETS,

    
    SAI_PORT_POOL_STAT_WRED_ECN_MARKED_BYTES,

    
    SAI_PORT_POOL_STAT_CURR_OCCUPANCY_BYTES,

    
    SAI_PORT_POOL_STAT_WATERMARK_BYTES,

    
    SAI_PORT_POOL_STAT_SHARED_CURR_OCCUPANCY_BYTES,

    
    SAI_PORT_POOL_STAT_SHARED_WATERMARK_BYTES,

    
    SAI_PORT_POOL_STAT_DROPPED_PKTS,

} sai_port_pool_stat_t;


typedef sai_status_t (*sai_create_port_pool_fn)(
        _Out_ sai_object_id_t *port_pool_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_port_pool_fn)(
        _In_ sai_object_id_t port_pool_id);


typedef sai_status_t (*sai_set_port_pool_attribute_fn)(
        _In_ sai_object_id_t port_pool_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_port_pool_attribute_fn)(
        _In_ sai_object_id_t port_pool_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_get_port_pool_stats_fn)(
        _In_ sai_object_id_t port_pool_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_get_port_pool_stats_ext_fn)(
        _In_ sai_object_id_t port_pool_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _In_ sai_stats_mode_t mode,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_clear_port_pool_stats_fn)(
        _In_ sai_object_id_t port_pool_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids);


typedef struct _sai_port_api_t
{
    sai_create_port_fn                create_port;
    sai_remove_port_fn                remove_port;
    sai_set_port_attribute_fn         set_port_attribute;
    sai_get_port_attribute_fn         get_port_attribute;
    sai_get_port_stats_fn             get_port_stats;
    sai_get_port_stats_ext_fn         get_port_stats_ext;
    sai_clear_port_stats_fn           clear_port_stats;
    sai_clear_port_all_stats_fn       clear_port_all_stats;
    sai_create_port_pool_fn           create_port_pool;
    sai_remove_port_pool_fn           remove_port_pool;
    sai_set_port_pool_attribute_fn    set_port_pool_attribute;
    sai_get_port_pool_attribute_fn    get_port_pool_attribute;
    sai_get_port_pool_stats_fn        get_port_pool_stats;
    sai_get_port_pool_stats_ext_fn    get_port_pool_stats_ext;
    sai_clear_port_pool_stats_fn      clear_port_pool_stats;

} sai_port_api_t;


#endif 
