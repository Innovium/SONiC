

#if !defined (__SAIWRED_H_)
#define __SAIWRED_H_

#include "saitypes.h"




typedef enum _sai_ecn_mark_mode_t
{
    
    SAI_ECN_MARK_MODE_NONE,

    
    SAI_ECN_MARK_MODE_GREEN,

    
    SAI_ECN_MARK_MODE_YELLOW,

    
    SAI_ECN_MARK_MODE_RED,

    
    SAI_ECN_MARK_MODE_GREEN_YELLOW,

    
    SAI_ECN_MARK_MODE_GREEN_RED,

    
    SAI_ECN_MARK_MODE_YELLOW_RED,

    
    SAI_ECN_MARK_MODE_ALL,

} sai_ecn_mark_mode_t;


typedef enum _sai_wred_attr_t
{
    
    SAI_WRED_ATTR_START = 0x00000000,

    
    SAI_WRED_ATTR_GREEN_ENABLE = SAI_WRED_ATTR_START,

    
    SAI_WRED_ATTR_GREEN_MIN_THRESHOLD = 0x00000001,

    
    SAI_WRED_ATTR_GREEN_MAX_THRESHOLD = 0x00000002,

    
    SAI_WRED_ATTR_GREEN_DROP_PROBABILITY = 0x00000003,

    
    SAI_WRED_ATTR_YELLOW_ENABLE = 0x00000004,

    
    SAI_WRED_ATTR_YELLOW_MIN_THRESHOLD = 0x00000005,

    
    SAI_WRED_ATTR_YELLOW_MAX_THRESHOLD = 0x00000006,

    
    SAI_WRED_ATTR_YELLOW_DROP_PROBABILITY = 0x00000007,

    
    SAI_WRED_ATTR_RED_ENABLE = 0x00000008,

    
    SAI_WRED_ATTR_RED_MIN_THRESHOLD = 0x00000009,

    
    SAI_WRED_ATTR_RED_MAX_THRESHOLD = 0x0000000a,

    
    SAI_WRED_ATTR_RED_DROP_PROBABILITY = 0x0000000b,

    
    SAI_WRED_ATTR_WEIGHT = 0x0000000c,

    
    SAI_WRED_ATTR_ECN_MARK_MODE = 0x0000000d,

    
    SAI_WRED_ATTR_ECN_GREEN_MIN_THRESHOLD = 0x0000000e,

    
    SAI_WRED_ATTR_ECN_GREEN_MAX_THRESHOLD = 0x0000000f,

    
    SAI_WRED_ATTR_ECN_GREEN_MARK_PROBABILITY = 0x00000010,

    
    SAI_WRED_ATTR_ECN_YELLOW_MIN_THRESHOLD = 0x00000011,

    
    SAI_WRED_ATTR_ECN_YELLOW_MAX_THRESHOLD = 0x00000012,

    
    SAI_WRED_ATTR_ECN_YELLOW_MARK_PROBABILITY = 0x00000013,

    
    SAI_WRED_ATTR_ECN_RED_MIN_THRESHOLD = 0x00000014,

    
    SAI_WRED_ATTR_ECN_RED_MAX_THRESHOLD = 0x00000015,

    
    SAI_WRED_ATTR_ECN_RED_MARK_PROBABILITY = 0x00000016,

    
    SAI_WRED_ATTR_ECN_COLOR_UNAWARE_MIN_THRESHOLD = 0x00000017,

    
    SAI_WRED_ATTR_ECN_COLOR_UNAWARE_MAX_THRESHOLD = 0x00000018,

    
    SAI_WRED_ATTR_ECN_COLOR_UNAWARE_MARK_PROBABILITY = 0x00000019,

    
    SAI_WRED_ATTR_END,

    
    SAI_WRED_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_WRED_ATTR_CUSTOM_RANGE_END

} sai_wred_attr_t;


typedef sai_status_t (*sai_create_wred_fn)(
        _Out_ sai_object_id_t *wred_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_wred_fn)(
        _In_ sai_object_id_t wred_id);


typedef sai_status_t (*sai_set_wred_attribute_fn)(
        _In_ sai_object_id_t wred_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_wred_attribute_fn)(
        _In_ sai_object_id_t wred_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef struct _sai_wred_api_t
{
    sai_create_wred_fn          create_wred;
    sai_remove_wred_fn          remove_wred;
    sai_set_wred_attribute_fn   set_wred_attribute;
    sai_get_wred_attribute_fn   get_wred_attribute;

} sai_wred_api_t;


#endif 
