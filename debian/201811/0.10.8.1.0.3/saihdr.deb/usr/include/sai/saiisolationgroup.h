

#if !defined (__SAIISOLATIONGROUP_H_)
#define __SAIISOLATIONGROUP_H_

#include <saitypes.h>




typedef enum _sai_isolation_group_type_t
{
    
    SAI_ISOLATION_GROUP_TYPE_PORT,

    
    SAI_ISOLATION_GROUP_TYPE_BRIDGE_PORT,

} sai_isolation_group_type_t;


typedef enum _sai_isolation_group_attr_t
{
    
    SAI_ISOLATION_GROUP_ATTR_START,

    
    SAI_ISOLATION_GROUP_ATTR_TYPE = SAI_ISOLATION_GROUP_ATTR_START,

    
    SAI_ISOLATION_GROUP_ATTR_ISOLATION_MEMBER_LIST,

    
    SAI_ISOLATION_GROUP_ATTR_END,

    
    SAI_ISOLATION_GROUP_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_ISOLATION_GROUP_ATTR_CUSTOM_RANGE_END

} sai_isolation_group_attr_t;

typedef enum _sai_isolation_group_member_attr_t
{
    
    SAI_ISOLATION_GROUP_MEMBER_ATTR_START,

    
    SAI_ISOLATION_GROUP_MEMBER_ATTR_ISOLATION_GROUP_ID = SAI_ISOLATION_GROUP_MEMBER_ATTR_START,

    
    SAI_ISOLATION_GROUP_MEMBER_ATTR_ISOLATION_OBJECT,

    
    SAI_ISOLATION_GROUP_MEMBER_ATTR_END,

    
    SAI_ISOLATION_GROUP_MEMBER_ATTR_CUSTOM_RANGE_START  = 0x10000000,

    
    SAI_ISOLATION_GROUP_MEMBER_ATTR_CUSTOM_RANGE_END

} sai_isolation_group_member_attr_t;


typedef sai_status_t (*sai_create_isolation_group_fn)(
        _Out_ sai_object_id_t *isolation_group_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_isolation_group_fn)(
        _In_ sai_object_id_t isolation_group_id);


typedef sai_status_t (*sai_set_isolation_group_attribute_fn)(
        _In_ sai_object_id_t isolation_group_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_isolation_group_attribute_fn)(
        _In_ sai_object_id_t isolation_group_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_create_isolation_group_member_fn)(
        _Out_ sai_object_id_t *isolation_group_member_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_isolation_group_member_fn)(
        _In_ sai_object_id_t isolation_group_member_id);


typedef sai_status_t (*sai_set_isolation_group_member_attribute_fn)(
        _In_ sai_object_id_t isolation_group_member_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_isolation_group_member_attribute_fn)(
        _In_ sai_object_id_t isolation_group_member_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef struct _sai_isolation_group_api_t
{
    sai_create_isolation_group_fn                   create_isolation_group;
    sai_remove_isolation_group_fn                   remove_isolation_group;
    sai_set_isolation_group_attribute_fn            set_isolation_group_attribute;
    sai_get_isolation_group_attribute_fn            get_isolation_group_attribute;
    sai_create_isolation_group_member_fn            create_isolation_group_member;
    sai_remove_isolation_group_member_fn            remove_isolation_group_member;
    sai_set_isolation_group_member_attribute_fn     set_isolation_group_member_attribute;
    sai_get_isolation_group_member_attribute_fn     get_isolation_group_member_attribute;

} sai_isolation_group_api_t;


#endif 
