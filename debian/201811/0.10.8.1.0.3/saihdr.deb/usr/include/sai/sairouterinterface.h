

#if !defined (__SAIROUTERINTERFACE_H_)
#define __SAIROUTERINTERFACE_H_

#include <saitypes.h>




typedef enum _sai_router_interface_type_t
{
    
    SAI_ROUTER_INTERFACE_TYPE_PORT,

    
    SAI_ROUTER_INTERFACE_TYPE_VLAN,

    
    SAI_ROUTER_INTERFACE_TYPE_LOOPBACK,

    
    SAI_ROUTER_INTERFACE_TYPE_MPLS_ROUTER,

    
    SAI_ROUTER_INTERFACE_TYPE_SUB_PORT,

    
    SAI_ROUTER_INTERFACE_TYPE_BRIDGE,

    
    SAI_ROUTER_INTERFACE_TYPE_QINQ_PORT,

} sai_router_interface_type_t;


typedef enum _sai_router_interface_attr_t
{
    
    SAI_ROUTER_INTERFACE_ATTR_START,

    

    
    SAI_ROUTER_INTERFACE_ATTR_VIRTUAL_ROUTER_ID = SAI_ROUTER_INTERFACE_ATTR_START,

    
    SAI_ROUTER_INTERFACE_ATTR_TYPE,

    
    SAI_ROUTER_INTERFACE_ATTR_PORT_ID,

    
    SAI_ROUTER_INTERFACE_ATTR_VLAN_ID,

    
    SAI_ROUTER_INTERFACE_ATTR_OUTER_VLAN_ID,

    
    SAI_ROUTER_INTERFACE_ATTR_INNER_VLAN_ID,

    
    SAI_ROUTER_INTERFACE_ATTR_BRIDGE_ID,

    

    
    SAI_ROUTER_INTERFACE_ATTR_SRC_MAC_ADDRESS,

    
    SAI_ROUTER_INTERFACE_ATTR_ADMIN_V4_STATE,

    
    SAI_ROUTER_INTERFACE_ATTR_ADMIN_V6_STATE,

    
    SAI_ROUTER_INTERFACE_ATTR_MTU,

    
    SAI_ROUTER_INTERFACE_ATTR_INGRESS_ACL,

    
    SAI_ROUTER_INTERFACE_ATTR_EGRESS_ACL,

    
    SAI_ROUTER_INTERFACE_ATTR_NEIGHBOR_MISS_PACKET_ACTION,

    
    SAI_ROUTER_INTERFACE_ATTR_V4_MCAST_ENABLE,

    
    SAI_ROUTER_INTERFACE_ATTR_V6_MCAST_ENABLE,

    
    SAI_ROUTER_INTERFACE_ATTR_LOOPBACK_PACKET_ACTION,

    
    SAI_ROUTER_INTERFACE_ATTR_IS_VIRTUAL,

    
    SAI_ROUTER_INTERFACE_ATTR_END,

    
    SAI_ROUTER_INTERFACE_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_ROUTER_INTERFACE_ATTR_CUSTOM_RANGE_END

} sai_router_interface_attr_t;


typedef enum _sai_router_interface_stat_t
{
    
    SAI_ROUTER_INTERFACE_STAT_IN_OCTETS,

    
    SAI_ROUTER_INTERFACE_STAT_IN_PACKETS,

    
    SAI_ROUTER_INTERFACE_STAT_OUT_OCTETS,

    
    SAI_ROUTER_INTERFACE_STAT_OUT_PACKETS,

    
    SAI_ROUTER_INTERFACE_STAT_IN_ERROR_OCTETS,

    
    SAI_ROUTER_INTERFACE_STAT_IN_ERROR_PACKETS,

    
    SAI_ROUTER_INTERFACE_STAT_OUT_ERROR_OCTETS,

    
    SAI_ROUTER_INTERFACE_STAT_OUT_ERROR_PACKETS

} sai_router_interface_stat_t;


typedef sai_status_t (*sai_create_router_interface_fn)(
        _Out_ sai_object_id_t *router_interface_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_router_interface_fn)(
        _In_ sai_object_id_t router_interface_id);


typedef sai_status_t (*sai_set_router_interface_attribute_fn)(
        _In_ sai_object_id_t router_interface_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_router_interface_attribute_fn)(
        _In_ sai_object_id_t router_interface_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_get_router_interface_stats_fn)(
        _In_ sai_object_id_t router_interface_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_get_router_interface_stats_ext_fn)(
        _In_ sai_object_id_t router_interface_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _In_ sai_stats_mode_t mode,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_clear_router_interface_stats_fn)(
        _In_ sai_object_id_t router_interface_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids);


typedef struct _sai_router_interface_api_t
{
    sai_create_router_interface_fn          create_router_interface;
    sai_remove_router_interface_fn          remove_router_interface;
    sai_set_router_interface_attribute_fn   set_router_interface_attribute;
    sai_get_router_interface_attribute_fn   get_router_interface_attribute;
    sai_get_router_interface_stats_fn       get_router_interface_stats;
    sai_get_router_interface_stats_ext_fn   get_router_interface_stats_ext;
    sai_clear_router_interface_stats_fn     clear_router_interface_stats;

} sai_router_interface_api_t;


#endif 
