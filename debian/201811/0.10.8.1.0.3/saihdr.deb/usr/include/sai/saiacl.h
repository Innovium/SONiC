

#if !defined (__SAIACL_H_)
#define __SAIACL_H_

#include <saitypes.h>




typedef enum _sai_acl_ip_type_t
{
    
    SAI_ACL_IP_TYPE_ANY,

    
    SAI_ACL_IP_TYPE_IP,

    
    SAI_ACL_IP_TYPE_NON_IP,

    
    SAI_ACL_IP_TYPE_IPV4ANY,

    
    SAI_ACL_IP_TYPE_NON_IPV4,

    
    SAI_ACL_IP_TYPE_IPV6ANY,

    
    SAI_ACL_IP_TYPE_NON_IPV6,

    
    SAI_ACL_IP_TYPE_ARP,

    
    SAI_ACL_IP_TYPE_ARP_REQUEST,

    
    SAI_ACL_IP_TYPE_ARP_REPLY

} sai_acl_ip_type_t;


typedef enum _sai_acl_ip_frag_t
{
    
    SAI_ACL_IP_FRAG_ANY,

    
    SAI_ACL_IP_FRAG_NON_FRAG,

    
    SAI_ACL_IP_FRAG_NON_FRAG_OR_HEAD,

    
    SAI_ACL_IP_FRAG_HEAD,

    
    SAI_ACL_IP_FRAG_NON_HEAD

} sai_acl_ip_frag_t;


typedef enum _sai_acl_dtel_flow_op_t
{
    
    SAI_ACL_DTEL_FLOW_OP_NOP,

    
    SAI_ACL_DTEL_FLOW_OP_INT,

    
    SAI_ACL_DTEL_FLOW_OP_IOAM,

    
    SAI_ACL_DTEL_FLOW_OP_POSTCARD,

} sai_acl_dtel_flow_op_t;


typedef enum _sai_acl_action_type_t
{
    
    SAI_ACL_ACTION_TYPE_REDIRECT,

    
    SAI_ACL_ACTION_TYPE_ENDPOINT_IP,

    
    SAI_ACL_ACTION_TYPE_REDIRECT_LIST,

    
    SAI_ACL_ACTION_TYPE_PACKET_ACTION,

    
    SAI_ACL_ACTION_TYPE_FLOOD,

    
    SAI_ACL_ACTION_TYPE_COUNTER,

    
    SAI_ACL_ACTION_TYPE_MIRROR_INGRESS,

    
    SAI_ACL_ACTION_TYPE_MIRROR_EGRESS,

    
    SAI_ACL_ACTION_TYPE_SET_POLICER,

    
    SAI_ACL_ACTION_TYPE_DECREMENT_TTL,

    
    SAI_ACL_ACTION_TYPE_SET_TC,

    
    SAI_ACL_ACTION_TYPE_SET_PACKET_COLOR,

    
    SAI_ACL_ACTION_TYPE_SET_INNER_VLAN_ID,

    
    SAI_ACL_ACTION_TYPE_SET_INNER_VLAN_PRI,

    
    SAI_ACL_ACTION_TYPE_SET_OUTER_VLAN_ID,

    
    SAI_ACL_ACTION_TYPE_SET_OUTER_VLAN_PRI,

    
    SAI_ACL_ACTION_TYPE_SET_SRC_MAC,

    
    SAI_ACL_ACTION_TYPE_SET_DST_MAC,

    
    SAI_ACL_ACTION_TYPE_SET_SRC_IP,

    
    SAI_ACL_ACTION_TYPE_SET_DST_IP,

    
    SAI_ACL_ACTION_TYPE_SET_SRC_IPV6,

    
    SAI_ACL_ACTION_TYPE_SET_DST_IPV6,

    
    SAI_ACL_ACTION_TYPE_SET_DSCP,

    
    SAI_ACL_ACTION_TYPE_SET_ECN,

    
    SAI_ACL_ACTION_TYPE_SET_L4_SRC_PORT,

    
    SAI_ACL_ACTION_TYPE_SET_L4_DST_PORT,

    
    SAI_ACL_ACTION_TYPE_INGRESS_SAMPLEPACKET_ENABLE,

    
    SAI_ACL_ACTION_TYPE_EGRESS_SAMPLEPACKET_ENABLE,

    
    SAI_ACL_ACTION_TYPE_SET_ACL_META_DATA,

    
    SAI_ACL_ACTION_TYPE_EGRESS_BLOCK_PORT_LIST,

    
    SAI_ACL_ACTION_TYPE_SET_USER_TRAP_ID,

    
    SAI_ACL_ACTION_TYPE_SET_DO_NOT_LEARN,

    
    SAI_ACL_ACTION_TYPE_ACL_DTEL_FLOW_OP,

    
    SAI_ACL_ACTION_TYPE_DTEL_INT_SESSION,

    
    SAI_ACL_ACTION_TYPE_DTEL_DROP_REPORT_ENABLE,

    
    SAI_ACL_ACTION_TYPE_DTEL_TAIL_DROP_REPORT_ENABLE,

    
    SAI_ACL_ACTION_TYPE_DTEL_FLOW_SAMPLE_PERCENT,

    
    SAI_ACL_ACTION_TYPE_DTEL_REPORT_ALL_PACKETS,

    
    SAI_ACL_ACTION_TYPE_SET_ISOLATION_GROUP,

} sai_acl_action_type_t;


typedef enum _sai_acl_table_group_type_t
{
    
    SAI_ACL_TABLE_GROUP_TYPE_SEQUENTIAL,

    
    SAI_ACL_TABLE_GROUP_TYPE_PARALLEL,

} sai_acl_table_group_type_t;


typedef enum _sai_acl_table_group_attr_t
{
    
    SAI_ACL_TABLE_GROUP_ATTR_START,

    
    SAI_ACL_TABLE_GROUP_ATTR_ACL_STAGE = SAI_ACL_TABLE_GROUP_ATTR_START,

    
    SAI_ACL_TABLE_GROUP_ATTR_ACL_BIND_POINT_TYPE_LIST,

    
    SAI_ACL_TABLE_GROUP_ATTR_TYPE,

    
    SAI_ACL_TABLE_GROUP_ATTR_MEMBER_LIST,

    
    SAI_ACL_TABLE_GROUP_ATTR_END,

    
    SAI_ACL_TABLE_GROUP_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_ACL_TABLE_GROUP_ATTR_CUSTOM_RANGE_END

} sai_acl_table_group_attr_t;


typedef enum _sai_acl_table_group_member_attr_t
{
    
    SAI_ACL_TABLE_GROUP_MEMBER_ATTR_START,

    
    SAI_ACL_TABLE_GROUP_MEMBER_ATTR_ACL_TABLE_GROUP_ID = SAI_ACL_TABLE_GROUP_MEMBER_ATTR_START,

    
    SAI_ACL_TABLE_GROUP_MEMBER_ATTR_ACL_TABLE_ID,

    
    SAI_ACL_TABLE_GROUP_MEMBER_ATTR_PRIORITY,

    
    SAI_ACL_TABLE_GROUP_MEMBER_ATTR_END,

    
    SAI_ACL_TABLE_GROUP_MEMBER_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_ACL_TABLE_GROUP_MEMBER_ATTR_CUSTOM_RANGE_END

} sai_acl_table_group_member_attr_t;


#define SAI_ACL_USER_DEFINED_FIELD_ATTR_ID_RANGE 0xFF


typedef enum _sai_acl_table_attr_t
{
    
    SAI_ACL_TABLE_ATTR_START,

    
    SAI_ACL_TABLE_ATTR_ACL_STAGE = SAI_ACL_TABLE_ATTR_START,

    
    SAI_ACL_TABLE_ATTR_ACL_BIND_POINT_TYPE_LIST,

    
    SAI_ACL_TABLE_ATTR_SIZE,

    
    SAI_ACL_TABLE_ATTR_ACL_ACTION_TYPE_LIST,

    

    
    SAI_ACL_TABLE_ATTR_FIELD_START = 0x00001000,

    
    SAI_ACL_TABLE_ATTR_FIELD_SRC_IPV6 = SAI_ACL_TABLE_ATTR_FIELD_START,

    
    SAI_ACL_TABLE_ATTR_FIELD_DST_IPV6,

    
    SAI_ACL_TABLE_ATTR_FIELD_INNER_SRC_IPV6,

    
    SAI_ACL_TABLE_ATTR_FIELD_INNER_DST_IPV6,

    
    SAI_ACL_TABLE_ATTR_FIELD_SRC_MAC,

    
    SAI_ACL_TABLE_ATTR_FIELD_DST_MAC,

    
    SAI_ACL_TABLE_ATTR_FIELD_SRC_IP,

    
    SAI_ACL_TABLE_ATTR_FIELD_DST_IP,

    
    SAI_ACL_TABLE_ATTR_FIELD_INNER_SRC_IP,

    
    SAI_ACL_TABLE_ATTR_FIELD_INNER_DST_IP,

    
    SAI_ACL_TABLE_ATTR_FIELD_IN_PORTS,

    
    SAI_ACL_TABLE_ATTR_FIELD_OUT_PORTS,

    
    SAI_ACL_TABLE_ATTR_FIELD_IN_PORT,

    
    SAI_ACL_TABLE_ATTR_FIELD_OUT_PORT,

    
    SAI_ACL_TABLE_ATTR_FIELD_SRC_PORT,

    
    SAI_ACL_TABLE_ATTR_FIELD_OUTER_VLAN_ID,

    
    SAI_ACL_TABLE_ATTR_FIELD_OUTER_VLAN_PRI,

    
    SAI_ACL_TABLE_ATTR_FIELD_OUTER_VLAN_CFI,

    
    SAI_ACL_TABLE_ATTR_FIELD_INNER_VLAN_ID,

    
    SAI_ACL_TABLE_ATTR_FIELD_INNER_VLAN_PRI,

    
    SAI_ACL_TABLE_ATTR_FIELD_INNER_VLAN_CFI,

    
    SAI_ACL_TABLE_ATTR_FIELD_L4_SRC_PORT,

    
    SAI_ACL_TABLE_ATTR_FIELD_L4_DST_PORT,

    
    SAI_ACL_TABLE_ATTR_FIELD_INNER_L4_SRC_PORT,

    
    SAI_ACL_TABLE_ATTR_FIELD_INNER_L4_DST_PORT,

    
    SAI_ACL_TABLE_ATTR_FIELD_ETHER_TYPE,

    
    SAI_ACL_TABLE_ATTR_FIELD_INNER_ETHER_TYPE,

    
    SAI_ACL_TABLE_ATTR_FIELD_IP_PROTOCOL,

    
    SAI_ACL_TABLE_ATTR_FIELD_INNER_IP_PROTOCOL,

    
    SAI_ACL_TABLE_ATTR_FIELD_IP_IDENTIFICATION,

    
    SAI_ACL_TABLE_ATTR_FIELD_DSCP,

    
    SAI_ACL_TABLE_ATTR_FIELD_ECN,

    
    SAI_ACL_TABLE_ATTR_FIELD_TTL,

    
    SAI_ACL_TABLE_ATTR_FIELD_TOS,

    
    SAI_ACL_TABLE_ATTR_FIELD_IP_FLAGS,

    
    SAI_ACL_TABLE_ATTR_FIELD_TCP_FLAGS,

    
    SAI_ACL_TABLE_ATTR_FIELD_ACL_IP_TYPE,

    
    SAI_ACL_TABLE_ATTR_FIELD_ACL_IP_FRAG,

    
    SAI_ACL_TABLE_ATTR_FIELD_IPV6_FLOW_LABEL,

    
    SAI_ACL_TABLE_ATTR_FIELD_TC,

    
    SAI_ACL_TABLE_ATTR_FIELD_ICMP_TYPE,

    
    SAI_ACL_TABLE_ATTR_FIELD_ICMP_CODE,

    
    SAI_ACL_TABLE_ATTR_FIELD_ICMPV6_TYPE,

    
    SAI_ACL_TABLE_ATTR_FIELD_ICMPV6_CODE,

    
    SAI_ACL_TABLE_ATTR_FIELD_PACKET_VLAN,

    
    SAI_ACL_TABLE_ATTR_FIELD_TUNNEL_VNI,

    

    
    SAI_ACL_TABLE_ATTR_FIELD_FDB_DST_USER_META,

    
    SAI_ACL_TABLE_ATTR_FIELD_ROUTE_DST_USER_META,

    
    SAI_ACL_TABLE_ATTR_FIELD_NEIGHBOR_DST_USER_META,

    
    SAI_ACL_TABLE_ATTR_FIELD_PORT_USER_META,

    
    SAI_ACL_TABLE_ATTR_FIELD_VLAN_USER_META,

    
    SAI_ACL_TABLE_ATTR_FIELD_ACL_USER_META,

    

    
    SAI_ACL_TABLE_ATTR_FIELD_FDB_NPU_META_DST_HIT,

    
    SAI_ACL_TABLE_ATTR_FIELD_NEIGHBOR_NPU_META_DST_HIT,

    
    SAI_ACL_TABLE_ATTR_FIELD_ROUTE_NPU_META_DST_HIT,

    
    SAI_ACL_TABLE_ATTR_FIELD_BTH_OPCODE,

    
    SAI_ACL_TABLE_ATTR_FIELD_AETH_SYNDROME,

    
    SAI_ACL_TABLE_ATTR_USER_DEFINED_FIELD_GROUP_MIN,

    
    SAI_ACL_TABLE_ATTR_USER_DEFINED_FIELD_GROUP_MAX = SAI_ACL_TABLE_ATTR_USER_DEFINED_FIELD_GROUP_MIN + SAI_ACL_USER_DEFINED_FIELD_ATTR_ID_RANGE,

    
    SAI_ACL_TABLE_ATTR_FIELD_ACL_RANGE_TYPE,

    
    SAI_ACL_TABLE_ATTR_FIELD_IPV6_NEXT_HEADER,

    
    SAI_ACL_TABLE_ATTR_FIELD_END = SAI_ACL_TABLE_ATTR_FIELD_IPV6_NEXT_HEADER,

    
    SAI_ACL_TABLE_ATTR_ENTRY_LIST,

    
    SAI_ACL_TABLE_ATTR_AVAILABLE_ACL_ENTRY,

    
    SAI_ACL_TABLE_ATTR_AVAILABLE_ACL_COUNTER,

    
    SAI_ACL_TABLE_ATTR_END,

    
    SAI_ACL_TABLE_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_ACL_TABLE_ATTR_CUSTOM_RANGE_END

} sai_acl_table_attr_t;


typedef enum _sai_acl_entry_attr_t
{
    
    SAI_ACL_ENTRY_ATTR_START,

    
    SAI_ACL_ENTRY_ATTR_TABLE_ID = SAI_ACL_ENTRY_ATTR_START,

    
    SAI_ACL_ENTRY_ATTR_PRIORITY,

    
    SAI_ACL_ENTRY_ATTR_ADMIN_STATE,

    

    
    SAI_ACL_ENTRY_ATTR_FIELD_START = 0x00001000,

    
    SAI_ACL_ENTRY_ATTR_FIELD_SRC_IPV6 = SAI_ACL_ENTRY_ATTR_FIELD_START,

    
    SAI_ACL_ENTRY_ATTR_FIELD_DST_IPV6,

    
    SAI_ACL_ENTRY_ATTR_FIELD_INNER_SRC_IPV6,

    
    SAI_ACL_ENTRY_ATTR_FIELD_INNER_DST_IPV6,

    
    SAI_ACL_ENTRY_ATTR_FIELD_SRC_MAC,

    
    SAI_ACL_ENTRY_ATTR_FIELD_DST_MAC,

    
    SAI_ACL_ENTRY_ATTR_FIELD_SRC_IP,

    
    SAI_ACL_ENTRY_ATTR_FIELD_DST_IP,

    
    SAI_ACL_ENTRY_ATTR_FIELD_INNER_SRC_IP,

    
    SAI_ACL_ENTRY_ATTR_FIELD_INNER_DST_IP,

    
    SAI_ACL_ENTRY_ATTR_FIELD_IN_PORTS,

    
    SAI_ACL_ENTRY_ATTR_FIELD_OUT_PORTS,

    
    SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT,

    
    SAI_ACL_ENTRY_ATTR_FIELD_OUT_PORT,

    
    SAI_ACL_ENTRY_ATTR_FIELD_SRC_PORT,

    
    SAI_ACL_ENTRY_ATTR_FIELD_OUTER_VLAN_ID,

    
    SAI_ACL_ENTRY_ATTR_FIELD_OUTER_VLAN_PRI,

    
    SAI_ACL_ENTRY_ATTR_FIELD_OUTER_VLAN_CFI,

    
    SAI_ACL_ENTRY_ATTR_FIELD_INNER_VLAN_ID,

    
    SAI_ACL_ENTRY_ATTR_FIELD_INNER_VLAN_PRI,

    
    SAI_ACL_ENTRY_ATTR_FIELD_INNER_VLAN_CFI,

    
    SAI_ACL_ENTRY_ATTR_FIELD_L4_SRC_PORT,

    
    SAI_ACL_ENTRY_ATTR_FIELD_L4_DST_PORT,

    
    SAI_ACL_ENTRY_ATTR_FIELD_INNER_L4_SRC_PORT,

    
    SAI_ACL_ENTRY_ATTR_FIELD_INNER_L4_DST_PORT,

    
    SAI_ACL_ENTRY_ATTR_FIELD_ETHER_TYPE,

    
    SAI_ACL_ENTRY_ATTR_FIELD_INNER_ETHER_TYPE,

    
    SAI_ACL_ENTRY_ATTR_FIELD_IP_PROTOCOL,

    
    SAI_ACL_ENTRY_ATTR_FIELD_INNER_IP_PROTOCOL,

    
    SAI_ACL_ENTRY_ATTR_FIELD_IP_IDENTIFICATION,

    
    SAI_ACL_ENTRY_ATTR_FIELD_DSCP,

    
    SAI_ACL_ENTRY_ATTR_FIELD_ECN,

    
    SAI_ACL_ENTRY_ATTR_FIELD_TTL,

    
    SAI_ACL_ENTRY_ATTR_FIELD_TOS,

    
    SAI_ACL_ENTRY_ATTR_FIELD_IP_FLAGS,

    
    SAI_ACL_ENTRY_ATTR_FIELD_TCP_FLAGS,

    
    SAI_ACL_ENTRY_ATTR_FIELD_ACL_IP_TYPE,

    
    SAI_ACL_ENTRY_ATTR_FIELD_ACL_IP_FRAG,

    
    SAI_ACL_ENTRY_ATTR_FIELD_IPV6_FLOW_LABEL,

    
    SAI_ACL_ENTRY_ATTR_FIELD_TC,

    
    SAI_ACL_ENTRY_ATTR_FIELD_ICMP_TYPE,

    
    SAI_ACL_ENTRY_ATTR_FIELD_ICMP_CODE,

    
    SAI_ACL_ENTRY_ATTR_FIELD_ICMPV6_TYPE,

    
    SAI_ACL_ENTRY_ATTR_FIELD_ICMPV6_CODE,

    
    SAI_ACL_ENTRY_ATTR_FIELD_PACKET_VLAN,

    
    SAI_ACL_ENTRY_ATTR_FIELD_TUNNEL_VNI,

    

    
    SAI_ACL_ENTRY_ATTR_FIELD_FDB_DST_USER_META,

    
    SAI_ACL_ENTRY_ATTR_FIELD_ROUTE_DST_USER_META,

    
    SAI_ACL_ENTRY_ATTR_FIELD_NEIGHBOR_DST_USER_META,

    
    SAI_ACL_ENTRY_ATTR_FIELD_PORT_USER_META,

    
    SAI_ACL_ENTRY_ATTR_FIELD_VLAN_USER_META,

    
    SAI_ACL_ENTRY_ATTR_FIELD_ACL_USER_META,

    

    
    SAI_ACL_ENTRY_ATTR_FIELD_FDB_NPU_META_DST_HIT,

    
    SAI_ACL_ENTRY_ATTR_FIELD_NEIGHBOR_NPU_META_DST_HIT,

    
    SAI_ACL_ENTRY_ATTR_FIELD_ROUTE_NPU_META_DST_HIT,

    
    SAI_ACL_ENTRY_ATTR_FIELD_BTH_OPCODE,

    
    SAI_ACL_ENTRY_ATTR_FIELD_AETH_SYNDROME,

    
    SAI_ACL_ENTRY_ATTR_USER_DEFINED_FIELD_GROUP_MIN,

    
    SAI_ACL_ENTRY_ATTR_USER_DEFINED_FIELD_GROUP_MAX = SAI_ACL_ENTRY_ATTR_USER_DEFINED_FIELD_GROUP_MIN + SAI_ACL_USER_DEFINED_FIELD_ATTR_ID_RANGE,

    
    SAI_ACL_ENTRY_ATTR_FIELD_ACL_RANGE_TYPE,

    
    SAI_ACL_ENTRY_ATTR_FIELD_IPV6_NEXT_HEADER,

    
    SAI_ACL_ENTRY_ATTR_FIELD_END = SAI_ACL_ENTRY_ATTR_FIELD_IPV6_NEXT_HEADER,

    

    
    SAI_ACL_ENTRY_ATTR_ACTION_START = 0x00002000,

    
    SAI_ACL_ENTRY_ATTR_ACTION_REDIRECT = SAI_ACL_ENTRY_ATTR_ACTION_START,

    
    SAI_ACL_ENTRY_ATTR_ACTION_ENDPOINT_IP,

    
    SAI_ACL_ENTRY_ATTR_ACTION_REDIRECT_LIST,

    
    SAI_ACL_ENTRY_ATTR_ACTION_PACKET_ACTION,

    
    SAI_ACL_ENTRY_ATTR_ACTION_FLOOD,

    
    SAI_ACL_ENTRY_ATTR_ACTION_COUNTER,

    
    SAI_ACL_ENTRY_ATTR_ACTION_MIRROR_INGRESS,

    
    SAI_ACL_ENTRY_ATTR_ACTION_MIRROR_EGRESS,

    
    SAI_ACL_ENTRY_ATTR_ACTION_SET_POLICER,

    
    SAI_ACL_ENTRY_ATTR_ACTION_DECREMENT_TTL,

    
    SAI_ACL_ENTRY_ATTR_ACTION_SET_TC,

    
    SAI_ACL_ENTRY_ATTR_ACTION_SET_PACKET_COLOR,

    
    SAI_ACL_ENTRY_ATTR_ACTION_SET_INNER_VLAN_ID,

    
    SAI_ACL_ENTRY_ATTR_ACTION_SET_INNER_VLAN_PRI,

    
    SAI_ACL_ENTRY_ATTR_ACTION_SET_OUTER_VLAN_ID,

    
    SAI_ACL_ENTRY_ATTR_ACTION_SET_OUTER_VLAN_PRI,

    
    SAI_ACL_ENTRY_ATTR_ACTION_SET_SRC_MAC,

    
    SAI_ACL_ENTRY_ATTR_ACTION_SET_DST_MAC,

    
    SAI_ACL_ENTRY_ATTR_ACTION_SET_SRC_IP,

    
    SAI_ACL_ENTRY_ATTR_ACTION_SET_DST_IP,

    
    SAI_ACL_ENTRY_ATTR_ACTION_SET_SRC_IPV6,

    
    SAI_ACL_ENTRY_ATTR_ACTION_SET_DST_IPV6,

    
    SAI_ACL_ENTRY_ATTR_ACTION_SET_DSCP,

    
    SAI_ACL_ENTRY_ATTR_ACTION_SET_ECN,

    
    SAI_ACL_ENTRY_ATTR_ACTION_SET_L4_SRC_PORT,

    
    SAI_ACL_ENTRY_ATTR_ACTION_SET_L4_DST_PORT,

    
    SAI_ACL_ENTRY_ATTR_ACTION_INGRESS_SAMPLEPACKET_ENABLE,

    
    SAI_ACL_ENTRY_ATTR_ACTION_EGRESS_SAMPLEPACKET_ENABLE,

    
    SAI_ACL_ENTRY_ATTR_ACTION_SET_ACL_META_DATA,

    
    SAI_ACL_ENTRY_ATTR_ACTION_EGRESS_BLOCK_PORT_LIST,

    
    SAI_ACL_ENTRY_ATTR_ACTION_SET_USER_TRAP_ID,

    
    SAI_ACL_ENTRY_ATTR_ACTION_SET_DO_NOT_LEARN,

    
    SAI_ACL_ENTRY_ATTR_ACTION_ACL_DTEL_FLOW_OP,

    
    SAI_ACL_ENTRY_ATTR_ACTION_DTEL_INT_SESSION,

    
    SAI_ACL_ENTRY_ATTR_ACTION_DTEL_DROP_REPORT_ENABLE,

    
    SAI_ACL_ENTRY_ATTR_ACTION_DTEL_TAIL_DROP_REPORT_ENABLE,

    
    SAI_ACL_ENTRY_ATTR_ACTION_DTEL_FLOW_SAMPLE_PERCENT,

    
    SAI_ACL_ENTRY_ATTR_ACTION_DTEL_REPORT_ALL_PACKETS,

    
    SAI_ACL_ENTRY_ATTR_ACTION_SET_ISOLATION_GROUP,

    
    SAI_ACL_ENTRY_ATTR_ACTION_END = SAI_ACL_ENTRY_ATTR_ACTION_SET_ISOLATION_GROUP,

    
    SAI_ACL_ENTRY_ATTR_END,

    
    SAI_ACL_ENTRY_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_ACL_ENTRY_ATTR_CUSTOM_RANGE_END

} sai_acl_entry_attr_t;


typedef enum _sai_acl_counter_attr_t
{
    
    SAI_ACL_COUNTER_ATTR_START,

    
    SAI_ACL_COUNTER_ATTR_TABLE_ID = SAI_ACL_COUNTER_ATTR_START,

    

    
    SAI_ACL_COUNTER_ATTR_ENABLE_PACKET_COUNT,

    
    SAI_ACL_COUNTER_ATTR_ENABLE_BYTE_COUNT,

    
    SAI_ACL_COUNTER_ATTR_PACKETS,

    
    SAI_ACL_COUNTER_ATTR_BYTES,

    
    SAI_ACL_COUNTER_ATTR_END,

    
    SAI_ACL_COUNTER_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_ACL_COUNTER_ATTR_CUSTOM_RANGE_END

} sai_acl_counter_attr_t;


typedef enum _sai_acl_range_type_t
{
    
    SAI_ACL_RANGE_TYPE_L4_SRC_PORT_RANGE,

    
    SAI_ACL_RANGE_TYPE_L4_DST_PORT_RANGE,

    
    SAI_ACL_RANGE_TYPE_OUTER_VLAN,

    
    SAI_ACL_RANGE_TYPE_INNER_VLAN,

    
    SAI_ACL_RANGE_TYPE_PACKET_LENGTH

} sai_acl_range_type_t;


typedef enum _sai_acl_range_attr_t
{
    
    SAI_ACL_RANGE_ATTR_START,

    
    SAI_ACL_RANGE_ATTR_TYPE = SAI_ACL_RANGE_ATTR_START,

    
    SAI_ACL_RANGE_ATTR_LIMIT,

    
    SAI_ACL_RANGE_ATTR_END,

    
    SAI_ACL_RANGE_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_ACL_RANGE_ATTR_CUSTOM_RANGE_END

} sai_acl_range_attr_t;


typedef sai_status_t (*sai_create_acl_table_fn)(
        _Out_ sai_object_id_t *acl_table_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_acl_table_fn)(
        _In_ sai_object_id_t acl_table_id);


typedef sai_status_t (*sai_set_acl_table_attribute_fn)(
        _In_ sai_object_id_t acl_table_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_acl_table_attribute_fn)(
        _In_ sai_object_id_t acl_table_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_create_acl_entry_fn)(
        _Out_ sai_object_id_t *acl_entry_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_acl_entry_fn)(
        _In_ sai_object_id_t acl_entry_id);


typedef sai_status_t (*sai_set_acl_entry_attribute_fn)(
        _In_ sai_object_id_t acl_entry_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_acl_entry_attribute_fn)(
        _In_ sai_object_id_t acl_entry_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_create_acl_counter_fn)(
        _Out_ sai_object_id_t *acl_counter_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_acl_counter_fn)(
        _In_ sai_object_id_t acl_counter_id);


typedef sai_status_t (*sai_set_acl_counter_attribute_fn)(
        _In_ sai_object_id_t acl_counter_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_acl_counter_attribute_fn)(
        _In_ sai_object_id_t acl_counter_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_create_acl_range_fn)(
        _Out_ sai_object_id_t *acl_range_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_acl_range_fn)(
        _In_ sai_object_id_t acl_range_id);


typedef sai_status_t (*sai_set_acl_range_attribute_fn)(
        _In_ sai_object_id_t acl_range_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_acl_range_attribute_fn)(
        _In_ sai_object_id_t acl_range_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_create_acl_table_group_fn)(
        _Out_ sai_object_id_t *acl_table_group_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_acl_table_group_fn)(
        _In_ sai_object_id_t acl_table_group_id);


typedef sai_status_t (*sai_set_acl_table_group_attribute_fn)(
        _In_ sai_object_id_t acl_table_group_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_acl_table_group_attribute_fn)(
        _In_ sai_object_id_t acl_table_group_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_create_acl_table_group_member_fn)(
        _Out_ sai_object_id_t *acl_table_group_member_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_acl_table_group_member_fn)(
        _In_ sai_object_id_t acl_table_group_member_id);


typedef sai_status_t (*sai_set_acl_table_group_member_attribute_fn)(
        _In_ sai_object_id_t acl_table_group_member_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_acl_table_group_member_attribute_fn)(
        _In_ sai_object_id_t acl_table_group_member_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef struct _sai_acl_api_t
{
    sai_create_acl_table_fn                     create_acl_table;
    sai_remove_acl_table_fn                     remove_acl_table;
    sai_set_acl_table_attribute_fn              set_acl_table_attribute;
    sai_get_acl_table_attribute_fn              get_acl_table_attribute;
    sai_create_acl_entry_fn                     create_acl_entry;
    sai_remove_acl_entry_fn                     remove_acl_entry;
    sai_set_acl_entry_attribute_fn              set_acl_entry_attribute;
    sai_get_acl_entry_attribute_fn              get_acl_entry_attribute;
    sai_create_acl_counter_fn                   create_acl_counter;
    sai_remove_acl_counter_fn                   remove_acl_counter;
    sai_set_acl_counter_attribute_fn            set_acl_counter_attribute;
    sai_get_acl_counter_attribute_fn            get_acl_counter_attribute;
    sai_create_acl_range_fn                     create_acl_range;
    sai_remove_acl_range_fn                     remove_acl_range;
    sai_set_acl_range_attribute_fn              set_acl_range_attribute;
    sai_get_acl_range_attribute_fn              get_acl_range_attribute;
    sai_create_acl_table_group_fn               create_acl_table_group;
    sai_remove_acl_table_group_fn               remove_acl_table_group;
    sai_set_acl_table_group_attribute_fn        set_acl_table_group_attribute;
    sai_get_acl_table_group_attribute_fn        get_acl_table_group_attribute;
    sai_create_acl_table_group_member_fn        create_acl_table_group_member;
    sai_remove_acl_table_group_member_fn        remove_acl_table_group_member;
    sai_set_acl_table_group_member_attribute_fn set_acl_table_group_member_attribute;
    sai_get_acl_table_group_member_attribute_fn get_acl_table_group_member_attribute;
} sai_acl_api_t;


#endif 
