

#if !defined (__SAIHASH_H_)
#define __SAIHASH_H_

#include <saitypes.h>




typedef enum _sai_native_hash_field_t
{
    
    SAI_NATIVE_HASH_FIELD_SRC_IP = 0,

    
    SAI_NATIVE_HASH_FIELD_DST_IP = 1,

    
    SAI_NATIVE_HASH_FIELD_INNER_SRC_IP = 2,

    
    SAI_NATIVE_HASH_FIELD_INNER_DST_IP = 3,

    
    SAI_NATIVE_HASH_FIELD_VLAN_ID = 4,

    
    SAI_NATIVE_HASH_FIELD_IP_PROTOCOL = 5,

    
    SAI_NATIVE_HASH_FIELD_ETHERTYPE = 6,

    
    SAI_NATIVE_HASH_FIELD_L4_SRC_PORT = 7,

    
    SAI_NATIVE_HASH_FIELD_L4_DST_PORT = 8,

    
    SAI_NATIVE_HASH_FIELD_SRC_MAC = 9,

    
    SAI_NATIVE_HASH_FIELD_DST_MAC = 10,

    
    SAI_NATIVE_HASH_FIELD_IN_PORT = 11,

} sai_native_hash_field_t;


typedef enum _sai_hash_attr_t
{
    
    SAI_HASH_ATTR_START,

    
    SAI_HASH_ATTR_NATIVE_HASH_FIELD_LIST = SAI_HASH_ATTR_START,

    
    SAI_HASH_ATTR_UDF_GROUP_LIST,

    
    SAI_HASH_ATTR_END,

    
    SAI_HASH_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_HASH_ATTR_CUSTOM_RANGE_END

} sai_hash_attr_t;


typedef sai_status_t (*sai_create_hash_fn)(
        _Out_ sai_object_id_t *hash_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_hash_fn)(
        _In_ sai_object_id_t hash_id);


typedef sai_status_t (*sai_set_hash_attribute_fn)(
        _In_ sai_object_id_t hash_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_hash_attribute_fn)(
        _In_ sai_object_id_t hash_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef struct _sai_hash_api_t
{
    sai_create_hash_fn          create_hash;
    sai_remove_hash_fn          remove_hash;
    sai_set_hash_attribute_fn   set_hash_attribute;
    sai_get_hash_attribute_fn   get_hash_attribute;

} sai_hash_api_t;


#endif 
