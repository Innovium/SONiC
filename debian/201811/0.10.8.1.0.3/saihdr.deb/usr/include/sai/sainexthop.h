

#if !defined (__SAINEXTHOP_H_)
#define __SAINEXTHOP_H_

#include <saitypes.h>




typedef enum _sai_next_hop_type_t
{
    
    SAI_NEXT_HOP_TYPE_IP,

    
    SAI_NEXT_HOP_TYPE_MPLS,

    
    SAI_NEXT_HOP_TYPE_TUNNEL_ENCAP,

    
    SAI_NEXT_HOP_TYPE_SEGMENTROUTE_SIDLIST,

    
    SAI_NEXT_HOP_TYPE_SEGMENTROUTE_ENDPOINT

} sai_next_hop_type_t;


typedef enum _sai_next_hop_endpoint_type_t
{
    
    SAI_NEXT_HOP_ENDPOINT_TYPE_E,

    
    SAI_NEXT_HOP_ENDPOINT_TYPE_X,

    
    SAI_NEXT_HOP_ENDPOINT_TYPE_T,

    
    SAI_NEXT_HOP_ENDPOINT_TYPE_DX2,

    
    SAI_NEXT_HOP_ENDPOINT_TYPE_DX6,

    
    SAI_NEXT_HOP_ENDPOINT_TYPE_DX4,

    
    SAI_NEXT_HOP_ENDPOINT_TYPE_DT6,

    
    SAI_NEXT_HOP_ENDPOINT_TYPE_DT4,

    
    SAI_NEXT_HOP_ENDPOINT_TYPE_CUSTOM_RANGE_BASE = 0x10000000

} sai_next_hop_endpoint_type_t;


typedef enum _sai_next_hop_endpoint_pop_type_t
{
    
    SAI_NEXT_HOP_ENDPOINT_POP_TYPE_PSP,

    
    SAI_NEXT_HOP_ENDPOINT_POP_TYPE_USP,

} sai_next_hop_endpoint_pop_type_t;


typedef enum _sai_next_hop_attr_t
{
    
    SAI_NEXT_HOP_ATTR_START,

    
    SAI_NEXT_HOP_ATTR_TYPE = SAI_NEXT_HOP_ATTR_START,

    
    SAI_NEXT_HOP_ATTR_IP,

    
    SAI_NEXT_HOP_ATTR_ROUTER_INTERFACE_ID,

    
    SAI_NEXT_HOP_ATTR_TUNNEL_ID,

    
    SAI_NEXT_HOP_ATTR_TUNNEL_VNI,

    
    SAI_NEXT_HOP_ATTR_TUNNEL_MAC,

    
    SAI_NEXT_HOP_ATTR_SEGMENTROUTE_SIDLIST_ID,

    
    SAI_NEXT_HOP_ATTR_SEGMENTROUTE_ENDPOINT_TYPE,

    
    SAI_NEXT_HOP_ATTR_SEGMENTROUTE_ENDPOINT_POP_TYPE,

    
    SAI_NEXT_HOP_ATTR_LABELSTACK,

    
    SAI_NEXT_HOP_ATTR_END,

    
    SAI_NEXT_HOP_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_NEXT_HOP_ATTR_CUSTOM_RANGE_END

} sai_next_hop_attr_t;


typedef sai_status_t (*sai_create_next_hop_fn)(
        _Out_ sai_object_id_t *next_hop_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_next_hop_fn)(
        _In_ sai_object_id_t next_hop_id);


typedef sai_status_t (*sai_set_next_hop_attribute_fn)(
        _In_ sai_object_id_t next_hop_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_next_hop_attribute_fn)(
        _In_ sai_object_id_t next_hop_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef struct _sai_next_hop_api_t
{
    sai_create_next_hop_fn        create_next_hop;
    sai_remove_next_hop_fn        remove_next_hop;
    sai_set_next_hop_attribute_fn set_next_hop_attribute;
    sai_get_next_hop_attribute_fn get_next_hop_attribute;

} sai_next_hop_api_t;


#endif 
