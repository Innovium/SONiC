

#if !defined (__SAIROUTE_H_)
#define __SAIROUTE_H_

#include <saitypes.h>




typedef enum _sai_route_entry_attr_t
{
    
    SAI_ROUTE_ENTRY_ATTR_START,

    

    
    SAI_ROUTE_ENTRY_ATTR_PACKET_ACTION = SAI_ROUTE_ENTRY_ATTR_START,

    
    SAI_ROUTE_ENTRY_ATTR_USER_TRAP_ID,

    
    SAI_ROUTE_ENTRY_ATTR_NEXT_HOP_ID,

    
    SAI_ROUTE_ENTRY_ATTR_META_DATA,

    
    SAI_ROUTE_ENTRY_ATTR_END,

    
    SAI_ROUTE_ENTRY_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_ROUTE_ENTRY_ATTR_CUSTOM_RANGE_END

} sai_route_entry_attr_t;


typedef struct _sai_route_entry_t
{
    
    sai_object_id_t switch_id;

    
    sai_object_id_t vr_id;

    
    sai_ip_prefix_t destination;

} sai_route_entry_t;


typedef sai_status_t (*sai_create_route_entry_fn)(
        _In_ const sai_route_entry_t *route_entry,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_route_entry_fn)(
        _In_ const sai_route_entry_t *route_entry);


typedef sai_status_t (*sai_set_route_entry_attribute_fn)(
        _In_ const sai_route_entry_t *route_entry,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_route_entry_attribute_fn)(
        _In_ const sai_route_entry_t *route_entry,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_bulk_create_route_entry_fn)(
        _In_ uint32_t object_count,
        _In_ const sai_route_entry_t *route_entry,
        _In_ const uint32_t *attr_count,
        _In_ const sai_attribute_t **attr_list,
        _In_ sai_bulk_op_error_mode_t mode,
        _Out_ sai_status_t *object_statuses);


typedef sai_status_t (*sai_bulk_remove_route_entry_fn)(
        _In_ uint32_t object_count,
        _In_ const sai_route_entry_t *route_entry,
        _In_ sai_bulk_op_error_mode_t mode,
        _Out_ sai_status_t *object_statuses);


typedef sai_status_t (*sai_bulk_set_route_entry_attribute_fn)(
        _In_ uint32_t object_count,
        _In_ const sai_route_entry_t *route_entry,
        _In_ const sai_attribute_t *attr_list,
        _In_ sai_bulk_op_error_mode_t mode,
        _Out_ sai_status_t *object_statuses);


typedef sai_status_t (*sai_bulk_get_route_entry_attribute_fn)(
        _In_ uint32_t object_count,
        _In_ const sai_route_entry_t *route_entry,
        _In_ const uint32_t *attr_count,
        _Inout_ sai_attribute_t **attr_list,
        _In_ sai_bulk_op_error_mode_t mode,
        _Out_ sai_status_t *object_statuses);


typedef struct _sai_route_api_t
{
    sai_create_route_entry_fn                   create_route_entry;
    sai_remove_route_entry_fn                   remove_route_entry;
    sai_set_route_entry_attribute_fn            set_route_entry_attribute;
    sai_get_route_entry_attribute_fn            get_route_entry_attribute;

    sai_bulk_create_route_entry_fn              create_route_entries;
    sai_bulk_remove_route_entry_fn              remove_route_entries;
    sai_bulk_set_route_entry_attribute_fn       set_route_entries_attribute;
    sai_bulk_get_route_entry_attribute_fn       get_route_entries_attribute;

} sai_route_api_t;


#endif 
