

#if !defined (__SAIRPFGROUP_H_)
#define __SAIRPFGROUP_H_

#include <saitypes.h>




typedef enum _sai_rpf_group_attr_t
{
    
    SAI_RPF_GROUP_ATTR_START,

    
    SAI_RPF_GROUP_ATTR_RPF_INTERFACE_COUNT = SAI_RPF_GROUP_ATTR_START,

    
    SAI_RPF_GROUP_ATTR_RPF_MEMBER_LIST,

    
    SAI_RPF_GROUP_ATTR_END,

    
    SAI_RPF_GROUP_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_RPF_GROUP_ATTR_CUSTOM_RANGE_END

} sai_rpf_group_attr_t;

typedef enum _sai_rpf_group_member_attr_t
{
    
    SAI_RPF_GROUP_MEMBER_ATTR_START,

    
    SAI_RPF_GROUP_MEMBER_ATTR_RPF_GROUP_ID = SAI_RPF_GROUP_MEMBER_ATTR_START,

    
    SAI_RPF_GROUP_MEMBER_ATTR_RPF_INTERFACE_ID,

    
    SAI_RPF_GROUP_MEMBER_ATTR_END,

    
    SAI_RPF_GROUP_MEMBER_ATTR_CUSTOM_RANGE_START  = 0x10000000,

    
    SAI_RPF_GROUP_MEMBER_ATTR_CUSTOM_RANGE_END

} sai_rpf_group_member_attr_t;


typedef sai_status_t (*sai_create_rpf_group_fn)(
        _Out_ sai_object_id_t *rpf_group_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_rpf_group_fn)(
        _In_ sai_object_id_t rpf_group_id);


typedef sai_status_t (*sai_set_rpf_group_attribute_fn)(
        _In_ sai_object_id_t rpf_group_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_rpf_group_attribute_fn)(
        _In_ sai_object_id_t rpf_group_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_create_rpf_group_member_fn)(
        _Out_ sai_object_id_t *rpf_group_member_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_rpf_group_member_fn)(
        _In_ sai_object_id_t rpf_group_member_id);


typedef sai_status_t (*sai_set_rpf_group_member_attribute_fn)(
        _In_ sai_object_id_t rpf_group_member_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_rpf_group_member_attribute_fn)(
        _In_ sai_object_id_t rpf_group_member_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef struct _sai_rpf_group_api_t
{
    sai_create_rpf_group_fn                    create_rpf_group;
    sai_remove_rpf_group_fn                    remove_rpf_group;
    sai_set_rpf_group_attribute_fn             set_rpf_group_attribute;
    sai_get_rpf_group_attribute_fn             get_rpf_group_attribute;
    sai_create_rpf_group_member_fn             create_rpf_group_member;
    sai_remove_rpf_group_member_fn             remove_rpf_group_member;
    sai_set_rpf_group_member_attribute_fn      set_rpf_group_member_attribute;
    sai_get_rpf_group_member_attribute_fn      get_rpf_group_member_attribute;

} sai_rpf_group_api_t;


#endif 
