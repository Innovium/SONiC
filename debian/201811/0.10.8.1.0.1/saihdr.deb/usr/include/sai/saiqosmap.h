

#if !defined (__SAIQOSMAP_H_)
#define __SAIQOSMAP_H_

#include <saitypes.h>




typedef enum _sai_qos_map_type_t
{
    
    SAI_QOS_MAP_TYPE_DOT1P_TO_TC = 0x00000000,

    
    SAI_QOS_MAP_TYPE_DOT1P_TO_COLOR = 0x00000001,

    
    SAI_QOS_MAP_TYPE_DSCP_TO_TC = 0x00000002,

    
    SAI_QOS_MAP_TYPE_DSCP_TO_COLOR = 0x00000003,

    
    SAI_QOS_MAP_TYPE_TC_TO_QUEUE = 0x00000004,

    
    SAI_QOS_MAP_TYPE_TC_AND_COLOR_TO_DSCP = 0x00000005,

    
    SAI_QOS_MAP_TYPE_TC_AND_COLOR_TO_DOT1P = 0x00000006,

    
    SAI_QOS_MAP_TYPE_TC_TO_PRIORITY_GROUP = 0x00000007,

    
    SAI_QOS_MAP_TYPE_PFC_PRIORITY_TO_PRIORITY_GROUP = 0x00000008,

    
    SAI_QOS_MAP_TYPE_PFC_PRIORITY_TO_QUEUE = 0x00000009,

    
    SAI_QOS_MAP_TYPE_CUSTOM_RANGE_BASE = 0x10000000

} sai_qos_map_type_t;


typedef enum _sai_qos_map_attr_t
{
    
    SAI_QOS_MAP_ATTR_START,

    
    SAI_QOS_MAP_ATTR_TYPE = SAI_QOS_MAP_ATTR_START,

    
    SAI_QOS_MAP_ATTR_MAP_TO_VALUE_LIST = 0x00000001,

    
    SAI_QOS_MAP_ATTR_END,

    
    SAI_QOS_MAP_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_QOS_MAP_ATTR_CUSTOM_RANGE_END

} sai_qos_map_attr_t;


typedef sai_status_t (*sai_create_qos_map_fn)(
        _Out_ sai_object_id_t *qos_map_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_qos_map_fn)(
        _In_ sai_object_id_t qos_map_id);


typedef sai_status_t (*sai_set_qos_map_attribute_fn)(
        _In_ sai_object_id_t qos_map_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_qos_map_attribute_fn)(
        _In_ sai_object_id_t qos_map_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef struct _sai_qos_map_api_t
{
    sai_create_qos_map_fn         create_qos_map;
    sai_remove_qos_map_fn         remove_qos_map;
    sai_set_qos_map_attribute_fn  set_qos_map_attribute;
    sai_get_qos_map_attribute_fn  get_qos_map_attribute;

} sai_qos_map_api_t;


#endif 
