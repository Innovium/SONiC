

#if !defined (__SAIEXPERIMENTALBMTOR_H_)
#define __SAIEXPERIMENTALBMTOR_H_

#include <saitypes.h>




typedef enum _sai_table_bitmap_classification_entry_action_t
{
    SAI_TABLE_BITMAP_CLASSIFICATION_ENTRY_ACTION_SET_METADATA,

    SAI_TABLE_BITMAP_CLASSIFICATION_ENTRY_ACTION_NOACTION,

} sai_table_bitmap_classification_entry_action_t;


typedef enum _sai_table_bitmap_router_entry_action_t
{
    SAI_TABLE_BITMAP_ROUTER_ENTRY_ACTION_TO_NEXTHOP,

    SAI_TABLE_BITMAP_ROUTER_ENTRY_ACTION_TO_LOCAL,

    SAI_TABLE_BITMAP_ROUTER_ENTRY_ACTION_TO_CPU,

    SAI_TABLE_BITMAP_ROUTER_ENTRY_ACTION_DROP,

    SAI_TABLE_BITMAP_ROUTER_ENTRY_ACTION_NOACTION,

} sai_table_bitmap_router_entry_action_t;


typedef enum _sai_table_meta_tunnel_entry_action_t
{
    SAI_TABLE_META_TUNNEL_ENTRY_ACTION_TUNNEL_ENCAP,

    SAI_TABLE_META_TUNNEL_ENTRY_ACTION_NOACTION,

} sai_table_meta_tunnel_entry_action_t;


typedef enum _sai_table_bitmap_classification_entry_attr_t
{
    
    SAI_TABLE_BITMAP_CLASSIFICATION_ENTRY_ATTR_START,

    
    SAI_TABLE_BITMAP_CLASSIFICATION_ENTRY_ATTR_ACTION = SAI_TABLE_BITMAP_CLASSIFICATION_ENTRY_ATTR_START,

    
    SAI_TABLE_BITMAP_CLASSIFICATION_ENTRY_ATTR_ROUTER_INTERFACE_KEY,

    
    SAI_TABLE_BITMAP_CLASSIFICATION_ENTRY_ATTR_IS_DEFAULT,

    
    SAI_TABLE_BITMAP_CLASSIFICATION_ENTRY_ATTR_IN_RIF_METADATA,

    
    SAI_TABLE_BITMAP_CLASSIFICATION_ENTRY_ATTR_END,

    
    SAI_TABLE_BITMAP_CLASSIFICATION_ENTRY_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_TABLE_BITMAP_CLASSIFICATION_ENTRY_ATTR_CUSTOM_RANGE_END,

} sai_table_bitmap_classification_entry_attr_t;


typedef enum _sai_table_bitmap_router_entry_attr_t
{
    
    SAI_TABLE_BITMAP_ROUTER_ENTRY_ATTR_START,

    
    SAI_TABLE_BITMAP_ROUTER_ENTRY_ATTR_ACTION = SAI_TABLE_BITMAP_ROUTER_ENTRY_ATTR_START,

    
    SAI_TABLE_BITMAP_ROUTER_ENTRY_ATTR_PRIORITY,

    
    SAI_TABLE_BITMAP_ROUTER_ENTRY_ATTR_IN_RIF_METADATA_KEY,

    
    SAI_TABLE_BITMAP_ROUTER_ENTRY_ATTR_IN_RIF_METADATA_MASK,

    
    SAI_TABLE_BITMAP_ROUTER_ENTRY_ATTR_DST_IP_KEY,

    
    SAI_TABLE_BITMAP_ROUTER_ENTRY_ATTR_TUNNEL_INDEX,

    
    SAI_TABLE_BITMAP_ROUTER_ENTRY_ATTR_NEXT_HOP,

    
    SAI_TABLE_BITMAP_ROUTER_ENTRY_ATTR_ROUTER_INTERFACE,

    
    SAI_TABLE_BITMAP_ROUTER_ENTRY_ATTR_TRAP_ID,

    
    SAI_TABLE_BITMAP_ROUTER_ENTRY_ATTR_END,

    
    SAI_TABLE_BITMAP_ROUTER_ENTRY_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_TABLE_BITMAP_ROUTER_ENTRY_ATTR_CUSTOM_RANGE_END,

} sai_table_bitmap_router_entry_attr_t;


typedef enum _sai_table_meta_tunnel_entry_attr_t
{
    
    SAI_TABLE_META_TUNNEL_ENTRY_ATTR_START,

    
    SAI_TABLE_META_TUNNEL_ENTRY_ATTR_ACTION = SAI_TABLE_META_TUNNEL_ENTRY_ATTR_START,

    
    SAI_TABLE_META_TUNNEL_ENTRY_ATTR_METADATA_KEY,

    
    SAI_TABLE_META_TUNNEL_ENTRY_ATTR_IS_DEFAULT,

    
    SAI_TABLE_META_TUNNEL_ENTRY_ATTR_TUNNEL_ID,

    
    SAI_TABLE_META_TUNNEL_ENTRY_ATTR_UNDERLAY_DIP,

    
    SAI_TABLE_META_TUNNEL_ENTRY_ATTR_END,

    
    SAI_TABLE_META_TUNNEL_ENTRY_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_TABLE_META_TUNNEL_ENTRY_ATTR_CUSTOM_RANGE_END,

} sai_table_meta_tunnel_entry_attr_t;


typedef enum _sai_table_bitmap_classification_entry_stat_t
{
    SAI_TABLE_BITMAP_CLASSIFICATION_ENTRY_STAT_HIT_PACKETS,
    SAI_TABLE_BITMAP_CLASSIFICATION_ENTRY_STAT_HIT_OCTETS,
} sai_table_bitmap_classification_entry_stat_t;


typedef enum _sai_table_bitmap_router_entry_stat_t
{
    SAI_TABLE_BITMAP_ROUTER_ENTRY_STAT_HIT_PACKETS,
    SAI_TABLE_BITMAP_ROUTER_ENTRY_STAT_HIT_OCTETS,
} sai_table_bitmap_router_entry_stat_t;


typedef enum _sai_table_meta_tunnel_entry_stat_t
{
    SAI_TABLE_META_TUNNEL_ENTRY_STAT_HIT_PACKETS,
    SAI_TABLE_META_TUNNEL_ENTRY_STAT_HIT_OCTETS,
} sai_table_meta_tunnel_entry_stat_t;


typedef sai_status_t (*sai_create_table_bitmap_classification_entry_fn)(
        _Out_ sai_object_id_t *table_bitmap_classification_entry_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_table_bitmap_classification_entry_fn)(
        _In_ sai_object_id_t table_bitmap_classification_entry_id);


typedef sai_status_t (*sai_set_table_bitmap_classification_entry_attribute_fn)(
        _In_ sai_object_id_t table_bitmap_classification_entry_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_table_bitmap_classification_entry_attribute_fn)(
        _In_ sai_object_id_t table_bitmap_classification_entry_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_get_table_bitmap_classification_entry_stats_fn)(
        _In_ sai_object_id_t table_bitmap_classification_entry_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_get_table_bitmap_classification_entry_stats_ext_fn)(
        _In_ sai_object_id_t table_bitmap_classification_entry_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _In_ sai_stats_mode_t mode,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_clear_table_bitmap_classification_entry_stats_fn)(
        _In_ sai_object_id_t table_bitmap_classification_entry_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids);


typedef sai_status_t (*sai_create_table_bitmap_router_entry_fn)(
        _Out_ sai_object_id_t *table_bitmap_router_entry_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_table_bitmap_router_entry_fn)(
        _In_ sai_object_id_t table_bitmap_router_entry_id);


typedef sai_status_t (*sai_set_table_bitmap_router_entry_attribute_fn)(
        _In_ sai_object_id_t table_bitmap_router_entry_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_table_bitmap_router_entry_attribute_fn)(
        _In_ sai_object_id_t table_bitmap_router_entry_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_get_table_bitmap_router_entry_stats_fn)(
        _In_ sai_object_id_t table_bitmap_router_entry_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_get_table_bitmap_router_entry_stats_ext_fn)(
        _In_ sai_object_id_t table_bitmap_router_entry_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _In_ sai_stats_mode_t mode,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_clear_table_bitmap_router_entry_stats_fn)(
        _In_ sai_object_id_t table_bitmap_router_entry_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids);


typedef sai_status_t (*sai_create_table_meta_tunnel_entry_fn)(
        _Out_ sai_object_id_t *table_meta_tunnel_entry_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_table_meta_tunnel_entry_fn)(
        _In_ sai_object_id_t table_meta_tunnel_entry_id);


typedef sai_status_t (*sai_set_table_meta_tunnel_entry_attribute_fn)(
        _In_ sai_object_id_t table_meta_tunnel_entry_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_table_meta_tunnel_entry_attribute_fn)(
        _In_ sai_object_id_t table_meta_tunnel_entry_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_get_table_meta_tunnel_entry_stats_fn)(
        _In_ sai_object_id_t table_meta_tunnel_entry_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_get_table_meta_tunnel_entry_stats_ext_fn)(
        _In_ sai_object_id_t table_meta_tunnel_entry_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _In_ sai_stats_mode_t mode,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_clear_table_meta_tunnel_entry_stats_fn)(
        _In_ sai_object_id_t table_meta_tunnel_entry_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids);

typedef struct _sai_bmtor_api_t
{
    sai_create_table_bitmap_classification_entry_fn           create_table_bitmap_classification_entry;
    sai_remove_table_bitmap_classification_entry_fn           remove_table_bitmap_classification_entry;
    sai_set_table_bitmap_classification_entry_attribute_fn    set_table_bitmap_classification_entry_attribute;
    sai_get_table_bitmap_classification_entry_attribute_fn    get_table_bitmap_classification_entry_attribute;
    sai_get_table_bitmap_classification_entry_stats_fn        get_table_bitmap_classification_entry_stats;
    sai_get_table_bitmap_classification_entry_stats_ext_fn    get_table_bitmap_classification_entry_stats_ext;
    sai_clear_table_bitmap_classification_entry_stats_fn      clear_table_bitmap_classification_entry_stats;
    sai_create_table_bitmap_router_entry_fn                   create_table_bitmap_router_entry;
    sai_remove_table_bitmap_router_entry_fn                   remove_table_bitmap_router_entry;
    sai_set_table_bitmap_router_entry_attribute_fn            set_table_bitmap_router_entry_attribute;
    sai_get_table_bitmap_router_entry_attribute_fn            get_table_bitmap_router_entry_attribute;
    sai_get_table_bitmap_router_entry_stats_fn                get_table_bitmap_router_entry_stats;
    sai_get_table_bitmap_router_entry_stats_ext_fn            get_table_bitmap_router_entry_stats_ext;
    sai_clear_table_bitmap_router_entry_stats_fn              clear_table_bitmap_router_entry_stats;
    sai_create_table_meta_tunnel_entry_fn                     create_table_meta_tunnel_entry;
    sai_remove_table_meta_tunnel_entry_fn                     remove_table_meta_tunnel_entry;
    sai_set_table_meta_tunnel_entry_attribute_fn              set_table_meta_tunnel_entry_attribute;
    sai_get_table_meta_tunnel_entry_attribute_fn              get_table_meta_tunnel_entry_attribute;
    sai_get_table_meta_tunnel_entry_stats_fn                  get_table_meta_tunnel_entry_stats;
    sai_get_table_meta_tunnel_entry_stats_ext_fn              get_table_meta_tunnel_entry_stats_ext;
    sai_clear_table_meta_tunnel_entry_stats_fn                clear_table_meta_tunnel_entry_stats;
} sai_bmtor_api_t;


#endif 
