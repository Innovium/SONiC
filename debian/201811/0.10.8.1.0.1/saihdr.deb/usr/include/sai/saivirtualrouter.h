

#if !defined (__SAIVIRTUALROUTER_H_)
#define __SAIVIRTUALROUTER_H_

#include <saitypes.h>




typedef enum _sai_virtual_router_attr_t
{
    
    SAI_VIRTUAL_ROUTER_ATTR_START,

    

    
    SAI_VIRTUAL_ROUTER_ATTR_ADMIN_V4_STATE = SAI_VIRTUAL_ROUTER_ATTR_START,

    
    SAI_VIRTUAL_ROUTER_ATTR_ADMIN_V6_STATE,

    
    SAI_VIRTUAL_ROUTER_ATTR_SRC_MAC_ADDRESS,

    
    SAI_VIRTUAL_ROUTER_ATTR_VIOLATION_TTL1_PACKET_ACTION,

    
    SAI_VIRTUAL_ROUTER_ATTR_VIOLATION_IP_OPTIONS_PACKET_ACTION,

    
    SAI_VIRTUAL_ROUTER_ATTR_UNKNOWN_L3_MULTICAST_PACKET_ACTION,

    
    SAI_VIRTUAL_ROUTER_ATTR_END,

    
    SAI_VIRTUAL_ROUTER_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_VIRTUAL_ROUTER_ATTR_CUSTOM_RANGE_END

} sai_virtual_router_attr_t;


typedef sai_status_t (*sai_create_virtual_router_fn)(
        _Out_ sai_object_id_t *virtual_router_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_virtual_router_fn)(
        _In_ sai_object_id_t virtual_router_id);


typedef sai_status_t (*sai_set_virtual_router_attribute_fn)(
        _In_ sai_object_id_t virtual_router_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_virtual_router_attribute_fn)(
        _In_ sai_object_id_t virtual_router_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef struct _sai_virtual_router_api_t
{
    sai_create_virtual_router_fn        create_virtual_router;
    sai_remove_virtual_router_fn        remove_virtual_router;
    sai_set_virtual_router_attribute_fn set_virtual_router_attribute;
    sai_get_virtual_router_attribute_fn get_virtual_router_attribute;

} sai_virtual_router_api_t;


#endif 
