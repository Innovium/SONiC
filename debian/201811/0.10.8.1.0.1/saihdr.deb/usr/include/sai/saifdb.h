

#if !defined (__SAIFDB_H_)
#define __SAIFDB_H_

#include <saitypes.h>




typedef enum _sai_fdb_entry_type_t
{
    
    SAI_FDB_ENTRY_TYPE_DYNAMIC,

    
    SAI_FDB_ENTRY_TYPE_STATIC,

} sai_fdb_entry_type_t;


typedef struct _sai_fdb_entry_t
{
    
    sai_object_id_t switch_id;

    
    sai_mac_t mac_address;

    
    sai_object_id_t bv_id;

} sai_fdb_entry_t;


typedef enum _sai_fdb_event_t
{
    
    SAI_FDB_EVENT_LEARNED,

    
    SAI_FDB_EVENT_AGED,

    
    SAI_FDB_EVENT_MOVE,

    
    SAI_FDB_EVENT_FLUSHED,

} sai_fdb_event_t;


typedef enum _sai_fdb_entry_attr_t
{
    
    SAI_FDB_ENTRY_ATTR_START,

    
    SAI_FDB_ENTRY_ATTR_TYPE = SAI_FDB_ENTRY_ATTR_START,

    
    SAI_FDB_ENTRY_ATTR_PACKET_ACTION,

    
    SAI_FDB_ENTRY_ATTR_USER_TRAP_ID,

    
    SAI_FDB_ENTRY_ATTR_BRIDGE_PORT_ID,

    
    SAI_FDB_ENTRY_ATTR_META_DATA,

    
    SAI_FDB_ENTRY_ATTR_ENDPOINT_IP,

    
    SAI_FDB_ENTRY_ATTR_END,

    
    SAI_FDB_ENTRY_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_FDB_ENTRY_ATTR_CUSTOM_RANGE_END

} sai_fdb_entry_attr_t;


typedef enum _sai_fdb_flush_entry_type_t
{
    
    SAI_FDB_FLUSH_ENTRY_TYPE_DYNAMIC,

    
    SAI_FDB_FLUSH_ENTRY_TYPE_STATIC,

    
    SAI_FDB_FLUSH_ENTRY_TYPE_ALL,

} sai_fdb_flush_entry_type_t;


typedef enum _sai_fdb_flush_attr_t
{
    
    SAI_FDB_FLUSH_ATTR_START,

    
    SAI_FDB_FLUSH_ATTR_BRIDGE_PORT_ID = SAI_FDB_FLUSH_ATTR_START,

    
    SAI_FDB_FLUSH_ATTR_BV_ID,

    
    SAI_FDB_FLUSH_ATTR_ENTRY_TYPE,

    
    SAI_FDB_FLUSH_ATTR_END,

    
    SAI_FDB_FLUSH_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_FDB_FLUSH_ATTR_CUSTOM_RANGE_END

} sai_fdb_flush_attr_t;


typedef struct _sai_fdb_event_notification_data_t
{
    
    sai_fdb_event_t event_type;

    
    sai_fdb_entry_t fdb_entry;

    
    uint32_t attr_count;

    
    sai_attribute_t *attr;

} sai_fdb_event_notification_data_t;


typedef sai_status_t (*sai_create_fdb_entry_fn)(
        _In_ const sai_fdb_entry_t *fdb_entry,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_fdb_entry_fn)(
        _In_ const sai_fdb_entry_t *fdb_entry);


typedef sai_status_t (*sai_set_fdb_entry_attribute_fn)(
        _In_ const sai_fdb_entry_t *fdb_entry,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_fdb_entry_attribute_fn)(
        _In_ const sai_fdb_entry_t *fdb_entry,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_flush_fdb_entries_fn)(
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef void (*sai_fdb_event_notification_fn)(
        _In_ uint32_t count,
        _In_ const sai_fdb_event_notification_data_t *data);


typedef struct _sai_fdb_api_t
{
    sai_create_fdb_entry_fn                     create_fdb_entry;
    sai_remove_fdb_entry_fn                     remove_fdb_entry;
    sai_set_fdb_entry_attribute_fn              set_fdb_entry_attribute;
    sai_get_fdb_entry_attribute_fn              get_fdb_entry_attribute;
    sai_flush_fdb_entries_fn                    flush_fdb_entries;

} sai_fdb_api_t;


#endif 
