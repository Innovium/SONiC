

#if !defined (__SAIPOLICER_H_)
#define __SAIPOLICER_H_

#include <saitypes.h>




typedef enum _sai_meter_type_t
{
    
    SAI_METER_TYPE_PACKETS = 0x00000000,

    
    SAI_METER_TYPE_BYTES = 0x00000001,

    
    SAI_METER_TYPE_CUSTOM_RANGE_BASE = 0x10000000

} sai_meter_type_t;


typedef enum _sai_policer_mode_t
{
    
    SAI_POLICER_MODE_SR_TCM = 0x00000000,

    
    SAI_POLICER_MODE_TR_TCM = 0x00000001,

    
    SAI_POLICER_MODE_STORM_CONTROL = 0x00000002,

    
    SAI_POLICER_MODE_CUSTOM_RANGE_BASE = 0x10000000

} sai_policer_mode_t;


typedef enum _sai_policer_color_source_t
{
    
    SAI_POLICER_COLOR_SOURCE_BLIND = 0x00000000,

    
    SAI_POLICER_COLOR_SOURCE_AWARE = 0x00000001,

    
    SAI_POLICER_COLOR_SOURCE_CUSTOM_RANGE_BASE = 0x10000000

} sai_policer_color_source_t;


typedef enum _sai_policer_attr_t
{
    
    SAI_POLICER_ATTR_START = 0x00000000,

    
    SAI_POLICER_ATTR_METER_TYPE = SAI_POLICER_ATTR_START,

    
    SAI_POLICER_ATTR_MODE = 0x00000001,

    
    SAI_POLICER_ATTR_COLOR_SOURCE = 0x00000002,

    
    SAI_POLICER_ATTR_CBS = 0x00000003,

    
    SAI_POLICER_ATTR_CIR = 0x00000004,

    
    SAI_POLICER_ATTR_PBS = 0x00000005,

    
    SAI_POLICER_ATTR_PIR = 0x00000006,

    
    SAI_POLICER_ATTR_GREEN_PACKET_ACTION = 0x00000007,

    
    SAI_POLICER_ATTR_YELLOW_PACKET_ACTION = 0x00000008,

    
    SAI_POLICER_ATTR_RED_PACKET_ACTION = 0x00000009,

    
    SAI_POLICER_ATTR_ENABLE_COUNTER_PACKET_ACTION_LIST = 0x0000000a,

    
    SAI_POLICER_ATTR_END,

    
    SAI_POLICER_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_POLICER_ATTR_CUSTOM_RANGE_END

} sai_policer_attr_t;


typedef enum _sai_policer_stat_t
{
    
    SAI_POLICER_STAT_PACKETS = 0x00000000,

    
    SAI_POLICER_STAT_ATTR_BYTES = 0x00000001,

    
    SAI_POLICER_STAT_GREEN_PACKETS = 0x00000002,

    
    SAI_POLICER_STAT_GREEN_BYTES = 0x00000003,

    
    SAI_POLICER_STAT_YELLOW_PACKETS = 0x00000004,

    
    SAI_POLICER_STAT_YELLOW_BYTES = 0x00000005,

    
    SAI_POLICER_STAT_RED_PACKETS = 0x00000006,

    
    SAI_POLICER_STAT_RED_BYTES = 0x00000007,

    
    SAI_POLICER_STAT_CUSTOM_RANGE_BASE = 0x10000000

} sai_policer_stat_t;


typedef sai_status_t (*sai_create_policer_fn)(
        _Out_ sai_object_id_t *policer_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_policer_fn)(
        _In_ sai_object_id_t policer_id);


typedef sai_status_t (*sai_set_policer_attribute_fn)(
        _In_ sai_object_id_t policer_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_policer_attribute_fn)(
        _In_ sai_object_id_t policer_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_get_policer_stats_fn)(
        _In_ sai_object_id_t policer_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_get_policer_stats_ext_fn)(
        _In_ sai_object_id_t policer_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _In_ sai_stats_mode_t mode,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_clear_policer_stats_fn)(
        _In_ sai_object_id_t policer_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids);


typedef struct _sai_policer_api_t
{
    sai_create_policer_fn                 create_policer;
    sai_remove_policer_fn                 remove_policer;
    sai_set_policer_attribute_fn          set_policer_attribute;
    sai_get_policer_attribute_fn          get_policer_attribute;
    sai_get_policer_stats_fn              get_policer_stats;
    sai_get_policer_stats_ext_fn          get_policer_stats_ext;
    sai_clear_policer_stats_fn            clear_policer_stats;

} sai_policer_api_t;


#endif 
