#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import os
import sys
import socket
import select
import argparse
import errno
import time
import datetime
from threading import Thread
from ctypes import *
from ifcs_ctypes import *
from ifcs_cli import IFCS_CLI
from utils.compat_util import *
from verbosity import log, log_err
if COMPAT_PY2:
    from exceptions import IOError
from collections import OrderedDict, deque

g_reserved_port = 7105
g_recommended_host = 'localhost'
class InnoRemoteShell():
    def __init__(self,
                 port=None,
                 host='localhost',
                 server=None,
                 log_file_name=None,
                 flush_interval_sec=60):
        intro               = ''
        self.HOST           = host
        self.PORT           = port
        self.SERVER         = server
        self.MAX_CLIENTS    = 5
        self.clientcount    = 0
        self.active_sockets = [] * self.MAX_CLIENTS
        self.open_client_sockets = [] * self.MAX_CLIENTS
        self.cli            = IFCS_CLI(intro)
        self.cli.set_rt_env('switch')
        self.cli.set_server_mode(True)
        self.cli.set_server_object(self)
        self.cli.set_node_id(0)
        self.cli.init_cmds()
        self.no_shell_mode  = 0
        self.peak_client_count = self.clientcount
        self.peak_client_count_ts = datetime.datetime.now()
        self.client_reject_count = 0
        self.error_epipe_count = 0
        self.error_other_count = 0
        self.exception_count = 0
        self.MAX_ERROR_LOGS = 5
        self.error_logs = deque()
        self.log_filename = log_file_name
        self.log_file = None
        self.log_flush_interval = flush_interval_sec
        self.last_log_flush = time.time()

        if self.log_filename:
            try:
                self.log_file = open(self.log_filename, "w")
                log("Innovium shell server: Using log file {}".format(
                    self.log_filename))
            except Exception:
                log_err("Failed to create log file {}: {}".format(
                    self.log_filename, sys.exc_info()))
                # Ignore error and continue
                self.log_file = None

    def __del__(self):
        if self.log_file:
            self.log_file.close()
            self.log_file = None

    def set_noshell_mode(self, mode):
        self.no_shell_mode = mode

    def setup_modules(self):
        try:
            self.cli.onecmd("setup_modules")
        except:
            server_msg = "Innovium shell server: Error in setup_modules : {}".format(sys.exc_info())
            log(server_msg)
            log_im_msg(IFCS_LOG_LEVEL_ERROR, server_msg, self)
            # re-raise the exception as server cannot continue running
            raise

    def server_log(self, msg):
        if not self.log_file:
            return
        self.log_file.write(msg)
        if self.log_flush_interval == 0:
            self.log_file.flush()
        else:
            cur_time = time.time()
            if cur_time - self.last_log_flush > self.log_flush_interval:
                self.log_file.flush()
                self.last_log_flush = cur_time

    def is_server_log_enabled(self):
        return True if self.log_file else False

    def create_inet_socket(self):

        for sock in self.open_client_sockets + self.active_sockets:
            sock.shutdown(socket.RDWR)
            sock.close()

        # create the socket
        s_in = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        # set sock opt to not resue address
        s_in.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            # bind to the socket
            s_in.bind((self.HOST, self.PORT))
            server_msg = "Innovium shell server (inet): Successfully bound to port %d" % (self.PORT)
            log(server_msg)
            log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg, self)
        except socket.error as msg:
            server_msg = 'Innovium shell server: Bind failed with error: {}'.format(msg)
            log(server_msg)
            log_im_msg(IFCS_LOG_LEVEL_ERROR, server_msg, self)
            return

        # listen to the socket
        s_in.listen(self.MAX_CLIENTS)
        server_msg = "Innovium shell server (inet): Listening for incoming shell clients"
        log(server_msg)
        log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg, self)

        # append socket to active_sockets list
        self.active_sockets.append(s_in)


    def create_unix_socket(self):

        for sock in self.open_client_sockets + self.active_sockets:
            sock.shutdown(socket.RDWR)
            sock.close()

        # make sure the socket doesn't already exist
        try:
            os.unlink(self.SERVER)
        except OSError as e:
            if os.path.exists(self.SERVER):
                server_msg = "Innovium shell server (ERROR): server already in use : {}".format(e)
                log(server_msg)
                log_im_msg(IFCS_LOG_LEVEL_ERROR, server_msg, self)
                return

        # create the socket
        s_in = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)

        try:
            # bind to the socket
            s_in.bind(self.SERVER)
            server_msg = "Innovium shell server (unix): Successfully bound to server %s" % (self.SERVER)
            log(server_msg)
            log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg, self)
        except socket.error as msg:
            server_msg = 'Innovium shell server: Bind failed with error: {}'.format(msg)
            log(server_msg)
            log_im_msg(IFCS_LOG_LEVEL_ERROR, server_msg, self)
            return

        # listen to the socket
        s_in.listen(self.MAX_CLIENTS)
        server_msg = "Innovium shell server (unix): Listening for incoming shell clients"
        log(server_msg)
        log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg, self)

        # append socket to active_sockets list
        self.active_sockets.append(s_in)

    def clientthread(self, conn, addr, data_in):
        # duplicate sys.stdout
        self.cli.stdout = old_stdout = sys.stdout

        # replace sys.stdout with a string buffer
        sys.stdout = new_stdout = compat_StringIO()

        # account for third-party shells that have no prompt
        no_prompt = False

        if 'np' in data_in:
            no_prompt = True
            data_in = data_in.split("np")[0]

        try:
            # execute the incoming command
            if data_in.strip() == "serverexit":
                log("Shell server exiting")
            else:
                self.cli.onecmd(data_in)
        except:
            # retrieve the return buf
            reply = new_stdout.getvalue()

            new_stdout.close()
            # replace the original stdout
            sys.stdout = old_stdout

            # Append error message to client
            err_msg = "Error occurred when executing command : {}".format(sys.exc_info())
            reply = "{}\n{}".format(reply, err_msg)

            # Save copy for logging
            reply_copy = reply

            # encode the reply length in the response
            if not self.no_shell_mode:
                reply = str(len(reply)) + ':::' + reply
            else:
                if no_prompt:
                    reply = reply + "\n"
                else:
                    reply = reply + "\nIVM:R>"

            # send the reply and error message
            conn.sendall(compat_strToBytes(reply))

            # Log if needed
            if self.is_server_log_enabled():
                self.server_log("SHELL:: CMD:: {}\n{}\n".format(
                    data_in, reply_copy))

            # re-raise the exception so that server logs it
            raise

        # retrieve the return buf
        reply = new_stdout.getvalue()

        # Save copy for logging
        reply_copy = reply

        new_stdout.close()
        # replace the original stdout
        sys.stdout = old_stdout

        # encode the reply length in the response
        if not self.no_shell_mode:
            reply = str(len(reply)) + ':::' + reply
        else:
            if no_prompt:
                reply = reply + "\n"
            else:
                reply = reply + "IVM:R>\n"

        # send the reply
        conn.sendall(compat_strToBytes(reply))

        # Log if needed
        if self.is_server_log_enabled():
            self.server_log("SHELL:: CMD:: {}\n{}\n".format(
                data_in, reply_copy))

        # reset the no-prompt flag
        no_prompt = False

    def handle_exception(self, error):
        # restore the stdout
        sys.stdout = self.cli.stdout

        # handle error
        if type(error).__name__ in ['BrokenPipeError', 'error']:
            if type(error).__name__ == 'BrokenPipeError' or error.errno == errno.EPIPE:
                self.error_epipe_count += 1
                server_msg = "Innovium shell server (INFO): client has closed the connection before write finished: {}".format(error)
                log(server_msg)
                log_im_msg(IFCS_LOG_LEVEL_INFO, server_msg, self)
            else:
                self.error_other_count += 1
                server_msg = "Innovium shell server (WARNING): {}".format(error)
                log(server_msg)
                log_im_msg(IFCS_LOG_LEVEL_WARN, server_msg, self)
        else:
            self.exception_count += 1
            server_msg = "Innovium shell server (ERROR): {}".format(error)
            log(server_msg)
            log_im_msg(IFCS_LOG_LEVEL_ERROR, server_msg, self)

    def communicate(self):
        # store open shell client sockets
        self.open_client_sockets = []

        # listen in on incoming socket connections
        while True:
            try:
                read_list, write_list, exception_list = select.select(self.active_sockets + self.open_client_sockets, [], [])

                # for a new shell client  accept the connection
                for current_socket in read_list:
                    if current_socket in self.active_sockets:
                        (new_socket, address) = current_socket.accept()

                        # store the incoming socket in open client sockets list
                        self.open_client_sockets.append(new_socket)

                        # if the client count exceeds max clients, send an error the client and  bail
                        if self.clientcount >= self.MAX_CLIENTS:
                            server_msg = "Innovium shell server: Max number of clients (%d) reached" % (self.MAX_CLIENTS)
                            log(server_msg)
                            log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg, self)
                            error_msg = "Err: Max clients-%d" % (self.MAX_CLIENTS)
                            new_socket.send(compat_strToBytes(error_msg))
                            self.open_client_sockets.remove(new_socket)
                            self.client_reject_count += 1
                            self.save_error_log(
                                "Max number of clients (%d) reached" %
                                (self.MAX_CLIENTS))
                            continue

                        if self.PORT:
                            server_msg = 'Innovium shell server: Accepted shell client {}:{}'.format(address[0], address[1])
                            log(server_msg)
                            log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg, self)
                        else:
                            server_msg = 'Innovium shell server: Accepted shell client'
                            log(server_msg)
                            log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg, self)

                        self.clientcount = self.clientcount + 1
                        if self.peak_client_count <= self.clientcount:
                            self.peak_client_count = self.clientcount
                            self.peak_client_count_ts = datetime.datetime.now()
                        if not self.no_shell_mode:
                            new_socket.send(compat_strToBytes('Success'))
                    else:
                        # recieve the cli command from the socket
                        try:
                            data = compat_bytesToStr(current_socket.recv(1024))
                        except:
                            data = ''
                            server_msg = "Something bad happened. Trying to close connection gracefully. error: {}".format(sys.exc_info())
                            log(server_msg)
                            log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg, self)

                        if len(data) == 0:
                            server_msg = "Innovium shell server: Closing client connection"
                            log(server_msg)
                            log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg, self)
                            current_socket.close()
                            self.open_client_sockets.remove(current_socket)
                            self.clientcount = self.clientcount - 1
                        else:
                            # Execute and return the command
                            self.clientthread(current_socket, address, data)
                            if data.strip() == "serverexit":
                                server_msg = "Innovium shell server: Closing client connection and exiting per request"
                                log(server_msg)
                                log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg, self)
                                current_socket.close()
                                self.open_client_sockets.remove(current_socket)
                                self.clientcount = self.clientcount - 1
                                return
            except (Exception, IOError, socket.error) as e:
                self.save_error_log("Exception: {}".format(sys.exc_info()))
                self.handle_exception(e)

    def save_error_log(self, msg):
        if len(self.error_logs) >= self.MAX_ERROR_LOGS:
            self.error_logs.popleft()
        self.error_logs.append(str(datetime.datetime.now()) + ": " + msg)

    def socket_to_str(self, sock, server=True):
        if COMPAT_PY3:
            return str(sock)
        try:
            if server:
                obj_repr = "<fd={}, family={}, type={} proto={}, laddr={}>".format(
                    sock.fileno(), sock.family, sock.type, sock.proto, sock.getsockname())
            else:
                obj_repr = "<fd={}, family={}, type={} proto={}, laddr={}, raddr={}>".format(
                    sock.fileno(), sock.family, sock.type, sock.proto, sock.getsockname(), sock.getpeername())
        except BaseException:
            obj_repr = str(sock)
        return obj_repr

    def get_server_stats(self):
        stats = OrderedDict()
        stats["Remote client count"] = self.clientcount
        idx = 0
        for sock in self.open_client_sockets:
            stats["Open client socket #{}".format(idx)] = self.socket_to_str(sock, False)
            idx += 1
        stats["Peak remote client count"] = self.peak_client_count
        stats["Latest peak remote client time"] = str(self.peak_client_count_ts)
        idx = 0
        for sock in self.active_sockets:
            stats["Server socket #{}".format(idx)] = self.socket_to_str(sock)
            idx += 1
        stats["Clients rejected due to limit"] = self.client_reject_count
        stats["Server errno.EPIPE count"] = self.error_epipe_count
        stats["Server other errno count"] = self.error_other_count
        stats["Server exception count"] = self.exception_count
        idx = 0
        for msg in self.error_logs:
            stats["Server last error #{}".format(idx)] = msg
            idx += 1
        return stats

    def clear_server_stats(self):
        self.peak_client_count = self.clientcount
        self.peak_client_count_ts = datetime.datetime.now()
        self.client_reject_count = 0
        self.error_epipe_count = 0
        self.error_other_count = 0
        self.exception_count = 0
        self.error_logs = deque()

def log_im_msg(level, msg, server_obj=None):
    if level <= ILC.log_level:
        im_log(IM_LOG_USER_IFCS, level, compat_strToBytes("%s CLI: %s"), ITC.trace_str[ITA_NODE], compat_strToBytes(msg))
        if server_obj and server_obj.is_server_log_enabled():
            server_obj.server_log("IFCS_LOG [{}] [NODE] CLI: {}\n".format(
                level, msg))

def config_inet_server(log_filename=None, flush_interval=60):
    # get the port
    global g_reserved_port
    try:
        PORT = int(os.environ['IFCS_INNO_CLI_PORT'])
        server_msg = "Innovium shell server: Found IFCS_INNO_CLI_PORT: {}".format(PORT)
        log(server_msg)
        log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg)
    except:
        PORT = g_reserved_port
        server_msg = "Innovium shell server: IFCS_INNO_CLI_PORT not set.. assuming default port {}".format(PORT)
        log(server_msg)
        log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg)
    # Get the host. For safety, recommended to use localhost.
    try:
        HOST = os.environ['IFCS_INNO_CLI_HOST']
        if HOST in ["", "0.0.0.0", "all"]:
            HOST = ""
        server_msg = "Innovium shell server: Using host : {}".format(
            "all address" if HOST == "" else HOST)
        log(server_msg)
        log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg)
    except:
        HOST = g_recommended_host
        server_msg = "Innovium shell server: Using default host : {}".format(
            HOST)
        log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg)
    remoteShell = InnoRemoteShell(port=PORT,
                                  host=HOST,
                                  log_file_name=log_filename,
                                  flush_interval_sec=flush_interval)
    remoteShell.create_inet_socket()
    remoteShell.setup_modules()
    remoteShell.communicate()

def config_unix_server(log_filename=None, flush_interval=60):
    # get the server address
    try:
        SERVER = os.environ['IFCS_INNO_CLI_SERVER']
        server_msg = "Innovium shell server: Found IFCS_INNO_CLI_SERVER: {}".format(SERVER)
        log(server_msg)
        log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg)
    except:
        server_msg = "Innovium shell server (ERROR): IFCS_INNO_CLI_SERVER not set.. defaulting to inet server"
        log(server_msg)
        log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg)
        config_inet_server(log_filename, flush_interval)

    try:
        NOSHELL = int(os.environ['IFCS_INNO_CLI_SERVER_NOSHELL'])
        server_msg = "Innovium shell server: Found IFCS_INNO_CLI_SERVER_NOSHELL: {}".format(NOSHELL)
        log(server_msg)
        log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg)
    except:
        NOSHELL=0
        pass

    remoteShell = InnoRemoteShell(server=SERVER,
                                  log_file_name=log_filename,
                                  flush_interval_sec=flush_interval)
    remoteShell.create_unix_socket()
    remoteShell.set_noshell_mode(NOSHELL)
    remoteShell.setup_modules()
    remoteShell.communicate()

def main(log_filename=None, flush_interval=60):
    # figure out type of server to spawn
    configure_method = 0

    config_serv_methods = {
        0  : config_inet_server,
        1  : config_inet_server,
        2  : config_unix_server,
    }

    try:
        PORT = int(os.environ['IFCS_INNO_CLI_PORT'])

        # configure the inet server
        configure_method = 1
    except:
        try:
            SERVER = os.environ['IFCS_INNO_CLI_SERVER']

            # configure unix server
            configure_method = 2
        except:
            server_msg = "Innovium shell (ERROR) : IFCS_INNO_CLI_PORT / IFCS_INNO_CLI_SERVER not set.. defaulting to INET SERVER"
            log(server_msg)
            log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg)

    try:
        config_serv_methods[configure_method](log_filename, flush_interval)
    except Exception as e:
        server_msg = "Innovium shell server : {}".format(e)
        log(server_msg)
        log_im_msg(IFCS_LOG_LEVEL_ERROR, server_msg)

if __name__ == "__main__":
    # get the host and port
    PORT = int(os.environ['IFCS_INNO_CLI_PORT'])
    remoteShell = InnoRemoteShell()
    remoteShell.create_socket()
    remoteShell.communicate()
