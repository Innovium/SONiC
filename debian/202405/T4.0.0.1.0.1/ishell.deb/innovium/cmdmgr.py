
#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import argparse

class Command(object):
    def __init__(self):
        self.active_node = -1
        self.error = 1

    def clearError(self):
        err = self.error
        self.error = 0
        return err

    def run(self, context, args):
        pass

class CmdMgr(object):
    def __init__(self):
        self.cmds = {}

    def __iter__(self):
        return iter(self.cmds.items())

    def add_cmd(self, name, cmd_class):
        self.cmds[name] = cmd_class

    def find_cmd(self, name):
        try:
            return self.cmds[name]
        except KeyError:
            return None

class CommandError(Exception):
    def __init__(self, message, rc = None, rc_str = None):
        self.message = message
        self.rc = rc
        self.rc_str = rc_str
        if not rc is None:
            message = message + ' rc={}'.format(rc)
        if not rc_str is None:
            message = message + ' {}'.format(rc_str)
        super(CommandError, self).__init__(message)
