#-------------------------------------------------------------------------------
# Copyright (c) (2023) Marvell. All rights reserved
# *
# * This material is proprietary to Innovium. All rights reserved.
# * The methods and techniques described herein are considered trade secrets
# * and/or confidential. Reproduction or distribution, in whole or in part, is
# * forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

from ctypes import *
from ifcs_cmds.cli_types import *
from itertools import *
from time import *
from ifcs_cmds.intf import *
from utils.compat_util import *
from verbosity import *
from print_table import PrintTable
import sys
from utils.compat_util import *
ifcs_ctypes = sys.modules['ifcs_ctypes']

ecmp_group_type_dict = {
    ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_STG1_REGULAR: "Regular",
    ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_STG2_CLONE: "Clone",
    ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_STG2_DUAL: "Dual",
}

ecmp_mbr_type_dict = {
    ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_MBR_STG1_TUNNEL: "Tunnel",
    ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_MBR_STG1_NON_TUNNEL: "Non-tunnel",
    ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_MBR_STG1_DUAL: "Dual",
    ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_MBR_STG2_NON_TUNNEL: "Non-tunnel",
    ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_MBR_STG2_CLONE: "Clone",
}


def show_ecmp_extension_usage_detail(arg1, arg2, self):
    num_attr = 2
    attr_list = (ifcs_ctypes.ifcs_attr_t * num_attr)()
    ecmp_enable = ifcs_ctypes.ifcs_bool_t()
    ecmp_profile = ifcs_ctypes.ifcs_uint32_t()

    for index in range(num_attr):
        ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, index))

    rc = ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, 0), ifcs_ctypes.IFCS_NODE_ATTR_ECMP_HIERARCHICAL_ENABLE)
    assert rc == ifcs_ctypes.IFCS_SUCCESS
    rc = ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, 1), ifcs_ctypes.IFCS_NODE_ATTR_ECMP_PROFILE)
    assert rc == ifcs_ctypes.IFCS_SUCCESS

    count = ifcs_ctypes.ifcs_uint32_t()
    for index in range(num_attr):
        ifcs_ctypes.ifcs_node_attr_get(self.cli.node_id, 1, compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, index), pointer(count))

    rc = ifcs_ctypes.ifcs_attr_t_value_data_get(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, 0), pointer(ecmp_enable))
    assert rc == ifcs_ctypes.IFCS_SUCCESS
    rc = ifcs_ctypes.ifcs_attr_t_value_u32_get(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, 1), pointer(ecmp_profile))
    assert rc == ifcs_ctypes.IFCS_SUCCESS

    if int(ecmp_enable.value) != ifcs_ctypes.IFCS_BOOL_TRUE or int(ecmp_profile.value) != ifcs_ctypes.IFCS_ECMP_PROFILE_ID_2:
        log_err("ECMP usage detail supported only for ECMP_PROFILE_ID_2")
        return

    usage_p = (ifcs_ctypes.ifcs_usage_t * 3)()
    obj = (ifcs_ctypes.ifcs_usage_obj_t * 3)()

    obj[0].ecmp = ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_STG1_REGULAR
    obj[1].ecmp = ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_STG2_CLONE
    obj[2].ecmp = ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_STG2_DUAL

    for index in range(2):
        ifcs_ctypes.ifcs_usage_t_obj_api_class_id_set(
            compat_pointerAtIndex(usage_p, ifcs_ctypes.ifcs_usage_t, index),
            ifcs_ctypes.IFCS_USAGE_OBJ_API_CLASS_ID_ECMP)
        ifcs_ctypes.ifcs_usage_t_obj_type_set(
            compat_pointerAtIndex(usage_p, ifcs_ctypes.ifcs_usage_t, index),
            compat_pointerAtIndex(obj, ifcs_ctypes.ifcs_usage_obj_t, index))
        rc = ifcs_ctypes.ifcs_ecmp_usage_detail_get(
            0, 0, None, compat_pointerAtIndex(usage_p, ifcs_ctypes.ifcs_usage_t, index))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("Failed to get ECMP usage rc: {1}".format(
                convert_error_code_to_string(rc)))
            return

    log_dbg(1, " Inside extension ecmp usage show")
    log("Stage 1:")
    table = PrintTable()
    table.add_row(["group type", "max", "used", "available"])
    table.add_row([
        ecmp_group_type_dict[obj[0].ecmp], usage_p[0].max, usage_p[0].current,
        usage_p[0].max - usage_p[0].current
    ])
    table.print_table(brief=True)
    table.reset_table()

    log("Stage 2:")
    table2 = PrintTable()
    table2.add_row(["group type", "max", "used", "available"])
    table2.add_row([
        ecmp_group_type_dict[obj[1].ecmp], usage_p[1].max, usage_p[1].current,
        usage_p[1].max - usage_p[1].current
    ])
    table2.add_row([
        ecmp_group_type_dict[obj[2].ecmp], usage_p[2].max, usage_p[2].current,
        usage_p[2].max - usage_p[2].current
    ])
    table2.print_table(brief=True)
    table2.reset_table()
    log("Note: Dual and clone groups are internal")
    return


def show_ecmp_member_extension_usage_detail(arg1, arg2, self):
    num_attr = 2
    attr_list = (ifcs_ctypes.ifcs_attr_t * num_attr)()
    ecmp_enable = ifcs_ctypes.ifcs_bool_t()
    ecmp_profile = ifcs_ctypes.ifcs_uint32_t()

    for index in range(num_attr):
        ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, index))

    rc = ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, 0), ifcs_ctypes.IFCS_NODE_ATTR_ECMP_HIERARCHICAL_ENABLE)
    assert rc == ifcs_ctypes.IFCS_SUCCESS
    rc = ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, 1), ifcs_ctypes.IFCS_NODE_ATTR_ECMP_PROFILE)
    assert rc == ifcs_ctypes.IFCS_SUCCESS

    count = ifcs_ctypes.ifcs_uint32_t()
    for index in range(num_attr):
        ifcs_ctypes.ifcs_node_attr_get(self.cli.node_id, 1, compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, index), pointer(count))

    rc = ifcs_ctypes.ifcs_attr_t_value_data_get(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, 0), pointer(ecmp_enable))
    assert rc == ifcs_ctypes.IFCS_SUCCESS
    rc = ifcs_ctypes.ifcs_attr_t_value_u32_get(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, 1), pointer(ecmp_profile))
    assert rc == ifcs_ctypes.IFCS_SUCCESS

    if int(ecmp_enable.value) != ifcs_ctypes.IFCS_BOOL_TRUE or int(ecmp_profile.value) != ifcs_ctypes.IFCS_ECMP_PROFILE_ID_2:
        log_err("ECMP usage detail supported only for ECMP_PROFILE_ID_2")
        return

    usage_p = (ifcs_ctypes.ifcs_usage_t * 5)()
    obj = (ifcs_ctypes.ifcs_usage_obj_t * 5)()

    obj[0].ecmp_mbr = ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_MBR_STG1_TUNNEL
    obj[1].ecmp_mbr = ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_MBR_STG1_NON_TUNNEL
    obj[2].ecmp_mbr = ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_MBR_STG1_DUAL
    obj[3].ecmp_mbr = ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_MBR_STG2_NON_TUNNEL
    obj[4].ecmp_mbr = ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_MBR_STG2_CLONE

    for index in range(5):
        ifcs_ctypes.ifcs_usage_t_obj_api_class_id_set(
            compat_pointerAtIndex(usage_p, ifcs_ctypes.ifcs_usage_t, index),
            ifcs_ctypes.IFCS_USAGE_OBJ_API_CLASS_ID_ECMP)
        ifcs_ctypes.ifcs_usage_t_obj_type_set(
            compat_pointerAtIndex(usage_p, ifcs_ctypes.ifcs_usage_t, index),
            compat_pointerAtIndex(obj, ifcs_ctypes.ifcs_usage_obj_t, index))
        rc = ifcs_ctypes.ifcs_ecmp_member_usage_detail_get(
            0, 0, 0, None, compat_pointerAtIndex(usage_p, ifcs_ctypes.ifcs_usage_t, index))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("Failed to get ECMP member usage rc: {1}".format(
                convert_error_code_to_string(rc)))
            return

    log_dbg(1, " Inside extension ecmp member usage show")
    log("Stage 1:")
    table = PrintTable()
    table.add_row(["member type", "max", "used", "available"])
    table.add_row([
        ecmp_mbr_type_dict[obj[0].ecmp_mbr], usage_p[0].max, usage_p[0].current,
        usage_p[0].max - (usage_p[0].current + usage_p[1].current)
    ])
    table.add_row([
        ecmp_mbr_type_dict[obj[1].ecmp_mbr], usage_p[1].max, usage_p[1].current,
        usage_p[1].max - (usage_p[1].current + usage_p[0].current)
    ])
    table.add_row([
        ecmp_mbr_type_dict[obj[2].ecmp_mbr], usage_p[2].max, usage_p[2].current,
        usage_p[2].max - usage_p[2].current
    ])
    table.print_table(brief=True)
    table.reset_table()

    log("Stage 2:")
    table2 = PrintTable()
    table2.add_row(["member type", "max", "used", "available"])
    if((usage_p[3].current + usage_p[4].current) >= usage_p[3].max):
        table2.add_row([
            ecmp_mbr_type_dict[obj[3].ecmp_mbr], usage_p[3].max, usage_p[3].current,
            0
        ])
    else:
        table2.add_row([
            ecmp_mbr_type_dict[obj[3].ecmp_mbr], usage_p[3].max, usage_p[3].current,
            usage_p[3].max - (usage_p[3].current + usage_p[4].current)
        ])
    table2.add_row([
        ecmp_mbr_type_dict[obj[4].ecmp_mbr], usage_p[4].max, usage_p[4].current,
        usage_p[4].max - (usage_p[4].current + usage_p[3].current)
    ])
    table2.print_table(brief=True)
    table2.reset_table()
    log("Note: Dual and clone members are internal")
    return
