/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_wred_util.h
 * @brief ISAI Util Include file for WRED module
 */


#ifndef __IFCS_SAI_WRED_UTIL_H__
#define __IFCS_SAI_WRED_UTIL_H__

#include "util/ifcs_sai_wred_util_dep.h"

/*
 * @brief Initialize defaults SAI attr for wred obj
 *
 * @param [in,out] obj_p        - wred DSO object
 * @param [in] id        - wred OID
 * @return sai_status_t
 */
sai_status_t
isai_im_wred_default_attr(
    isai_shim_qos_info_t *obj_p,
    sai_object_id_t      id);

/*
 * @brief Fill defaults SAI attr for wred obj if user has not provided
 * those values.
 *
 * @param [in] id        -     node_Id
 * @param [in,out] obj_p        - wred DSO object
 * @return sai_status_t
 */
sai_status_t
isai_im_wred_default_attr_fill(ifcs_node_id_t       node_id,
                               isai_shim_qos_info_t *obj_p);


/*
 * @brief Converts SAI attr to IFCS attr
 *
 * @param [in] switch_id        - Switch OID
 * @param [in] api_type        - CRUD operation type
 * @param [in] attr_count        - SAI Attr count
 * @param [in] attr_list_p       - SAI Attr pointer
 * @param [out] ifcs_attr_count  - IFCS attr count
 * @param [out] ifcs_attr_list_pp - IFCS attr list
 * @return sai_status_t
 */
sai_status_t
isai_im_wred_queue_attr_stoi(
    sai_object_id_t       switch_id,
    sai_common_api_t      api_type,
    uint32_t              attr_count,
    const sai_attribute_t *attr_list_p,
    uint32_t              *ifcs_attr_count,
    ifcs_attr_t           **ifcs_attr_list_pp);

/*
 * @brief Delete Egress ACL rule to drop drained packetd from Queue for PFCWD
 *
 * @param [in] node_id        -     node_Id
 * @param [in] switch_deinit_info_p   - printer to switch_deinit_info[switch_id, node_id, restart type etc…]
 * @return sai_status_t
 */
sai_status_t
isai_im_wred_port_pfc_egress_acl_deinit(ifcs_node_id_t           node_id,
                                        sai_switch_deinit_info_t *switch_deinit_info_p);

sai_status_t
isai_im_wred_port_pfc_egress_acl_setup(sai_object_id_t switch_oid,
                                       sai_object_id_t port_oid);

sai_status_t
isai_im_wred_port_pfc_egress_acl_cleanup(sai_object_id_t switch_oid,
                                         sai_object_id_t port_oid);

sai_status_t
isai_im_wred_init(sai_switch_init_info_t *sai_switch_init_info_p);

sai_status_t
isai_im_wred_deinit(sai_switch_deinit_info_t  *switch_deinit_info_p);

sai_status_t
isai_im_wred_enable_ecn_statistics(sai_switch_init_info_t *sw_info_p);


#endif /* __IFCS_SAI_WRED_UTIL_H__ */
