/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_wred.h
 * @brief ISAI IM Include file for WRED module
 */


#ifndef __IFCS_SAI_WRED_H__
#define __IFCS_SAI_WRED_H__


#define ISAI_MODULE_LOCK_WRED    1ULL


#include "isai_im_nmgr.h"
#include "ifcs_sai_qos_common.h"
#include "ifcs_sai_acl.h"
#include "ifcs_sai_buffer.h"
#include "ifcs_sai_switch.h"
#endif /* __IFCS_SAI_WRED_H__ */
