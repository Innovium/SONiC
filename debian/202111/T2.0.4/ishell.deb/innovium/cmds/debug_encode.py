import os
import sys
import json
import time
try:
    import cPickle as pickle
except BaseException:
    import pickle
from ctypes import *
from ifcs_ctypes import *
from utils.compat_util import *
from verbosity import *
# To avoid renaming arguments in certain functions in this file.
_my_log = log

FIELD_NAME_MAX_LENGTH = 48
PEN_NAME_MAX_LENGTH = 48

ifcs_ctypes = sys.modules['ifcs_ctypes']

#------------------------------------------
# ---- UTILS ---- #


def get_pen_info(pen_id):
    """
        Get pen info
    """
    peninfo = pen_t()
    node_get_pen_info(0, pen_id, pointer(peninfo))
    return peninfo

#------------------------------------------


def get_flds_from_pen_id(pen_id):
    """
        Get fields from pen id
    """
    peninfo = get_pen_info(pen_id)
    nflds = c_uint()
    nflds.value = peninfo.num_flds
    fldinfo = (pen_field_t * nflds.value)()
    try:
        node_get_pen_fields(
            0,
            pen_id,
            pointer(peninfo),
            byref(nflds),
            compat_pointer(fldinfo, pen_field_t))
    except Exception as ex:
        log(type(ex).__name__, ex.args)
    return nflds, fldinfo


#------------------------------------------

def get_flds_from_peninfo(pen_id, peninfo):
    """
        Get fields from peninfo
    """
    nflds = c_uint()
    nflds.value = peninfo.num_flds
    fldinfo = (pen_field_t * nflds.value)()
    rc = node_get_pen_fields(
        0,
        pen_id,
        pointer(peninfo),
        byref(nflds),
        compat_pointer(fldinfo, pen_field_t))
    if rc != IFCS_SUCCESS:
        log_dbg(1, "Get PEN Fields Failed for Pen " + str(pen_id))
    return nflds, fldinfo

#------------------------------------------


def get_fld_info(pen_id, fld):
    """
        Get field info
    """
    nflds, fldinfo = get_flds_from_pen_id(pen_id)
    for j in range(nflds.value):
        if ((fldinfo[j].fname == fld)):
            return fldinfo[j]
    assert 0, "PEN " + str(pen_id) + ": Field " + str(fld) + " not found"

#------------------------------------------


def get_fld_info_from_flds(nflds, fldinfo, pen_id, fld):
    """
        Get field info from fields
    """
    for j in range(nflds.value):
        if ((fldinfo[j].fname == fld)):
            return fldinfo[j]
    assert 0, "PEN " + str(pen_id) + ": Field " + str(fld) + " not found"

#------------------------------------------


def get_fld_width(nflds, fldinfo, pen_id, fld):
    """
        Get field width
    """
    fld_width = -1
    for j in range(nflds.value):
        if ((fldinfo[j].fname == fld)):
            fld_width = fldinfo[j].width
            break
    return fld_width

#------------------------------------------


def get_fld_val_from_fldlst(pen_id, fldlst, fld_id):
    """
        Get field value from field list
    """
    val = -1
    for fld in fldlst:
        if fld[0] == fld_id:
            val = fld[1]
            return val

    assert 0, "PEN " + str(pen_id) + ": Field " + str(fld) + " not found"

#------------------------------------------


def check_fld_present(pen_id, fld_id):
    """
        Check if the field is present
    """
    nflds, fldinfo = get_flds_from_pen_id(pen_id)
    for j in range(nflds.value):
        if (fldinfo[j].fname == fld_id):
            return 1
    return 0

#------------------------------------------


def convert_ctypes_array_to_list(array):
    """
        Convert ctypes list to python list
    """

    if not isinstance(array, ctypes.Array):
        return array

    lst = list()
    for i in range(len(array)):
        lst.append(array[i])

    return lst

#------------------------------------------


def gen_fldlst_from_tentry(pen_id, nflds, fldinfo, entry, verbose):
    """
        Function to get field list from tentry length
    """
    fld_str = c_char_p(b" " * FIELD_NAME_MAX_LENGTH)

    fldlst = []

    for j in range(nflds.value):
        rc = node_get_pen_field_name(
            0, fldinfo[j].fname, fld_str, FIELD_NAME_MAX_LENGTH)
        if (rc != IFCS_SUCCESS):
            log_dbg(1,"Couldnt get name for field id " + str(fld_id))

        if (fldinfo[j].width <= 32):
            rd_val = c_uint(0)
            rc = tentry_get_item(
                0,
                pen_id,
                fldinfo[j].fname,
                TENTRY_FLD_TYPE_UINT32,
                entry,
                pointer(rd_val))
            if (rc != IFCS_SUCCESS):
                log_dbg(1,"PEN " + str(pen_id) + ": Get Field " + str(fldinfo[j].fname) + " failed")
            rdval = ctypes.c_uint32(rd_val.value).value
            fldlst.append([fldinfo[j].fname, rdval])
            if verbose:
                log_dbg(1,"    %s : 0x%X " % (fld_str.value, rdval))
        else:
            nbytes = compat_division((fldinfo[j].width + 7), 8)
            buf = (c_ubyte * nbytes)()
            rc = tentry_get_item(
                0,
                pen_id,
                fldinfo[j].fname,
                TENTRY_FLD_TYPE_ANY,
                entry,
                compat_pointer(buf, c_ubyte))
            if (rc != IFCS_SUCCESS):
                log_dbg(1,"PEN " + str(pen_id) + ": Get Field " + str(fldninfo[j].fname) + " failed")
            fldlst.append([fldinfo[j].fname, buf])
            if verbose:
                log("    %s : " % (fld_str.value), [hex(i) for i in buf])

    return fldlst

#------------------------------------------


def get_fld_len(pen_id, fld_id):
    """
        Function to get field length
    """
    pen_str = c_char_p(b" " * PEN_NAME_MAX_LENGTH)
    fld_str = c_char_p(b" " * FIELD_NAME_MAX_LENGTH)

    rc = node_get_pen_name(0, pen_id, pen_str, PEN_NAME_MAX_LENGTH)
    if (rc != IFCS_SUCCESS):
        log_dbg(1,"Couldnt get name for pen id " + str(pen_id))

    fld_info = get_fld_info(pen_id, fld_id)
    rc = node_get_pen_field_name(0, fld_id, fld_str, FIELD_NAME_MAX_LENGTH)
    if (rc != IFCS_SUCCESS):
        log_dbg(1,"Couldnt get name for field id " + str(fld_id))

    return fld_info.width

#------------------------------------------


def read_pen(
        pen_id,
        index,
        fldlst=[],
        indir_cmd=ISN_CMD_HASH_RSVD15,
        ib=0,
        node=0,
        fldtargets=[],
        log=None,
        sample_id=0,
        pic=0,
        asyncFlag=False,
        blockmode=False,
        entries=1,
        event=None,
        clear=False):
    """
        Function to directly read one PEN Entry
    """
    IB_NUM = 0
    if (ib == 0 and IB_NUM != 0):
        ib = IB_NUM
    if fldtargets and log:
        pen_str = c_char_p(b" " * PEN_NAME_MAX_LENGTH)
        peninfo = get_pen_info(pen_id)
        status = c_uint(0)

        if blockmode:
            if entries == 0:
                _my_log("Must specify num. entries to read with block access mode")
                sys.exit(1)
            entry = bentry_t()
            bentry_init(0, pointer(entry), pen_id, peninfo.num_entries)
            bentry_alloc(0, pointer(entry))
            if asyncFlag and event is None:
                _my_log("Must specify event type with block read asyncFlag")
                sys.exit(1)
        else:
            entry = tentry_new(pen_id, -1, -1)

        peninfo = get_pen_info(pen_id)
        rc = node_get_pen_name(0, pen_id, pen_str, PEN_NAME_MAX_LENGTH)
        if (rc != IFCS_SUCCESS):
            log_dbg(1,"Couldnt get name for pen id " + str(pen_id))
        nflds, fldinfo = get_flds_from_peninfo(pen_id, peninfo)
        pentype = c_uint(0)
        penacc = c_uint(0)
        rc = node_get_pen_type_acc(
            0, int(pen_id), byref(pentype), byref(penacc))
        if (rc != IFCS_SUCCESS):
            log_dbg(1,"PEN get type/acc failed: rc = " + str(rc))

        if blockmode:
            if asyncFlag:
                rc = node_isn_pen_block_read_async(
                    node, ib, int(pen_id), index, entries, 0, event, None, pointer(status))
                if (rc != IFCS_SUCCESS):
                    log_dbg(1,"Could not perform asyncFlag block reads for pen id {} rc= {}".format(str(pen_id), str(rc)))
            else:
                rc = node_isn_pen_block_read(
                    node, ib, int(pen_id), index, entries, 0, pointer(entry))
                if (rc != IFCS_SUCCESS):
                    log_dbg(1,"Could not perform block reads for pen id {} rc {}".format(str(pen_id), str(rc)))
        elif (pentype.value & PEN_TYPE_HASH):
            hash_fn = 0
            bktmd = c_uint(0)
            hash_index = c_uint(0)
            hash_index.value = index
            rc = node_isn_pen_hash_cmd(
                node,
                ib,
                int(pen_id),
                ISN_CMD_HASH_READ,
                hash_fn,
                byref(hash_index),
                byref(bktmd),
                entry)
            if ((rc != IFCS_SUCCESS) and (rc != IFCS_ENTRY_REPLACED)):
                log_dbg(1,"PEN {} Hash command failed rc: {}".format(str(pen_str.value), str(rc)))
        elif (pentype.value & PEN_TYPE_ILPM):
            hash_fn = 0
            bktmd = c_uint(0)
            hash_index = c_uint(0)
            hash_index.value = index
            hash_cmd = ISN_CMD_HASH_READ
            rc = node_isn_pen_ilpm_cmd(
                node,
                ib,
                int(pen_id),
                hash_cmd,
                byref(hash_index),
                byref(bktmd),
                entry)
            if(rc != IFCS_SUCCESS):
                log_dbg(1,"PEN {} ILPM command failed: rc {}".format(str(pen_str.value), str(rc)))
        elif ((pentype.value & PEN_TYPE_TCAM) or (pentype.value & PEN_TYPE_ABB_TCAM)):
            if (penacc.value):
                tcam_index = c_uint(0)
                tcam_index.value = index
                if (indir_cmd == ISN_CMD_HASH_RSVD15):
                    tcam_cmd = ISN_CMD_TCAM_READ
                else:
                    tcam_cmd = indir_cmd

                rc = node_isn_pen_tcam_cmd(
                    node, ib, int(pen_id), tcam_cmd, byref(tcam_index), entry)
                if (rc != IFCS_SUCCESS):
                    log_dbg(1,"PEN {} : TCAM command failure: rc {}".format(str(pen_str.value), str(rc)))
            else:
                hints = 0
                if pic > 0:
                    pic_id = pic
                    stid = (ib + (pic_id << 4))
                    rc = node_isn_pen_read(
                        node, stid, int(pen_id), index, hints, entry)
                else:
                    rc = node_isn_pen_read(
                        node, ib, int(pen_id), index, hints, entry)
                if (rc != IFCS_SUCCESS):
                    log_dbg(1,"PEN {} : Read failed : rc {}".format(str(pen_str.value), str(rc)))

        else:
            if asyncFlag:
                hints = 0
                if pic > 0:
                    pic_id = pic
                    stid = (ib + (pic_id << 4))
                    rc = node_isn_pen_read_async(
                        node, stid, pen_id, index, entry, 0)
                else:
                    rc = node_isn_pen_read_async(
                        node, ib, pen_id, index, entry, 0)
                if (rc != IFCS_SUCCESS):
                    log_dbg(1,"PEN {} : Read failed: rc = {}".format(str(pen_str.value), str(rc)))
            else:
                hints = 0
                if pic > 0:
                    pic_id = pic
                    stid = (ib + (pic_id << 4))
                    if clear:
                        rc = node_isn_pen_read_clear(
                            node, stid, int(pen_id), index, hints, entry)
                    else:
                        rc = node_isn_pen_read(
                            node, stid, int(pen_id), index, hints, entry)
                else:
                    if clear:
                        rc = node_isn_pen_read_clear(
                            node, ib, int(pen_id), index, hints, entry)
                    else:
                        rc = node_isn_pen_read(
                            node, ib, int(pen_id), index, hints, entry)

                if (rc != IFCS_SUCCESS):
                    log_dbg(1,"PEN {} : Read failed: rc = {}".format(str(pen_str.value), str(rc)))

    else:
        pen_str = c_char_p(b" " * PEN_NAME_MAX_LENGTH)
        peninfo = get_pen_info(pen_id)
        status = c_uint(0)

        if blockmode:
            if entries == 0:
                _my_log("Must specify number of entries to read with block access mode")
                sys.exit(1)
            entry = bentry_t()
            bentry_init(0, pointer(entry), pen_id, peninfo.num_entries)
            bentry_alloc(0, pointer(entry))
            if asyncFlag and event is None:
                _my_log("Must specify event type with block read asyncFlag")
                sys.exit(1)
        else:
            entry = tentry_new(pen_id, -1, -1)

        peninfo = get_pen_info(pen_id)
        rc = node_get_pen_name(0, pen_id, pen_str, PEN_NAME_MAX_LENGTH)
        if (rc != IFCS_SUCCESS):
            log_dbg(1,"Couldnt get name for pen id {}".format(str(pen_id)))

        nflds, fldinfo = get_flds_from_peninfo(pen_id, peninfo)

        pentype = c_uint(0)
        penacc = c_uint(0)

        rc = node_get_pen_type_acc(
            0, int(pen_id), byref(pentype), byref(penacc))
        if (rc != IFCS_SUCCESS):
            log_dbg(1,"PEN get type/acc failed: rc = " + str(rc))

        if blockmode:
            if asyncFlag:
                rc = node_isn_pen_block_read_async(
                    node, ib, int(pen_id), index, entries, 0, IM_EVENT_TEST, None, pointer(status))
                if (rc != IFCS_SUCCESS):
                    log_dbg(1,"Could not perform asyncFlag block reads for pen id {} rc {}".format(str(pen_id), str(rc)))
            else:
                rc = node_isn_pen_block_read(
                    node, ib, int(pen_id), index, entries, 0, pointer(entry))
                if (rc != IFCS_SUCCESS):
                    log_dbg(1,"Could not perform block reads for pen id {} rc = {}".format(str(pen_id), str(rc)))
        elif (pentype.value & PEN_TYPE_HASH):
            hash_fn = 0
            bktmd = c_uint(0)
            hash_index = c_uint(0)
            hash_index.value = index
            rc = node_isn_pen_hash_cmd(
                    node,
                    ib,
                    int(pen_id),
                    ISN_CMD_HASH_READ,
                    hash_fn,
                    byref(hash_index),
                    byref(bktmd),
                    entry)
            if ((rc != IFCS_SUCCESS) and (rc != IFCS_ENTRY_REPLACED)):
                log_dbg(1,"PEN {} : Hash command failed: rc {}".format(str(pen_str.value), str(rc)))
        elif (pentype.value & PEN_TYPE_ILPM):
            hash_fn = 0
            bktmd = c_uint(0)
            hash_index = c_uint(0)
            hash_index.value = index
            hash_cmd = ISN_CMD_HASH_READ

            rc = node_isn_pen_ilpm_cmd(
                node,
                ib,
                int(pen_id),
                hash_cmd,
                byref(hash_index),
                byref(bktmd),
                entry)
            if ((rc != IFCS_SUCCESS)):
                log_dbg(1,"PEN {} : ILPM command failed: rc {} ".format(str(pen_str.value), str(rc)))

        elif ((pentype.value & PEN_TYPE_TCAM) or (pentype.value & PEN_TYPE_ABB_TCAM)):
            if (penacc.value):
                tcam_index = c_uint(0)
                tcam_index.value = index

                if (indir_cmd == ISN_CMD_HASH_RSVD15):
                    tcam_cmd = ISN_CMD_TCAM_READ
                else:
                    tcam_cmd = indir_cmd

                rc = node_isn_pen_tcam_cmd(
                    node, ib, int(pen_id), tcam_cmd, byref(tcam_index), entry)
                if (rc != IFCS_SUCCESS):
                    log_dbg(1,"PEN {} : TCAM command failed: rc {}".format(str(pen_str.value), str(rc)))
            else:
                hints = 0
                if pic > 0:
                    pic_id = pic
                    stid = (ib + (pic_id << 4))
                    rc = node_isn_pen_read(
                        node, stid, int(pen_id), index, hints, entry)
                else:
                    rc = node_isn_pen_read(
                        node, ib, int(pen_id), index, hints, entry)
                if (rc != IFCS_SUCCESS):
                    log_dbg(1,"PEN {} : Read failed: rc = {}".format(str(pen_str.value), str(rc)))
        else:
            if asyncFlag:
                hints = 0
                if pic > 0:
                    pic_id = pic
                    stid = (ib + (pic_id << 4))
                    rc = node_isn_pen_read_async(
                        node, stid, pen_id, index, entry, 0)
                else:
                    rc = node_isn_pen_read_async(
                        node, ib, pen_id, index, entry, 0)
                if (rc != IFCS_SUCCESS):
                    log_dbg(1,"PEN {} : Read failed: rc = {}".format(str(pen_str.value), str(rc)))
            else:
                hints = 0
                if pic > 0:
                    pic_id = pic
                    stid = (ib + (pic_id << 4))
                    if clear:
                        rc = node_isn_pen_read_clear(
                            node, stid, int(pen_id), index, hints, entry)
                    else:
                        rc = node_isn_pen_read(
                            node, stid, int(pen_id), index, hints, entry)
                else:
                    if clear:
                        rc = node_isn_pen_read_clear(
                            node, ib, int(pen_id), index, hints, entry)
                    else:
                        rc = node_isn_pen_read(
                            node, ib, int(pen_id), index, hints, entry)

                if (rc != IFCS_SUCCESS):
                    log_dbg(1,"PEN " + str(pen_str.value) +
                        " : Read failed: rc = " + str(rc))
    return entry

#------------------------------------------


def get_sfld_width(
        nflds,
        fldinfo,
        pen_id,
        pen_str,
        mfld,
        mfld_str,
        mk,
        prof,
        sfld,
        sfld_str):
    mfld_info = get_fld_info_from_flds(nflds, fldinfo, pen_id, mfld)
    if (mk == 1):
        mmk = cast(mfld_info.mk_profile, POINTER(mk_profile_list_t))
        for j in range(mmk[prof].num_fields):
            if (mmk[prof].fields[j].fname == sfld):
                return mmk[prof].fields[j].width
        assert 0, "PEN " + pen_str.value + ", Field " + mfld_str.value + \
            ": Could not find field " + sfld_str.value + " in mk_id = " + str(prof)

    else:
        mepp = cast(mfld_info.ep_profile, POINTER(ep_profile_list_t))
        for j in range(mepp[prof].num_actions):
            if (mepp[prof].ep_profiles[j].fname == sfld):
                return mepp[prof].ep_profiles[j].width
        assert 0, "PEN " + pen_str.value + ", Field " + mfld_str.value + \
            ": Could not find field " + sfld_str.value + " in epp = " + str(prof)


#------------------------------------------

def debug_encode(cmp_id=[], ib_list=[], max_idx=-1):
    """
        Function that iterates over all pens all ibs
        retrieves pen information.
    """
    def debug_encode_callback(node_id, buff):
        log_dbg(1, "%s" % compat_bytesToStr(buff))

    callback_type = CFUNCTYPE(
        ifcs_ctypes.UNCHECKED(None),
        ifcs_ctypes.ifcs_node_id_t,
        c_char_p)
    callback = callback_type(debug_encode_callback)

    # Test Run id = time in string
    test_run_id = time.strftime("%b_%d_%Y_%H%M%S", time.localtime())

    # Form the comp id list. The cmp_id list [1, 3, 5, 6, 7, 8, 16] is statically set
    # in the c code
    if not cmp_id or (len(cmp_id) == 0):
        cmp_id = [1, 3, 5, 6, 7, 8, 16]

    cmpid_len = len(cmp_id)
    cmpid_memory = (c_uint32 * cmpid_len)
    cmpid_array = cmpid_memory(*cmp_id)

    # Form the ib id list based on active ibs
    if not ib_list or (len(ib_list) == 0):
        ib_bitmap = im_nmgr_ib_active(0)
        for ib in range(6):
            if (ib_bitmap.contents.value & (1 << int(ib))):
                ib_list.append(ib)

    # Create the state dump file.
    log('Generating state dump... ' + test_run_id)

    files_list = []
    # Iterate over ib list
    for ib_id in ib_list:
        log("ib {} ..".format(ib_id))
        ibs = []
        ib_f = '%s_' % format(ib_id) + str(test_run_id)
        try:
            ib_fh = open(ib_f, 'wb')
        except Exception as e:
            log("File Open error ( {} ):{}/{}".format(e, os.getcwd(), ib_f))
            return
        ib_start_time = time.time()
        pendump_get_all_pens(0, ib_id, 0, PEN_COMMON_MAX, compat_pointer(cmpid_array, c_uint32),
                             cmpid_len, c_char_p(compat_strToBytes(ib_f)),
                             compat_funcPointer(callback, ifcs_ctypes.pendump_user_cb_t))

        cmd = "gzip {0}".format(ib_f)
        time.sleep(1)
        os.system(cmd)
        files_list.append(ib_f + ".gz")
        # End ib loop

#    fileName = os.environ['HOME'] + '/stateDump_' + str(test_run_id) + '.tar.gz'
    fileName = os.getcwd() + '/stateDump_' + str(test_run_id) + '.tar.gz'

    cmd = "tar -czf %s" % (fileName) + " "
    for file_ in files_list:
        log_dbg(1, file_)
        cmd += file_ + ' '

    log("Writing to file.. " + fileName)
    os.system(cmd)

    # Cleanup
    for file_ in files_list:
        cmd = "rm %s "
        cmd = cmd % (file_)
        os.system(cmd)

    end_time = time.strftime("%b_%d_%Y_%H%M%S", time.localtime())
    log_dbg(1, 'Quiting ' + end_time)

    return
# ------------------------------------------------------

def main():
    debug()


if __name__ == "__main__":
    debug()
