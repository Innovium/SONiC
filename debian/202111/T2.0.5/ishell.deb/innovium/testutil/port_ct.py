#-------------------------------------------------------------------------------
# * Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------
"""Enable/Disbale cut-through on all Eth Ports
  Typical command usage examples:

    To enable cut-through on all devports of type ETH:
    run port_ct --enable

    To disable cut-through on all devports of type ETH:
    run port_ct --disable

    For help in usage:
    run port_ct -h
"""

import sys
import argparse
from verbosity import log, log_dbg, log_err
from utils.compat_util import *
import ctypes
ifcs_ctypes = sys.modules['ifcs_ctypes']


class PortCt:

    def __init__(self, args):
        self._node_id = 0
        self._fp_devports = []
        self._fp_ct_enable = None

        try:
            self._parse_args(args)
            if (self._fp_ct_enable != None):
                self._fetch_and_process_all_fp_ports()
            self._display_status()
        except:
            log_dbg(
                1, 'Error occurred for port_ct command with arguments {}:\n{}'.
                format(args, sys.exc_info()))

    def _status_to_string(self, rc):
        return compat_bytesToStr(ifcs_ctypes.ifcs_status_to_string(rc))

    def _parse_args(self, args):
        args = args.strip()
        if not args:
            msg = 'Missing mandatory argument, --enable or --disable'
            log_err(msg)
            raise ValueError(msg)

        args = args.split()
        log_dbg(1, 'run port_ct command: parsing arguments: {}'.format(args))
        if len(args) > 1:
            msg = 'Only one arg expected, either --enable or --disable'
            log_err(msg)
            raise ValueError(msg)

        parser = argparse.ArgumentParser(
            prog='run port_ct',
            description='Enable/Disbale cut-through on all Eth Ports',
            formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-e',
                            '--enable',
                            help='Eanble cut-through on all Eth Ports',
                            action='store_const',
                            const=1)
        parser.add_argument('-d',
                            '--disable',
                            help='Disable cut-through on all Eth Ports',
                            action='store_const',
                            const=1)

        res = None
        try:
            res = parser.parse_args(args)
        except:
            if len(args) == 1 and args[0] in ['-h', '--help']:
                raise ValueError('Help option is provided to the command')
            msg = 'Missing arguments or invalid arguments provided'
            log_err(msg)
            raise ValueError(msg)

        if (res.enable != None):
            self._fp_ct_enable = ifcs_ctypes.IFCS_BOOL_TRUE
        elif (res.disable != None):
            self._fp_ct_enable = ifcs_ctypes.IFCS_BOOL_FALSE

    def _fetch_and_process_all_fp_ports(self):
        log_dbg(1, 'port_ct command: Enable/Disbale cut-through on all Eth Ports')

        # Fetch all ETH devports
        def myCallback(node_id, devport, attr_count, attr_list, user_data):
            self._fp_devports.append(devport)

        callback_type = ctypes.CFUNCTYPE(
            ifcs_ctypes.UNCHECKED(None), ifcs_ctypes.ifcs_node_id_t,
            ifcs_ctypes.ifcs_devport_t, ctypes.c_uint32,
            ctypes.POINTER(ifcs_ctypes.ifcs_attr_t), ctypes.POINTER(None))
        callback = callback_type(myCallback)
        callback_p = compat_funcPointer(callback,
                                        ifcs_ctypes.ifcs_devport_user_cb_t)
        devport_count = ctypes.c_uint32()

        attr = ifcs_ctypes.ifcs_attr_t()
        assert ifcs_ctypes.ifcs_attr_t_init(
            pointer(attr)) == ifcs_ctypes.IFCS_SUCCESS
        assert ifcs_ctypes.ifcs_attr_t_id_set(
            pointer(attr),
            ifcs_ctypes.IFCS_DEVPORT_ATTR_TYPE) == ifcs_ctypes.IFCS_SUCCESS
        assert ifcs_ctypes.ifcs_attr_t_value_u32_set(
            pointer(attr),
            ifcs_ctypes.IFCS_DEVPORT_TYPE_ETH) == ifcs_ctypes.IFCS_SUCCESS
        rc = ifcs_ctypes.ifcs_devport_get_all(self._node_id, 1, pointer(attr),
                                              callback_p, None,
                                              pointer(devport_count))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            msg = 'Failed to get all ETH devport rc: {0}'.format(
                self._status_to_string(rc))
            log_err(msg)
            raise KeyError(msg)

        log_dbg(1, 'port_ct command: fp ports {}'.format(self._fp_devports))

        # Set IFCS_DEVPORT_ATTR_CUT_THROUGH_ENABLE for all ETH devports
        attr_list = (ifcs_ctypes.ifcs_attr_t * 1)()

        attr_count = 0

        rc = ifcs_ctypes.ifcs_attr_t_init(
            compat_pointerAtIndex(
                attr_list, ifcs_ctypes.ifcs_attr_t, attr_count))
        assert rc == ifcs_ctypes.IFCS_SUCCESS

        rc = ifcs_ctypes.ifcs_attr_t_id_set(
            compat_pointerAtIndex(
                attr_list,
                ifcs_ctypes.ifcs_attr_t,
                attr_count),
            ifcs_ctypes.IFCS_DEVPORT_ATTR_CUT_THROUGH_ENABLE)
        assert rc == ifcs_ctypes.IFCS_SUCCESS

        rc = ifcs_ctypes.ifcs_attr_t_value_data_set(
            compat_pointerAtIndex(
                attr_list,
                ifcs_ctypes.ifcs_attr_t,
                attr_count),
            self._fp_ct_enable)
        assert rc == ifcs_ctypes.IFCS_SUCCESS

        attr_count += 1

        for devport in sorted(self._fp_devports):
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                       ifcs_ctypes.ifcs_devport_attr_set(self._node_id,
                                   devport,
                                   attr_count,
                                   compat_pointer(attr_list, ifcs_ctypes.ifcs_attr_t)))
            if rc != ifcs_ctypes.IFCS_SUCCESS and rc != ifcs_ctypes.IFCS_UNSUPPORTED:
                msg = 'Attr set failed for ETH devport {} rc: {}'.format(
                    devport, self._status_to_string(rc))
                log_err(msg)
                raise KeyError(msg)

    def _display_status(self):
        log('Updated CUT_THROUGH_ENABLE on all devports')


def main(args):
    x = PortCt(args)
