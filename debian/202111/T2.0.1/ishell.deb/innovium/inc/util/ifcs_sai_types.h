/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_types.h
 * @brief ISAI Util Include file for ACL module
 */


#ifndef __IFCS_SAI_TYPES_H__
#define __IFCS_SAI_TYPES_H__

#include "ifcs_node.h"
#include "ifcs_devport.h"
#include "ifcs_bam.h"
#include "ifcs_dtm.h"
#include "ifcs_node.h"
#include "ifcs_isai_ds.h"
#include "ifcs_isai_ds_switch.h"
#include "ifcs_isai_ds_tunnel.h"
#include "ifcs_sai_shim_util_id_alloc.h"
#include "ifcs_acl.h"
#include "ifcs_sai_shim_qosmap_wb.h"

#define ISAI_RIF_STAT_SCALE_IN (4096)
#define ISAI_RIF_STAT_SCALE_EG (4096)

#define ISAI_NEXT_HOP_GROUP_TYPE         (0)
#define ISAI_NEXT_HOP_GROUP_NO_OF_SLOTS  (8)

/* No iSAI includes are allowed */

/****************************
 * Vlan
 ***************************/
#define IFCS_SAI_DEFAULT_VLAN_ID    1

#define ISAI_VLAN_MAX_LEARN_ADDRS    (0xffffffff)

#define NUM_VLANS           (4096)

/* IFCS SAI Shim OID Structure */
typedef struct ifcs_sai_shim_oid_s {
    ifcs_handle_t isai_ds_hdl;  ///< IFCS handle of the object
    uint16_t      unused;       ///< Always set to 0
    uint8_t       node_id;      ///< Node ID of the object
    uint8_t       type;         ///< Type of the object
} ifcs_sai_shim_oid_t;

typedef struct _sai_shim_vlan_mem_info_s {
    ifcs_handle_t   l2vni_hdl;
    ifcs_handle_t   port_hdl;
    ifcs_handle_t   mc_dest;
    sai_object_id_t vlan_oid;
} sai_shim_vlan_mem_info_t;
#define ISAI_MAX_SUPPORTED_IPG_QUEUE_COUNT    8
#define MAX_NUM_SPEEDS                  10
#define MAX_NUM_FEC_MODES               4
#define ISAI_SERES_SPEED_25G            25
#define ISAI_SERES_SPEED_50G            50
#define ISAI_SERES_SPEED_100G           100

#define ISAI_QOS_BIND_MAX    (128 * 8)     /* Max binds of a qos object;
                                            * for eg. a scheduler can be at most attached to
                                            * num_devports X num_queues_per_devport */
#define ISAI_QOS_ATTR_MAX    256           /* Max attrs */

#define ISAI_BASE_BUFFER_POOL_INDEX       0x0FC7

#define IFCS_SAI_MAX_ETH_IB_PORTS    66        ///< Maximum eth ib ports per IB(such that indexing with ib_port works in this struct
#define IFCS_SAI_MAX_IBS    6                  ///< Maximum IBs per Node

#define NUM_CPU_QUEUES                                   48
#define NUM_RECIRC_QUEUES                                8
#define NUM_AUX_QUEUES                                   8

#define INVALID_PS_ID              -1 // IFCS supports ps id 0-3 so far

#define ISAI_SHIM_MAX_NUM_LOSSLESS_TC (2)

#define ISAI_MAX_KV_PAIR_VALUE_STR_LEN   512

/* Datapath related typedefs and defines - thread-safe*/
#define CPU_QUEUE_RESERVED_Q0_47_BYTES      1518.0
#define RECIRC_QUEUE_RESERVED_Q0_8_BYTES    1518.0

#define AUX_QUEUE_RESERVED_Q0_Q7_BYTES    1518.0

#define NUM_RECIRC_AUX_QUEUES                   8

#define INGRESS_PG_RESERVED_PG1_BYTES    1518.0
#define INGRESS_PG_RESERVED_PG2_BYTES    1518.0

#define BAM_QUEUE_BIT_POSITION_ON_IPG_HANDLE 0
#define IPPS_CM_BIT_POSITION_ON_IPG_HANDLE   1
#define QUEUE_BIT_POSITION_ON_QUEUE_HANDLE   0

#define ISAI_SHIM_LOSSLESS_TC1 (3)
#define ISAI_SHIM_LOSSLESS_TC2 (4)

/* Priority of Rules:
 * PFC WD Rules >  Flood Control Rules Routed >   Flood Control Rules Switched > HDC Workaround Rules
 * In IFCS, lower the priority number indicates higher priority
 */
#define ISAI_DATAPATH_PFD_WD_ACE_PRIORITY  1
#define ISAI_DATAPATH_PFD_FLOOD_CONTROL_ROUTED_ACE_PRIORITY 2
#define ISAI_DATAPATH_PFD_FLOOD_CONTROL_SWITCHED_ACE_PRIORITY 3
#define ISAI_DATAPATH_HDC_ACE_PRIORITY 4
#define ISAI_RIF_LOOPBACK_ACE_PRIORITY 5

#define IFCS_SAI_MAX_IBS    6         ///< Maximum IBs per Node
#define ITERATE_IB_START(node_id, ib, ifcs_rc, sai_rc, cleanup) \
{\
    uint32_t actual_attr_count = 0;\
    for(ib = 0; ib < g_switch_num_ibs; ib++) {\
        ifcs_attr_t local_ifcs_attr;\
        ifcs_attr_t_init(&local_ifcs_attr);\
        ifcs_attr_t_id_set(&local_ifcs_attr, IFCS_DTM_BUFFER_ATTR_TOTAL_SIZE);\
        ifcs_rc = ifcs_dtm_buffer_attr_get(node_id, ib, 1, &local_ifcs_attr, &actual_attr_count);\
        if(IFCS_STATUS_REASON(ifcs_rc) == IFCS_NOTFOUND) {\
            continue;\
        }\
        if(ifcs_rc != IFCS_SUCCESS || (actual_attr_count == 0)) {\
            sai_rc = ifcs_to_sai_translate_status(ifcs_rc);\
            goto cleanup;\
        }

#define ITERATE_IB_END     } \
}

#define ITERATE_SINGLE_IB_START(node_id, ib, ifcs_rc, sai_rc, cleanup) \
{\
    uint32_t actual_attr_count = 0;\
    ifcs_attr_t local_ifcs_attr;\
    ifcs_attr_t_init(&local_ifcs_attr);\
    ifcs_attr_t_id_set(&local_ifcs_attr, IFCS_DTM_BUFFER_ATTR_TOTAL_SIZE);\
    ifcs_rc = ifcs_dtm_buffer_attr_get(node_id, ib, 1, &local_ifcs_attr, &actual_attr_count);\
    if(IFCS_STATUS_REASON(ifcs_rc) == IFCS_NOTFOUND) {\
        sai_rc = ifcs_to_sai_translate_status(ifcs_rc);\
        goto cleanup;\
    }\
    if(ifcs_rc != IFCS_SUCCESS || (actual_attr_count == 0)) {\
        sai_rc = ifcs_to_sai_translate_status(ifcs_rc);\
        goto cleanup;\
    }

#define ITERATE_SINGLE_IB_END     } \

/* BAM assumptions */
#define ISAI_RECIRC_AUX_LOSSLESS_RESERVED_SIZE_BYTES   1518.0
#define BAM_QUEUE_RESERVED_SIZE_IN_BAM_WORD         48
#define BAM_QUEUE_DEFAULT_SHARED_STATIC_THRESHOLD_VALUE  400
#define AVG_RES_PER_LOSSY_BAM_QUEUE_BYTES           1518.0
#define AVG_RES_PER_LOSSLESS_BAM_QUEUE_BYTES        1518.0
#define MAX_NUM_LOSSLESS_BAM_QUEUES                 2

#define BAM_BUFFER_PART_DEFAULT_LL_LINK_LEN_PROF     IFCS_LL_INFLIGHT_LINK_LENGTH_PROFILE_V_LONG
#define BAM_BUFFER_PART_DEFAULT_LL_TUNING_FACTOR     100
#define BAM_BUFFER_PART_DEFAULT_LL_OVERSUB_FACTOR_TH 200
#define BAM_BUFFER_PART_DEFAULT_LL_SHARED_PART_PERCENT  40


/******* TL CONSTANTS *******/
#define NUM_CG_QUEUES_TL              6


/* Following are in DTM cell units */
#define ISAI_DTM_INFLIGHT_SIZE_TL_TC1    3200
#define ISAI_DTM_INFLIGHT_SIZE_TL_TC2    6400


/******* K2 CONSTANTS *******/
#define NUM_CG_QUEUES_K2              2


/* Following are in DTM cell units */
#define ISAI_DTM_INFLIGHT_SIZE_K2_TC1    1200
#define ISAI_DTM_INFLIGHT_SIZE_K2_TC2    2400

typedef struct _sai_shim_lag_mem_info_s {
    ifcs_handle_t   lag_hdl;
    ifcs_handle_t   port_hdl;
} sai_shim_lag_mem_info_t;
/*
 * The following are declared as globals as they do not change after
 * boot time and so they need not be retreived from IFCS every time
 * isai code needs it.
 * These globals are initialized in ifcs_sai_datapath_globals_init
 */
extern int8_t  g_pgindex_to_ps_id_mapping[ISAI_MAX_SUPPORTED_IPG_QUEUE_COUNT];

typedef enum switch_queue_type_s {
    SWITCH_QUEUE_TYPE_CPU = 0,
    SWITCH_QUEUE_TYPE_AUX = 1,
    SWITCH_QUEUE_TYPE_RECIRC = 2,
    SWITCH_QUEUE_TYPE_FP = 3,
    SWITCH_QUEUE_TYPE_CG = 4
} switch_queue_type_t;

typedef struct sai_switch_queue_info_s {
    uint32_t reserved_size;                   // Reserved Size of the queues in bytes
    uint32_t uc_dtl;                          // Dynamic threshold limit factor for UC traffic
    uint32_t nonuc_dtl;                       // Dynamic threshold limit factor for non UC traffic
    uint32_t uc_shared_buffer_max_limit;      // max limit for the queue on access to
                                              // actual shared buffer access for UC traffic=
                                              //       Max(uc_shared_buffer_max_limit,
                                              //               shared space determined by uc_dtl)
    uint32_t nonuc_shared_buffer_max_limit;   // max limit for the queue on access to
                                              // actual shared buffer access for non UC traffic =
                                              //       Max(nonuc_shared_buffer_max_limit,
                                              //               shared space determined by uc_dtl)
    uint32_t resume_offset;
    uint32_t user_entered_values_flag;
} isai_switch_queue_info_t;

typedef struct _sai_switch_notification_s {
    sai_switch_state_change_notification_fn on_switch_state_change;
    sai_fdb_event_notification_fn           on_fdb_event;
    sai_port_state_change_notification_fn   on_port_state_change;
    sai_switch_shutdown_request_notification_fn          on_switch_shutdown_request;
    sai_packet_event_notification_fn        on_packet_event;
} sai_switch_notification_t;

/*
 * Reserved size values passed in the by user via ivm.sai.datapath.config.yaml
 * These values are used in datapath setup while creating DTM and BAM buffer
 * partitions. We are getting these values from a config file so that the user,
 * if needed can tune these values and this also makes ISAI datapath code
 * chip independent.
 */
typedef struct isai_switch_ib_reserved_sizes_s {
    /* All lossy */
    uint32_t dtm_all_lossy_default_size; // PARAM_P0_1_LS
    uint32_t dtm_all_lossy_non_fp_size;  // PARAM_P0_1_ALS
    uint32_t bam_all_lossy_size;         // PARAM_P0_0_LS

    /* Lossy, lossless combination */
    uint32_t dtm_lossy_default_size; // PARAM_P1_1_LS
    uint32_t dtm_lossy_non_fp_size;  // PARAM_P1_1_ALS
    uint32_t dtm_ll_default_size;    // PARAM_P1_1_LL
    uint32_t dtm_ll_non_fp_size;     // PARAM_P1_1_ALL
    uint32_t bam_lossy_size;         // PARAM_P1_0_LS
    uint32_t bam_ll_size;            // PARAM_P1_0_LL
} isai_switch_ib_reserved_sizes_t;

typedef struct isai_bam_queue_config_s {
    uint32_t threshold_mode;
    uint32_t threshold_value;
} isai_bam_queue_config_t;

typedef struct isai_switch_bam_queue_config_s {
    isai_bam_queue_config_t ll_bam_queue;
    isai_bam_queue_config_t lossy_bam_queue;
} isai_switch_bam_queue_config_t;

typedef struct isai_switch_bam_buffer_part_config_s {
    uint32_t ll_inflight_link_length_prof;
    uint32_t ll_inflight_tuning_factor;
    uint32_t ll_oversub_factor_th;
    uint32_t ll_shared_part_percent;
} isai_switch_bam_buffer_part_config_t;

typedef struct _switch_db_info_s {
    bool                      is_created;
    sai_switch_profile_id_t   profile_id;
    sai_switch_notification_t notification_callbacks;
    uint32_t                  route_table_size;
    uint32_t                  neighbor_table_size;
    sai_mac_t                 device_mac;
    bool                      restart_warm;
    bool                      uninit_data_plane_on_removal;
    pthread_t                 *p_shell_pthread;
    bool                      bdc_enable;
    uint32_t                  sai_queue_type;
    bool                      hdc_enable;
    bool                      ipv6_ingress_mirror_enable;
    bool                      ipv6_egress_mirror_enable;
    uint32_t                  pfc_eacl_table_depth_enc_val;
    uint32_t                  mirror_sample_rate;
    int32_t                   nrz_ports_sig_detect_mode_tl7;
    uint32_t                  rif_stat_scale_in;
    uint32_t                  rif_stat_scale_eg;
    uint32_t                  rif_mac_mode;
    uint32_t                  disable_mirror_policer;
    uint32_t                  disable_sflow_policer;
    uint32_t                  pfcwd_eg_acl_counter_entries;
    isai_switch_queue_info_t cpu_queue[NUM_CPU_QUEUES];
    isai_switch_queue_info_t aux_queue[NUM_AUX_QUEUES];
    isai_switch_queue_info_t recirc_queue[NUM_RECIRC_QUEUES];
    char                            dp_config_file[
        ISAI_MAX_KV_PAIR_VALUE_STR_LEN];
    isai_switch_ib_reserved_sizes_t reserved_sizes[IFCS_SAI_MAX_IBS];
    char                      uds_path_name[ISAI_MAX_KV_PAIR_VALUE_STR_LEN];
    bool bam_queue_stat_present[IFCS_BAM_QUEUE_STATS_ID_ALL];
    bool check_bam_queue_stats;
    bool ipps_cm_stat_present[IFCS_IPPS_CM_STATS_ID_ALL];
    bool check_ipps_cm_stats;
    uint32_t max_ports_per_ib;
    uint32_t next_hop_group_type;
    uint32_t next_hop_group_no_of_slots;
    uint32_t reserved_ing_acl_priorities_bmp;
    uint32_t reserved_egr_acl_priorities_bmp;
    uint32_t cpu_sp_fwd_mode;
    bool     cpu_netdev_rif_create_enable;
    uint32_t mcast_snoop_capability;
    bool     pre_ingress_acl_allow_dst_ipv6;
    bool     pre_ingress_acl_disable_stats;
    bool     defvr_fallback_enable;
    bool     hierarchical_ecmp_disable;
    isai_switch_bam_queue_config_t bam_queue_config;
    isai_switch_bam_buffer_part_config_t ll_bam_buffer_part_config[IFCS_SAI_MAX_IBS];
    uint32_t   ptf_drop_counter_l2l3_flag;
} switch_db_info_t;


typedef struct  isai_shim_qos_info_s {
    sai_object_id_t oid;            /* SAI_OBJECT  id */
    ifcs_node_id_t  node_id;        /// valid for objects with corresponding IFCS
    ifcs_handle_t   handle;         /// valid for objects with corresponding IFCS
    ifcs_handle_t   counter_handle; /// valid for objects with counter, today it is Policer

    /* User configured SAI attr count and list for this SAI object*/
    uint32_t        attr_count;
    sai_attribute_t attr_list[ISAI_QOS_ATTR_MAX];

    /* Bindpoint list has the list of queues to
     * which this scheduler/buffer* is attached to.
     * when any scheduler attr is updated,
     * walk through the bind-point-list and update each queue */
    uint32_t        bind_point_list_count;
    sai_object_id_t bind_point_list[ISAI_QOS_BIND_MAX];
} isai_shim_qos_info_t;

#define PORT_TO_SAI_OID(port_oid) ( * ( (sai_object_id_t *) (void *) (&(port_oid)) ) )
#define SAI_TO_PORT_OID(sai_oid)  ( * ( (ifcs_sai_shim_oid_t *) &(sai_oid) ) )
#define SAI_TO_PORT_OID_P(sai_oid)  ((ifcs_sai_shim_oid_t *) &(sai_oid))
/*
 * N.B: For port module devport ID is stored in isai_ds_hdl
 */
#define PORT_OID_P_TO_DEVPORT(port_oid_p) \
        ( (ifcs_devport_t) (((ifcs_sai_shim_oid_t *) (port_oid_p))->isai_ds_hdl) )

 /**/

#define IFCS_SAI_DEFAULT_MTU            1514

#define MAX_NUM_SPEEDS                  10
#define MAX_NUM_FEC_MODES               4

#define ISAI_NUM_PG                     8

#define ISAI_IS_K2_DEVICE_TYPE(_device_type)  ( \
        ( _device_type == IFCS_DEVICE_TYPE_TERALYNX5_1) || \
        ( _device_type == IFCS_DEVICE_TYPE_TERALYNX5_2) || \
        ( _device_type == IFCS_DEVICE_TYPE_TERALYNX5_3) || \
        ( _device_type == IFCS_DEVICE_TYPE_TERALYNX5_4)    \
        )

#define ISAI_IS_TL7_DEVICE_TYPE(_device_type)  ( \
        ( _device_type == IFCS_DEVICE_TYPE_TERALYNX7_1) || \
        ( _device_type == IFCS_DEVICE_TYPE_TERALYNX7_2) || \
        ( _device_type == IFCS_DEVICE_TYPE_TERALYNX7_3) || \
        ( _device_type == IFCS_DEVICE_TYPE_TERALYNX7_4)    \
        )

typedef struct _sai_shim_port_info_s
{

    /* top level */
    ifcs_bool_t                 exists;
    ifcs_sai_shim_oid_t         sai_port_oid;
    ifcs_node_id_t              node_id;
    ifcs_handle_t               sysport_hdl;

    /* Devport related, IFCS params */
    ifcs_devport_type_t         type;
    ifcs_devport_t              devport;
    ifcs_devport_serdes_group_t isg_num;
    uint32_t                    start_lane, num_lanes;
    ifcs_devport_fec_mode_t     fec_mode;

    /* Hostif related */
    bool                        has_hostif_name;
    char                        hostif_name[32];

    /* Auto-Neg */
    uint32_t                    num_advertized_speeds;
    uint32_t                    advertized_speeds[MAX_NUM_SPEEDS];
    uint32_t                    num_advertized_fec_modes;
    sai_port_fec_mode_t         advertized_fec_modes[MAX_NUM_FEC_MODES];

    /* PFC related */
    ifcs_devport_pfc_mode_t     pfc_mode;
    ifcs_bool_t                 is_ipg_created_by_default;
    ifcs_bool_t                 is_ipg_created_by_user;
    sai_object_id_t             pg_oids[ISAI_MAX_SUPPORTED_IPG_QUEUE_COUNT];

    /* Scheduler related */
    sai_object_id_t             scheduler_oid;

    ifcs_bool_t                 is_datapath_inited;
    /* Sflow related */
    sai_object_id_t             ing_samplepacket_oid;
    sai_object_id_t             egr_samplepacket_oid;

    sai_object_id_t             ingress_mirror_oid;
    sai_object_id_t             ingress_acl;

    /* Port Storm Control */
    sai_object_id_t             flood_storm_policer_oid;
    sai_object_id_t             broadcast_storm_policer_oid;
    ifcs_handle_t               storm_acl_hdl;
    ifcs_handle_t               storm_fld_ace_hdl;
    ifcs_handle_t               storm_bc_ace_hdl;
} sai_port_info_t;


/* Structure to hold sample packet object ID information */
typedef struct ifcs_sai_samplepacket_oid_s {
    ifcs_handle_t handle;    ///< Holds IFCS DS handle
    uint16_t      reserved;  ///< Reserved for future use
    uint8_t       node_id;   ///< Holds NODE-ID of the object
    uint8_t       type;      ///< Holds type of the object
} ifcs_sai_samplepacket_oid_t;


typedef struct ifcs_sai_switch_oid_s {
    ifcs_handle_t switch_hdl; ///< Holds switch handle
    uint16_t      reserved;   ///< Reserved for future use
    uint8_t       node_id;    ///< Holds NODE-ID of the object
    uint8_t       type;       ///< Holds type of the object
} ifcs_sai_switch_oid_t;

/*SAI Queue object OID structure */
typedef struct ifcs_sai_queue_oid_s {
    uint32_t devport;
    uint8_t  node;
    uint8_t  queue_id;
    uint8_t  reserved3;
    uint8_t  type;
} ifcs_sai_queue_oid_t;

/* Generic SAI QOS related object OID structure */
typedef struct ifcs_sai_qos_oid_s {
    uint32_t id;
    uint8_t  node;
    uint8_t  reserved2;
    uint8_t  reserved3;
    uint8_t  type;
} ifcs_sai_qos_oid_t;

#define ISAI_QOS_BUFFER_POOL_TO_PARTITION_ID(obj_id)     (((ifcs_sai_qos_oid_t *)&obj_id)->id - ISAI_BASE_BUFFER_POOL_INDEX)

/*SAI Ingress priority group object OID structure */
typedef struct ifcs_sai_ingress_priority_group_oid_s {
    uint32_t devport;
    uint8_t  node;
    uint8_t  reserved;
    uint8_t  ipg_index;
    uint8_t  type;
} ifcs_sai_ingress_priority_group_oid_t;

#define ISAI_QOS_TYPE(obj_id)    (((ifcs_sai_qos_oid_t *)&obj_id)->type)

#define ISAI_QOS_PG_ID(obj_id)                            \
    (((ifcs_sai_ingress_priority_group_oid_t *)&obj_id)-> \
        ipg_index)

#define ISAI_QOS_PS_ID(obj_id)                            \
    (uint8_t)g_pgindex_to_ps_id_mapping[ISAI_QOS_PG_ID(obj_id)]

#define ISAI_QOS_PG_DEVPORT(obj_id)                       \
    (((ifcs_sai_ingress_priority_group_oid_t *)&obj_id)-> \
        devport)

#define ISAI_QOS_Q_ID(obj_id)            \
    (((ifcs_sai_queue_oid_t *)&obj_id)-> \
        queue_id)

#define ISAI_QOS_NODE_ID(obj_id)    (((ifcs_sai_qos_oid_t *)&obj_id)->node)
#define ISAI_QOS_OBJ_ID(obj_id)     (((ifcs_sai_qos_oid_t *)&obj_id)->id)

#define ISAI_QOS_Q_DEVPORT(obj_id)       \
    (((ifcs_sai_queue_oid_t *)&obj_id)-> \
        devport)

/* Structure to hold HASH object ID information */
typedef struct ifcs_sai_hash_oid_s {
    ifcs_handle_t handle;    ///< Holds IFCS handle
    uint16_t      reserved;  ///< Reserved for future use
    uint8_t       node_id;   ///< Holds NODE-ID of the object
    uint8_t       type;      ///< Holds type of the object
} ifcs_sai_hash_oid_t;

typedef enum _isai_shim_dp_qmap_type_e {
    ISAI_SHIM_DP_QMAP_TYPE_TC_TO_QUEUE,
    ISAI_SHIM_DP_QMAP_TYPE_TC_TO_PRIORITY_GROUP,
    ISAI_SHIM_DP_QMAP_TYPE_PFC_PRIORITY_TO_PRIORITY_GROUP,
    ISAI_SHIM_DP_QMAP_TYPE_PFC_PRIORITY_TO_QUEUE,
    ISAI_SHIM_DP_QMAP_TYPE_MAX
} isai_shim_dp_qmap_type_t;

typedef struct _isai_shim_datapath_qmap_cfg_s {
    sai_object_id_t map_oid;    // SAI qos map object id for this type
} isai_shim_datapath_qmap_cfg_t;

typedef struct _isai_shim_qm_port_db_entry_s {
    //sysport handle is the key to this hash db.
    isai_shim_datapath_qmap_cfg_t dp_qmap_arr[ISAI_SHIM_DP_QMAP_TYPE_MAX];
    sai_object_id_t               qmap_cache_arr[ISAI_SHIM_QOSMAP_TYPE_MAX];
} isai_shim_qm_port_db_entry_t;

typedef enum isai_shim_qmh_type_e {
    ISAI_SHIM_QMHDL_TYPE_START = 0,
    ISAI_SHIM_QMHDL_TYPE_DSCP  = ISAI_SHIM_QMHDL_TYPE_START,
    ISAI_SHIM_QMHDL_TYPE_DOT1P,
//    ISAI_SHIM_QMHDL_TYPE_EXP,
    ISAI_SHIM_QMHDL_TYPE_MAX   = ISAI_SHIM_QMHDL_TYPE_DOT1P + 1,
} isai_shim_qmh_type_t;

typedef struct _sai_shim_qmhdl_db_entry_s {
    isai_shim_qmh_type_t type;
    uint32_t             ref_count;
    sai_object_id_t      ingress_tc_oid;
    sai_object_id_t      ingress_dp_oid;
    sai_object_id_t      egress_tc_dp_oid;
} isai_shim_qmhdl_db_entry_t;

#define ISAI_SHIM_PORT_QOSATTR_MAX    (10)

#define ISAI_MAX_STP_PORT 0xffff //IFCS_STP_PORT_MAX

typedef struct _sai_shim_stp_port_info_s {
    ifcs_handle_t   stp_hdl;
    ifcs_handle_t   sysport_hdl;
} sai_shim_stp_port_info_t;

/* STP Vlan list call_back */
typedef struct ifcs_sai_stp_vlan_list_s {
    sai_vlan_list_t    *vlan_list_p;
    uint32_t            total_count;
    sai_status_t        cb_rc;
} ifcs_sai_stp_vlan_list_t;

/* STP Port list call_back */
typedef struct ifcs_sai_stp_port_list_s {
    sai_object_list_t   *port_list_p;
    uint32_t            total_count;
    sai_status_t        cb_rc;
} ifcs_sai_stp_port_list_t;


#define IFCS_SAI_MAX_BRIDGE        4096
#define IFCS_SAI_MAX_BRIDGE_PORTS  (16 * 1024)

/*  Object id structures */
typedef struct _sai_shim_bridge_port_db_entry_s {
   sai_object_id_t bridge_port_id;   /* Bridge port OID           */
   sai_bridge_port_type_t type;      /* Type of bridge port       */
   sai_object_id_t port_oid;         /* Port/LAG object ID        */
   sai_object_id_t bridge_oid;       /* Bridge Instance Object ID */
   bool            admin_mode;       /* Adminstrative mode        */
   ii_hash_el_t    hash_el;
} sai_shim_bridge_port_db_entry_t;

typedef struct _sai_shim_isg_mem_info_s {
    ifcs_handle_t   sysport_hdl;
} sai_shim_isg_mem_info_t;

#define FLUSH_NOTIFICATION_SIZE    10
/**
 *  * @brief FDB event type - used in SHIM Layer
 *  */
typedef enum _sai_shim_fdb_event_t
{
    /** New FDB entry learned */
    SAI_SHIM_FDB_EVENT_LEARNED,

    /** FDB entry aged */
    SAI_SHIM_FDB_EVENT_AGED,

    /** FDB entry move */
    SAI_SHIM_FDB_EVENT_MOVE,

    /** FDB entry flushed */
    SAI_SHIM_FDB_EVENT_FLUSHED,

    /** FDB entry added statically by SAI API */
    SAI_SHIM_FDB_EVENT_ADD,

    /** FDB entry deleted by SAI API */
    SAI_SHIM_FDB_EVENT_REMOVE,

    /** FDB entry set */
    SAI_SHIM_FDB_EVENT_SET,

} sai_shim_fdb_event_t;
/**
 * @brief FDB Notification data format for SHIM layer modules
 */
typedef struct _sai_shim_fdb_event_notification_data_t
{
    /** Event type */
    sai_shim_fdb_event_t event_type;

    /** FDB entry */
    sai_fdb_entry_t fdb_entry;

} sai_shim_fdb_event_notification_data_t;
typedef struct _fdb_flush_notification_cb_data {
    uint32_t    count;
    uint32_t    remaining_count;
    sai_fdb_event_notification_fn notify_p;
    sai_fdb_event_notification_data_t *n_data;
    sai_shim_fdb_event_notification_data_t *shim_data; /*For shim layer*/
} fdb_flush_notification_cb_data_t;

/* Structure for link scan event queue message */
typedef struct fdb_msg_s {
    uint32_t                          count;
    sai_shim_fdb_event_notification_data_t data_p[FLUSH_NOTIFICATION_SIZE];
} fdb_msg_t;

typedef struct _sai_shim_debug_counter_info_s
{
    ifcs_sai_shim_oid_t debug_counter_oid;
    ifcs_uint8_t node_id;
    ifcs_uint32_t bind_method;
    ifcs_uint32_t  family_type;  // Type of family to which the
                                 // debug counter belongs to. Eg:
                                 // SAI_DEBUG_COUNTER_TYPE_PORT_IN_DROP_REASONS
    ifcs_uint32_t family_stat_index;  // The stat index assigned
                                      // when the debug object
                                      // is attached to the family object type
    ifcs_u32_list_t family_stats_list; // The list of family stats
                                       // the debug counter s associated with
} sai_shim_debug_counter_info_t;

/* Type definition for link scan event callback */
typedef void
(*isai_fdb_event_cb_t) (uint32_t                          count,
                        sai_shim_fdb_event_notification_data_t *data_p);


#define ISAI_MAX_LAG_MEMBERS 256   //IFCS_LAG_MEMBER_MAX

/* Maximum callbacks that can be registered to get LAG events */
#define ISAI_LAG_MAX_REG_CB (16)

/* Maximum callbacks that can be registered to get LAG member events */
#define ISAI_LAG_MEM_MAX_REG_CB (16)

/* Enumerations for LAG events */
typedef enum isai_lag_event_s {
    ISAI_LAG_EVENT_CREATE = 0, ///< LAG group is created
    ISAI_LAG_EVENT_DELETE = 1, ///< LAG groupd is deleted
    ISAI_LAG_EVENT_MAX = 2     ///< Maximum lag events - invalid event
} isai_lag_event_t;

/* Enumerations for LAG member events */
typedef enum isai_lag_mem_event_s {
    ISAI_LAG_MEM_EVENT_CREATE = 0, ///< LAG member group is created
    ISAI_LAG_MEM_EVENT_DELETE = 1, ///< LAG member groupd is deleted
    ISAI_LAG_MEM_EVENT_MAX = 2     ///< Maximum lag member events - invalid event
} isai_lag_mem_event_t;


#define IFCS_COLLECTOR_MAX               96
#define IFCS_COLLECTOR_SET_MAX           24
#define IFCS_DCDP_MAX                    8
#define IFCS_COLLECTOR_SET_MEMBER_MAX    4

typedef struct _sai_shim_mirror_session_db_entry_s {
    //DSKey
    uint32_t        msid;                                            /* mirror session id */
    ifcs_u8_list_t  ifcs_attr_list;
    uint32_t        count;
    uint32_t        ing_ref_count;
    uint32_t        eg_ref_count;
    ifcs_handle_t   ifcs_dcdp_handle;
    ifcs_handle_t   ing_collector_handle;
    ifcs_handle_t   eg_collector_handle;
    ifcs_handle_t   ing_collector_set_handle;
    ifcs_handle_t   egr_collector_set_handle;
    ifcs_handle_t   ace_meter_ingress;
    ifcs_handle_t   ace_meter_egress;
    sai_object_id_t port_oid;
    sai_object_id_t policer_oid;
    uint32_t        sample_rate;
    uint8_t         type;
} sai_shim_mirror_session_db_entry_t;

/* db for port dcdp mapping */
typedef struct _sai_shim_sysport_dcdp_db_entry_s {
    sai_object_id_t port_oid;
    ifcs_handle_t   dcdp_hdl;
    uint32_t        ref_count;
} sysport_dcdp_db_entry_t;

typedef struct _sai_shim_sysport_cs_db_entry_s {
    sai_object_id_t port_oid;
    ifcs_handle_t   ing_collector_set_handle;
    uint32_t        ing_count;
    sai_object_id_t ing_obj_list[4];
    ifcs_handle_t   eg_collector_set_handle;
    uint32_t        eg_count;
    sai_object_id_t eg_obj_list[4];
} sysport_cs_db_entry_t;

/* db for acl collector set */

typedef struct _sai_shim_collector_set_db_entry_s {
    sai_object_id_t collector_set_handle;
    uint32_t        count;
    sai_object_id_t obj_list[4];
    uint8_t         direction;
    uint8_t         type;
    uint32_t        ref_count;
} collector_set_db_entry_t;


/* Policer */
/*
 * Number of action handles typically created on an ACE to implement policing in
 * the datapath.
 * The action types are typically METER, COUNTER and DROP
 */
#define ISAI_POLICER_ACTION_HANDLE_COUNT  (3)
typedef enum isai_policer_color_e {
    POLICER_COLOR_GREEN,
    POLICER_COLOR_YELLOW,
    POLICER_COLOR_RED
} ifcs_sai_policer_color_t;

typedef struct isai_policer_meter_internal_s {
    ifcs_handle_t acl_table_handle;
    uint32_t      meter_attr_count;
    ifcs_attr_t   *meter_attr_list_p;
    uint32_t      counter_attr_count;
    ifcs_attr_t   *counter_attr_list_p;
} isai_policer_meter_internal_t;

/* END POLICER */


/*****************************************************************
 * L3 module related declarations
 ****************************************************************/
#define TUN_NHRES_SIZE  (sizeof(isai_tun_nhop_res_t))

/* Structure to break router OID */
typedef struct ifcs_sai_router_oid_s {
    ifcs_handle_t l3vni_hdl; ///< Holds handle to L3VNI object
    uint16_t      reserved;  ///< Reserved for future use
    uint8_t       node_id;   ///< Holds NODE-ID of the handle
    uint8_t       type;      ///< Holds type of the handle
} ifcs_sai_router_oid_t;

/* Nexthop info */
typedef struct isai_shim_nexthop_info_s {
    sai_ip_address_t nh_ip;         /* Nexthop ip address */
    ifcs_handle_t    intf_hdl;      /* Nexthop interface handle */
    ifcs_handle_t    local_dst_hdl; /* Local dest handle */
    sai_mac_t        nh_mac;        /* Nexthop mac address */
} isai_shim_nexthop_info_t;


/* Structure to break next-hop group OID */
typedef struct ifcs_sai_next_hop_group_oid_s {
    ifcs_handle_t ifcs_hdl;     ///< ECMP group IFCS handle
    uint16_t      reserved;     ///< Reserved for future use
    uint8_t       node_id;      ///< Node ID of the object
    uint8_t       type;         ///< Type of the object
} ifcs_sai_next_hop_group_oid_t;

/* Structure to break next-hop group member OID */
typedef struct ifcs_sai_next_hop_group_member_oid_s {
    ifcs_handle_t ecmp_hdl;     ///< ECMP group IFCS handle
    ifcs_handle_t mem_hdl;      ///< Member IFCS handle
} ifcs_sai_next_hop_group_member_oid_t;

/* L3 multicast related declarations */
/* Structure to break RPF group OID */
typedef struct ifcs_sai_rpfg_oid_s {
    ifcs_handle_t ds_hdl;     ///< IFCS Interface List Handle
    uint16_t      reserved;     ///< Reserved for future use
    uint8_t       node_id;      ///< Node ID of the object
    uint8_t       type;         ///< Type of the object
} ifcs_sai_rpfg_oid_t;

/* Structure to break RPF group member OID */
typedef struct ifcs_sai_rpfg_member_oid_s {
    ifcs_handle_t ds_hdl;       ///< DS handle for RPFG member
    uint16_t      reserved;     ///< Reserved for future use
    uint8_t       node_id;      ///< Node ID of the object
    uint8_t       type;         ///< Type of the object
} ifcs_sai_rpfg_mem_oid_t;

/**
 *  @brief isai_ds_rpf_group info
 *
 */
typedef struct isai_ds_rpf_group_ds_entry_s {
    sai_object_id_t  oid;           ///< OID of RPF group
    ifcs_handle_t    intf_count;   ///< Interface count
    ifcs_handle_t    ref_count;   ///< Ref count
} isai_shim_rpf_group_ds_entry_t;

/**
 *  @brief isai_ds_rpf_group_member info
 *
 */
typedef struct isai_ds_rpf_group_member_ds_entry_s {
    sai_object_id_t oid;            ///< OID of rpf Member
    sai_object_id_t group_oid;      ///< OID of rpf Group
    sai_object_id_t rpf_intf_oid;   ///< RPF interface OID
} isai_shim_rpf_group_member_ds_entry_t;


/*
 * Entry structure for VLAN to Mutlicast nexthop data store
 * This should be the mirror  definition of ipmc_rif_mcast_nexthop  in isai_ds.yaml
 */
typedef struct _isai_shim_ipmc_vlan_mcast_nexthop_s {
    uint64_t vlan_oid;    /* VLAN OID */
    uint32_t nh_handle;   /* Nh handle */
    uint32_t ref_count;   /* ref count */
} isai_shim_vlan_mcast_nexthop_db_entry;

/**
 *  @brief isai_ds_ipmc_group info
 *
 */
typedef struct isai_ds_ipmc_group_ds_entry_s {
    sai_object_id_t  oid;          ///< OID of IPMC group
    ifcs_uint32_t    mem_count;    ///< Member count
    ifcs_uint32_t    ref_count;    ///< Ref count
    ifcs_handle_t    mdg_hdl;      ///< MDG handle
} isai_shim_ipmc_group_ds_entry_t;

/**
 *  @brief isai_ds_ipmc_group_member info
 *
 */
typedef struct isai_ds_ipmc_group_member_ds_entry_s {
    sai_object_id_t oid;            ///< OID of ipmc Member
    sai_object_id_t group_oid;      ///< OID of ipmc Group
    sai_object_id_t output_id;      ///< Member OUTPUT ID/Bride port OID
    ifcs_handle_t   mc_dest_hdl;    ///< MC Destination handle
} isai_shim_ipmc_group_member_ds_entry_t;


/*
 * Entry structure for RIF to Mutlicast nexthop data store
 * This should be the mirror  definition of ipmc_rif_mcast_nexthop  in isai_ds.yaml
 */
typedef struct _isai_shim_ipmc_rif_mcast_nexthop_s {
    uint64_t rif_oid;     /* RIF OID */
    uint32_t nh_handle;   /* Nh handle */
    uint32_t ref_count;   /* ref count */
} isai_shim_rif_mcast_nexthop_db_entry;


/**
 * @brief Key for isai_ds_ipmc_entry Entry
 */
typedef struct _isai_ds_ipmc_entry_t_key_s {

  ifcs_uint64_t switch_id;           /* Switch OID */
  ifcs_uint64_t vr_id;               /* Virtual Router OID */
  ifcs_uint8_t type;                 /* IPMC Entry Type */
  ifcs_ip_address_t destination;     /* Group IP address */
  ifcs_ip_address_t source;          /* Source IP address */
} isai_ds_ipmc_entry_key_t;

/*
 * Entry structure for IPMC Entry data store
 * This should be the mirror  definition of ipmc_entry  in isai_ds.yaml
 */
typedef struct isai_shim_ipmc_ds_entry_s {
  isai_ds_ipmc_entry_key_t  key;
  ifcs_uint32_t packet_action;                  /* packet action */
  ifcs_uint64_t output_group_id;                /* IPMC Group Id */
  ifcs_uint64_t rpf_group_id;                   /* RPF Group Id */
} isai_shim_ipmc_ds_entry_t;

/* IPMC DS Table */
typedef struct isai_shim_ipmc_ds_entry_list_s {
    isai_shim_ipmc_ds_entry_t  *ipmc_ds_entry_p;  /* Array of IPMC DS entry */
    uint32_t            max_count;    /* Max count -- indicate memory allocated */
    uint32_t            actual_count; /* Number of entries populated [out] */
    sai_status_t        cb_rc; /* Callback return status */
} isai_shim_ipmc_ds_entry_list_t;

/* Tunnel related declarations */

typedef enum _sai_shim_nh_tunnel_dir_s {
    ISAI_NH_TUNNEL_DIRECTION_TX_ONLY,
    ISAI_NH_TUNNEL_DIRECTION_RX_ONLY,
    ISAI_NH_TUNNEL_DIRECTION_BOTH
} sai_shim_nh_tunnel_dir_t;

typedef enum _sai_shim_nh_tunnel_nh_type_s {
    ISAI_NH_TUNNEL_NH_TYPE_UNICAST,
    ISAI_NH_TUNNEL_NH_TYPE_MULTICAST,
} sai_shim_nh_tunnel_nh_type_t;

/* Tunnel Nhop Resolution data */
typedef struct _isai_tun_nhop_res_t {
    sai_ip_address_t  tun_nh_ip;
    ifcs_handle_t     underlay_nh_hdl;
    sai_ip_address_t  res_ip_addr;
    sai_ip_address_t  res_ip_mask;
    sai_object_id_t   tun_nh_oid;
    sai_object_id_t   tun_oid;
    uint32_t          direction;
    uint32_t         nh_type;
} isai_tun_nhop_res_t;

extern isai_id_alloc_t *l2vni_id_allocator;
extern isai_id_alloc_t *tun_nh_id_allocator;

/*
 * Entry structure for tnl nh ip to hdl ds
 * This should be the mirror  definition of tnl_nh_ip_to_hdl table in isai_ds.yam
 */
typedef struct _isai_shim_tunnel_nexthop_handle_db_s {
    uint8_t          nh_type;             /* IFCS nexthop Type */
    sai_ip_address_t tnl_nh_ip;           /* TUN NH ID */
    uint32_t         nh_hdl;              /* Nh handle */
    uint32_t         ref_count;           /* Ref count */
    sai_object_id_t  l2_tun_nh_oid;       /* L2 tunnel nexthop oid */
    uint32_t         l2_ref_count;        /* L2 nexthop ref count */
    uint32_t         mcast_selected_port; /* Mcast selected sys port */
} isai_shim_tunnel_nexthop_handle_db_entry;

/*
 * Entry structure for VxLAN underlay unicast to mcast map table
 */
typedef struct _isai_shim_vxlan_mcast_map_table_db_s {
    uint32_t unicast_nh_hdl;      /* Unicast Nh handle */
    uint32_t mcast_nh_hdl;        /* Nh handle */
    uint32_t ref_count;           /* Ref count */
    uint32_t selected_ng_mem_hdl; /* Selected ECMP member handle */
} isai_vxlan_ul_mcast_nh_db_entry;

/*
 * Entry structure for TNL NH to Overlay Nh map data store
 * This should be the mirror  definition of tnl_nh_to_overlay_nh in isai_ds.yaml
 */
typedef struct _isai_shim_tnl_nh_to_overlay_nh_db_s {
    ifcs_isai_ds_vxlan_tnl_nh_to_overlay_nh_t key;
    uint32_t overlay_nh_hdl;
}isai_shim_tnl_nh_to_overlay_nh_db_entry_t;

/*
 * Entry structure for Overlay next hop entry
 * This should be the mirror  definition of tnl_nh_to_overlay_nh in isai_ds.yaml
 */
typedef struct _isai_shim_vxlan_overlay_nexthop_db_s {
  uint32_t overlay_nh_hdl;            /* Key */
  sai_mac_t dst_mac;                  /* Nexthop Mac */
  uint32_t l3if_hdl;                  /* L3 interface handle */
  uint64_t tnl_nh_oid;                /* Tunnel nexthop OID */
  bool     default_vxlan_mac_used;    /* Using VxLAN default router mac or not */
  uint32_t ref_count;                 /* ref count */
} isai_shim_overlay_nexthop_db_entry_t;

/*
 * Entry structure for VR to VNI map data store
 * This should be the mirror  definition of vr_to_vni map in isai_ds.yaml
 */
typedef struct _isai_shim_vr_to_vni_db_s {
  uint64_t vr_id;       /* Virtual router OID */
  uint32_t vni_id;      /* VxLAN  VNI Id */
  uint16_t il2vni;      /* Internal L2VNI */
  uint32_t svi_hdl;     /* Internal SVI handle */
  uint32_t ref_cnt;     /* Route count */
} isai_shim_vr_to_vni_db_entry;

/*
 * Entry structure for override data store
 * This should be the mirror  definition of vxlan_override_vni table in isai_ds.yaml
 */
typedef struct _isai_shim_override_vni_db_s {
  uint32_t vni_id;       /* VxLAN  VNI Id */
  uint16_t il2vni;      /* Internal L2VNI */
  uint32_t svi_hdl;     /* Internal SVI handle */
  uint32_t ref_count;   /* Ref count */
} isai_shim_override_vni_db_entry;


/* HOSTIF START */
#define ISAI_HOSTIF_DEF_VLAN_TAG_ACT    SAI_HOSTIF_VLAN_TAG_STRIP

/*  UDT Info structure exposed other module like ACL */
typedef struct ifcs_sai_shim_hostif_user_defined_trap_info_s {
    ifcs_handle_t   trap_handle;
    sai_object_id_t policer_id;
    sai_object_id_t trap_group_oid;
    sai_object_id_t udt_oid;
    bool            admin_state;
} ifcs_sai_shim_hostif_user_defined_trap_info_t;

typedef enum _sai_shim_fdb_pkt_type_t {
    FDB_UNICAST   = 1,
    FDB_MULTICAST = 2,
    FDB_BROADCAST = 3,
} sai_shim_fdb_pkt_type_t;


/*
 * Trap group type based on the traps contained in it.
 * NONE: Empty.
 * PROTOCOL: BGP, VRRP, ARP, etc
 * SFLOW   : SAMPLE_PACKET
 * UDT     : User Defined Trap.
 */

typedef enum isai_shim_hostif_trap_group_type_e {
    ISAI_SHIM_HOSTIF_TRAP_GROUP_TYPE_NONE,
    ISAI_SHIM_HOSTIF_TRAP_GROUP_TYPE_PROTOCOL,
    ISAI_SHIM_HOSTIF_TRAP_GROUP_TYPE_SFLOW,
    ISAI_SHIM_HOSTIF_TRAP_GROUP_TYPE_UDT,
    ISAI_SHIM_HOSTIF_TRAP_GROUP_TYPE_MAX,
} isai_shim_hostif_trap_group_type_t;

/* HOSTIF END */

/* ACL START */
/* ACL Counter OID */

#define ISAI_ACL_COUNTER_ATTR_MAX  (256)

typedef struct  isai_shim_acl_counter_info_s {
    sai_object_id_t oid;            /* SAI_OBJECT  id */
    /* User configured SAI attr count and list for this SAI object*/
    uint32_t        attr_count;
    sai_attribute_t attr_list[ISAI_ACL_COUNTER_ATTR_MAX];
} isai_shim_acl_counter_info_t;

/*
 * ISAI_IFCS_ACL_TABLE_ATTR_COUNT_MAX is the greatest of the following:
 *  IFCS_ACL_TABLE_ATTR_MAX_COUNT
 *  IFCS_ACL_MATCH_PROFILE_ATTR_MAX_COUNT
 *  IFCS_ACL_ACTION_PROFILE_ATTR_MAX_COUNT
 */
#define ISAI_IFCS_ACL_TABLE_ATTR_COUNT_MAX                                      \
    (((uint32_t)IFCS_ACL_TABLE_ATTR_MAX_COUNT >                                 \
      (uint32_t)IFCS_ACL_MATCH_PROFILE_ATTR_MAX_COUNT) ?                        \
     (((uint32_t)IFCS_ACL_TABLE_ATTR_MAX_COUNT >                                \
       (uint32_t)IFCS_ACL_ACTION_PROFILE_ATTR_MAX_COUNT) ?                      \
      IFCS_ACL_TABLE_ATTR_MAX_COUNT : IFCS_ACL_ACTION_PROFILE_ATTR_MAX_COUNT) : \
     (((uint32_t)IFCS_ACL_MATCH_PROFILE_ATTR_MAX_COUNT >                        \
       (uint32_t)IFCS_ACL_ACTION_PROFILE_ATTR_MAX_COUNT) ?                      \
      IFCS_ACL_MATCH_PROFILE_ATTR_MAX_COUNT :                                   \
      IFCS_ACL_ACTION_PROFILE_ATTR_MAX_COUNT))

#define IFCS_SAI_PKTACTIONS_MAX    5

#define IFCS_SAI_PKT_ACTION_ACL_HDL_MAX    5 /*CTC, Drop, Policer, Counter, copy cancel */
/*
 * The priority space that we expose to the user is a subset of the actual
 * priority space that IFCS supports. This is because some ACLs may need to
 * be implemented via a combination of multiple ACEs pf different priorities
 * and so we need holes in the priority space to accomodate those implicit
 * ACEs. The use case today is ACL entries with 'ip type' match field.
 */
#define ISAI_ACE_PRIORITY_SHIFT_BITS    1
#define ISAI_ACE_MIN_USER_PRIORITY \
    (IAI_ACE_MIN_PRIORITY >>       \
     ISAI_ACE_PRIORITY_SHIFT_BITS)


/*
 * IFCS Supports only Muliple of 128 ACL Table size
 * Convert User passed value to ceil(128)
 */
#define CEIL_128(acl_table_size)      ((acl_table_size + 127) & (uint32_t) ~(0x7F))
/*
 * Entry type in acl_pktaction_arr. Look at ifcs_acl_action_type_t and
 * ifcs_acl_action_value_t to understand what type/value pairs IFCS expects.
 */
typedef struct pkt_action_stoi_acl_action_s {
    uint8_t                 count; // Number of acl actions

    // Only a subset of action types have valid values.
    bool                    value_valid[IFCS_SAI_PKT_ACTION_ACL_HDL_MAX];
    ifcs_acl_action_type_t  type[IFCS_SAI_PKT_ACTION_ACL_HDL_MAX];

    //valid only when value_valid is TRUE
    ifcs_acl_action_value_t value[IFCS_SAI_PKT_ACTION_ACL_HDL_MAX];
} pkt_action_stoi_acl_action_t;

typedef struct pkt_action_stoi_acl_action_policer_s {
    ifcs_acl_action_type_t ifcs_action;
    /* list of all possible SAI actions, for given ifcs_action type */
    uint32_t               num_sai_actions;
    sai_packet_action_t    sai_actions[IFCS_SAI_PKTACTIONS_MAX];
} pkt_action_stoi_acl_action_policer_t;

/* ACL END */

/* SWITCH START */

#define SAI_SWITCH_CUSTOM_ATTR_OFFSET(id) (id - SAI_SWITCH_ATTR_CUSTOM_RANGE_START - 1)


#define ISAI_SHIM_SWITCH_DB_RESERVED_SIZE_MASK                 (0x1 << 0)
#define ISAI_SHIM_SWITCH_DB_UC_DTL_MASK                        (0x1 << 1)
#define ISAI_SHIM_SWITCH_DB_NONUC_DTL_MASK                     (0x1 << 2)
#define ISAI_SHIM_SWITCH_DB_UC_SHARED_BUFFER_MAX_LIMIT_MASK    (0x1 << 3)
#define ISAI_SHIM_SWITCH_DB_NONUC_SHARED_BUFFER_MAX_LIMIT_MASK (0x1 << 4)
#define ISAI_SHIM_SWITCH_DB_RESUME_OFFSET_MASK                 (0x1 << 5)

#define ISAI_MIRROR_SAMPLE_RATE                           1

#define SAI_KEY_PLATFORM_LIBRARY   "PLATFORM_LIBRARY"

/* SWITCH END */

#endif /* __IFCS_SAI_TYPES_H__ */
