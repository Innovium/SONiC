/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_tunnel_util.h
 * @brief ISAI Util Include file for TUNNEL module
 */


#ifndef __IFCS_SAI_TUNNEL_UTIL_H__
#define __IFCS_SAI_TUNNEL_UTIL_H__

#include "util/ifcs_sai_tunnel_util_dep.h"
#include "ifcs_isai_ds_tunnel.h"

/*
 * @brief Initializes tunnel module
 *
 * @param [in]  switch_oid               - Switch Object ID
 * @param [in]  sai_switch_init_info_p   - SAI db info pointer
 * @return sai_status_t
 */
extern sai_status_t
isai_im_tunnel_init(
    sai_switch_init_info_t *sai_db_info_p);

/*
 * @brief Un-initializes tunnel module
 *
 * @param [in]  switch_deinit_info_p   - Pointer to switch de-init info
 * @return sai_status_t
 */
extern sai_status_t
isai_im_tunnel_deinit(
    sai_switch_deinit_info_t *switch_deinit_info_p);


/*
 * @brief Converts SAI object ID to ifcs handle to interface
 *
 * @param [in]  sai_object_id - SAI object ID
 * @param [out] ifcs_handle_p - Pointer to IFCS handle to interface
 * @return sai_status_t
 */
extern sai_status_t
isai_im_tunnel_stoi_xlate_oid(
    sai_object_id_t sai_object_id,
    ifcs_handle_t   *ifcs_handle_p);


/*
 * @brief Get brigde port handle for the tunnel id
 * @param [in] tunnel_id   - Tunnel oid
 * @param [ou] bp_handle_p - Pointer to bridge port handle
 * @return sai_status_t
 */
extern sai_status_t
isai_im_tunnel_get_bridge_port_handle(
    sai_object_id_t  tunnel_id,
    uint32_t         *bp_handle_p);

/*
 * @brief set admin state for tunnel bridge port
 * @param [in] bp_handle          -- bridge port handle
 * @param [in] admin_state        -- Admin state
 * @return sai_status_t
 */
extern sai_status_t
isai_im_tunnel_set_bridge_port_admin_state(ifcs_node_id_t node_id,
                                                 ifcs_handle_t  bp_handle,
                                                 bool           admin_state);

/**
 * @brief Get tunnel db entry
 *
 * @param [in]  tunnel_oid      - Tunnel object ID
 * @param [in]  attr_count      - Number of attributes
 * @param [out] attr_list_p     - Pointer to attribute list
 * @return sai_status_t
 */
extern sai_status_t
isai_im_tunnel_get_db_entry(
    sai_object_id_t tunnel_oid,
    uint32_t        attr_count,
    sai_attribute_t *attr_list_p);

/**
 * @brief Get Overlay Nexthop Entry
 *
 * @param [in]  node_id                   -  Node id
 * @param [in]  overlay_nh_hdl            -  VxLAN overlay_nh_hdl ID
 * @param [out] overlay_nexthop_entry_p   -  Pointer to overlay nexthop entry
 * @return sai_status_t
 */
extern sai_status_t
isai_im_tunnel_get_overlay_nh_ds_entry(
    ifcs_node_id_t                       node_id,
    uint32_t                             overlay_nh_hdl,
    isai_shim_overlay_nexthop_db_entry_t *overlay_nexthop_entry_p);


/*
 * @brief Update (Increment or decrement) overlay nexthop ref count
 *        Delete the db entry if ref_count is 0 and the b_remove_entry flag is set
 *
 * @param [in] node_id         -  ifcs node id
 * @param [in] overlay_nh_hdl  -  Overlay nexthop handle [Key]
 * @param [in] b_remove_entry  -  Delete entry if ref_count isA zero and  b_remove_entry is set to true
 * @param [in] increment       -  Increment the ref count if inrement=true , otherwise decrement the ref_count
 * @param [in] new_ref_count_p -  New ref count after increment/decrement operation
 * @return sai_status_t
 */
extern sai_status_t
isai_im_tunnel_overlay_nh_update_ref_count(
    ifcs_node_id_t node_id,
    uint32_t       overlay_nh_hdl,
    bool           b_remove_entry,
    bool           increment,
    uint32_t       *new_ref_count_p);

/*
 * @brief Form data store key for Tunnel Nh to overlay Nh map
 *      Key is the combination of [tunl_nh_oid, vnid and iL2vni]
 *
 * @param [out]  isai_ds_key_p     - isai DS key for tnl_nh_to_overlay_nh db
 * @param [in]   tnl_nh_oid        - Tunnel nh oid
 * @param [in]   vnid              - VNID
 * @param [in]   il2vni            - internal l2vni
 * @return sai_status_t
 */
extern sai_status_t
isai_im_tunnel_form_ds_key_for_tnl_nh_to_overlay_nh(
    ifcs_isai_ds_vxlan_tnl_nh_to_overlay_nh_t *isai_ds_key_p,
    ifcs_uint64_t                             tnl_nh_oid,
    ifcs_uint32_t                             vnid,
    ifcs_uint16_t                             il2vni);


/**
 * @brief Get Tunnel Nh to overlay Nh Map Entry
 *
 * @param [in]  node_id                         -  IFCS node id
 * @param [in]  isai_ds_key                     -  DS Key made from tnl_nh_id, vnid and il2vni
 * @param [out] tnl_nh_to_overlay_nh_entry_p    -  Pointer to tunnel Nh to Overlay nh entry
 * @return sai_status_t
 */
extern sai_status_t
isai_im_tunnel_get_tnh_to_onh_ds_entry(
    ifcs_node_id_t                            node_id,
    ifcs_isai_ds_vxlan_tnl_nh_to_overlay_nh_t *isai_ds_key,
    isai_shim_tnl_nh_to_overlay_nh_db_entry_t *tnl_nh_to_overlay_nh_entry_p);


/**
 * @brief Delete a given Tunnel Nh to Overlay Nh Data Store entry
 *
 * Caller provides key [Made from tnl_nh_oid, vnid and iL2vni] for the entry to be deleted
 * If object_id exists, then it is deleted from the database.
 *
 * @param [in] node_id - ifcs node id
 * @param [in] isai_ds_key_p - DS Key made from tnl_nh_id, vnid and il2vni
 * @return sai_status_t
 */
extern sai_status_t
isai_im_tunnel_remove_tnh_to_onh_ds_entry(
    ifcs_node_id_t                            node_id,
    ifcs_isai_ds_vxlan_tnl_nh_to_overlay_nh_t *isai_ds_key_p);

/**
 * @brief Validate Vxlan tunnel object ID
 *
 * @param [in]     node_id        - Node identifier
 * @param [in]     tunnel_oid     - Tunnel OID
 */
extern sai_status_t
isai_im_tunnel_vxlan_validate_oid(
    ifcs_node_id_t  node_id,
    sai_object_id_t tunnel_oid);

/*
 * @brief Process tunnel override VNI
 *
 * @param [in]   switch_id   - Switch OId
 * @param [in]   vnid        - VxLAN VNID
 * @param [in]   tnl_nh_oid  - Tunnel nexthop oid
 * @param [in]   tnl_mac     - Tunnel next hop mac
 * @return sai_status_t
 */
extern sai_status_t
isai_im_tunnel_vxlan_process_nh_vni(
    sai_object_id_t switch_id,
    uint32_t        vnid,
    sai_object_id_t tnl_nh_oid,
    sai_mac_t       tnl_mac);

/*
 * @brief Create overlay nexthop
 *
 * @param [in]   switch_id          - Switch OId
 * @param [in]   vnid               - VxLan VNID
 * @param [in]   iL2vni             - Internal L2vni
 * @param [in]   svi_hdl            - SVI handle
 * @param [in]   tnl_mac            - Tunnel next hop mac
 * @param [in]   tnl_nh_oid         - Tunnel nexthop oid
 * @param [out]  overlay_nh_hdl_p  - Overlay nexthop handle
 * @return sai_status_t
 */
extern sai_status_t
isai_im_tunnel_vxlan_create_overlay_nh(
    sai_object_id_t switch_id,
    uint32_t        vnid,
    uint16_t        iL2vni,
    ifcs_handle_t   svi_hdl,
    sai_mac_t       tnl_mac,
    sai_object_id_t tnl_nh_oid,
    ifcs_handle_t   *overlay_nh_hdl_p);

/*
 * @brief  Clean up Tunnel nexthop vni
 *
 * @param    [in] node_id - Ifcs node id
 * @param    [in] vnid    - Nexthop VNI
 * @param    [in] tnl_nh_oid    - Tunnel nexthop OID
 * @return sai_status_t
 */
extern sai_status_t
isai_im_tunnel_vxlan_cleanup_nh_vni(
    ifcs_node_id_t  node_id,
    ifcs_handle_t   vnid,
    sai_object_id_t tnl_nh_oid);

/*
 * @brief Process VxLAN router mac
 *       -> Program it as inner destination mac for all Tunnel nexthop
 *       -> Update the termination mac list with VxLAN router mac
 * @param [in]  node_id                -  node_id
 * @param [in]  vxlan_router_mac       -  VxLAN default router mac
 * @return sai_status_t
 */
extern sai_status_t
isai_im_tunnel_vxlan_process_def_router_mac(
    ifcs_node_id_t node_id,
    sai_mac_t      vxlan_router_mac);

/**
 * @brief Get override VNI to VR Map DS Entry
 *
 * @param [in]  node_id           - IFCS node id
 * @param [in]  vnid              -  VxLAN VNID ID
 * @param [out] override_vni_entry_p -  Pointer to VNI to VR DS entry
 * @return sai_status_t
 */
sai_status_t
isai_im_tunnel_get_override_vni_ds_entry(
    ifcs_node_id_t                  node_id,
    uint32_t                        vnid,
    isai_shim_override_vni_db_entry *override_vni_entry_p);

/**
 * @brief Get VNI to VR Map DS Entry
 *
 * @param [in]  vr_oid                - VR object ID
 * @param [out] vr_to_vni_entry_p     - Pointer to VR to VNI entry
 * @return sai_status_t
 */
sai_status_t
isai_im_tunnel_get_vr_to_vni_map_ds_entry(
    sai_object_id_t              vr_oid,
    isai_shim_vr_to_vni_db_entry *vr_to_vni_entry_p);

/**
 * @brief Update VNI to VR Map Ref Count
 *
 * @param [in]  vr_oid                - VR object ID
 * @param [in]  increment             - Increment/Decrement
 * @return sai_status_t
 */
sai_status_t
isai_im_tunnel_update_vr_to_vni_map_ref_cnt(
    sai_object_id_t        vr_oid,
    bool                   increment);

/**
 * @brief Get IFCS handle from tunnel term database entry
 *
 * @param [in]  oid         - Tunnel term object ID
 * @param [in]  handle_p    - Pointer to IFCS intf handle
 * @return sai_status_t
 */
sai_status_t
isai_im_tunnel_term_db_ifcs_intf_handle_get(const sai_object_id_t oid,
                                 ifcs_handle_t         *handle_p);


#endif /* __IFCS_SAI_TUNNEL_UTIL_H__ */
