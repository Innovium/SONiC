/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_mirror_util.h
 * @brief ISAI Util Include file for MIRROR module
 */


#ifndef __IFCS_SAI_MIRROR_UTIL_H__
#define __IFCS_SAI_MIRROR_UTIL_H__

#include "util/ifcs_sai_mirror_util_dep.h"

sai_status_t
isai_im_mirror_get_mirror_ingress(sai_object_id_t port_id,
                                 sai_attribute_t *attr_p);

sai_status_t
isai_im_mirror_set_mirror_ingress(sai_object_id_t port_id,
                                 sai_attribute_t *attr_p);

sai_status_t
isai_im_mirror_get_mirror_egress(sai_object_id_t port_id,
                                 sai_attribute_t *attr_p);

sai_status_t
isai_im_mirror_set_mirror_egress(sai_object_id_t port_id,
                                 sai_attribute_t *attr_p);

sai_status_t
isai_im_mirror_get_sample_rate(ifcs_node_id_t  node_id,
                            sai_object_id_t mirror_oid,
                            uint32_t        *sample_rate_p);
sai_status_t
isai_im_mirror_acl_set_ingress(ifcs_node_id_t           node_id,
                                const sai_attribute_t   *sai_attr_p,
                                     ifcs_handle_t      *ifcs_collector_set_handle);

sai_status_t
isai_im_mirror_acl_set_egress(ifcs_node_id_t           node_id,
                                const sai_attribute_t   *sai_attr_p,
                                     ifcs_handle_t      *ifcs_collector_set_handle);

sai_status_t
isai_im_mirror_acl_delete(ifcs_node_id_t  node_id,
                                ifcs_handle_t collector_set_handle);

sai_status_t
isai_im_mirror_acl_get_session(ifcs_node_id_t    node_id,
                                     ifcs_handle_t     cs_id,
                                     sai_object_list_t *mirror_list_p);

sai_status_t
isai_im_mirror_session_init(sai_switch_init_info_t *sai_switch_init_info_p);

sai_status_t
isai_im_mirror_session_deinit(sai_switch_deinit_info_t *switch_deinit_info_p);

sai_status_t
isai_im_mirror_get_acl_table(ifcs_node_id_t node_id,
                                   ifcs_handle_t  *acl_tbl_hdl_p);

sai_status_t
isai_im_mirror_get_monitor_ib(ifcs_node_id_t  node_id,
                                sai_object_id_t mirror_oid,
                                uint8_t         *ib_p);
#endif /* __IFCS_SAI_MIRROR_UTIL_H__ */
