/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_neighbor_util.h
 * @brief ISAI Util Include file for NEIGHBOR module
 */


#ifndef __IFCS_SAI_NEIGHBOR_UTIL_H__
#define __IFCS_SAI_NEIGHBOR_UTIL_H__

#include "util/ifcs_sai_neighbor_util_dep.h"
#include "ifcs_isai_ds_nbr.h"

/*
 * @brief Initializes Neighbor module
 *
 * @param [in]  sai_switch_init_info_p   - Pointer to switch init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_neighbor_init(
    sai_switch_init_info_t *sai_switch_init_info_p);

/*
 * @brief Un-initializes Neighbor module
 *
 * @param [in]  switch_deinit_info_p   - Pointer to switch deinit information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_neighbor_deinit(
    const sai_switch_deinit_info_t *switch_deinit_info_p);

/*
 * @brief Forms IFCS neighbor database key
 *
 * @param [out] ifcs_key_p        - IFCS neighbor database key
 * @param [in]  neighbor_entry_p  - Pointer to neighbor entry
 * @return sai_status_t
 */
extern sai_status_t
isai_im_neighbor_form_ifcs_key(
    ifcs_isai_ds_nbr_t                *ifcs_key_p,
    const sai_neighbor_entry_t *const neighbor_entry_p);


/**
 * @brief Get neighbor NH handle
 *
 * @param [in]  neighbor_entry_p   - Pointer to neighbor entry
 * @param [in]  nbr_handle_p       - Pointer for handle
 * @return sai_status_t
 */
extern sai_status_t
isai_im_neighbor_get_nh(
    const sai_neighbor_entry_t *neighbor_entry_p,
          ifcs_handle_t        *nbr_handle_p);


/**
 * @brief Increment neighbor reference count
 *
 * @param [in]  neighbor_entry_p   - Pointer to neighbor entry
 * @param [in]  nh_handle          - IFCS NH handle
 * @return sai_status_t
 */
extern sai_status_t
isai_im_neighbor_ref_count_inc(
    const sai_neighbor_entry_t *neighbor_entry_p,
    const ifcs_handle_t        nh_handle);


/**
 * @brief Decrement neighbor reference count
 *
 * @param [in]  neighbor_entry_p   - Pointer to neighbor entry
 * @param [in]  nh_handle          - IFCS NH handle
 * @return sai_status_t
 */
extern sai_status_t
isai_im_neighbor_ref_count_dec(
    const sai_neighbor_entry_t *neighbor_entry_p,
    const ifcs_handle_t        nh_handle);

/**
 * @brief Fdb event notification for neighbor module (only for static fdb events)
 *
 * @param [in] node_id       - IFCS node id
 * @param [in] count         - Number of entries
 * @param [in] data_p        - Pointer to notification data
 */
extern sai_status_t isai_im_neighbor_fdb_event_notify(ifcs_node_id_t node_id, uint32_t       count,
                                sai_shim_fdb_event_notification_data_t *data_p);

#endif /* __IFCS_SAI_NEIGHBOR_UTIL_H__ */
