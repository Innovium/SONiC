/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_nexthopgroup_util.h
 * @brief ISAI Util Include file for NEXTHOPGROUP module
 */


#ifndef __IFCS_SAI_NEXTHOPGROUP_UTIL_H__
#define __IFCS_SAI_NEXTHOPGROUP_UTIL_H__

#include "util/ifcs_sai_nexthopgroup_util_dep.h"

/*
 * @brief  Converts SAI object ID to IFCS handle
 *
 * @param [in]  sai_object_id - SAI object ID
 * @param [out] ifcs_handle   - Handle to IFCS nexthop-group object
 * @return sai_status_t
 */
extern sai_status_t
isai_im_nexthopgroup_stoi_xlate_oid(
    sai_object_id_t sai_object_id,
    ifcs_handle_t   *ifcs_handle_p);

/*
 * @brief Converts SAI object ID to ifcs handle
 *
 * @param [in]  switch_oid   - Switch Object ID
 * @param [in]  ifcs_handle  - IFCS Handle
 * @param [out] object_id_p  - Pointer to SAI object ID
 * @return sai_status_t
 */
extern sai_status_t
isai_im_nexthopgroup_itos_xlate_oid(
    sai_object_id_t switch_oid,
    ifcs_handle_t   ifcs_handle,
    sai_object_id_t *object_id_p);

sai_status_t
isai_im_nexthopgroup_get_group_hdl(sai_object_id_t   object_id,
                                   ifcs_handle_t     *group_hdl_p);
sai_status_t
isai_im_nexthopgroup_get_mem_hdl(sai_object_id_t     object_id,
                                   ifcs_handle_t     *group_mem_hdl_p);


#endif /* __IFCS_SAI_NEXTHOPGROUP_UTIL_H__ */
