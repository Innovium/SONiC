/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_debug_counter_util.h
 * @brief ISAI Util Include file for DEBUG_COUNTER module
 */


#ifndef __IFCS_SAI_DEBUG_COUNTER_UTIL_H__
#define __IFCS_SAI_DEBUG_COUNTER_UTIL_H__

#include "util/ifcs_sai_debug_counter_util_dep.h"
/*
 * @brief Get the ifcs handle of the debug counter datastore entry
 *
 * @param [in] family_type      - Family Type
 * @param [in] stat_index       - Debug Stat Index
 * @param [OUT] ifcs_hdl        - IFCS Handle
 * @return sai_status_t
 */
sai_status_t
isai_im_debug_counter_ifcs_handle_get(uint16_t family_type,
                                     uint32_t stat_index,
                                     ifcs_handle_t *ifcs_hdl);

/*
 * @brief Get the Debug Counter Datastore Entry
 *
 * @param [in]  node_id      - Node Id
 * @param [in]  ifcs_hdl     - IFCS Handle
 * @param [out] dc_info      - Debug Counter datastore values
 * @return sai_status_t
 */
sai_status_t
isai_im_debug_counter_ds_entry_get(ifcs_uint32_t node_id,
                                ifcs_handle_t ifcs_hdl,
                                sai_shim_debug_counter_info_t *dc_info);

/*
 * @brief Get the pp drop handle from switch datastore
 *
 * @param [in]  node_id               - Node Id
 * @param [in]  drop_ifcs_attr_id     - pp drop attr list
 * @param [out] pp_drop_ifcs_hdl      - pp drop IFCS Handle
 * @return sai_status_t
 */
sai_status_t
isai_im_debug_counter_get_pp_drop_handle(ifcs_node_id_t node_id,
                                         ifcs_attr_id_t  drop_ifcs_attr_id,
                                         ifcs_handle_t *pp_drop_ifcs_hdl);

/*
 * @brief PP drop handles cleanup called during switch shutdown
 *
 * @param [in]  sai_switch_deinit_info_p  - Switch DS attributes
 * @return sai_status_t
 */
sai_status_t
isai_im_debug_counter_pp_drop_reason_deinit(
                       sai_switch_deinit_info_t *sai_switch_deinit_info_p);

/*
 * @brief PP drop handles init called during switch startup
 *
 * @param [in]  sai_switch_init_info_p  - Switch DS attributes
 * @return sai_status_t
 */
sai_status_t
isai_im_debug_counter_pp_drop_reason_init(
                       sai_switch_init_info_t *sai_switch_init_info_p);

sai_status_t
isai_im_debug_counter_acl_install(
                       sai_switch_init_info_t *sai_switch_init_info_p);
sai_status_t
isai_im_debug_counter_acl_warmboot_restore(
                       sai_switch_init_info_t *sai_switch_init_info_p);

sai_status_t
isai_im_debug_counter_acl_uninstall(
                       sai_switch_deinit_info_t *sai_switch_deinit_info_p);

#endif /* __IFCS_SAI_DEBUG_COUNTER_UTIL_H__ */
