/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_route_util.h
 * @brief ISAI Util Include file for ROUTE module
 */


#ifndef __IFCS_SAI_ROUTE_UTIL_H__
#define __IFCS_SAI_ROUTE_UTIL_H__

#include "util/ifcs_sai_route_util_dep.h"

/*
 * @brief  Initializes route module
 *
 * @param [in]  sai_switch_init_info_p - Pointer to switch init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_route_init(
    sai_switch_init_info_t *sai_switch_init_info_p);

/*
 * @brief  Uninitializes route module
 * @param [in]  switch_deinit_info_p   - Pointer to deinit information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_route_pre_deinit(
    sai_switch_deinit_info_t  *switch_deinit_info_p);
/*
 * @brief  Uninitializes route module
 * @param [in]  switch_deinit_info_p   - Pointer to deinit information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_route_deinit(
    sai_switch_deinit_info_t  *switch_deinit_info_p);

/**
 * @brief: Register for RCP Processing in the VR
 *
 * Start Tracking this VR for Tunnel Nhop Update Resolution.
 *
 * @param [in] vr_oid   - Object ID Of a VR
 * @return sai_status_t
 */
extern sai_status_t
isai_im_route_rcp_event_register(const sai_object_id_t vr_oid);


/**
 * @brief: De-Register for RCP Processing in the VR
 *
 * Stop Tracking this VR for Tunnel Nhop Updates
 * after VR Tunnel Nhop count becomes 0.
 *
 * @param [in] vr_oid   - Object ID Of a VR
 * @return sai_status_t
 */
extern sai_status_t
isai_im_route_rcp_event_deregister(const sai_object_id_t vr_oid);


/**
 * @brief: Build VR database with Tunenl Nhops
 *
 * Create teh VR database with Number of Tunnel Nhops
 *
 * @param [in] vr_oid   - Object ID Of a VR
 * @return sai_status_t
 */
sai_status_t
isai_im_route_update_tunnh_count_in_vr(const sai_object_id_t vr_oid);


/**
 * @brief: Process Route update
 *
 * Check whether Route update, modifies Underlay Tunnel Resolution
 *
 * @param [in] data - Pointer for Route update
 */
sai_status_t
isai_im_route_rcp_process_route_update(void *data);


/**
 * @brief: ADD Tunnel NH element to VR list
 *
 * @param [in] node_id      - IFCS Node id
 * @param [in] tun_nh_res_p - Pointer for TUN NH data
 *
 */
sai_status_t
isai_im_route_add_tunnh_to_vr(ifcs_node_id_t       node_id,
                              isai_tun_nhop_res_t  *tun_nh_res_p);

#endif /* __IFCS_SAI_ROUTE_UTIL_H__ */
