/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_policer.h
 * @brief ISAI IM Include file for POLICER module
 */


#ifndef __IFCS_SAI_POLICER_H__
#define __IFCS_SAI_POLICER_H__


#define ISAI_MODULE_LOCK_POLICER    1ULL


#include "isai_im_nmgr.h"
#include "ifcs_sai_qos_common.h"
#include "ifcs_sai_hostif.h"
#include "ifcs_sai_mirror.h"
#endif /* __IFCS_SAI_POLICER_H__ */
