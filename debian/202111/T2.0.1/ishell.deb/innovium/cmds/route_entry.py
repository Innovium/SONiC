
#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2016
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------


import shlex
import time
import random
import copy
import argparse
import sys

from cmdmgr import Command
from utils.compat_util import *
from verbosity import *
from ctypes import *
from collections import OrderedDict
from ifcs_cmds.devport import Devport as Devport
from print_table import PrintTable
from node import *
from utils.log_utils import raiseExpOnFail
ifcs_ctypes = sys.modules['ifcs_ctypes']

class Routeentry(Command):
    def __init__(self, cli):
        self.sub_cmds = {
                         'create'           : self.create,
                         'help'             : self.help,
                         '?'                : self.help
                        }
        self.cli = cli
        self.cli.node_id = 0
        self.arg_list = []
        #super(Routeentry, self).__init__()


    def _create_(
            self,
            nodeId,
            key_type=None,
            key=None,
            nexthop=None,
            fwdPolicy=None,
            ctcPolicy=None,
            counter=None,
            hostResourceType=None,
            usageGetRouteType=None,
            ttlCheckProfile=None,
            userCookie=None,
            userHandle=None,
            expRc=None,
            invalidAttrId=None,
            attrCount=None,
            bulkKeyCount=None,
            bulkKeys=None,
            bulkAttrCounts=None,
            bulkAttrs=None,
            bulkStatuses=None,
            ifcsCall=True,
            bulk=False):
        if bulk is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_route_entry_bulk_create(
                    nodeId,
                    NULL,
                    bulkKeyCount,
                    pointer(bulkKeys),
                    pointer(bulkAttrCounts),
                    pointer(bulkAttrs),
                    pointer(bulkStatuses)))
            if expRc:
                assert rc == expRc, "Bulk route_entry creation failed rc expected: {0} actual :{1}".format(
                    expRc, rc)
            else:
                raiseExpOnFail(rc, "Bulk route_entry  create failed")
        else:

            route_entry_key = ifcs_ctypes.ifcs_route_entry_key_t()
            self.handle = addressof(route_entry_key)
            self.route_entry_key = route_entry_key

            rc = ifcs_ctypes.ifcs_route_entry_key_t_init(pointer(route_entry_key))
            assert rc == ifcs_ctypes.IFCS_SUCCESS

            rc = ifcs_ctypes.ifcs_route_entry_key_t_key_type_set(
                pointer(route_entry_key), key_type)

            if key_type == ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_L3VNI:
                rc = ifcs_ctypes.ifcs_route_entry_key_t_ip_dest_l3vni_set(
                    pointer(route_entry_key), key.ip_dest_l3vni)

                ip_dest = ifcs_ctypes.ifcs_ip_prefix_t()
                rc = ifcs_ctypes.ifcs_ip_prefix_t_init(pointer(ip_dest))
                rc = ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(
                    pointer(ip_dest), key.ip_dest_l3vni.ip_dest.addr_family)
                rc = ifcs_ctypes.ifcs_ip_prefix_t_addr_set(
                    pointer(ip_dest), pointer(
                        key.ip_dest_l3vni.ip_dest.addr))
                rc = ifcs_ctypes.ifcs_ip_prefix_t_mask_set(
                    pointer(ip_dest), pointer(
                        key.ip_dest_l3vni.ip_dest.mask))
                rc = ifcs_ctypes.ifcs_route_entry_key_ip_dest_l3vni_t_ip_dest_set(
                    pointer(route_entry_key.key.ip_dest_l3vni), pointer(ip_dest))

                rc = ifcs_ctypes.ifcs_route_entry_key_ip_dest_l3vni_t_l3vni_set(
                    pointer(route_entry_key.key.ip_dest_l3vni), key.ip_dest_l3vni.l3vni)

            attrList = (ifcs_ctypes.ifcs_attr_t * 10)()
            for index in range(10):
                rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                assert rc == ifcs_ctypes.IFCS_SUCCESS
            index = 0

            if invalidAttrId is not None:
                attrList[index].id = ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_MAX_COUNT
                attrList[index].value.u32 = 0
                index += 1
            if nexthop is not None:
                attrList[index].id = ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_NEXTHOP
                attrList[index].value.handle = nexthop
                index += 1
            if fwdPolicy is not None:
                attrList[index].id = ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_FWD_POLICY
                attrList[index].value.fwd_policy = fwdPolicy
                index += 1
            if ctcPolicy is not None:
                attrList[index].id = ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_CTC_POLICY
                attrList[index].value.ctc_policy = ctcPolicy
                index += 1
            if counter is not None:
                attrList[index].id = ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_COUNTER
                attrList[index].value.data = counter
                index += 1
            if hostResourceType is not None:
                attrList[index].id = ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_HOST_RESOURCE_TYPE
                attrList[index].value.u32 = hostResourceType
                index += 1
            if usageGetRouteType is not None:
                attrList[index].id = ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_USAGE_GET_ROUTE_TYPE
                attrList[index].value.u32 = usageGetRouteType
                index += 1
            if ttlCheckProfile is not None:
                attrList[index].id = ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_TTL_CHECK_PROFILE
                attrList[index].value.u32 = ttlCheckProfile
                index += 1
            if userCookie is not None:
                attrList[index].id = ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_USER_COOKIE
                attrList[index].value.u32 = userCookie
                index += 1

            if attrCount is None:
                if index > ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_MAX_COUNT:
                    attrCount = ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_MAX_COUNT
                else:
                    attrCount = index
            if ifcsCall is True:
                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_route_entry_create(
                        nodeId,
                        pointer(route_entry_key),
                        attrCount,
                        attrList))
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log("Route Entry creation failed rc: {0}".format(rc))
                else:
                    log("Route Entry creation successful")
                return rc


    def run_cmd(self, args):
        log_dbg(1, "in Routeentry run")
        self.arg_list = shlex.split(args)
        try:
            return self.sub_cmds[self.arg_list[2]](args)
        except (KeyError):
            log_dbg(1, "RouteentryKeyError")
            self.help(args)
        except (ValueError):
            log_dbg(1, "RouteentryValueError")
            self.help(args)
        except Exception as ex:
            self.cli.error()
            self.help(args)

        return

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def ifcs_route_entry_key_map_fill(self, l3vni, addr_family, ip, mask):
        key = ifcs_ctypes.ifcs_route_entry_key_map_t()
        key.ip_dest_l3vni.l3vni = l3vni
        key.ip_dest_l3vni.ip_dest.addr_family = addr_family
        if addr_family == ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4:
            key.ip_dest_l3vni.ip_dest.addr.ipv4 = ip
            key.ip_dest_l3vni.ip_dest.mask.ipv4 = mask
        else:
            key.ip_dest_l3vni.ip_dest.addr.ipv6 = ip
            key.ip_dest_l3vni.ip_dest.mask.ipv6 = mask
        return key

    def create(self, args):
        log_dbg(1, "in Routeentry create")
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Routeentry create', prog='routeentry', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-inherit_nexthop_ctc', action="store_true", help='Inherit CTC policy from nexthop handle')
        #mandatory arguments
        requiredArgs = parser.add_argument_group('Mandatory arguments')
        requiredArgs.add_argument('-l3vni_handle', action="store", help='L3VNI handle', required=True)
        requiredArgs.add_argument('-dest_ip', action="store", help='Destination IP address', required=True)
        requiredArgs.add_argument('-dest_mask', action="store", help='Destination mask', required=True)
        requiredArgs.add_argument('-nexthop_handle', action="store", help='ECMP or Nexthop handle', required=True)
        #requiredArgs.add_argument('-inherit_nexthop_ctc', action="store", help='Inherit nexthop CTC policy onto the route', required=False)
        try:
            res = parser.parse_args(self.arg_list)
        except:
            log('Create parse_args failed')
            return 1
        # Get l3vni_handle
        l3vni_handle = int(res.l3vni_handle, 0)

        # Get dest ip
        dest_ip_l = res.dest_ip.split(".")
        dest_ip_l = [int(i, 0) for i in dest_ip_l]

        # Get dest mask
        dest_mask_l = res.dest_mask.split(".")
        dest_mask_l = [int(i, 0) for i in dest_mask_l]

        # Get nexthop
        nexthop_handle = int(res.nexthop_handle, 0)

        ctc_policy = None

        # Inherit CTC policy from the nexthop
        if res.inherit_nexthop_ctc:
            if ifcs_ctypes.IFCS_HANDLE_MODULE(nexthop_handle) == ifcs_ctypes.IFCS_MOD_NEXTHOP:
                attr = ifcs_ctypes.ifcs_attr_t()
                rc = ifcs_ctypes.ifcs_attr_t_init(pointer(attr))
                assert rc == ifcs_ctypes.IFCS_SUCCESS
                attr.id = ifcs_ctypes.IFCS_NEXTHOP_ATTR_CTC_POLICY
                actual_count = c_uint32()
                actual_count_p = pointer(actual_count)
                attr_p = pointer(attr)

                rc = ifcs_ctypes.ifcs_nexthop_attr_get(
                        self.cli.node_id,
                        nexthop_handle,
                        1,
                        attr_p,
                        actual_count_p)
                assert rc == ifcs_ctypes.IFCS_SUCCESS
                ctc_policy = attr.value.ctc_policy

        # Convert IP and Mask to 32bit values
        dest_ip = dest_ip_l[0] << 24 | dest_ip_l[1] << 16 | dest_ip_l[2] << 8 | dest_ip_l[3]
        dest_mask = dest_mask_l[0] << 24 | dest_mask_l[1] << 16 | dest_mask_l[2] << 8 | dest_mask_l[3]

        key = self.ifcs_route_entry_key_map_fill(l3vni_handle, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4, dest_ip, dest_mask)
        return self._create_(self.cli.node_id,
                             ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_L3VNI,
                             key,
                             nexthop=nexthop_handle,
                             ctcPolicy=ctc_policy)

    def help(self, args):
        table = PrintTable()
        table.add_row(['Command', 'Description'])
        table.add_row(['create', 'Create Route_entry'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        routeentry_help_string = """
Usage::

    Type "config routeentry <command>" followed by -h to see command's sub-options.
"""
        log(routeentry_help_string)
