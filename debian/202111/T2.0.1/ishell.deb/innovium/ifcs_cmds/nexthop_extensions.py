
#-------------------------------------------------------------------------------
# * Copyright (c) Innovium, Inc., 2017
# *
# * This material is proprietary to Innovium. All rights reserved.
# * The methods and techniques described herein are considered trade secrets
# * and/or confidential. Reproduction or distribution, in whole or in part, is
# * forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

from ctypes import *
from ifcs_cmds.cli_types import *
from itertools import *
from time import *
from ifcs_cmds.intf import *
from utils.compat_util import *
from verbosity import *
from print_table import PrintTable
import sys
from utils.compat_util import *
ifcs_ctypes = sys.modules['ifcs_ctypes']

filter_option_all = [
    'l3port_uc_txonly',
    'l3port_uc_rxonly',
    'l3port_uc_bidir',
    'l3port_mc_txonly',
    'l3port_mc_rxonly',
    'l3port_mc_bidir',
    'svi_uc_txonly',
    'svi_uc_rxonly',
    'svi_uc_bidir',
    'svi_mc_txonly',
    'svi_mc_rxonly',
    'svi_mc_bidir',
    'l3_port_cvid_uc_txonly',
    'l3_port_cvid_uc_rxonly',
    'l3_port_cvid_uc_bidir',
    'l3_port_cvid_mc_txonly',
    'l3_port_cvid_mc_rxonly',
    'l3_port_cvid_mc_bidir',
    'reserved_uc_bidir',
    'ip_in_ipv4_uc_txonly',
    'ip_in_ipv4_uc_rxonly',
    'ip_in_ipv4_uc_bidir',
    'ip_in_ipv4_mc_txonly',
    'ip_in_ipv4_mc_rxonly',
    'ip_in_ipv4_mc_bidir',
    'ip_in_ipv6_uc_txonly',
    'ip_in_ipv6_uc_rxonly',
    'ip_in_ipv6_uc_bidir',
    'ip_in_ipv6_mc_txonly',
    'ip_in_ipv6_mc_rxonly',
    'ip_in_ipv6_mc_bidir',
    'ip_in_ipv4_gre_uc_txonly',
    'ip_in_ipv4_gre_uc_rxonly',
    'ip_in_ipv4_gre_uc_bidir',
    'ip_in_ipv4_gre_mc_txonly',
    'ip_in_ipv4_gre_mc_rxonly',
    'ip_in_ipv4_gre_mc_bidir',
    'ip_in_ipv6_gre_uc_txonly',
    'ip_in_ipv6_gre_uc_rxonly',
    'ip_in_ipv6_gre_uc_bidir',
    'ip_in_ipv6_gre_mc_txonly',
    'ip_in_ipv6_gre_mc_rxonly',
    'ip_in_ipv6_gre_mc_bidir',
    'ip_in_ipv4_gre_key_uc_txonly',
    'ip_in_ipv4_gre_key_uc_rxonly',
    'ip_in_ipv4_gre_key_uc_bidir',
    'ip_in_ipv4_gre_key_mc_txonly',
    'ip_in_ipv4_gre_key_mc_rxonly',
    'ip_in_ipv4_gre_key_mc_bidir',
    'ip_in_ipv6_gre_key_uc_txonly',
    'ip_in_ipv6_gre_key_uc_rxonly',
    'ip_in_ipv6_gre_key_uc_bidir',
    'ip_in_ipv6_gre_key_mc_txonly',
    'ip_in_ipv6_gre_key_mc_rxonly',
    'ip_in_ipv6_gre_key_mc_bidir',
    'l2_in_ipv4_vxlan_uc_txonly',
    'l2_in_ipv4_vxlan_uc_rxonly',
    'l2_in_ipv4_vxlan_uc_bidir',
    'l2_in_ipv4_vxlan_mc_txonly',
    'l2_in_ipv4_vxlan_mc_rxonly',
    'l2_in_ipv4_vxlan_mc_bidir',
    'l2_in_ipv6_vxlan_uc_txonly',
    'l2_in_ipv6_vxlan_uc_rxonly',
    'l2_in_ipv6_vxlan_uc_bidir',
    'l2_in_ipv6_vxlan_mc_txonly',
    'l2_in_ipv6_vxlan_mc_rxonly',
    'l2_in_ipv6_vxlan_mc_bidir']

intf_type_dict = {
    ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_TYPE_L3PORT: "L3PORT",
    ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_TYPE_SVI: "SVI",
    ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_TYPE_L3_PORT_CVID: "L3_PORT_CVID",
    ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_TYPE_IP_IN_IPV4: "IP_IN_IPV4",
    ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_TYPE_IP_IN_IPV6: "IP_IN_IPV6",
    ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_TYPE_IP_IN_IPV4_GRE: "IP_IN_IPV4_GRE",
    ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_TYPE_IP_IN_IPV6_GRE: "IP_IN_IPV6_GRE",
    ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_TYPE_IP_IN_IPV4_GRE_KEY: "IP_IN_IPV4_GRE_KEY",
    ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_TYPE_IP_IN_IPV6_GRE_KEY: "IP_IN_IPV6_GRE_KEY",
    ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_TYPE_L2_IN_IPV4_VXLAN: "L2_IN_IPV4_VXLAN",
    ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_TYPE_L2_IN_IPV6_VXLAN: "L2_IN_IPV6_VXLAN",
    ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_TYPE_MAX: "MAX",
    ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_NON_TUNNEL: "Non-Tunnel",
    ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_TUNNEL: "Tunnel",
}

nexthop_type_dict = {
    ifcs_ctypes.IFCS_NEXTHOP_TYPE_UC: "UC",
    ifcs_ctypes.IFCS_NEXTHOP_TYPE_MC: "MC",
}

nexthop_dir_dict = {
    ifcs_ctypes.IFCS_NEXTHOP_DIRECTION_BIDIR: "BIDIR",
    ifcs_ctypes.IFCS_NEXTHOP_DIRECTION_TXONLY: "TXONLY",
    ifcs_ctypes.IFCS_NEXTHOP_DIRECTION_RXONLY: "RXONLY",
}


def process_add_row(filter_option, row, table1, nz):

    if (nz == True and row['current'] > 0) or (nz == False):
        table1.add_row([row['intf_type'], row['nh_type'],
                        row['dir'], row['current']])

    return


def show_nexthop_extension_usage_detail_helper(filter_option):

    if filter_option not in filter_option_all:
        log_err("Invalid filter option {0}". format(filter_option))
        return

    # Default direction is BIDIR
    if 'tx' in filter_option:
        nh_dir_val = ifcs_ctypes.IFCS_NEXTHOP_DIRECTION_TXONLY
    elif 'rx' in filter_option:
        nh_dir_val = ifcs_ctypes.IFCS_NEXTHOP_DIRECTION_RXONLY
    else:
        nh_dir_val = ifcs_ctypes.IFCS_NEXTHOP_DIRECTION_BIDIR

    # Default nexthop type is UC
    if 'mc' in filter_option:
        nh_type_val = ifcs_ctypes.IFCS_NEXTHOP_TYPE_MC
    else:
        nh_type_val = ifcs_ctypes.IFCS_NEXTHOP_TYPE_UC

    if 'l3_port_cvid' in filter_option:
        intf_type_val = ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_TYPE_L3_PORT_CVID
    elif 'l3port' in filter_option:
        intf_type_val = ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_TYPE_L3PORT
    elif 'svi' in filter_option:
        intf_type_val = ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_TYPE_SVI
    elif 'ipv4_gre_key' in filter_option:
        intf_type_val = ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_TYPE_IP_IN_IPV4_GRE_KEY
    elif 'ipv4_gre' in filter_option:
        intf_type_val = ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_TYPE_IP_IN_IPV4_GRE
    elif 'ipv4_vxlan' in filter_option:
        intf_type_val = ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_TYPE_L2_IN_IPV4_VXLAN
    elif 'ipv4' in filter_option:
        intf_type_val = ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_TYPE_IP_IN_IPV4
    elif 'ipv6_gre_key' in filter_option:
        intf_type_val = ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_TYPE_IP_IN_IPV6_GRE_KEY
    elif 'ipv6_gre' in filter_option:
        intf_type_val = ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_TYPE_IP_IN_IPV6_GRE
    elif 'ipv6_vxlan' in filter_option:
        intf_type_val = ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_TYPE_L2_IN_IPV6_VXLAN
    elif 'ipv6' in filter_option:
        intf_type_val = ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_TYPE_IP_IN_IPV6
    elif 'reserved' in filter_option:
        intf_type_val = ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_TYPE_MAX

    attr_count = 0
    num_attr = 2
    attr_list = (ifcs_ctypes.ifcs_attr_t * num_attr)()
    usage_p = ifcs_ctypes.ifcs_usage_t()
    usage_obj_p = ifcs_ctypes.ifcs_usage_obj_t()

    ifcs_ctypes.ifcs_attr_t_id_set(
        compat_pointerAtIndex(
            attr_list,
            ifcs_ctypes.ifcs_attr_t,
            attr_count),
        ifcs_ctypes.IFCS_NEXTHOP_ATTR_TYPE)
    ifcs_ctypes.ifcs_attr_t_value_u32_set(
        compat_pointerAtIndex(
            attr_list,
            ifcs_ctypes.ifcs_attr_t,
            attr_count),
        nh_type_val)
    attr_count += 1

    ifcs_ctypes.ifcs_attr_t_id_set(
        compat_pointerAtIndex(
            attr_list,
            ifcs_ctypes.ifcs_attr_t,
            attr_count),
        ifcs_ctypes.IFCS_NEXTHOP_ATTR_DIRECTION)
    ifcs_ctypes.ifcs_attr_t_value_u32_set(
        compat_pointerAtIndex(
            attr_list,
            ifcs_ctypes.ifcs_attr_t,
            attr_count),
        nh_dir_val)
    attr_count += 1

    ifcs_ctypes.ifcs_usage_t_obj_api_class_id_set(
        pointer(usage_p), ifcs_ctypes.IFCS_USAGE_OBJ_API_CLASS_ID_NEXTHOP)
    usage_obj_p.nexthop = intf_type_val
    ifcs_ctypes.ifcs_usage_t_obj_type_set(
        pointer(usage_p), pointer(usage_obj_p))

    rc = ifcs_ctypes.ifcs_nexthop_usage_detail_get(
        0, num_attr, attr_list, pointer(usage_p))
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to get {0} intf usage rc: {1}".format(
            filter_option, convert_error_code_to_string(rc)))
        return

    row = {}

    if intf_type_val != ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_TYPE_MAX:
        row['intf_type'] = intf_type_dict[intf_type_val]
        row['nh_type'] = nexthop_type_dict[nh_type_val]
        row['dir'] = nexthop_dir_dict[nh_dir_val]
    else:
        row['intf_type'] = "RESERVED NON_TUNNEL"
        row['nh_type'] = ""
        row['dir'] = ""

    row['max'] = usage_p.max
    row['current'] = usage_p.current

    return row


def get_nexthop_summary_table():
    usage_p = (ifcs_ctypes.ifcs_usage_t * 2)()
    obj = (ifcs_ctypes.ifcs_usage_obj_t * 2)()

    obj[0].nexthop = ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_NON_TUNNEL
    ifcs_ctypes.ifcs_usage_t_obj_api_class_id_set(
        compat_pointerAtIndex(
            usage_p,
            ifcs_ctypes.ifcs_usage_t,
            0),
        ifcs_ctypes.IFCS_USAGE_OBJ_API_CLASS_ID_NEXTHOP)
    ifcs_ctypes.ifcs_usage_t_obj_type_set(
        compat_pointerAtIndex(
            usage_p, ifcs_ctypes.ifcs_usage_t, 0), compat_pointerAtIndex(
            obj, ifcs_ctypes.ifcs_usage_obj_t, 0))

    rc = ifcs_ctypes.ifcs_nexthop_usage_detail_get(
        0, 0, None, compat_pointerAtIndex(
            usage_p, ifcs_ctypes.ifcs_usage_t, 0))
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to get {0} intf usage rc: {1}".format(
            filter_option, convert_error_code_to_string(rc)))
        return

    obj[1].nexthop = ifcs_ctypes.IFCS_USAGE_OBJ_NEXTHOP_INTF_TUNNEL
    ifcs_ctypes.ifcs_usage_t_obj_api_class_id_set(
        compat_pointerAtIndex(
            usage_p,
            ifcs_ctypes.ifcs_usage_t,
            1),
        ifcs_ctypes.IFCS_USAGE_OBJ_API_CLASS_ID_NEXTHOP)
    ifcs_ctypes.ifcs_usage_t_obj_type_set(
        compat_pointerAtIndex(
            usage_p, ifcs_ctypes.ifcs_usage_t, 1), compat_pointerAtIndex(
            obj, ifcs_ctypes.ifcs_usage_obj_t, 1))

    rc = ifcs_ctypes.ifcs_nexthop_usage_detail_get(
        0, 0, None, compat_pointerAtIndex(
            usage_p, ifcs_ctypes.ifcs_usage_t, 1))
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to get {0} intf usage rc: {1}".format(
            filter_option, convert_error_code_to_string(rc)))
        return

    table = PrintTable()
    table.add_row(["nexthop space", "used", "max", "available"])
    table.add_row([intf_type_dict[obj[0].nexthop], usage_p[0].current,
                   usage_p[0].max, usage_p[0].max - usage_p[0].current])
    table.add_row([intf_type_dict[obj[1].nexthop], usage_p[1].current,
                   usage_p[1].max, usage_p[1].max - usage_p[1].current])

    return table


def show_nexthop_extension_usage_detail(arg1, arg2, nexthop):
    log_dbg(1, " Inside extension usage show")
    table = PrintTable()
    table.add_row(["intf type", "nexthop type", "direction", "count"])
    total = 0
    if nexthop.filter_option == {}:
        for filter_option in filter_option_all:
            row = show_nexthop_extension_usage_detail_helper(filter_option)
            process_add_row(filter_option, row, table, False)
            total += row['current']
        table2 = get_nexthop_summary_table()
        log("Total nexthop count: {0}".format(total))
        table.print_table(brief=True)
        log("Total nexthop count: {0}\n".format(total))
        table2.print_table(brief=True)
        table.reset_table()
        table2.reset_table()

    else:
        filter_option = (nexthop.filter_option['filter']).strip()
        if filter_option == 'nz':
            for nz_filter_option in filter_option_all:
                row = show_nexthop_extension_usage_detail_helper(
                    nz_filter_option)
                process_add_row(nz_filter_option, row, table, True)
                total += row['current']
            table2 = get_nexthop_summary_table()
            log("Total nexthop count: {0}".format(total))
            table.print_table(brief=True)
            log("Total nexthop count: {0}\n".format(total))
            table2.print_table(brief=True)
            table.reset_table()
            table2.reset_table()
        else:
            row = show_nexthop_extension_usage_detail_helper(filter_option)
            table.add_row([row['intf_type'], row['nh_type'],
                           row['dir'], row['current']])
            table.print_table(brief=True)
            table.reset_table()
    log("NOTE: nexthop counts include nexthops reserved for internal use\n")

    return
