#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

from verbosity import log

class PrintTable():
    def __init__(self):
        self.rows = []
        self.h_size = 1
        self.f_size = 0
        self.just = 'right'
        self.mid_header = []
        self.block_empties = False

    def reset_table(self):
        del self.rows[:]

    def set_header_size(self, size):
        ''' Method to set header size '''
        self.h_size = size

    def set_footer_size(self, size):
        ''' Method to set footer size '''
        self.f_size = size

    def set_justification(self, just):
        ''' Method to set header size '''
        if just not in ['right','left']:
            raise ValueError

        self.just = just

    def set_num_columns(self, columns):
        ''' Method to set number of columns in table '''
        self.numColumns = columns

    def add_row(self, row):
        ''' Method to add row to rows'''
        self.rows.append(row)

    def add_mid_header(self, mid):
        ''' Method to add middle header'''
        self.mid_header.append(mid)

    def getFirstEmpty(self, val_list):
        ''' Method to get the index of the first empty element in a list'''
        for i,val in enumerate(val_list):
            if val.isspace():
                return i
        return -1

    def block_empty_displays(self):
        ''' Method to remove : from the display of an empty block in the table '''
        self.block_empties = True

    def print_table(self, brief=False):
        '''Prints out the table in ascii form'''
        column_widths = None
        for column in self.rows:
            if not column_widths:
                column_widths = [len(str(x)) for x in column]
            else:
                column_widths = [max(x, len(str(y))) for x, y in zip(column_widths, column)]

        if self.mid_header:
            column_widths = [max(x, len(str(y))) for x, y in zip(column_widths, self.mid_header[0])]

        # print seperator
        header_seperator = ["-"*w for w in column_widths]
        log("+-{0}-+".format("---".join(list(header_seperator))))

        # print header
        for h in range(0, self.h_size):
            header = self.rows[h]
            if self.just == 'right':
                header_col = [str(c).rjust(w) for w, c in zip(column_widths, header)]
            elif self.just == 'left':
                header_col = [str(c).ljust(w) for w, c in zip(column_widths, header)]
            if brief:
                log("| {0} |".format(" | ".join(list(header_col))))
            else:
                if self.block_empties:
                    idx = self.getFirstEmpty(header_col)
                    if not idx ==  -1:
                        full_half = " : ".join(header_col[:idx])
                        empty_half = "    ".join(header_col[idx:])
                        joined_header_col = full_half + " " + empty_half
                        log("| {0} |".format(joined_header_col))
                        continue
                log("| {0} |".format(" : ".join(list(header_col))))

        # print seperator
        if self.h_size:
            log("|-{0}-|".format("---".join(list(header_seperator))))


        if self.mid_header:
            if self.just == 'right':
                cols = [str(c).rjust(w) for w, c in zip(column_widths, self.mid_header[0])]
            elif self.just == 'left':
                cols = [str(c).ljust(w) for w, c in zip(column_widths, self.mid_header[0])]
            if brief:
                log("| {0} |".format(" | ".join(list(cols))))
            else:
                log("| {0} |".format(" : ".join(list(cols))))

            # print seperator
            log("|-{0}-|".format("---".join(list(header_seperator))))

        # print data
        outIndx = self.h_size
        for columns in self.rows[self.h_size:]:
            # This will be true if a footer is set
            if outIndx == (len(self.rows) - self.f_size):
                # Add separator for the footer
                log("+-{0}-+".format("---".join(list(header_seperator))))
            if self.just == 'right':
                cols = [str(c).rjust(w) for w, c in zip(column_widths, columns)]
            elif self.just == 'left':
                cols = [str(c).ljust(w) for w, c in zip(column_widths, columns)]
            if brief:
                log("| {0} |".format(" | ".join(list(cols))))
            else:
                log("| {0} |".format(" : ".join(list(cols))))
            outIndx = outIndx + 1

        # print seperator
        log("+-{0}-+".format("---".join(list(header_seperator))))

        # Clean up after print
        del self.rows[:]

if __name__ == '__main__':

    table = PrintTable()

    # Test 1 Rows are fewer that fields
    table.add_row(['key','value'])
    table.add_row(['ip_addr','ip_mask','l3vni_handle','nexthop'])
    table.add_row(['10.10.10.0,255.255.255.0,0x12345678','0x3c050000'])
    table.print_table()
