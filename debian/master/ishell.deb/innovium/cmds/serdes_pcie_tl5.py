#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------
""" Management port serdes operations """

import argparse
import sys,traceback
import time
import copy
import ifcs_ctypes as ifcs

try:
    from cmdmgr import Command
    from testutil import pci
except:
    pass

from testutil import sierra
from utils.compat_util import *

NUM_LANES = 4

def speed_get(lane):
    nls2speed = {0: 0, 1:2.5, 2:5.0, 3:8.0}  # map from NLS bits to speed in GT/s
    nls = pci.read_fields('PCI_CFG_I_PCIE_CAP_STRUCT_I_LINK_CTRL_STATUS')['nls_f']
    if nls in nls2speed:
        return nls2speed[nls]
    return 0

# Transport specific functions for K2 PCIE
# K2-specific serdes address mapping functions

MID_PHY_OFFSET  = 0x10200000

def serdes_addr_to_msn(addr):
    return (addr<<4) + MID_PHY_OFFSET

def msn_addr_to_serdes(pci_addr):
    return (pci_addr - MID_PHY_OFFSET) >> 4

def mid_write32(addr, data):
    pci.write32(ifcs.MID_ADR, addr)
    pci.write32(ifcs.MID_DAT32, data)

def mid_read32(addr):
    pci.write32(ifcs.MID_ADR, addr)
    val = pci.read32(ifcs.MID_DAT32)
    return val

def base_serdes_read(addr):
    return mid_read32(serdes_addr_to_msn(addr))

def base_serdes_write(addr, data):
    mid_write32(serdes_addr_to_msn(addr), data)

def toggle_port_enable():
    pass
# end K2-specific

def get_phy(node_id):
    device_type = ifcs.im_nmgr_node_device_type_get(node_id)
    if device_type == ifcs.IM_NMGR_NODE_DEVICE_TYPE_TL10:
        return sierra.Sierra(NUM_LANES, base_serdes_read, base_serdes_write, toggle_port_enable, 7)
    log("Unexpected Device type 0x%x, no transport for phy" % device_type)
    return None

default_lane_list = [0]
def get_lane_list(args):
    global default_lane_list
    if args.lane is not None:
        default_lane_list = args.lane
    for lane in default_lane_list:
        if len(default_lane_list) > 1:
            if lane != default_lane_list[0]:
                log('')  # empty line between lanes
            log('Mgmt Lane %d' % lane)
        yield lane

# Intended for use with argparse: convert a string to a list of integers:
# '5' => [5], '3,8,2' => [3, 8, 2], '4-6' => [4,5,6]
def parse_list(s):
    out = []
    for item in s.split(','):
        if ':' in item:
            itemlist = item.split(':', 2)
        elif '-' in item:
            itemlist = item.split('-', 2)
        else:
            itemlist = [item]
        first = int(itemlist[0], 0)
        if len(itemlist) == 1:
            out.append(int(itemlist[0], 0))
        elif len(itemlist) == 2:
            last = int(itemlist[1], 0)
            for x in range(first, last+1):
                out.append(x)
        else:
            raise ValueError("Error parsing list argument")
    return out

def Hex(s):
    return int(s,16)


def cli_status(args):
    phy = get_phy(0)
    for lane in get_lane_list(args):
        speed = speed_get(lane)
        phy_status = phy.status_str(lane)
        log('Lane: %d  Speed: %dGT/s  %s' % (lane, speed, phy_status))


def cli_creq_diag(args):
    phy = get_phy(0)
    for lane in get_lane_list(args):
        phy.cli_creq_diag(lane)

def cli_deq_diag(args):
    phy = get_phy(0)
    for lane in get_lane_list(args):
        phy.cli_deq_diag(lane, args)

def cli_bathtub(args):
    phy = get_phy(0)
    for lane in get_lane_list(args):
        sample_scaling = 1
        phy.cli_bathtub(lane, sample_scaling, args)

def cli_eye(args):
    phy = get_phy(0)
    for lane in get_lane_list(args):
        sample_scaling = 1
        phy.cli_eye(lane, sample_scaling, args)

def cli_read(args):
    phy = get_phy(0)
    if args.bus == 'raw':
        for serdes_addr in range(args.addr, args.addr + args.range):
            val = phy.serdes_read(serdes_addr)
            log('Read %04x : %08x' % (serdes_addr, val))
    else:
        for lane in get_lane_list(args):
            for serdes_addr in range(args.addr, args.addr + args.range):
                val = phy.serdes_read(serdes_addr, lane=lane)
                log('Lane %d Read %04x : %08x' % (lane, serdes_addr, val))

def cli_write(args):
    phy = get_phy(0)
    if args.bus == 'raw':
        log('Write to %04x: %08x' % (args.addr, args.value))
        val = phy.serdes_write(args.addr, args.value, lane=0)
    else:
        for lane in get_lane_list(args):
            log('Write to Lane %d, %04x: %08x' % (lane, args.addr, args.value))
            val = phy.serdes_write(args.addr, args.value, lane=lane)

def cli_config(orig_args):
    phy = get_phy(0)
    for lane in get_lane_list(orig_args):
        args = copy.deepcopy(orig_args)  # for multi-lane calls, don't overwrite the referenced args
        verbose = args.verbose
        args.verbose = None
        args.lane = None
        args.func = None
        phy.cli_config(lane, verbose, args)

def cli_ber(args):
    phy = get_phy(0)
    for lane in get_lane_list(args):
        data_rate = 1e9 * speed_get(lane)
        phy.show_ber(lane, args.time, data_rate)

def cli_process(args):
    phy = get_phy(0)
    if args.verbose:
        orig_log_reg_ops = sierra.log
        sierra.log = True
    f = args.file
    f.seek(0)
    for line in f:
        time.sleep(.01)
        no_comment = line.split('//')[0].split('#')[0][:-1]
        splitcmd = no_comment.split()
        if args.verbose:
            log(line[:-1])

        if len(splitcmd) < 2:
            continue
        cmd = splitcmd[0].upper()
        addr = int(splitcmd[1], 0)
        if len(splitcmd) >= 3:
            val = int(splitcmd[2], 0)
        else:
            val = None

        if cmd == 'WRITE':
            phy.serdes_write(addr, val)
        elif cmd == 'READ':
            read_val = phy.serdes_read(addr)
            if val != None and read_val != val:
                log('**** Read 0x%04x: got 0x%04x, expected 0x%04x' % (addr, read_val, val))
        elif cmd == 'WAIT':
            time.sleep(addr / 1000.0)
        else:
            log("Unexpected cmd '%s' in line '%s'" % (cmd, line))
            return ifcs.IFCS_INVAL
    if args.verbose:
        sierra.log = orig_log_reg_ops

def add_parser(parser):
    parser.add_argument('--lane', type=parse_list, default=None)

    subparsers = parser.add_subparsers(help='All numerical arguments in hex')

    parser_status = subparsers.add_parser('status', help='show status')
    parser_status.set_defaults(func=cli_status)

    parser_read = subparsers.add_parser('read', help='read SerDes register')
    parser_read.add_argument('addr', type=Hex, help='address')
    parser_read.add_argument('--bus', '-b', type=str, choices=['serdes', 'raw'], default='serdes')
    parser_read.add_argument('--dry-run', '-d', dest='dry_run', action='store_true')
    parser_read.add_argument('--range', type=int, default=1, help='number of entries to read')
    parser_read.set_defaults(func=cli_read)

    parser_write = subparsers.add_parser('write', help='write SerDes register')
    parser_write.add_argument('addr', type=Hex, help='address')
    parser_write.add_argument('value', type=Hex, help='value')
    parser_write.add_argument('--bus', '-b', type=str, choices=['serdes', 'raw'], default='serdes')
    parser_write.add_argument('--dry-run', '-d', dest='dry_run', action='store_true')
    parser_write.set_defaults(func=cli_write)

    parser_creq = subparsers.add_parser('creq', help='CREQ debug')
    parser_creq.add_argument('diagidx', type=parse_list)
    parser_creq.set_defaults(func=cli_creq_diag)

    parser_deq = subparsers.add_parser('deq', help='DEQ debug')
    parser_deq.add_argument('diagidx', type=parse_list)
    parser_deq.set_defaults(func=cli_deq_diag)

    parser_eye = subparsers.add_parser('eye', help='Eye plot')
    parser_eye.add_argument('-C', '--collect', nargs='?', type=int, const=6, metavar='DEPTH', help='collect eye data (default depth 6)')
    parser_eye.add_argument('-p', '--plot', action='store_true', help='display eye plot')
    parser_eye.add_argument('-s', '--sizes', nargs='?', type=parse_list, default=None, const=[8, 12, 15],
                            help='print size at specified depths (default 8,12,15)')
    parser_eye.add_argument('-c', '--color', type=str.lower, choices=['gray', 'none'], default='normal')
    parser_eye.add_argument('-i', '--invert', action='store_true', help='invert color scale')
    parser_eye.add_argument('-S', '--save', type=argparse.FileType('w'), default=None, help='save data to file')
    parser_eye.add_argument('-v', '--verbose', action='store_true')
    parser_eye.add_argument('-q', '--quiet', action='store_true')
    parser_eye.add_argument('--cols', type=int, default=None, help='columns in textual plot')
    parser_eye.set_defaults(func=cli_eye)

    parser_bathtub = subparsers.add_parser('bathtub', help='Bathtub plot')
    parser_bathtub.add_argument('-H', '--horizontal', action='store_true', help='horizontal bathtub (default is vertical)')
    parser_bathtub.add_argument('-C', '--collect', nargs='?', type=int, const=7, metavar='DEPTH', help='collect bathtub data (default depth 7)')
    parser_bathtub.add_argument('-p', '--plot', nargs='?', type=int, default=None, const=14, metavar='DEPTH', help='plot bathtub [DEPTH: default 14]')
    parser_bathtub.add_argument('-s', '--sizes', nargs='?', type=parse_list, default=None, const=[8, 12, 15],
                            help='print size at specified depths (default 8,12,15)')
    parser_bathtub.add_argument('-S', '--save', type=argparse.FileType('w'), default=None, help='save data to file')
    parser_bathtub.add_argument('-v', '--verbose', action='store_true')
    parser_bathtub.add_argument('-q', '--quiet', action='store_true')
    parser_bathtub.add_argument('--cols', type=int, default=None, help='columns in textual plot')
    parser_bathtub.set_defaults(func=cli_bathtub)

    parser_ber = subparsers.add_parser('ber', help = 'show ber')
    parser_ber.add_argument('--time', type=int, default=5, help='maximum time for BER in seconds (def. 5)')
    parser_ber.set_defaults(func=cli_ber)

    parser_config = subparsers.add_parser('config', help='set configuration')
    tx_type_group = parser_config.add_mutually_exclusive_group(required=False)
    parser_config.add_argument('--pre1', nargs='?', type=int, const=1000, default=None, help='Pre1 Tap value (default: restore serdes-generated value))')
    parser_config.add_argument('--main', nargs='?', type=int, const=1000, default=None, help='Main Tap value (default: restore serdes-generated value))')
    parser_config.add_argument('--post1', nargs='?', type=int, const=1000, default=None, help='Post1 Tap value (default: restore serdes-generated value))')
    parser_config.add_argument('--tx-margin', dest='tx_margin', nargs='?', type=int, const=1000, default=None, help='Tx margin value (default: restore serdes-generated value))')
    tx_type_group.add_argument('--tx-test', dest='tx_test', type=str.upper, choices=['PRBS7', 'PRBS15', 'PRBS23', 'PRBS31', 'OFF'])
    parser_config.add_argument('--verbose', '-v', default=None, action='store_true')
    parser_config.add_argument('--rx-check', dest='rx_check', type=str.upper, choices=['PRBS7', 'PRBS15', 'PRBS23', 'PRBS31'])
    parser_config.set_defaults(func=cli_config)

    parser_process = subparsers.add_parser('process', help='process a serdes transaction log')
    parser_process.add_argument('file', type=argparse.FileType('r'), help='filename')
    parser_process.add_argument('--verbose', '-v', default=False, action='store_true')
    parser_process.set_defaults(func=cli_process)

# for direct use from python
def run_cmd(arglist):
    try:
        while '##' in arglist or '#' in arglist or '//' in arglist:
            arglist.pop()
        arglist = ['--help' if a == 'help' else a for a in arglist]  # replace any 'help' arguments with '--help'

        parser = argparse.ArgumentParser(prog='diagtest serdes pcie')
        add_parser(parser)
        args = parser.parse_args(arglist)
        rc = args.func(args)
        if rc == None:
            rc = ifcs.IFCS_SUCCESS
        return rc
    except ValueError as ex:
        log("Value Error: %s" % ":".join(ex.args))
    except Exception as ex:
        traceback.print_exc(file=sys.stdout)
        log("exception: ", type(ex).__name__, ex.args)
    except:
        log_dbg(1, "Error in serdes_pcie_tl5 run_cmd: {}".format(sys.exc_info()))

    return ifcs.IFCS_INVAL
