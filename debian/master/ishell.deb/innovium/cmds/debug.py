#-------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------

import shlex
import argparse
import itertools
import time
import json
import sys
from utils.log_utils import *
from utils.compat_util import *
from verbosity import *
from cmdmgr import Command
from ctypes import *
import sys
ifcs_ctypes=sys.modules['ifcs_ctypes']
from collections import OrderedDict
from ifcs_cmds.all import *
from ifcs_cmds.cli_types import *
from debug_encode import *
from print_table import PrintTable
 
ifcs_ctypes = sys.modules['ifcs_ctypes']

# Class implements Debug state dump related commands
class Debug(Command):
    def __init__(self, cli):
        self.cli = cli
        self.arg_list = []
        super(Debug, self).__init__()

        self.sub_cmds = {
            'ifcs': self.debug_ifcs,
            'device': self.debug_device,
            'cli': self.debug_cli,
 
            'help': self.help,
            '?': self.help
        }

        self.sub_device_cmds = {
            'pen': self.debug_device_pen,
 
        }

 
        self.sub_cli_cmds = {
            'show': {
                'summary': self.debug_cli_show_summary
            },
            'clear': {
                'counters': self.debug_cli_clear_counters
            }
        }
 
        self.show_debug_names = ['ifcs', 'device', 'cli']

    def __del__(self):
        return

    def validate_ifcs_args(self, args):
        # split the args
        arg_list = args.split()

        if arg_list[-2] == 'all' and len(arg_list) > 3:
            file_path = arg_list[-1].split('/')
            file_path = '/'.join(file_path[:-1])
            if os.path.isdir(file_path) and os.path.exists(file_path):
                arg_list = arg_list[:-1]
            else:
                raise KeyError(file_path + " Doesn't exist")

        # ensure length is atleast 3
        if len(arg_list) < 3:
            raise KeyError("Invalid command")

        # get all ifcs objs
        ifcsObjs = IfcsAll(self.cli)

        # api_class
        try:
            api_class = arg_list[2]
        except:
            raise KeyError("Invalid command")

        # dispatch
        try:
            dispatch = arg_list[-1]
            api_class_instance = arg_list[-2]
        except:
            raise KeyError("Invalid command")

        # all ifcs_obj_names
        obj_names = ifcsObjs.get_ifcs_obj_names()

        # validate if arg_list contains valid api_class
        if (len(arg_list) > 2) and ((api_class not in obj_names) and (api_class != "all" and api_class != "snapshot")):
            raise KeyError("Invalid Command")

        # if arg_list contains stats, ensure the api_class instance is provided
        if dispatch == 'stats' and ((api_class_instance == 'all') or (api_class_instance in obj_names)):
            raise KeyError("Invalid Command")

        # if arg_list doesn't contain stats, ensure that dispatch is obj_name
        if dispatch != 'stats' and dispatch != api_class and dispatch != 'mod':
            raise KeyError("Invalid command")

        return

    def parse_ifcs_args(self, args):
        # split the args
        arg_list = args.split()

        if arg_list[-2] == 'all' and len(arg_list) > 3:
            file_path = arg_list[-1].split('/')
            file_path = '/' + '/'.join(file_path[:-1])
            if os.path.isdir(file_path) and os.path.exists(file_path):
                arg_list = arg_list[:-1]
            else:
                raise KeyError(file_path + " Doesn't exist")

        # get the last arg
        last_arg = arg_list[-1]

        if last_arg == 'all' or last_arg == 'snapshot':
            dispatch = last_arg
        elif last_arg == 'stats':
            dispatch = last_arg
        else:
            dispatch = 'modules'

        return dispatch, args

    def run_cmd(self, args):
        log_dbg(1, "In Ifcs run")
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        try:
            rc = self.sub_cmds[self.arg_list[1]](args)
            return rc
        except (KeyError):
            log_dbg(
                1, "KeyError in debug [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
            return IFCS_INVAL
        except (ValueError):
            log_dbg(
                1, "ValueError in debug [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
            return IFCS_INVAL
        except BaseException:
            log_dbg(
                1, "OtherError in debug [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
            return IFCS_INVAL

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)
        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]
        elif remline == text:
            if 'ifcs' == cmd.rstrip():
                ifcsObjs = IfcsAll(self.cli)
                return [j.lower() for j in ifcsObjs.get_ifcs_obj_names()
                        if j.startswith(text)]
            elif 'device' == cmd.rstrip():
                return [
                    j for j in self.sub_device_cmds.keys() if j.startswith(text)]
            elif 'cli' == cmd.rstrip():
                return [
                    j for j in self.sub_cli_cmds.keys() if j.startswith(text)]
            else:
                return None
        else:
            try:
                return getattr(
                    self,
                    'complete_' +
                    cmd)(
                    cmd,
                    remline,
                    line,
                    text)
            except AttributeError:
                return None

    def complete_device(self, cmd, remline, line, text):
        if remline == 'decode':
            return [i.lower() for i in self.sub_device_decode_cmds.keys()]
        elif remline == 'restore':
            return [i.lower() for i in self.sub_device_restore_cmds.keys()]
        elif remline in self.sub_device_cmds.keys():
            log('Text = ' + text)
            return [i.lower()
                    for i in ['-ib', '-comp'] if i.lower().startswith(text)]
        elif remline.split()[1] in self.sub_device_cmds.keys():
            return [i.lower()
                    for i in ['-ib', '-comp'] if i.lower().startswith(text)]
        else:
            return [i.lower() for i in self.sub_device_cmds.keys()
                    if i.lower().startswith(text)]

    def complete_ifcs(self, cmd, remline, line, text):
        ifcsObjs = IfcsAll(self.cli)
        if remline == 'ifcs':
            return [i.lower() for i in ifcsObjs.keys()]
        else:
            return [i.lower() for i in ifcsObjs.keys().lower().startswith(text)]

    def complete_cli(self, cmd, remline, line, text):
        if remline in self.sub_cli_cmds:
            return compat_listkeys(self.sub_cli_cmds[remline])
        parts = remline.split()
        if len(parts) == 2 and parts[0] in self.sub_cli_cmds and text:
            return [i for i in self.sub_cli_cmds[parts[0]].keys()
                    if i.startswith(text)]
        return None

    def debug_snapshot(self, args):
        log('Generating ifcs state dump. This might take a while..')
        im_nmgr_wb_snapshot(self.cli.node_id)
        log('Saved IFCS State to '+ os.environ['IFCS_WB_FILE'])
        try:
            debug_encode([], [])
        except MemoryError as me:
            log_err("Out of memory : {}".format(sys.exc_info()))
        except Exception as e:
            log_err("Error occurred : {}".format(sys.exc_info()))


    def get_stats_dict_from_stats(self, ifcs_obj, obj):
        stats     = {}
        stats_list = ifcs_obj.stats_get(obj)
        # Decode the stat ids into stat names
        for stat_id in range(len(stats_list)):
            stats[ifcs_obj.statslist[stat_id].lower()] = int(
                stats_list[stat_id])
        return stats

    def debug_all_ifcs(self, args):
        log('Generating ifcs state dump. This might take a while..')

        outfile = ''
        arg_list = args.split()

        if arg_list[-2] == 'all' and len(arg_list) > 3:
            outfile = arg_list[-1]
            file_path = arg_list[-1].split('/')
            file_path = '/' + '/'.join(file_path[:-1])
            if os.path.isdir(file_path) and os.path.exists(file_path):
                outfile = arg_list[-1]
                arg_list = arg_list[:-1]
                args = ' '.join(arg_list)

        arg_split = args.split()
        arg_split.append('mod')
        args = ' '.join(arg_split)
        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            api_state = {}
            mod_state = {}
            state     = []
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                mod_state['module']  = ifcs_obj.getAllIfcsState(args)
            except:
                mod_state['module']  = {}
            state.append(mod_state)
            try:
                count = 0
                rc, all_objs = getattr(ifcs_obj, 'bulk_get_all_'+name+'_keys')()
                for count, obj in enumerate(all_objs):
                    obj_state = OrderedDict()
                    obj_state[name] = count
                    try:
                        obj_state['attributes'] = json.loads(ifcs_obj.getIfcsState(obj))
                    except:
                        obj_state['attributes'] = {}
                    try:
                        obj_state['stats'] = self.get_stats_dict_from_stats(ifcs_obj, obj)
                    except:
                        obj_state['stats'] = {}
                    state.append(obj_state)
            except Exception as e:
                exp_msg = "{}".format(e)
                if 'no attribute' in exp_msg:
                    obj_state = {}
                    obj_state['attributes'] = {}
                    obj_state['stats'] = {}
                    state.append(obj_state)
                else:
                    log_err(exp_msg)
                    return

            # Fill up the object
            api_state[name.capitalize()] = state
            all_state.append(api_state)

        if outfile:
            log('..Writing ifcs state dump to ' + outfile)
            with open(outfile, 'w') as f:
                f.write(json.dumps(all_state, indent=4, sort_keys=True))
                f.flush()
                f.close()
        log(json.dumps(all_state, indent=4, sort_keys=True))
        return IFCS_SUCCESS

    def debug_statlist_ifcs(self, args):

        # fetch ifcs all object
        arg_list     = args.split()
        ifcsObjs     = IfcsAll(self.cli)
        all_stats    = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        object_id    = int(arg_list[-2])
        object_name  = arg_list[-3]
        OBJ_NAME     = object_name.upper()

        # find the object in question
        for name in ifcsObjNames:
            if name.lower() != object_name:
                continue

            # found the object
            obj_state     = {}
            stats         = {}
            ifcs_obj      = ifcsObjs.get_ifcs_obj_from_name(name)
            object_handle = globals()['IFCS_HANDLE_%s' % (OBJ_NAME)](object_id)
            try:
                stats_list = ifcs_obj.stats_get(object_handle)
            except Exception as e:
                exp_msg = "{}".format(e)
                if 'no attribute' in exp_msg:
                    state = ''
                else:
                    log_err(exp_msg)
                    return

            # Decode the stat ids into stat names
            for stat_id in range(len(stats_list)):
                stats[ifcs_obj.statslist[stat_id].lower()] = int(
                    stats_list[stat_id])

            # Fill up the object
            obj_state[name.capitalize()] = hex(object_handle)
            obj_state['Stats']           = stats
            all_stats.append(obj_state)

        log(json.dumps(all_stats, indent=4, sort_keys=True))
        return IFCS_SUCCESS

    def debug_modlist_ifcs(self, args):
        log('Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()

        for name in ifcsObjNames:
            if name.lower() not in args:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                state = ifcs_obj.getAllIfcsState(args)
            except Exception as e:
                exp_msg = "{}".format(e)
                if 'no attribute' in exp_msg:
                    state = ''
                else:
                    log_err(exp_msg)
                    return
            obj_state[name.capitalize()] = state
            all_state.append(obj_state)

        log(json.dumps(all_state, indent=4, sort_keys=True))
        return IFCS_SUCCESS

    def debug_ifcs(self, args):
        log_dbg(1, "Debugging ifcs state ..")

        # check if api log is enabled. If so, bail
        if (self.is_api_log_enabled()):
            log("Please disable API logging and try again. Set IFCS_NODE_ATTR_API_LOG_ENABLE to FALSE..")
            log("Use cli 'ifcs set node api_log_enable 0' to disable API logging")
            return

        # setup the cmd dispatch dictionary
        dispatch_cmds = {
            'snapshot'  : self.debug_snapshot,
            'all'       : self.debug_all_ifcs,
            'modules'   : self.debug_modlist_ifcs,
            'stats'     : self.debug_statlist_ifcs,
        }

        # validate args
        try:
            self.validate_ifcs_args(args)
        except Exception as e:
            log_err("{}".format(e))
            return

        # parse the args
        try:
            dispatch, args = self.parse_ifcs_args(args)
        except Exception as e:
            log_err("{}".format(e))
            return

        # dispatch the command
        dispatch_cmds[dispatch](args)

    def debug_device(self, args):
        log_dbg(1, "Debugging device state ..")

        # check if api log is enabled. If so, bail
        if (self.is_api_log_enabled()):
            log("Please disable API logging and try again. Set IFCS_NODE_ATTR_API_LOG_ENABLE to FALSE..")
            log("Use cli 'ifcs set node api_log_enable 0' to disable API logging")
            return

        arg_list = args.split()

        if arg_list[2] not in self.sub_device_cmds.keys():
            log_err("Invalid command")
            return IFCS_INVAL

        self.sub_device_cmds[arg_list[2]](args)
        return IFCS_SUCCESS

    def debug_device_pen(self, args):
        log_dbg(1, "Debugging pen state..")
        """
            debug device pen -ib <ib-id> -comp <cmp-id>
            or
            debug device pen -ib <ib-id>
            or
            debug device pen -comp <cmp-id>
            or
            debug device pen
        """
        arg_list = args.split()

        if arg_list[2] != 'pen':
            log_err("Invalid command")
            return IFCS_INVAL

        parser = argparse.ArgumentParser(prog="debug")
        parser.add_argument("group")
        parser.add_argument("cmd")
        parser.add_argument("obj")

        ib_id = []
        if '-ib' in arg_list:
            parser.add_argument("-ib", nargs="+", type=int)

        cmp_id = []
        if '-comp' in arg_list:
            parser.add_argument("-comp", nargs="+", type=int)

        if 'internal' in arg_list:
            parser.add_argument("internal")
        parsed_res = parser.parse_args(arg_list)

        try:
            ib_id = parsed_res.ib
        except BaseException:
            pass

        try:
            cmp_id = parsed_res.comp
        except BaseException:
            pass

        try:
            if parsed_res.internal:
                debug_internal(cmp_id, ib_id)
                return
        except Exception as e:
            pass

        try:
            debug_encode(cmp_id, ib_id)
        except MemoryError as me:
            log_err("Out of memory : {}".format(sys.exc_info()))
        except Exception as e:
            log_err("Error occurred : {}".format(sys.exc_info()))
        return IFCS_SUCCESS

    def is_api_log_enabled(self):

        attr = (1 * ifcs_ctypes.ifcs_attr_t)()
        count = ctypes.c_uint32()
        attr[0].id = ifcs_ctypes.IFCS_NODE_ATTR_API_LOG_ENABLE

        rc = ifcs_ctypes.ifcs_node_attr_get(self.cli.node_id, 1, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t),
                                   pointer(count))
        if (rc != ifcs_ctypes.IFCS_SUCCESS) or (count.value <= 0):
            log_err("Failed to get node attr IFCS_NODE_ATTR_API_LOG_ENABLE")
            return False

        if (attr[0].value.data == ifcs_ctypes.IFCS_BOOL_TRUE):
            return True
        else:
            return False

        return False

 

    def debug_cli(self, args):
        log_dbg(1, "Debugging cli state ..")

        arg_list = args.split()
        sub_cmds = self.sub_cli_cmds
        for idx in range(2, len(arg_list)):
            if arg_list[idx] not in sub_cmds:
                log_err("Invalid command")
                return IFCS_INVAL
            if isinstance(sub_cmds[arg_list[idx]], dict):
                sub_cmds = sub_cmds[arg_list[idx]]
            else:
                return sub_cmds[arg_list[idx]](args)
        log_err("Invalid command")
        return IFCS_INVAL

    def debug_cli_show_summary(self, args):
        log_dbg(1, "Debugging cli show summary ..")
        self.cli.handle_debug_cli_show_summary()
        return IFCS_SUCCESS

    def debug_cli_clear_counters(self, args):
        log_dbg(1, "Debugging cli clear counters ..")
        self.cli.handle_debug_cli_clear_counters()
        return IFCS_SUCCESS

 

    #=========================================================
    # Extensive help
    #=========================================================

    ifcs_help_str = """
              Usage::
                    debug ifcs [all] [<api_name> [<handle> stats]]
              Command Options:
                    [all]                          - All IFCS objects with all their attributes
                                                     and values in JSON
                    [<api_name>]                   - All IFCS objects of <api_name> with all their
                                                     attributes and values in JSON
                    [<api_name> [<handle> stats]]  - Stats for IFCS object of <api_name> <handle> in JSON
    """
    cli_help_str = """
              Usage::
                    debug cli [show summary] [clear counters]
              Command Options:
                    [show summary]                 - CLI shell server information for troubleshooting
                    [clear counters]               - CLI shell server counters used for troubleshooting
    """
    device_help_str = """
              Usage::
                    debug device pen
              Command Options:
                    pen                            - Pen related debug dump
    """
    pen_help_str = """
              Usage::
                    debug device pen [-ib <ib list>] [-comp <comp-id list>]
              Command Options:
                    -ib                            - Indicates IB numbers follow
                    <ib list>                      - Single space delimited IB numbers e.g. -ib 0 1
                    -comp                          - Indicates component Id numbers follow
                    <comp-id list>                 - Single space delimited comp Id numbers e.g. -comp 1 3
                                                     Valid values are 1, 3, 5, 6, 7, 8, 16
    """
    default_help_str = """
              Usage:
                   debug ifcs all
                   debug ifcs <api_name>
                   debug ifcs <api_name> <handle> stats
                   debug cli show summary
                   debug cli clear counters
                   debug device pen
                   debug device pen -ib <ib list>
                   debug device pen -comp <compId list>
                   debug device pen -ib <ib list> -comp <comp-id list>
                   debug device pen -comp <comp-id list> -ib <ib list>
    """


    def help(self, args):
        self.help_menu = {
            'ifcs': self.ifcs_help_str,
            'cli':  self.cli_help_str,
            #ifndef 
            'device': self.device_help_str,
            'pen': self.pen_help_str,
            'help': self.default_help_str,
            '?': self.default_help_str,
            #else
            'device': self.device_help_internal_str,
            'pen': self.pen_help_str,
            'decode': self.decode_help_internal_str,
            'decode-pen': self.decodepen_help_internal_str,
            'tprof': self.tprof_help_internal_str,
            'tprof-show': self.tprof_show_help_internal_str,
            'tprof-clear': self.tprof_clear_help_internal_str,
            'help': self.default_help_internal_str,
            '?': self.default_help_internal_str,
            #endif
        }
        arg_list = shlex.split(args)



        if len(arg_list) >= 2:
            if arg_list[-1] in {'help', '?'}:
                if arg_list[-2] in self.help_menu:
                    log(self.help_menu[arg_list[-2]])
                    return

        log(self.help_menu['help'])

        return
