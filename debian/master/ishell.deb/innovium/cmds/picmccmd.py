#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2017
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

import argparse
import shlex
import time
import distutils

from testutil import util
from testutil import bincopy
from utils.compat_util import *
from verbosity import *
from cmdmgr import Command
from ctypes import *
from ifcs_ctypes import *
from testutil import picmc
from operator import add
from itertools import *
if COMPAT_PY2:
    from exceptions import IOError

# temporary, to provide backtrace on breakage
import sys,traceback

def parse_list(s):
    out = []
    for item in s.split(','):
        itemlist = item.split('-', 2)
        first = int(itemlist[0], 0)
        if len(itemlist) == 1:
            out.append(int(itemlist[0], 0))
        elif len(itemlist) == 2:
            last = int(itemlist[1], 0)
            for x in range(first, last+1):
                out.append(x)
        else:
            raise ValueError
    return out

default_ib = 0
default_pic = 0

class Picmc(Command):
    def __init__(self, cli):
        self.sub_cmds = {'read'        : self.cmd_read,
                         'write'       : self.cmd_write,
                         'load'        : self.cmd_load,
                         'run'         : self.cmd_run,
                         'reset'       : self.cmd_reset,
                         'status'      : self.cmd_status,
                         'dump'        : self.cmd_dump,
                         'log'         : self.cmd_log,
                         'port'        : self.cmd_port,
                         'lane'        : self.cmd_lane,
                         'default'     : self.cmd_default,
                         'help'        : self.help,
                         '?'           : self.help
                        }
        self.cli = cli

        super(Picmc, self).__init__()

    # ------------
    # Read command
    # ------------
    def cmd_read(self, arg_list):
        global default_ib, default_pic
        parser = argparse.ArgumentParser(prog='picmc read')
        parser.add_argument('--ib', type=int, default=default_ib)
        parser.add_argument('--pic', type=int, default=default_pic)
        # by default, argparse won't take hex.  Pass it a conversion func to allow hex/decimal/...
        parser.add_argument('addr', type=lambda x: int(x,0))
        parser.add_argument('count', type=lambda x: int(x,0), default=1)
        args = parser.parse_args(arg_list)

        addr = args.addr
        if addr < 0x01000000:
            addr += 0x80000000

        read_vals = picmc.picmc(ib=args.ib, pic=args.pic).read32(addr, args.count)

        # Take output 4 words at a time
        for group in compat_izip_longest(*[iter(read_vals)]*4):
            log_no_newline("%08x: " % (addr))
            addr += 4 * 4
            for val in group:
                 if val is not None:
                     log_no_newline("%08x " % (val))
            log("")

    # ------------
    # Write command
    # ------------
    def cmd_write(self, arg_list):
        global default_ib, default_pic
        parser = argparse.ArgumentParser(prog='picmc write')
        parser.add_argument('--ib', type=int, default=default_ib)
        parser.add_argument('--pic', type=int, default=default_pic)
        # by default, argparse won't take hex.  Pass it a conversion func to allow hex/decimal/...
        parser.add_argument('addr', type=lambda x: int(x,0))
        parser.add_argument('values', type=lambda x: int(x,0), nargs='+')
        args = parser.parse_args(arg_list)

        addr = args.addr
        if addr < 0x01000000:
            addr += 0x80000000

        picmc.picmc(ib=args.ib, pic=args.pic).write32(addr, args.values)

    # ------------
    # Load command
    # ------------
    def cmd_load(self, arg_list):
        global default_ib, default_pic
        parser = argparse.ArgumentParser(prog='picmc load')
        parser.add_argument('--ib', type=int, default=default_ib)
        parser.add_argument('--pic', type=int, default=default_pic)
        parser.add_argument('name', type=str)
        args = parser.parse_args(arg_list)

        pmc = picmc.picmc(ib=args.ib, pic=args.pic)
        pmc.set_resets(1, 0)
        pmc.load(args.name)

    # ------------
    # Reset command
    # ------------
    def cmd_reset(self, arg_list):
        global default_ib, default_pic
        parser = argparse.ArgumentParser(prog='picmc reset')
        parser.add_argument('--ib', type=int, default=default_ib)
        parser.add_argument('--pic', type=int, default=default_pic)
        parser.add_argument('--uncore', type=lambda x: distutils.util.strtobool(x), default="off")
        parser.add_argument('value', type=lambda x: distutils.util.strtobool(x), nargs='?', default="on")
        args = parser.parse_args(arg_list)

        picmc.picmc(ib=args.ib, pic=args.pic).set_resets(args.value, args.uncore)

    # ------------
    # Status command
    # ------------
    def cmd_status(self, arg_list):
        global default_ib, default_pic
        parser = argparse.ArgumentParser(prog='picmc status')
        parser.add_argument('--ib', type=int, default=default_ib)
        parser.add_argument('--pic', type=int, default=default_pic)
        parser.add_argument('--verbose', '-v', action="store_true")
        args = parser.parse_args(arg_list)

        status = picmc.picmc(ib=args.ib, pic=args.pic).reset_status()
        if status[0] or status[1]:
            offon = ['Off', 'On']
            log("Core Reset %s, Uncore Reset %s" % (offon[status[0]], offon[status[1]]))
        else:
            mbox = picmc.picmc(ib=args.ib, pic=args.pic).read_mbox()
            log("Core: Running  Code: %s" % mbox.status)
            if mbox.status == 'Fault':
                fault = picmc.picmc(ib=args.ib, pic=args.pic).read_fault()
                log("EPC: %08x : %s" % (fault.epc, fault.cause))
                log("Badaddr: %08x  Status: %08x" % (fault.badaddr, fault.status))
                for i in range(0,32):
                    log_no_newline("x%-2d: %08x" % (i, fault.reg[i]))
                    if i % 4 == 3:
                        log("")
                    else:
                        log_no_newline("   ")
            if args.verbose:
                log(mbox)

    def cmd_log(self, arg_list):
        global default_ib, default_pic
        parser = argparse.ArgumentParser(prog='picmc log')
        parser.add_argument('--ib', type=int, default=default_ib)
        parser.add_argument('--pic', type=int, default=default_pic)
        parser.add_argument('--port', type=parse_list, default='0-7')
        parser.add_argument('--lane', type=parse_list, default='0-7')
        parser.add_argument('subcmd', nargs='?', choices=['show', 'set', 'get'], default='show')
        args = parser.parse_args(arg_list)

        pmc = picmc.picmc(ib=args.ib, pic=args.pic)
        if args.subcmd == 'show':
            log = pmc.read_log()
            for e in log:
                # could/should restrict lines based on port/lane
                log(e)
        elif args.subcmd == 'set':
            pmc.log_mask_set(args.port, args.lane)
        elif args.subcmd == 'get':
            ports, lanes = pmc.log_mask_get()
            log('Ports:', ports, ' Lanes:', lanes)

    # ------------
    # Run command
    # ------------
    def cmd_run(self, arg_list):
        global default_ib, default_pic
        parser = argparse.ArgumentParser(prog='picmc run')
        parser.add_argument('--ib', type=int, default=default_ib)
        parser.add_argument('--pic', type=int, default=default_pic)
        parser.add_argument('name', type=str, nargs='?', default='')
        args = parser.parse_args(arg_list)

        pmc = picmc.picmc(ib=args.ib, pic=args.pic)
        pmc.set_resets(1, 0)
        if args.name != '':
            pmc.load(args.name)
        pmc.set_resets(0, 0)

    # ------------
    # Dump command
    # ------------
    def cmd_dump(self, arg_list):
        global default_ib, default_pic
        parser = argparse.ArgumentParser(prog='picmc dump')
        parser.add_argument('--ib', type=int, default=default_ib)
        parser.add_argument('--pic', type=int, default=default_pic)
        # by default, argparse won't take hex.  Pass it a conversion func to allow hex/decimal/...
        parser.add_argument('addr', type=lambda x: int(x,0))
        parser.add_argument('bytecount', type=lambda x: int(x,0), default=1)
        parser.add_argument('filename', type=str, nargs='?', default='')
        args = parser.parse_args(arg_list)

        addr = args.addr
        if addr < 0x01000000:
            addr += 0x80000000

        num_bytes = args.bytecount
        filename = args.filename

        word_data = picmc.picmc(ib=args.ib, pic=args.pic).read32(addr, (num_bytes + 3) / 4)  # round up if not on a word boundary
        bytedata = bytearray()
        for word in word_data:
            bytedata.append(word & 0xff)
            bytedata.append((word >> 8)  & 0xff)
            bytedata.append((word >> 16) & 0xff)
            bytedata.append((word >> 24) & 0xff)

        # if not on a word boundary, truncate
        bytedata = bytedata[:num_bytes]

        binfile = bincopy.BinFile()
        binfile.add_binary(bytedata, addr)

        if filename == '':
            log(binfile.as_hexdump())
        else:
            newfile = open(filename, 'wb')
            if filename.lower().endswith('srec'):
                newfile.write(binfile.as_srec())
            elif filename.lower().endswith('ihex'):
                newfile.write(binfile.as_ihex())
            else:
                newfile.write(bytedata)

    # ------------
    # Port command
    # ------------
    ###  Should have sub-commands.  For now, just "port show"
    def cmd_port(self, arg_list):
        global default_ib, default_pic
        parser = argparse.ArgumentParser(prog='picmc port')
        parser.add_argument('--ib', type=int, default=default_ib)
        parser.add_argument('--pic', type=int, default=default_pic)
        parser.add_argument('--ports', type=parse_list, default='0-7')
        parser.add_argument('subcmd', choices=['show', 'config', 'up', 'anlt', 'an', 'lt'], default='show')
        parser.add_argument('--mode', type=lambda x: int(x,0), default=-1)
        parser.add_argument('--link_fail_timer_period', type=lambda x: int(x,0), default=79687500)
        parser.add_argument('--serdes_ctrl', type=lambda x: int(x,0), default=1)
        parser.add_argument('--base_page', type=lambda x: int(x,0), default=0x000038004001)
        args = parser.parse_args(arg_list)

        pmc = picmc.picmc(ib=args.ib, pic=args.pic)
        if args.subcmd == 'show':
            mbox = pmc.read_mbox()
            log("State: ", mbox.port_state)
            log("Error: ", mbox.port_error)
        elif args.subcmd == 'config':
            if args.mode == -1:
                # show the config, don't set it
                mbox = pmc.read_mbox()
                for p in args.ports:
                    log(mbox.port_cfg[p])
            else:
                lanes_per_port = picmc.mode_list[args.mode].lanes
                exclude = []
                for p in sorted(args.ports):
                    if p in exclude:
                        continue
                    pmc.port_config_set(p, lanes_per_port, args.mode, args.link_fail_timer_period, args.serdes_ctrl, args.base_page)
                    exclude += compat_listrange(p, p + lanes_per_port)
                pmc.fw_cmd(picmc.FW_CMD_UPDATE_PORTS)
                log('Set cmd to %d' % picmc.FW_CMD_UPDATE_PORTS)
        else:
            if args.subcmd == 'lt':
                port_cmd = picmc.PORT_CMD_LT_ONLY
            elif args.subcmd == 'an':
                port_cmd = picmc.PORT_CMD_AN_ONLY
            elif args.subcmd == 'anlt' or args.subcmd == 'up':
                port_cmd = picmc.PORT_CMD_AN_LT
            elif args.subcmd == 'down':
                port_cmd = picmc.PORT_CMD_DOWN
            for p in sorted(args.ports):
                is_primary, mode = pmc.port_config_get(p)
                if is_primary:
                    pmc.port_cmd(p, port_cmd)
            pmc.fw_cmd(picmc.FW_CMD_DO_PORT_CMDS)

    # ------------
    # Lane command
    # ------------
    def cmd_lane(self, arg_list):
        global default_ib, default_pic
        parser = argparse.ArgumentParser(prog='picmc lane')
        parser.add_argument('--ib', type=int, default=default_ib)
        parser.add_argument('--pic', type=int, default=default_pic)
        parser.add_argument('--lanes', type=parse_list, default='0-7')
        parser.add_argument('subcmd', choices=['show', 'config'], default='show')
        parser.add_argument('values', type=lambda x: int(x,0), nargs='*')
        args = parser.parse_args(arg_list)

        if args.subcmd == 'show':
            lanes = picmc.picmc(ib=args.ib, pic=args.pic).read_lanes()
            lane_num = 0
            for l in lanes:
                if lane_num in args.lanes:
                    log("Lane %d:" % lane_num)
                    log("  PC: 0x%08x (Instr %d of Prog 0x%08x) APB Busy: %d   Run State: %d   Stage: %d  Tries: %d Mem: 0x%04x" % (
                        l.pc, (l.pc - l.startpc)/8, l.startpc, l.apb_busy_count, l.run_state, l.stage, l.verify_try_count, l.debug_mem))
                    if l.run_state != 0 and l.op != None:
                        log("  ", l.op)
                lane_num = lane_num + 1

        elif args.subcmd == 'config':
            pmc = picmc.picmc(ib=args.ib, pic=args.pic)
            for lane_num in args.lanes:
                if len(args.values) > 0:
                    pmc.lane_config_set(lane_num, args.values)
                else:
                    log("Lane %d: " % lane_num, pmc.lane_config_get(lane_num))

    # ------------
    # Default command
    # ------------
    def cmd_default(self, arg_list):
        global default_ib, default_pic
        parser = argparse.ArgumentParser(prog='picmc default')
        parser.add_argument('--ib', type=int, default=-1)
        parser.add_argument('--pic', type=int, default=-1)
        args = parser.parse_args(arg_list)
        if args.ib >= 0:
            default_ib = args.ib
        if args.pic >= 0:
            default_pic = args.pic
        log('Default IB: %d, PIC: %d' % (default_ib, default_pic))

    def run_cmd(self, args):
        arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(arg_list))

        # check that sub-command exists:
        try:
            self.sub_cmds[arg_list[1]]
        except:
            self.help(args)
            return

        try:
            return self.sub_cmds[arg_list[1]](arg_list[2:])
        except Exception as ex:
            traceback.print_exc(file=sys.stdout)
            log("run cmd: ", type(ex).__name__, ex.args)
            self.cli.error()
            self.help(args)
            return
        except SystemExit as ex:
            pass   # argparse threw error or parsed '--help', and printed a msg already
        except:
            log("Unexpected error:", sys.exc_info()[0])
            #self.cli.error()
            #self.help(args)
        return

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def help(self, args):
        log("Usage: ")
        log("picmc read <addr> [count]                  - Read <count> words from PICMC TIM")
        log("picmc dump <addr> <len> [filename]         - Dump <len> bytes from PICMC TIM")
        log("picmc write <addr> <val1> [<val2> ...]     - Write words to PICMC TIM")
        log("picmc load <filename>                      - Load PICMC TCM from SREC file")
        log("picmc reset [--noncore (on|off)] (on|off)  - Set PICMC reset state")
        log("picmc status                               - Shows status of PICMC Resets")
        log("picmc run <filename>                       - Load, then start execution")
        log("picmc port                                 - Shows status of PICMC Port FSMs")
        log("picmc log                                  - Print event log")
        log("picmc default [--ib <M>] [--pic <N>]       - Set the default IB and PIC")
