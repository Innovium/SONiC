#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2016
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

import sys
import time
import shlex
from cmdmgr import Command
from utils.compat_util import *
from verbosity import *
from print_table import PrintTable
from ctypes import *
ifcs_ctypes = sys.modules['ifcs_ctypes']

global devport_list

# Class implements Port related command
class Port(Command):
    def __init__(self, cli):
        self.sub_cmds = {'info'        : self.info,
                         'loopback'    : self.loopback,
                         'sig_det_mode': self.sig_det_mode,
                         'enable'      : self.enable,
                         'disable'     : self.enable,
                         'lt_enable'   : self.enable,
                         'lt_disable'  : self.enable,
                         'an_enable'   : self.enable,
                         'an_disable'  : self.enable,
                         'create'      : self.create,
                         'delete'      : self.delete,
                         'status'      : self.status,
                         'debug'       : self.debug,
                         'dbg'         : self.dbg,
                         'tx_eq'       : self.tx_eq,
                         'help'        : self.help,
                         '?'           : self.help,
                         'pdinfo'      : self.pdinfo,
                         'cut_through_enable' : self.cut_through,
                         'cut_through_disable' : self.cut_through,
                         'admin_st_toggle_test': self.admin_st_toggle_test
                        }
        self.cli = cli
        self.arg_list = []
        self.pi = []
        self.active_node = -1

    def set_active_node(self, node_id):
        self.active_node = node_id
        log("Port: NodeId: ", node_id)

    def run_cmd(self, args):
        log_dbg(1, "in Port run")
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        try:
            return self.sub_cmds[self.arg_list[1]](args)
        except (KeyError):
            log_dbg(
                1, "KeyError in port [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
        except (ValueError):
            log_dbg(
                1, "ValueError in port [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
        except:
            log_dbg(
                1, "OtherError in port [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
        return

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def get_ifcs_devport_type(self, devport_type):
        if devport_type == 'eth':
            return ifcs_ctypes.IFCS_DEVPORT_TYPE_ETH

        if devport_type == 'il':
            return ifcs_ctypes.IFCS_DEVPORT_TYPE_IL

        if devport_type == 'mgmt':
            return ifcs_ctypes.IFCS_DEVPORT_TYPE_AUX

        if devport_type == 'cpu':
            return ifcs_ctypes.IFCS_DEVPORT_TYPE_CPU

        return ifcs_ctypes.IFCS_DEVPORT_TYPE_ETH

    def get_ifcs_devport_speed(self, devport_speed):
        if devport_speed == '1':
            return ifcs_ctypes.IFCS_DEVPORT_SPEED_1G

        if devport_speed == '10':
            return ifcs_ctypes.IFCS_DEVPORT_SPEED_10G

        if devport_speed == '25':
            return ifcs_ctypes.IFCS_DEVPORT_SPEED_25G

        if devport_speed == '40':
            return ifcs_ctypes.IFCS_DEVPORT_SPEED_40G

        if devport_speed == '50':
            return ifcs_ctypes.IFCS_DEVPORT_SPEED_50G

        if devport_speed == '100':
            return ifcs_ctypes.IFCS_DEVPORT_SPEED_100G

        if devport_speed == '200':
            return ifcs_ctypes.IFCS_DEVPORT_SPEED_200G

        if devport_speed == '400':
            return ifcs_ctypes.IFCS_DEVPORT_SPEED_400G

        return ifcs_ctypes.IFCS_DEVPORT_SPEED_100G

    def get_ifcs_devport_isg(self, isg):
        if isg == 0:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG0
        if isg == 1:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG1
        if isg == 2:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG2
        if isg == 3:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG3
        if isg == 4:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG4
        if isg == 5:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG5
        if isg == 6:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG6
        if isg == 7:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG7
        if isg == 8:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG8
        if isg == 9:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG9
        if isg == 10:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG10
        if isg == 11:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG11
        if isg == 12:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG12
        if isg == 13:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG13
        if isg == 14:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG14
        if isg == 15:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG15
        if isg == 16:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG16
        if isg == 17:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG17
        if isg == 18:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG18
        if isg == 19:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG19
        if isg == 20:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG20
        if isg == 21:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG21
        if isg == 22:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG22
        if isg == 23:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG23
        if isg == 24:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG24
        if isg == 25:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG25
        if isg == 26:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG26
        if isg == 27:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG27
        if isg == 28:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG28
        if isg == 29:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG29
        if isg == 30:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG30
        if isg == 31:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_ISG31
        if isg == 32:
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_GROUP_MSER0

    def get_ifcs_devport_fec(self, fec_mode):
        if fec_mode == 'KR':
            return ifcs_ctypes.IFCS_DEVPORT_FEC_MODE_KR

        if fec_mode == 'KP':
            return ifcs_ctypes.IFCS_DEVPORT_FEC_MODE_KP

        if fec_mode == 'FC':
            return ifcs_ctypes.IFCS_DEVPORT_FEC_MODE_FC

        if fec_mode == 'NONE':
            return ifcs_ctypes.IFCS_DEVPORT_FEC_MODE_NONE

        return ifcs_ctypes.IFCS_DEVPORT_FEC_MODE_KR

    def get_devport_enum_type(self, devport_enum):
        if devport_enum == '0':
            return 'ETH'

        if devport_enum == '1':
            return 'AUX'

        if devport_enum == '2':
            return 'CPU'

        if devport_enum == '3':
            return 'IL'

        if devport_enum == '4':
            return 'RECIRC'

        return 'NONE'

    def get_devport_enum_speed(self, devport_enum):
        if devport_enum == '10':
            return '1G'

        if devport_enum == '1':
            return '10G'

        if devport_enum == '2':
            return '25G'

        if devport_enum == '3':
            return '40G'

        if devport_enum == '4':
            return '50G'

        if devport_enum == '5':
            return '100G'

        if devport_enum == '6':
            return '200G'

        if devport_enum == '7':
            return '400G'

        return 'NONE'

    def get_devport_enum_fec(self, devport_enum):
        if devport_enum == '1':
            return 'KRFEC'

        if devport_enum == '2':
            return 'KPFEC'

        if devport_enum == '3':
            return 'FCFEC'

        return 'NOFEC'

    def get_devport_enum_loopback(self, devport_enum):
        if devport_enum == '1':
            return 'PCS'

        if devport_enum == '2':
            return 'PMA'

        if devport_enum == '3':
            return 'REMOTE_LPBK'

        return 'NONE'

    def get_devport_enum_oper(self, devport_enum):
        if devport_enum == '1':
            return 'INITED'

        if devport_enum == '2':
            return 'DISABLED'

        if devport_enum == '3':
            return 'ENABLED'

        if devport_enum == '4':
            return 'AN_COMPLETE'

        if devport_enum == '5':
            return 'LINK_UP'

        if devport_enum == '6':
            return 'BUSY'

        return 'UINITED'

    def create(self, args):
        log("devport create")

        self.arg_list.pop(0)

        args_list = args.split()

        if len(args_list) < 10:
            log("Invalid number of arguments.")
            log("port create <devport> <type> <num_lanes> <start_lane> <speed> " \
                   "<isg> <fec> <sysport> <tx_pll_bw> - ifcs port create\n")
            return

        devport             = c_uint32(int(args_list[2]))
        devport_type_input  = args_list[3]
        num_lanes           = c_uint32(int(args_list[4]))
        start_lane          = c_uint32(int(args_list[5]))
        devport_speed_input = args_list[6]
        isg_input           = int(args_list[7])
        fec_mode_input      = args_list[8]
        sysport             = int(args_list[9])

        if len(args_list) == 11:
            tx_pll_bw           = int(args_list[10], 16)

        rc = ifcs_ctypes.ifcs_status_t()

        node_id = self.cli.node_id
        attr_count = 8
        attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

        devport_type  = self.get_ifcs_devport_type(devport_type_input)
        devport_speed = self.get_ifcs_devport_speed(devport_speed_input)
        fec_mode      = self.get_ifcs_devport_fec(fec_mode_input)
        isg           = self.get_ifcs_devport_isg(isg_input)

        sysport_handle = ifcs_ctypes.ifcs_handle_t()
        sysport_handle = ifcs_ctypes.IFCS_HANDLE_SYSPORT(sysport)

        attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_TYPE;
        attr_list_p[0].value.u32 = devport_type;

        attr_list_p[1].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_NUM_LANES;
        attr_list_p[1].value.u32 = num_lanes;

        attr_list_p[2].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_START_LANE;
        attr_list_p[2].value.u32 = start_lane;

        attr_list_p[3].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SPEED;
        attr_list_p[3].value.u32 = devport_speed;

        attr_list_p[4].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SERDES_GROUP;
        attr_list_p[4].value.u32 = isg;

        attr_list_p[5].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_FEC_MODE;
        attr_list_p[5].value.u32 = fec_mode;

        attr_list_p[6].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SYSPORT;
        attr_list_p[6].value.handle = sysport_handle;

        if len(args_list) == 11:
            attr_list_p[7].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_TX_PLL_BW_FREQ;
            attr_list_p[7].value.handle = tx_pll_bw;
        else:
            attr_count = 7

        rc = ifcs_ctypes.ifcs_devport_create (node_id,
                                  devport,
                                  attr_count,
                                  compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));

        assert rc == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during port create:" +\
                str(devport)

        log("create done")

    def delete(self, args):

        self.arg_list.pop(0)

        args_list = args.split()

        log("Port " + args_list[1])

        if len(args_list) < 3:
            log("Usage: " + args_list[0] + " " + args_list[1] + " <devport>")
            return

        devport = c_uint32(int(args_list[2]))

        rc = ifcs_ctypes.ifcs_status_t()

        node_id = self.cli.node_id

        rc = ifcs_ctypes.ifcs_devport_delete (node_id, devport);

        assert rc == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during port delete:" +\
                str(port)

        log("Port " + args_list[1] + " done")

    def get_max_devport(self, node_id=0):
        #Do get all devport to figure out max devports configured
        def myCallback(node_id, arg, attr_count, attr_list, user_data):

            devport = arg

            devport_list.append(devport)
        devport_list = []

        callback_type = CFUNCTYPE(
            ifcs_ctypes.UNCHECKED(None),
            ifcs_ctypes.ifcs_node_id_t,
            ifcs_ctypes.ifcs_devport_t,
            c_uint32,
            POINTER(ifcs_ctypes.ifcs_attr_t),
            POINTER(None))
        callback = callback_type(myCallback)

        try:
            rc = ifcs_ctypes.ifcs_devport_get_all(node_id, 0, None, compat_funcPointer(callback, ifcs_ctypes.ifcs_devport_user_cb_t), None, None)
            if ( rc != ifcs_ctypes.IFCS_SUCCESS):
                log("Failed to get all devport rc: {0}".format(rc))
        except:
            log("In except of devport get_all")
            pass
        # return excluding CPU port
        return (len(devport_list) - 1)


    def enable(self, args):
        self.arg_list.pop(0)
        en = self.arg_list.pop(0)
        res = self.arg_list.pop(0)

        max_dev_port = self.get_max_devport()
        max_devport_range = "1-2"
        if max_dev_port:
            max_devport_range = "1-%d"%(max_dev_port)

        if res == 'all':
            # Port range not given, default to all ports
            devport_arg = max_devport_range
            devport_arg_list = max_devport_range.split(",")
        else:
            # Use given devport range
            try:
                devport_arg = res
                devport_arg_list = res.split(",")
            except:
                devport_arg = max_devport_range
                devport_arg_list = max_devport_range.split(",")

        # Allocate run's data object which saves config
        devport_list = []

        for i, dp in enumerate(devport_arg_list):
            if '-' in dp:
                dp_range = devport_arg.split(",")[i].split("-")
                for j in range(int(dp_range[0]), int(dp_range[1]) + 1):
                    devport_list.append(j)
            else:
                devport_list.append(int(dp))
        try:
            # Enable/Disable all the ports
            if en == 'enable':
                devport_attr_ct = 1
                devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()

                devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE;
                devport_attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_TRUE;
            elif en == 'lt_enable':
                devport_attr_ct = 1
                devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()

                devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LINK_TRAINING;
                devport_attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_TRUE;
            elif en == 'lt_disable':
                devport_attr_ct = 1
                devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()

                devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LINK_TRAINING;
                devport_attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE;
            elif en == 'an_enable':
                devport_attr_ct = 1
                devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()

                devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_AUTO_NEG;
                devport_attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_TRUE;
            elif en == 'an_disable':
                devport_attr_ct = 1
                devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()

                devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_AUTO_NEG;
                devport_attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE;
            else:
                devport_attr_ct = 1
                devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()

                devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE;
                devport_attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE;

            for port in devport_list:
                if (port == 0 or (port >= 513 and port <=518)):
                    continue
                rc = ifcs_ctypes.ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t))
                assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                    "ERR during port admin disable:" + str(port)
        except:
                log("Hit except (Devport enable) config")


    def loopback(self, args):
        log("loopback set")
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        res = self.arg_list.pop(0)

        args_list = args.split()

        max_dev_port = self.get_max_devport()
        max_devport_range = "1-2"
        if max_dev_port:
            max_devport_range = "1-%d"%(max_dev_port)

        if res == 'all':
            # Port range not given, default to all ports
            devport_arg = max_devport_range
            devport_arg_list = max_devport_range.split(",")
        else:
            # Use given devport range
            try:
                devport_arg = res
                devport_arg_list = res.split(",")
            except:
                devport_arg = max_devport_range
                devport_arg_list = max_devport_range.split(",")

        # Allocate run's data object which saves config
        devport_list = []

        for i, dp in enumerate(devport_arg_list):
            if '-' in dp:
                dp_range = devport_arg.split(",")[i].split("-")
                for j in range(int(dp_range[0]), int(dp_range[1]) + 1):
                    devport_list.append(j)
            else:
                devport_list.append(int(dp))

        loopback = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_NONE

        if len(args_list) == 4:
            if args_list[3] == 'PCS':
                loopback = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_PCS
            elif args_list[3] == 'PMA':
                loopback = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_PMA
            elif args_list[3] == 'REMOTE':
                loopback = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_REMOTE_LPBK

        try:
            for port in devport_list:
                if (port == 0 or (port >= 513 and port <=518)):
                    continue
                rc = ifcs_ctypes.ifcs_status_t()

                node_id = self.cli.node_id
                attr_count = 1
                attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

                attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LOOPBACK;
                attr_list_p[0].value.u32 = loopback;

                rc = ifcs_ctypes.ifcs_devport_attr_set(node_id, port, attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t))
                assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                    "ERR during port loopback set:" + str(port)
        except:
                log("Hit except (Devport loopback) config")

    def sig_det_mode(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        res = self.arg_list.pop(0)

        args_list = args.split()

        max_dev_port = self.get_max_devport()
        max_devport_range = "1-2"
        if max_dev_port:
            max_devport_range = "1-%d"%(max_dev_port)

        if res == 'all':
            # Port range not given, default to all ports
            devport_arg = max_devport_range
            devport_arg_list = max_devport_range.split(",")
        else:
            # Use given devport range
            try:
                devport_arg = res
                devport_arg_list = res.split(",")
            except:
                devport_arg = max_devport_range
                devport_arg_list = max_devport_range.split(",")

        # Allocate run's data object which saves config
        devport_list = []

        for i, dp in enumerate(devport_arg_list):
            if '-' in dp:
                dp_range = devport_arg.split(",")[i].split("-")
                for j in range(int(dp_range[0]), int(dp_range[1]) + 1):
                    devport_list.append(j)
            else:
                devport_list.append(int(dp))

        flag = ifcs_ctypes.IFCS_DEVPORT_SIGNAL_DETECT_MODE_MODE1

        if len(args_list) == 4:
            if args_list[3] == '1':
                flag = ifcs_ctypes.IFCS_DEVPORT_SIGNAL_DETECT_MODE_MODE2

        try:
            for port in devport_list:
                if (port == 0 or (port >= 513 and port <=518)):
                    continue
                rc = ifcs_ctypes.ifcs_status_t()

                node_id = self.cli.node_id
                attr_count = 1
                attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

                attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SIG_DET_MODE;
                attr_list_p[0].value.u32 = flag;

                rc = ifcs_ctypes.ifcs_devport_attr_set(node_id, port, attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t))
                assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                    "ERR during sig det mode set:" + str(port)
        except:
                log("Hit except (Sig det mode) config")

    def info(self, args):
        self.arg_list.pop(0)

        ret = ifcs_ctypes.ifcs_status_t()
        args_list = args.split()

        dp_list = []

        table = PrintTable()
        table.add_row(['devport', 'type', 'isg', 'speed', 'fec', 'num_lanes', 'start_lane', 'loopback', 'auto_neg', 'link_training', 'oper_state', 'admin_state', 'link_status'])
        if (len(args_list) == 3):
            devport = c_uint32(int(args_list[2]))
            dp_list.append(devport)
            port_range = 1
        else:
            dp_list = self.getAlldevport()
            dp_list.sort()
            port_range = len(dp_list)

        for i in range(port_range):
            ret = ifcs_ctypes.ifcs_status_t()
            attr = ifcs_ctypes.ifcs_attr_t()
            actual_count = c_uint32(0)

            attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_TYPE
            ret = ifcs_ctypes.ifcs_devport_attr_get(0, dp_list[i], 1, pointer(attr),
                                    pointer(actual_count))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
            port_type = self.get_devport_enum_type(str(attr.value.u32))

            attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SERDES_GROUP
            ret = ifcs_ctypes.ifcs_devport_attr_get(0, dp_list[i], 1, pointer(attr),
                                    pointer(actual_count))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
            serdes_group = str(attr.value.u32 - 1)

            attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SPEED
            ret = ifcs_ctypes.ifcs_devport_attr_get(0, dp_list[i], 1, pointer(attr),
                                    pointer(actual_count))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
            speed = self.get_devport_enum_speed(str(attr.value.u32))

            attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_FEC_MODE
            ret = ifcs_ctypes.ifcs_devport_attr_get(0, dp_list[i], 1, pointer(attr),
                                    pointer(actual_count))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
            fec_mode = self.get_devport_enum_fec(str(attr.value.u32))

            attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_NUM_LANES
            ret = ifcs_ctypes.ifcs_devport_attr_get(0, dp_list[i], 1, pointer(attr),
                                    pointer(actual_count))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
            num_lanes = str(attr.value.u32)

            attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_START_LANE
            ret = ifcs_ctypes.ifcs_devport_attr_get(0, dp_list[i], 1, pointer(attr),
                                    pointer(actual_count))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
            start_lane = str(attr.value.u32)

            attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LOOPBACK
            ret = ifcs_ctypes.ifcs_devport_attr_get(0, dp_list[i], 1, pointer(attr),
                                    pointer(actual_count))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
            loopback = self.get_devport_enum_loopback(str(attr.value.u32))

            attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_AUTO_NEG
            ret = ifcs_ctypes.ifcs_devport_attr_get(0, dp_list[i], 1, pointer(attr),
                                    pointer(actual_count))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
            auto_neg = str(attr.value.u32)

            attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LINK_TRAINING
            ret = ifcs_ctypes.ifcs_devport_attr_get(0, dp_list[i], 1, pointer(attr),
                                    pointer(actual_count))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
            link_training = str(attr.value.u32)

            attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_OPER_STATE
            ret = ifcs_ctypes.ifcs_devport_attr_get(0, dp_list[i], 1, pointer(attr),
                                    pointer(actual_count))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
            oper_state = self.get_devport_enum_oper(str(attr.value.u32))

            attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE
            ret = ifcs_ctypes.ifcs_devport_attr_get(0, dp_list[i], 1, pointer(attr),
                                    pointer(actual_count))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
            admin_state = str(attr.value.u32)

            attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LINK_STATUS
            ret = ifcs_ctypes.ifcs_devport_attr_get(0, dp_list[i], 1, pointer(attr),
                                    pointer(actual_count))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "port attr get failed : ret = [" + str(ret) + "]"
            link_status = str(attr.value.u32)

            if (len(args_list) == 3):
                table.add_row([dp_list[i].value, port_type, serdes_group, speed, fec_mode, num_lanes, start_lane, loopback, auto_neg, link_training, oper_state, admin_state, link_status])
            else:
                table.add_row([dp_list[i], port_type, serdes_group, speed, fec_mode, num_lanes, start_lane, loopback, auto_neg, link_training, oper_state, admin_state, link_status])

        table.print_table(brief=True)
        table.reset_table()

        return

    def myCallback(self, node_id, arg, attr_count, attr_list, user_data):
        global devport_list
        devport = arg
        devport_list.append(devport)

    def getAlldevport(self):
        global devport_list

        devport_list = []
        callback_type = CFUNCTYPE(
            ifcs_ctypes.UNCHECKED(None),
            ifcs_ctypes.ifcs_node_id_t,
            ifcs_ctypes.ifcs_devport_t,
            c_uint32,
            POINTER(ifcs_ctypes.ifcs_attr_t),
            POINTER(None))
        callback = callback_type(self.myCallback)

        try:
            rc = ifcs_ctypes.ifcs_devport_get_all(0, 0, None, compat_funcPointer(callback, ifcs_ctypes.ifcs_devport_user_cb_t), None, None)
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Failed to get all devport rc: %d" %(rc))
        except Exception as e:
            log(" Failed to get all devports : %d" %(rc))
            raise e
        return devport_list

    def debug(self, args):
        args_list = args.split()
        deb = int(args_list[2])
        if( deb == 1):
           '''
           count = 2
           attr = (ifcs_ctypes.ifcs_attr_t * count)()
           attr[0].id = IFCS_DEVPORT_ATTR_PFC_WD_MITIGATION_ACTION
           attr[0].value.u32 = IFCS_PFC_WD_MITIGATION_ACTION_DROP
           rc = ifcs_ctypes.im_devport_attr_set(0, 2, 1, attr);
           assert rc == IFCS_SUCCESS, "IFCS_PFC_WD_MITIGATION_ACTION_DROP set failed rc " + str(rc) + ""
           '''
           ifcs_ctypes.im_queue_pfcwd_mitigate(0,2,5);
        else:
           ifcs_ctypes.im_queue_pfcwd_restore(0,2,5);

    def dbg(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)

        args_list = args.split()

        if len(args_list) == 4:
            attr = self.arg_list.pop(0)
            flag = self.arg_list.pop(0)
            try:
                if attr == 'pic_intr_enable':
                    linkscan_attr_ct = 1
                    linkscan_attr = (ifcs_ctypes.ifcs_attr_t * linkscan_attr_ct)()
                    linkscan_attr[0].id =  ifcs_ctypes.IM_LINKSCAN_ATTR_PIC_INTR_ENABLE;
                    linkscan_attr[0].value.u32 = int(flag);
                    rc = ifcs_ctypes.im_linkscan_attr_set(0, linkscan_attr_ct, linkscan_attr);
                    assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                        "ERR during im linkscan attr set"

            except:
                    log("Dbg operation failed")

        else:
            res = self.arg_list.pop(0)
            attr = self.arg_list.pop(0)
            flag = self.arg_list.pop(0)

            max_dev_port = self.get_max_devport()
            max_devport_range = "1-2"
            if max_dev_port:
                max_devport_range = "1-%d"%(max_dev_port)

            if res == 'all':
                # Port range not given, default to all ports
                devport_arg = max_devport_range
                devport_arg_list = max_devport_range.split(",")
            else:
                # Use given devport range
                try:
                    devport_arg = res
                    devport_arg_list = res.split(",")
                except:
                    devport_arg = max_devport_range
                    devport_arg_list = max_devport_range.split(",")

            # Allocate run's data object which saves config
            devport_list = []

            for i, dp in enumerate(devport_arg_list):
                if '-' in dp:
                    dp_range = devport_arg.split(",")[i].split("-")
                    for j in range(int(dp_range[0]), int(dp_range[1]) + 1):
                        devport_list.append(j)
                else:
                    devport_list.append(int(dp))
            try:
                if attr == 'an_stop_on_hcd':
                    devport_attr_ct = 1
                    devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
                    devport_attr[0].id =  ifcs_ctypes.IM_DEVPORT_ATTR_AUTO_NEG_STOP_ON_HCD;
                    devport_attr[0].value.u32 = int(flag);
                elif attr == 'an_restart_disable':
                    devport_attr_ct = 1
                    devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
                    devport_attr[0].id =  ifcs_ctypes.IM_DEVPORT_ATTR_AUTO_NEG_RESTART_DISABLE;
                    devport_attr[0].value.u32 = int(flag);
                elif attr == 'lt_restart_disable':
                    devport_attr_ct = 1
                    devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
                    devport_attr[0].id =  ifcs_ctypes.IM_DEVPORT_ATTR_LINK_TRAINING_RESTART_DISABLE;
                    devport_attr[0].value.u32 = int(flag);
                elif attr == 'an_nrz_link_fail_timer':
                    devport_attr_ct = 1
                    devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
                    devport_attr[0].id =  ifcs_ctypes.IM_DEVPORT_ATTR_AUTO_NEG_NRZ_LINK_FAIL_PERIOD;
                    devport_attr[0].value.u32 = int(flag);
                elif attr == 'an_pam4_link_fail_timer':
                    devport_attr_ct = 1
                    devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
                    devport_attr[0].id =  ifcs_ctypes.IM_DEVPORT_ATTR_AUTO_NEG_PAM4_LINK_FAIL_PERIOD;
                    devport_attr[0].value.u32 = int(flag);

                for port in devport_list:
                    if (port == 0 or (port >= 513 and port <=518)):
                        continue
                    rc = ifcs_ctypes.im_devport_attr_set(0, port, devport_attr_ct, devport_attr);
                    assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                        "ERR during im devport attr set:" + str(port)

            except:
                    log("Dbg operation failed")

    def pdinfo(self, args):
        ret = ifcs_ctypes.ifcs_status_t()
        ib = c_uint32(0)
        ibp = c_uint32(0)

        args_list = args.split()
        table = PrintTable()
        table.add_row(['Devport', 'IB', 'IBport', 'PIC_ID', 'PIC_PORT'])
        if (len(args_list) == 3):
            devport = c_uint32(int(args_list[2]))
            info = ifcs_ctypes.im_devport_info_t()
            rc = ifcs_ctypes.im_devport_info_get(0, devport, pointer(info));
            table.add_row([devport.value, info.pi_ib, info.pi_ibport, info.pi_pic_id, info.pi_pic_port])
        else:
            dp_list = self.getAlldevport()
            dp_list.sort()
            for i in range(len(devport_list)):
                info = ifcs_ctypes.im_devport_info_t()
                rc = ifcs_ctypes.im_devport_info_get(0, devport_list[i], pointer(info));
                table.add_row([devport_list[i], info.pi_ib, info.pi_ibport, info.pi_pic_id, info.pi_pic_port])

        table.print_table(brief=True)
        table.reset_table()

        return

    def status_chain_dump(self, kspace):
        node_id = self.cli.node_id
        ifcs_ctypes.im_devport_pic_status_chain_dump(node_id, kspace)

    def status(self, args):
        self.arg_list.pop(0)

        args_list = args.split()
        kspace = c_int(0)

        if len(args_list) == 3:
            kspace = c_int(int(args_list[2]))

        self.status_chain_dump(kspace)

    def tx_eq(self, args):
        log("TX EQ")

        self.arg_list.pop(0)

        args_list = args.split()

        if len(args_list) < 5:
            log("Usage: port tx_eq <set/get> <devport> <lane_mask>")
            return

        devport = c_uint32(int(args_list[3]))

        rc = ifcs_ctypes.ifcs_status_t()

        node_id = self.cli.node_id

        if args_list[2] == 'set':
            if len(args_list) < 10:
                log("Usage: port tx_eq <set/get> <devport> <lane_mask> <pre1> <pre2> <pre3> <attn> <post>")
                return
            attr_count = 6
            attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

            attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LANE_MASK;
            attr_list_p[0].value.u8 = c_uint8(int(args_list[4]));

            attr_list_p[1].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_TX_EQ_PRE1;
            TxEqPre1 = ifcs_i8_list_s()
            TxEqPre1.count = 1
            TxEqPre1.arr = (c_byte * TxEqPre1.count)()
            TxEqPre1.arr[0] = c_int8(int(args_list[5]));
            attr_list_p[1].value.i8_list = TxEqPre1

            attr_list_p[2].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_TX_EQ_PRE2;
            TxEqPre2 = ifcs_i8_list_s()
            TxEqPre2.count = 1
            TxEqPre2.arr = (c_byte * TxEqPre2.count)()
            TxEqPre2.arr[0] = c_int8(int(args_list[6]));
            attr_list_p[2].value.i8_list = TxEqPre2

            attr_list_p[3].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_TX_EQ_PRE3;
            TxEqPre3 = ifcs_i8_list_s()
            TxEqPre3.count = 1
            TxEqPre3.arr = (c_byte * TxEqPre3.count)()
            TxEqPre3.arr[0] = c_int8(int(args_list[7]));
            attr_list_p[3].value.i8_list = TxEqPre3

            attr_list_p[4].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_TX_EQ_ATTN;
            TxEqAttn = ifcs_i8_list_s()
            TxEqAttn.count = 1
            TxEqAttn.arr = (c_byte * TxEqAttn.count)()
            TxEqAttn.arr[0] = c_int8(int(args_list[8]));
            attr_list_p[4].value.i8_list = TxEqAttn

            attr_list_p[5].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_TX_EQ_POST;
            TxEqPost = ifcs_i8_list_s()
            TxEqPost.count = 1
            TxEqPost.arr = (c_byte * TxEqPost.count)()
            TxEqPost.arr[0] = c_int8(int(args_list[9]));
            attr_list_p[5].value.i8_list = TxEqPost

            rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, devport,
                                 attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));

            assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                   "ERR during port tx_eq set:" +\
                    str(devport)

            log("TX EQ set done")
        elif args_list[2] == 'get':
            tx_eq_pre1 = c_int8(0)
            tx_eq_pre2 = c_int8(0)
            tx_eq_pre3 = c_int8(0)
            tx_eq_attn = c_int8(0)
            tx_eq_post = c_int8(0)

            lane_mask = c_uint8(int(args_list[4]));

            rc = ifcs_ctypes.im_devport_get_tx_eq(node_id, devport, lane_mask, pointer(tx_eq_pre1), pointer(tx_eq_pre2),
                                     pointer(tx_eq_pre3), pointer(tx_eq_attn), pointer(tx_eq_post));

            assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                   "ERR during port tx_eq get:" +\
                    str(devport)

            log("PRE1\tPRE2\tPRE3\tATTN\tPOST\n")
            log("%d\t%d\t%d\t%d\t%d" %(tx_eq_pre1.value, tx_eq_pre2.value, tx_eq_pre3.value, tx_eq_attn.value, tx_eq_post.value))
        else:
            log("Invalid port tx_eq <set/get> param")

    def cut_through(self, args):
        self.arg_list.pop(0)
        args_list = args.split()
        log("Port " + args_list[1])
        if len(args_list) < 3:
            log("Usage: " + args_list[0] + " " + args_list[1] + " <devport>")
            return

        devport = c_uint32(int(args_list[2]))

        enable = 0
        if len(args_list) == 3:
            if args_list[1] == 'cut_through_enable':
                enable = 1
            elif args_list[1] == 'cut_through_disable':
                enable = 0

        rc = ifcs_ctypes.ifcs_status_t()

        node_id = self.cli.node_id
        attr_count = 1
        attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

        attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_CUT_THROUGH_ENABLE;
        attr_list_p[0].value.u32 = enable;

        rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, devport, attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "ERR during port cut_through set:" + str(devport)

        log("cut through set done")

    def admin_st_toggle_test(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        res = self.arg_list.pop(0)
        loop_cnt = self.arg_list.pop(0)
        max_wait_time = self.arg_list.pop(0)
        stop_on_link_down = self.arg_list.pop(0)

        max_dev_port = self.get_max_devport()
        max_devport_range = "1-2"
        if max_dev_port:
            max_devport_range = "1-%d"%(max_dev_port)

        if res == 'all':
            # Port range not given, default to all ports
            devport_arg = max_devport_range
            devport_arg_list = max_devport_range.split(",")
        else:
            # Use given devport range
            try:
                devport_arg = res
                devport_arg_list = res.split(",")
            except:
                devport_arg = max_devport_range
                devport_arg_list = max_devport_range.split(",")

        # Allocate run's data object which saves config
        devport_list = []

        for i, dp in enumerate(devport_arg_list):
            if '-' in dp:
                dp_range = devport_arg.split(",")[i].split("-")
                for j in range(int(dp_range[0]), int(dp_range[1]) + 1):
                    devport_list.append(j)
            else:
                devport_list.append(int(dp))

        for loop in range(0, int(loop_cnt)):
            log("\nLOOP:" + str(loop))
            devport_attr_ct = 1
            devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
            devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE;
            devport_attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_TRUE;

            for port in devport_list:
                rc = ifcs_ctypes.ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t))
                assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                    "ERR during port admin enable:" + port

            # Wait for all ports to go link-up for max_wait_time secs
            timer_val=float(max_wait_time)
            wait_time=0
            devport_attr_ct = 1
            devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
            devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LINK_STATUS;
            devport_attr[0].value.u32 = 0;
            actual_count = c_uint32()
            link_status=True
            while wait_time<timer_val:
                link_status=True
                for devport in devport_list:
                    rc = ifcs_ctypes.ifcs_devport_attr_get (0, devport, 1,
                                     compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t), pointer(actual_count));
                    assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                        "ERR during port admin enable:" +\
                        str(devport)

                    if (devport_attr[0].value.u32 != 1):
                        if (wait_time >= timer_val - 0.1):
                            log("Port not UP:" + str(devport))
                            if stop_on_link_down == '1':
                                link_status=False
                                break;
                        link_status=False
                if link_status:
                    break;
                else:
                    wait_time+=0.1
                    time.sleep(0.1)

            if stop_on_link_down == '1' and link_status == False:
                break;
            devport_attr_ct = 1
            devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
            devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE;
            devport_attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE;

            for port in devport_list:
                rc = ifcs_ctypes.ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t))
                assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                    "ERR during port admin disable:" + str(port)

    def help(self, args):
        self.cli.error()
        log("Usage: \n",                                                     \
              "port info     <devport    - ifcs port info\n",                  \
              "port loopback <devport>   - ifcs port loopback\n",              \
              "port enable   <devport> [all | <port> | <port range>]  - ifcs port enable\n",                \
              "port disable  <devport> [all | <port> | <port range>]   - ifcs port disable\n",               \
              "port lt_enable   <devport> [all | <port> | <port range>]  - ifcs port LT enable\n",                \
              "port lt_disable  <devport> [all | <port> | <port range>]  - ifcs port LT disable\n",                \
              "port an_enable   <devport> [all | <port> | <port range>]  - ifcs port AN enable\n",                \
              "port an_disable  <devport> [all | <port> | <port range>]  - ifcs port AN disable\n",                \
              "port create   <devport> <type> <num_lanes> <start_lane> <speed> \
<isg> <fec> <sysport> - ifcs port create\n",      \
              "port delete   <devport>   - ifcs port delete\n",                \
              "port status               - ifcs port status\n",                         \
              "port tx_eq    <set/get> <devport> <lane_mask> <pre1> <pre2> <pre3> <attn> <post> - ifcs port tx_eq\n",  \
              "port pdinfo               - ifcs pd info\n",                     \
              "port cut_through_enable <devport> - ifcs port cut_through_enable\n",              \
              "port cut_through_disable <devport> - ifcs port cut_through_disable\n",              \
              "port admin_st_toggle_test <devport> [all | <port> | <port range>] <iterations> <wait_time> <stop_on_link_down> - \
ifcs port admin state toggle test\n",   \
              "port help or ?            - show this text\n")
