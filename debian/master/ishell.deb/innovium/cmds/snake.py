
#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2018
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------


SNAKE_VERSION = [0, 14, 20, 0, 0, 0]

'''
L2snake test is used to setup forwarding rules to test unidirectional snake test
and bi-directional flow snake test

Unidirectional flow snake config:
=================================
-    Each port set to internal loopback
-    Packet on port (i), sent to port (i+1)
-    Last port fwds packet to first port


IVM:0>diagtest snake config -p 1-4 -lb 'PCS'


IVM:0>ifcs show sysport

Total sysport count: 33
+---------------------------------------------------------------------+
|             sysport_handle | default_cvid | egress_untagged_vlan_id |
|---------------------------------------------------------------------|
| (sysport:   1), 0x68200001 |            2 |                       1 |  --- For 1->2
| (sysport:   2), 0x68200002 |            3 |                       2 |  --- For 2->3
| (sysport:   3), 0x68200003 |            4 |                       3 |  --- For 3->4
| (sysport:   4), 0x68200004 |            1 |                       4 |  --- For 4->1



IVM:0>ifcs show l2_entry

Total l2_entry count: 8
+----------------------------------------------------------------------------
|          mac_addr |                    l2vni |                destination |
|----------------------------------------------------------------------------
| 00:00:00:00:00:bb | (l2vni:   1), 0x3c200001 | (sysport:   4), 0x68200004 |     ----- BB SRC MAC
| 00:00:00:00:00:aa | (l2vni:   1), 0x3c200001 | (sysport:   1), 0x68200001 |     ----- AA DST MAC for 4->1
| 00:00:00:00:00:aa | (l2vni:   2), 0x3c200002 | (sysport:   2), 0x68200002 |     ----- AA DST MAC for 1->2
| 00:00:00:00:00:bb | (l2vni:   2), 0x3c200002 | (sysport:   1), 0x68200001 |
| 00:00:00:00:00:bb | (l2vni:   3), 0x3c200003 | (sysport:   2), 0x68200002 |
| 00:00:00:00:00:aa | (l2vni:   3), 0x3c200003 | (sysport:   3), 0x68200003 |     ----- AA DST MAC for 2->3
| 00:00:00:00:00:bb | (l2vni:   4), 0x3c200004 | (sysport:   3), 0x68200003 |
| 00:00:00:00:00:aa | (l2vni:   4), 0x3c200004 | (sysport:   4), 0x68200004 |     ----- AA DST MAC for 3->4
+----------------------------------------------------------------------------

Note: If you are using cables to link up the ports and run l2snake with ixia traffic(unidir)
      Then ports should be connected like 1<->2, 3<->4, 5<->6, ..., 31<->32.
      And the commands are,

To config snake          : "diagtest snake config -p 1-32"
To start traffic(unidir) : "diagtest snake start_traffic -n 1000"
To stop traffic          : "diagtest snake stop_traffic"



===============================================================================================
===============================================================================================
===============================================================================================
Bidirectional cross flows snake config (ports connected like 2<->3, 4<->5, 6<->7, ..., 32<->1):
===============================================================================================
===============================================================================================
===============================================================================================
-    Fwd Flow: (Ixia -> 1 (->2); 2 -> 3(->4), 4 -> Ixia ... )
        - Incoming on Odd ports, Outgoing on Even ports
-    Rev Flow: (Ixia -> 4 (->3); 3 -> 2(->1); 1 -> Ixia ... )
        - Incoming on Even ports, Outgoing on Odd ports

To config snake  : "diagtest snake config -p 1-32 -b"

To start traffic : "diagtest snake start_traffic -n 1000 -b"

Note: If IXIA is used to send traffic, then construct the packet with below mac values
FWD flow:
fwd_dmac - 00:00:00:00:00:AA
fwd_smac - 00:00:00:00:00:BB

REV flow:
rev_dmac - 00:00:00:00:00:BB
rev_smac - 00:00:00:00:00:AA

To stop traffic  : "diagtest snake stop_traffic -b"

IVM:0>ifcs show sysport

Total sysport count: 33
+---------------------------------------------------------------------+
|             sysport_handle | default_cvid | egress_untagged_vlan_id |
|---------------------------------------------------------------------|
| (sysport:   1), 0x68200001 |            2 |                       1 |        ---- FWD for (1->2)
| (sysport:   2), 0x68200002 |            1 |                       2 |        ----     REV for (2->1)
| (sysport:   3), 0x68200003 |            4 |                       3 |        ---- FWD for (3->4)
| (sysport:   4), 0x68200004 |            3 |                       4 |        ----     REV for (4->3)

IVM:0>ifcs show l2_entry

Total l2_entry count: 8
+---------------------------------------------------------------------------
|          mac_addr |                    l2vni |               destination |
|---------------------------------------------------------------------------
| 00:00:00:00:00:bb | (l2vni:   1), 0x3c200001 |(sysport:   1), 0x68200001 | ----   REV BB DST MAC, for (2->1)
| 00:00:00:00:00:aa | (l2vni:   1), 0x3c200001 |(sysport:   2), 0x68200002 | ----   REV AA SRC MAC, SP2
| 00:00:00:00:00:aa | (l2vni:   2), 0x3c200002 |(sysport:   2), 0x68200002 | ---- FWD AA DST MAC, for (1->2)
| 00:00:00:00:00:bb | (l2vni:   2), 0x3c200002 |(sysport:   1), 0x68200001 | ---- FWD BB SRC MAC, SP1
| 00:00:00:00:00:bb | (l2vni:   3), 0x3c200003 |(sysport:   3), 0x68200003 | ----   REV BB DST MAC, for (4->3)
| 00:00:00:00:00:aa | (l2vni:   3), 0x3c200003 |(sysport:   4), 0x68200004 | ----   REV AA SRC MAC, SP4
| 00:00:00:00:00:bb | (l2vni:   4), 0x3c200004 |(sysport:   3), 0x68200003 | ---- FWD BB SRC MAC, SP3
| 00:00:00:00:00:aa | (l2vni:   4), 0x3c200004 |(sysport:   4), 0x68200004 | ---- FWD AA DST MAC, for (3->4)



===================================================================================================
===================================================================================================
===================================================================================================
Bidirectional straight flows snake config (ports connected like 1<->2, 3<->4, 5<->6, ..., 31<->32):
===================================================================================================
===================================================================================================
===================================================================================================
-    Fwd Flow: (Ixia -> 1; 1->2(->3); 3 -> 4; 4 -> Ixia ... )
        - Incoming on Odd ports, Outgoing on Even ports
-    Rev Flow: (Ixia -> 4; 4->3(->2); 2 -> 1; 1 -> Ixia ... )
        - Incoming on Even ports, Outgoing on Odd ports

To config snake  : "diagtest snake config -p 1-32 -bs"

To start traffic : "diagtest snake start_traffic -n 1000 -bs"

Note: If IXIA is used to send traffic, then construct the packet with below mac values
FWD flow:
fwd_dmac - 00:00:00:00:00:AA
fwd_smac - 00:00:00:00:00:BB

REV flow:
rev_dmac - 00:00:00:00:00:CC
rev_smac - 00:00:00:00:00:DD

To stop traffic  : "diagtest snake stop_traffic -bs"

IVM:0>ifcs show sysport

Total sysport count: 33
+---------------------------------------------------------------------+
|             sysport_handle | default_cvid | egress_untagged_vlan_id |
|---------------------------------------------------------------------|
| (sysport:   1), 0x68200001 |            4 |                       1 |        ---- REV for (1->4)
| (sysport:   2), 0x68200002 |            3 |                       2 |        ---- FWD for (2->3)
| (sysport:   3), 0x68200003 |            2 |                       3 |        ---- REV for (3->2)
| (sysport:   4), 0x68200004 |            1 |                       4 |        ---- FWD for (4->1)


IVM:0>ifcs show l2_entry

Total l2_entry count: 8
+----------------------------------------------------------------------------
|          mac_addr |                    l2vni |                destination |
-----------------------------------------------------------------------------
| 00:00:00:00:00:bb | (l2vni:   2), 0x3c200002 | (sysport:   1), 0x68200001 | ---- REV BB DST MAC, for (3->2)
| 00:00:00:00:00:bb | (l2vni:   3), 0x3c200003 | (sysport:   2), 0x68200002 | ---- REV BB SRC MAC, SP3
| 00:00:00:00:00:aa | (l2vni:   3), 0x3c200003 | (sysport:   3), 0x68200003 | ---- FWD AA DST MAC, for (2->3)
| 00:00:00:00:00:bb | (l2vni:   4), 0x3c200004 | (sysport:   3), 0x68200003 | ---- FWD BB SRC MAC, SP2
| 00:00:00:00:00:aa | (l2vni:   4), 0x3c200004 | (sysport:   4), 0x68200004 | ---- REV BB DST MAC, for (1->4)
| 00:00:00:00:00:aa | (l2vni:   4), 0x3c200004 | (sysport:   4), 0x68200004 | ---- REV AA SRC MAC, SP1
| 00:00:00:00:00:bb | (l2vni:   2), 0x3c200002 | (sysport:   2), 0x68200002 | ---- FWD BB SRC MAC, SP4
| 00:00:00:00:00:aa | (l2vni:   1), 0x3c200001 | (sysport:   1), 0x68200001 | ---- FWD AA DST MAC, for (4->1)

'''
import shlex
import argparse
import itertools
import time
import random
import json
from ctypes import *
from utils.compat_util import *
from verbosity import *
from cmdmgr import Command
from collections import OrderedDict
from ifcs_cmds.sysport import Sysport as sysport
from ifcs_cmds.devport import Devport as Devport
from ifcs_cmds.node import Node as node
from print_table import PrintTable
from testutil.util import hexdump
import sys
ifcs_ctypes = sys.modules['ifcs_ctypes']

MAX_DEV_PORTS = 520
cpu_port = 0

SNAKE_ID_IDX = 12 + 4
PKT_ID_IDX = SNAKE_ID_IDX + 1

def pkt_vos_cb(node_id, user_data, packet):
    mismatch = 0
    buf_len = packet.contents.pkt_buf_len
    buf = c_char_p(packet.contents.pkt_buf)
    packet = cast(buf, POINTER(c_char))
    packet = packet[:buf_len]
    #gen_pkt = Snake.vos_gen_pkt

    
    if compat_ord(packet[12]) == 0xBE and compat_ord(packet[13]) == 0xBA and \
       compat_ord(packet[14]) == 0xFE and compat_ord(packet[15]) == 0xCA:
        log_dbg(1, "Received packet signature verified")
    else:
        log_err("Received packet signature invalid. Received pkt:")
        log(":".join("{:02x}".format(compat_ord(c)) for c in packet))
        # Incrementing global mismatch counter id (not per Snake-id) as we don't know the snake-id here
        Snake.vos_glob_mismatch += 1
        return

    snake_id = compat_ord(packet[SNAKE_ID_IDX])
    find = False
    for instance in Snake.devport_stats_runs:
        if instance.id == snake_id:
            devport_stats = instance
            find = True
            break
    if find == False:
        log_err("Snake with id {0} doesn't exist".format(snake_id))
        log_err("Received pkt")
        log(":".join("{:02x}".format(compat_ord(c)) for c in packet))
        Snake.vos_glob_mismatch += 1
        return

    devport_stats.vos_num_rcvd_total += 1

    if devport_stats.payload_type == 'rrstress':
        pkt_id = compat_ord(packet[PKT_ID_IDX]) | (compat_ord(packet[PKT_ID_IDX + 1]) << 8) | (compat_ord(packet[PKT_ID_IDX + 2]) << 16)
    else:
        pkt_id = 0

    log_dbg(1, "Received pkt_id {}".format(pkt_id))

    gen_pkt = devport_stats.vos_gen_pkts[pkt_id]

    if len(gen_pkt) != len(packet):
        mismatch = 1
        log_err("Length mismatch; Sent pkt len {} Rcvd pkt len {}".format(len(gen_pkt), len(packet)))
        log_err("Sent pkt")
        log(":".join("{:02x}".format(compat_ord(c)) for c in gen_pkt))
        log_err("Received pkt")
        log(":".join("{:02x}".format(compat_ord(c)) for c in packet))

    if mismatch == 0:
        # now compare the content
        for i in range(len(gen_pkt)):
           if packet[i] != gen_pkt[i]:
               mismatch = 1
               log("Snake-id: {} Pkt-id: {} byte mismatch; byte: {} Sent: 0x{:02x} Received: 0x{:02x} XOR: 0x{:02x}".format( \
                   snake_id, pkt_id, i, compat_ord(gen_pkt[i]), compat_ord(packet[i]), (compat_ord(gen_pkt[i]) ^ compat_ord(packet[i]))))

    if mismatch == 0:
        devport_stats.vos_num_rcvd_good += 1
    else:
        devport_stats.vos_num_rcvd_bad += 1
        log_err("\n")

    log_dbg(1, ":".join("{:02x}".format(compat_ord(c)) for c in packet))

    return

def getSysportHandleFromDevPort(node_id, devPort):
    attr = ifcs_ctypes.ifcs_attr_t()
    actual_count = c_uint32()

    attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SYSPORT
    ret = ifcs_ctypes.ifcs_devport_attr_get(node_id, devPort, 1, pointer(attr),
                            pointer(actual_count))
    assert ret == ifcs_ctypes.IFCS_SUCCESS, "port sysport handle get: ret = [" + str(ret) + "]"

    return attr.value.handle


def auto_int(x):
    return int(x, 0)

# Object to store A "run" devport stats.
class DevportStats():
    def __init__(self):
        self.devport_rx_frames = [0] * MAX_DEV_PORTS
        self.devport_rx_bytes = [0] * MAX_DEV_PORTS
        self.devport_rx_gbps = [0] * MAX_DEV_PORTS
        self.devport_tx_frames = [0] * MAX_DEV_PORTS
        self.devport_tx_bytes = [0] * MAX_DEV_PORTS
        self.devport_tx_gbps = [0] * MAX_DEV_PORTS
        self.devport_rx_errors = [0] * MAX_DEV_PORTS
        self.devport_tx_errors = [0] * MAX_DEV_PORTS
        self.timestamp = [0] * MAX_DEV_PORTS
        self.devport_list = []
        self.lb_type = 0
        self.num_pkt = OrderedDict()
        self.node_id = 0
        self.verbose = 0
        self.time = 0
        self.dmac_l2_entry_array = []
        self.smac_l2_entry_array = []
        self.port_sp_hdl         = OrderedDict()
        self.cpu_sp_hdl          = ifcs_ctypes.ifcs_handle_t()
        self.stp_hdl             = ifcs_ctypes.ifcs_handle_t()
        self.id = 0
        self.type = "None"
        self.payload_type = ""
        self.vos = 0
        self.vos_gen_pkts        = []
        self.vos_num_gen_pkts    = 0
        self.vos_num_rcvd_total  = 0
        self.vos_num_rcvd_good   = 0
        self.vos_num_rcvd_bad    = 0
        self.state = SNAKE_STOPPED

    def display(self):
        log("\nSnake id         : %d" %(self.id))
        log("Loopback type    : %s" %(self.lb_type))
        log("Snake type       : %s" %(self.type))
        log("Number of packets:")
        for size, num in compat_iteritems(self.num_pkt):
            log("    Size: %4s, Packets: %s" %(size, num))

        header = []
        header.append('Devport')
        header.append('RX(frames)')
        header.append('RX(bytes)')
        header.append('RX(Gbps)')
        header.append('RX(error frames)')
        header.append('TX(frames)')
        header.append('TX(bytes)')
        header.append('TX(Gbps)')
        header.append('TX(error frames)')
        table = PrintTable()
        table.add_row(header)
        for p in range(MAX_DEV_PORTS):
            if p not in self.devport_list:
                continue
            devport_row = []
            devport_row.append(str(p))
            devport_row.append(str(self.devport_rx_frames[p]))
            devport_row.append(str(self.devport_rx_bytes[p]))
            devport_row.append(str('%.2f' %self.devport_rx_gbps[p]))
            devport_row.append(str(self.devport_rx_errors[p]))
            devport_row.append(str(self.devport_tx_frames[p]))
            devport_row.append(str(self.devport_tx_bytes[p]))
            devport_row.append(str('%.2f' %self.devport_tx_gbps[p]))
            devport_row.append(str(self.devport_tx_errors[p]))
            table.add_row(devport_row)
        table.print_table()
        table.reset_table()

    def display_config(self, id):
        for instance in Snake.devport_stats_runs:
            if instance.id == id:
                devport_stats = instance
                table = PrintTable()
                header = []
                header.append("Devports")
                header.append("Loopback type")
                header.append("Snake id")
                header.append("Snake type")
                table.add_row(header)

                data = []
                data.append(str(devport_stats.devport_list)[1:-1])
                data.append(str(devport_stats.lb_type))
                data.append(str(id))
                data.append(str(devport_stats.type))
                table.add_row(data)
                table.print_table()
                table.reset_table()
                break


SNAKE_UNCONFIG = 0
SNAKE_CONFIGD = 1
SNAKE_RUNNING = 2
SNAKE_STOPPED = 3

#Snake: This test injects a packet on a port and the forwarding
#       rules are configured in such a way that the packet loops
#       through all the ports and then back to CPU.
#       This is a work in progress, so we pass it for now
#
class Snake(Command):
    #Version of the snake.py file
    snake_file_version = 0
    ver_disp = "" # nomenclature: <ifcs_version>_<snake_version>

    state = SNAKE_UNCONFIG
    #Global across all Snake objects.

    cpu_queue_num = 3
    trap_id = 65
    trap_hdl = ifcs_ctypes.ifcs_handle_t()
    #All run's devport stats are saved in below list
    devport_stats_runs = []

    #Class variables
    dmac_l2_entry_array = []
    smac_l2_entry_array = []
    port_sp_hdl         = OrderedDict()
    cpu_sp_hdl          = ifcs_ctypes.ifcs_handle_t()
    stp_hdl             = ifcs_ctypes.ifcs_handle_t()

    rx_cbfn             = 0
    vos_glob_mismatch   = 0
    #Incremented for each run config (diagtest snake config)
    run = -1

    def __init__(self, cli, quiet="false"):
        self.sub_cmds = {
                         'config'       : self.config,
                         'config_show'  : self.config_show,
                         'start_traffic': self.start_traffic,
                         'stop_traffic' : self.stop_traffic,
                         'gen_report'   : self.gen_report,
                         'verify'       : self.verify,
                         'show_vos_stats'  : self.show_vos_stats,
                         'clear_vos_stats' : self.clear_vos_stats,
                         #'dump_report'  : self.dump_report,
                         'unconfig'     : self.unconfig,
                         'show_version' : self.show_ver,
                         'help'         : self.help,
                         '?'            : self.help
                        }
        self.cli = cli
        self.quiet = quiet
        self.arg_list = []

        
        version_num = [0] * 6
        for idx in range(len(SNAKE_VERSION)):
            version_num[idx] = SNAKE_VERSION[idx]
        self.ver_disp = "{}.{}.{}.{}.{}.{}".format(
            version_num[0], version_num[1], version_num[2], version_num[3],
            version_num[4], version_num[5])
        self.ver_disp = "{}_{}".format(self.ver_disp, self.snake_file_version)
        super(Snake, self).__init__()

    def __del__(self):
        return

    def show_ver(self, args):
        table = PrintTable()
        table.add_row(['IFCS L2Snake Version',"%s"%(self.ver_disp)])
        table.print_table()
        table.reset_table()

    def run_cmd(self, args):
        self.arg_list = shlex.split(args)
        try:
            rc = self.sub_cmds[self.arg_list[2]](args)
            return rc
        except (KeyError):
            log_dbg(1, "Invalid cmd")
            self.help(args)
            return ifcs_ctypes.IFCS_PARAM
        except Exception as ex:
            self.cli.error()
            self.help(args)

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def help(self, args):
        table = PrintTable()
        table.add_row(['Command', 'Description'])
        table.add_row(['config', 'Configure snake test'])
        table.add_row(['config_show', 'Show snake test configuration'])
        table.add_row(['start_traffic', 'Start snake test traffic'])
        table.add_row(['stop_traffic', 'Stop snake test traffic'])
        table.add_row(['gen_report', 'Generate snake test report for given sampling time'])
        table.add_row(['verify', 'Verify if traffic is running on all configured ports'])
        table.add_row(['show_vos_stats', 'Display vos statistics'])
        table.add_row(['clear_vos_stats', 'Clear vos statistics'])
        #table.add_row(['dump_report', 'Dump snake tests report to file'])
        table.add_row(['unconfig', 'Unconfigure snake test'])
        table.add_row(['show_version', 'Show Snake file version'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        snake_help_string = """
Usage::

    Type "diagtest snake <command>" followed by -h to see command's sub-options.
"""
        log(snake_help_string)

    def insert_run_data(self, run_data):
        # Increment run and insert run data
        Snake.run += 1
        Snake.devport_stats_runs.append(run_data)

    def get_run_data(self, run):
        return Snake.devport_stats_runs[run]

    def get_cur_run_data(self):
        run = Snake.run
        return Snake.devport_stats_runs[run]

    def get_max_devport(self, node_id=0):
        #Do get all devport to figure out max devports configured
        def myCallback(node_id, arg, attr_count, attr_list, user_data):

            devport = arg

            devport_list.append(devport)
        devport_list = []

        callback_type = CFUNCTYPE(
            ifcs_ctypes.UNCHECKED(None),
            ifcs_ctypes.ifcs_node_id_t,
            ifcs_ctypes.ifcs_devport_t,
            c_uint32,
            POINTER(ifcs_ctypes.ifcs_attr_t),
            POINTER(None))
        callback = callback_type(myCallback)

        attr = ifcs_ctypes.ifcs_attr_t()
        ifcs_ctypes.ifcs_attr_t_init(pointer(attr))
        ifcs_ctypes.ifcs_attr_t_id_set(pointer(attr), ifcs_ctypes.IFCS_DEVPORT_ATTR_TYPE)
        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_DEVPORT_TYPE_ETH)

        try:
            rc = ifcs_ctypes.ifcs_devport_get_all(node_id, 1, pointer(attr), compat_funcPointer(callback, ifcs_ctypes.ifcs_devport_user_cb_t), None, None)
            if ( rc != ifcs_ctypes.IFCS_SUCCESS):
                log("Failed to get all devport rc: {0}".format(rc))
        except:
            log("In except of devport get_all")
            pass

        return (len(devport_list))

    def config_snake_unidir(self, devport_stats):
       '''
       1. Packets are initiated from CPU to port 1
       2. Port 1 forwards and port 2
       3. Port 2 is internal loopbacked and gets packet
       4. Port 2 forwards it to port 3 and so on till 128
       5. Port 128 forwards to port 1
       6. Port 1, because of loopback gets packet again and cycle repeats
       +--------+
       | CPU    |
       +---+----+
           |
         +-------------------------------------------------------+
         | |    +----------------------------------------------+ |
         | |    |                                              | |
         | |    |  +-------  +-------  +---+   +---+ +------+  | |
         | |    |  |      |  |      |  |   |       | |      |  | |
         | +> +-v--++    +v--+     +v--+   v      +v-++    +v--+ |
         |    |   1 |    | 2 |     | 3 |          |127|    |128| |
         +----+-+-+-+----++-++-----++-++-----------+-+------+-+--+
                | ^       | ^       | ^            | ^      | ^
                | |       | |       | |            | |      | |
                +>+       +>+       +-+            +-+      +-+
       '''
       port_sp_hdl = devport_stats.port_sp_hdl
       mac_addr_t = c_uint8 * 6
       devport_list = devport_stats.devport_list
       l2vni_hdl = ifcs_ctypes.ifcs_handle_t()
       dmac_l2_entry_array = devport_stats.dmac_l2_entry_array
       smac_l2_entry_array = devport_stats.smac_l2_entry_array

       # SRC MAC config
       try:
           attr_count = 2
           attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()

           for i, port in enumerate(devport_stats.devport_list):
               count = port
               port_hdl = ifcs_ctypes.ifcs_handle_t()
               port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[port])
               mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xBB)
               port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)
               l2_entry = ifcs_ctypes.ifcs_l2_entry_key_t()
               if port == devport_list[-1]:
                   next_devport = devport_list[0]
               else:
                   next_devport = devport_list[i+1]
               l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[next_devport]))

               ifcs_ctypes.ifcs_l2_entry_key_t_init(pointer(l2_entry))
               ifcs_ctypes.ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry),
                       ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
               ifcs_ctypes.ifcs_l2_entry_key_t_mac_l2vni_set(pointer(l2_entry),
                       l2_entry.key.mac_l2vni)
               ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_mac_addr_set(pointer(l2_entry.key.mac_l2vni),
                       mac_addr)
               ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_l2vni_set(pointer(l2_entry.key.mac_l2vni),
                       l2vni_hdl)

               attr[0].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_DEST
               attr[0].value.handle = port_hdl
               attr[1].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
               attr[1].value.u32 = ifcs_ctypes.IFCS_L2_ENTRY_TYPE_STATIC
               rc = ifcs_ctypes.ifcs_l2_entry_create(self.cli.node_id, pointer(l2_entry), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
               assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create SMAC entry FAILED!!: rc = [" + str(rc) + "]"
               smac_l2_entry_array.append(l2_entry)
       except:
           src_l2entry_create_failed = 1
           log("Hit except (SMAC) config 1")
           pass

       # Dest MAC config
       try:
           for i, port in enumerate(devport_stats.devport_list):
               count = port
               port_hdl = ifcs_ctypes.ifcs_handle_t()
               port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[port])
               mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xAA)
               port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)
               l2_entry = ifcs_ctypes.ifcs_l2_entry_key_t()
               ifcs_ctypes.ifcs_l2_entry_key_t_init(pointer(l2_entry))
               l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(port_sp)

               ifcs_ctypes.ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry),
                       ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
               ifcs_ctypes.ifcs_l2_entry_key_t_mac_l2vni_set(pointer(l2_entry),
                       l2_entry.key.mac_l2vni)
               ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_mac_addr_set(pointer(l2_entry.key.mac_l2vni),
                       mac_addr)
               ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_l2vni_set(pointer(l2_entry.key.mac_l2vni),
                       l2vni_hdl)

               attr[0].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_DEST
               attr[0].value.handle = port_hdl
               attr[1].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
               attr[1].value.u32 = ifcs_ctypes.IFCS_L2_ENTRY_TYPE_STATIC
               rc = ifcs_ctypes.ifcs_l2_entry_create(self.cli.node_id, pointer(l2_entry), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
               assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create DMAC entry FAILED!!: rc = [" + str(rc) + "]"
               dmac_l2_entry_array.append(l2_entry)
       except:
           log("Hit except (DMAC) config 1")
           dst_l2entry_create_failed = 1
           pass

       try:
           # SYSPORT attr set
           #Build Sysport attr for Default VID config
           sp_attr_ct = 3
           sp_attr = (ifcs_ctypes.ifcs_attr_t * sp_attr_ct)()

           for i, port in enumerate(devport_stats.devport_list):
               if port == devport_stats.devport_list[-1]:
                   next_devport = devport_stats.devport_list[0]
               else:
                   next_devport = devport_stats.devport_list[i + 1]
               default_vid = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[next_devport])
               egress_vid = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[port])
               sp_attr[0].id = ifcs_ctypes.IFCS_SYSPORT_ATTR_DEFAULT_CVID
               sp_attr[0].value.u16 = default_vid
               sp_attr[1].id = ifcs_ctypes.IFCS_SYSPORT_ATTR_EGRESS_UNTAGGED_VLAN_ID
               sp_attr[1].value.u16 = egress_vid
               sp_attr[2].id = ifcs_ctypes.IFCS_SYSPORT_ATTR_EGRESS_UNTAGGED_VLAN_ID_ENABLE
               sp_attr[2].value.data = ifcs_ctypes.IFCS_BOOL_TRUE

               rc = ifcs_ctypes.ifcs_sysport_attr_set(self.cli.node_id, port_sp_hdl[port], 3, compat_pointer(sp_attr, ifcs_ctypes.ifcs_attr_t))
               assert rc == ifcs_ctypes.IFCS_SUCCESS, "SSP default PVID set FAILED!!: rc = [" + str(rc) + "]"
       except:
           log("Hit except (Sysport) config")
           sysport_attr_set_failed = 1
           pass

    # Connect ports like 2<->3, 4<->5, 6<->7, ..., 32<->1
    def config_snake_bidir(self, devport_stats):
       '''
           Fwd Flow: (Ixia -> 1 (->2); 2 -> 3(->4), 4 -> Ixia ... )
               > Incoming on Odd ports, Outgoing on Even ports

           Rev Flow: (Ixia -> 4 (->3); 3 -> 2(->1); 1 -> Ixia ... )
               > Incoming on Even ports, Outgoing on Odd ports
       '''
       port_sp_hdl = devport_stats.port_sp_hdl
       mac_addr_t = c_uint8 * 6
       devport_list = devport_stats.devport_list
       l2vni_hdl = ifcs_ctypes.ifcs_handle_t()
       dmac_l2_entry_array = devport_stats.dmac_l2_entry_array
       smac_l2_entry_array = devport_stats.smac_l2_entry_array

       rev_devport_list = [i for i in reversed(devport_list)]
       try:
           attr_count = 2
           attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()

           # SRC MAC entries for FWD flow
           for i, port in enumerate(devport_stats.devport_list):
               if (i % 2):
                   #pkts enter only on every other port starting from 1st port.
                   #So, skip alternate ports starting from second
                   continue
               count = port
               port_hdl = ifcs_ctypes.ifcs_handle_t()
               port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[port])
               mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xBB)
               port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)
               l2_entry = ifcs_ctypes.ifcs_l2_entry_key_t()
               ifcs_ctypes.ifcs_l2_entry_key_t_init(pointer(l2_entry))
               next_devport = devport_list[i+1]
               l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[next_devport]))

               ifcs_ctypes.ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry),
                       ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
               ifcs_ctypes.ifcs_l2_entry_key_t_mac_l2vni_set(pointer(l2_entry),
                       l2_entry.key.mac_l2vni)
               ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_mac_addr_set(pointer(l2_entry.key.mac_l2vni),
                       mac_addr)
               ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_l2vni_set(pointer(l2_entry.key.mac_l2vni),
                       l2vni_hdl)
               attr[0].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_DEST
               attr[0].value.handle = port_hdl
               attr[1].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
               attr[1].value.u32 = ifcs_ctypes.IFCS_L2_ENTRY_TYPE_STATIC
               rc = ifcs_ctypes.ifcs_l2_entry_create(self.cli.node_id, pointer(l2_entry), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
               assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create SMAC entry FAILED!!: rc = [" + str(rc) + "]"
               smac_l2_entry_array.append(l2_entry)

           log("Created l2_entries for SMAC for FWD flow")

           # SRC MAC entries for REVERSE flow
           for i, port in enumerate(rev_devport_list):
               if (i % 2):
                   #pkts enter only on every other port starting from 1st port.
                   #So, skip alternate ports starting from second
                   continue
               count = port
               port_hdl = ifcs_ctypes.ifcs_handle_t()
               port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[port])
               mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xAA)
               port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)
               l2_entry = ifcs_ctypes.ifcs_l2_entry_key_t()
               ifcs_ctypes.ifcs_l2_entry_key_t_init(pointer(l2_entry))
               next_devport = rev_devport_list[i+1]
               l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[next_devport]))

               ifcs_ctypes.ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry),
                       ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
               ifcs_ctypes.ifcs_l2_entry_key_t_mac_l2vni_set(pointer(l2_entry),
                       l2_entry.key.mac_l2vni)
               ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_mac_addr_set(pointer(l2_entry.key.mac_l2vni),
                       mac_addr)
               ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_l2vni_set(pointer(l2_entry.key.mac_l2vni),
                       l2vni_hdl)

               attr[0].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_DEST
               attr[0].value.handle = port_hdl
               attr[1].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
               attr[1].value.u32 = ifcs_ctypes.IFCS_L2_ENTRY_TYPE_STATIC
               rc = ifcs_ctypes.ifcs_l2_entry_create(self.cli.node_id, pointer(l2_entry), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
               assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create SMAC entry FAILED!!: rc = [" + str(rc) + "]"
               smac_l2_entry_array.append(l2_entry)
           log("Created l2_entries for SMAC for REVERSE flow")
       except:
           src_l2entry_create_failed = 1
           log("Hit except (SMAC) config 2")
           pass

       try:
           # Dest MAC entries for FWD flow
           for i, port in enumerate(devport_stats.devport_list):
               if ((i % 2) == 0):
                   #l2entry needed only to forward pkt to every other port starting from
                   #2nd port. So, skip alternate ports starting from first
                   continue
               count = port
               port_hdl = ifcs_ctypes.ifcs_handle_t()
               port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[port])
               mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xAA)
               port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)
               l2_entry = ifcs_ctypes.ifcs_l2_entry_key_t()
               ifcs_ctypes.ifcs_l2_entry_key_t_init(pointer(l2_entry))
               l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(port_sp)
               attr[0].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_DEST

               ifcs_ctypes.ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry),
                       ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
               ifcs_ctypes.ifcs_l2_entry_key_t_mac_l2vni_set(pointer(l2_entry),
                       l2_entry.key.mac_l2vni)
               ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_mac_addr_set(pointer(l2_entry.key.mac_l2vni),
                       mac_addr)
               ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_l2vni_set(pointer(l2_entry.key.mac_l2vni),
                       l2vni_hdl)

               attr[0].value.handle = port_hdl
               attr[1].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
               attr[1].value.u32 = ifcs_ctypes.IFCS_L2_ENTRY_TYPE_STATIC
               rc = ifcs_ctypes.ifcs_l2_entry_create(self.cli.node_id, pointer(l2_entry), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
               assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create DMAC entry FAILED!!: rc = [" + str(rc) + "]"
               dmac_l2_entry_array.append(l2_entry)
           log("Created l2_entries for DMAC for FWD flow")

           # Dest MAC entries for REVERSE flow
           for i, port in enumerate(rev_devport_list):
               if ((i % 2) == 0):
                   #l2entry needed only to forward pkt to every other port starting from
                   #2nd port. So, skip alternate ports starting from first
                   continue
               count = port
               mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xBB)
               port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[port])
               port_hdl = ifcs_ctypes.ifcs_handle_t()
               port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)
               l2_entry = ifcs_ctypes.ifcs_l2_entry_key_t()
               ifcs_ctypes.ifcs_l2_entry_key_t_init(pointer(l2_entry))
               l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(port_sp)

               ifcs_ctypes.ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry),
                       ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
               ifcs_ctypes.ifcs_l2_entry_key_t_mac_l2vni_set(pointer(l2_entry),
                       l2_entry.key.mac_l2vni)
               ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_mac_addr_set(pointer(l2_entry.key.mac_l2vni),
                       mac_addr)
               ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_l2vni_set(pointer(l2_entry.key.mac_l2vni),
                       l2vni_hdl)

               attr[0].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_DEST
               attr[0].value.handle = port_hdl
               attr[1].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
               attr[1].value.u32 = ifcs_ctypes.IFCS_L2_ENTRY_TYPE_STATIC
               rc = ifcs_ctypes.ifcs_l2_entry_create(self.cli.node_id, pointer(l2_entry), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
               assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create DMAC entry FAILED!!: rc = [" + str(rc) + "]"
               dmac_l2_entry_array.append(l2_entry)
           log("Created l2_entries for DMAC for REVERSE flow")
       except:
           log("Hit except (DMAC) config 2")
           dst_l2entry_create_failed = 1
           pass

       try:
           # SYSPORT attr set
           #Build Sysport attr for Default VID config
           sp_attr_ct = 3
           sp_attr = (ifcs_ctypes.ifcs_attr_t * sp_attr_ct)()

           for i, port in enumerate(devport_stats.devport_list):
               if ((i % 2) == 0):
                   #In FWD dir, every other port starting from first, CVID is next port.
                   #This way, by hitting corresponding l2_entries pkt goes to next port.
                   next_devport = devport_stats.devport_list[i + 1]
               else:
                   #In REV dir, every other port starting from second, CVID is previous port
                   #This way, by hitting corresponding l2_entries pkt goes to previous port.
                   next_devport = devport_stats.devport_list[i - 1]

               default_vid = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[next_devport])
               egress_vid = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[port])
               sp_attr[0].id = ifcs_ctypes.IFCS_SYSPORT_ATTR_DEFAULT_CVID
               sp_attr[0].value.u16 = default_vid
               sp_attr[1].id = ifcs_ctypes.IFCS_SYSPORT_ATTR_EGRESS_UNTAGGED_VLAN_ID
               sp_attr[1].value.u16 = egress_vid
               sp_attr[2].id = ifcs_ctypes.IFCS_SYSPORT_ATTR_EGRESS_UNTAGGED_VLAN_ID_ENABLE
               sp_attr[2].value.data = ifcs_ctypes.IFCS_BOOL_TRUE

               rc = ifcs_ctypes.ifcs_sysport_attr_set(self.cli.node_id, port_sp_hdl[port], 3, compat_pointer(sp_attr, ifcs_ctypes.ifcs_attr_t))
               assert rc == ifcs_ctypes.IFCS_SUCCESS, "SSP default PVID set FAILED!!: rc = [" + str(rc) + "]"
           log("Configured CVID and Untagged VID for all sysports")
       except:
           log("Hit except (Sysport) config")
           sysport_attr_set_failed = 1
           pass

    # Connect ports like 1<->2, 3<->4, 5<->6, ..., 31<->32
    def config_snake_bidir_straight(self, devport_stats):
       '''
           Fwd Flow: (Ixia -> 1; 1<->2(->3); 3<->4; 4 -> Ixia ... )
               > Incoming on Odd ports, Outgoing on Even ports

           Rev Flow: (Ixia -> 4; 4<->3(->2); 2<->1; 1 -> Ixia ... )
               > Incoming on Even ports, Outgoing on Odd ports
       '''
       port_sp_hdl = devport_stats.port_sp_hdl
       mac_addr_t = c_uint8 * 6
       devport_list = devport_stats.devport_list
       l2vni_hdl = ifcs_ctypes.ifcs_handle_t()
       dmac_l2_entry_array = devport_stats.dmac_l2_entry_array
       smac_l2_entry_array = devport_stats.smac_l2_entry_array

       # SRC MAC config
       try:
           attr_count = 2
           attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()

           for i, port in enumerate(devport_stats.devport_list):
               count = port
               port_hdl = ifcs_ctypes.ifcs_handle_t()
               port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[port])
               mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xBB)
               port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)
               l2_entry = ifcs_ctypes.ifcs_l2_entry_key_t()
               if port == devport_list[-1]:
                   next_devport = devport_list[0]
               else:
                   next_devport = devport_list[i + 1]
               l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[next_devport]))

               ifcs_ctypes.ifcs_l2_entry_key_t_init(pointer(l2_entry))
               ifcs_ctypes.ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry),
                       ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
               ifcs_ctypes.ifcs_l2_entry_key_t_mac_l2vni_set(pointer(l2_entry),
                       l2_entry.key.mac_l2vni)
               ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_mac_addr_set(pointer(l2_entry.key.mac_l2vni),
                       mac_addr)
               ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_l2vni_set(pointer(l2_entry.key.mac_l2vni),
                       l2vni_hdl)

               attr[0].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_DEST
               attr[0].value.handle = port_hdl
               attr[1].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
               attr[1].value.u32 = ifcs_ctypes.IFCS_L2_ENTRY_TYPE_STATIC
               rc = ifcs_ctypes.ifcs_l2_entry_create(self.cli.node_id, pointer(l2_entry), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
               assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create SMAC entry FAILED!!: rc = [" + str(rc) + "]"
               smac_l2_entry_array.append(l2_entry)
           log("Created l2_entries for SMAC for FWD flow")
       except:
           src_l2entry_create_failed = 1
           log("Hit except (SMAC) config 1")
           pass

       # Dest MAC config
       try:
           for i, port in enumerate(devport_stats.devport_list):
               count = port
               port_hdl = ifcs_ctypes.ifcs_handle_t()
               port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[port])
               mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xAA)
               port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)
               l2_entry = ifcs_ctypes.ifcs_l2_entry_key_t()
               ifcs_ctypes.ifcs_l2_entry_key_t_init(pointer(l2_entry))
               l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(port)
               l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[port]))

               ifcs_ctypes.ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry),
                       ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
               ifcs_ctypes.ifcs_l2_entry_key_t_mac_l2vni_set(pointer(l2_entry),
                       l2_entry.key.mac_l2vni)
               ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_mac_addr_set(pointer(l2_entry.key.mac_l2vni),
                       mac_addr)
               ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_l2vni_set(pointer(l2_entry.key.mac_l2vni),
                       l2vni_hdl)

               attr[0].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_DEST
               attr[0].value.handle = port_hdl
               attr[1].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
               attr[1].value.u32 = ifcs_ctypes.IFCS_L2_ENTRY_TYPE_STATIC
               rc = ifcs_ctypes.ifcs_l2_entry_create(self.cli.node_id, pointer(l2_entry), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
               assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create DMAC entry FAILED!!: rc = [" + str(rc) + "]"
               dmac_l2_entry_array.append(l2_entry)
           log("Created l2_entries for DMAC for FWD flow")
       except:
           log("Hit except (DMAC) config 1")
           dst_l2entry_create_failed = 1
           pass

       # Rev Flow Src MAC config
       try:
           attr_count = 2
           attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()

           for i, port in enumerate(devport_stats.devport_list):
               if ((i % 2) == 0):
                   #l2entry needed only to forward pkt to every other port starting from
                   #2nd port. So, skip alternate ports starting from first
                   continue
               count = port
               port_hdl = ifcs_ctypes.ifcs_handle_t()
               port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[port])
               mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xDD)
               port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)
               l2_entry = ifcs_ctypes.ifcs_l2_entry_key_t()
               if port == devport_list[-1]:
                   l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[devport_list[0]]))
               else:
                   next_devport = devport_list[i + 1]
                   l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[next_devport]))

               ifcs_ctypes.ifcs_l2_entry_key_t_init(pointer(l2_entry))
               ifcs_ctypes.ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry),
                       ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
               ifcs_ctypes.ifcs_l2_entry_key_t_mac_l2vni_set(pointer(l2_entry),
                       l2_entry.key.mac_l2vni)
               ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_mac_addr_set(pointer(l2_entry.key.mac_l2vni),
                       mac_addr)
               ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_l2vni_set(pointer(l2_entry.key.mac_l2vni),
                       l2vni_hdl)

               attr[0].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_DEST
               attr[0].value.handle = port_hdl
               attr[1].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
               attr[1].value.u32 = ifcs_ctypes.IFCS_L2_ENTRY_TYPE_STATIC
               rc = ifcs_ctypes.ifcs_l2_entry_create(self.cli.node_id, pointer(l2_entry), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
               assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create SMAC entry FAILED!!: rc = [" + str(rc) + "]"
               smac_l2_entry_array.append(l2_entry)
           log("Created l2_entries for SMAC for REVERSE flow")
       except:
           src_l2entry_create_failed = 1
           log("Hit except (SMAC) config 1")
           pass

       # Reverse Flow Dest MAC config
       try:
           for i, port in enumerate(devport_stats.devport_list):
               if ((i % 2) == 0):
                   #l2entry needed only to forward pkt to every other port starting from
                   #2nd port. So, skip alternate ports starting from first
                   continue
               count = port
               port_hdl = ifcs_ctypes.ifcs_handle_t()
               port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[port])
               mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xCC)
               port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)
               l2_entry = ifcs_ctypes.ifcs_l2_entry_key_t()
               ifcs_ctypes.ifcs_l2_entry_key_t_init(pointer(l2_entry))
               l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[port]))

               ifcs_ctypes.ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry),
                       ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
               ifcs_ctypes.ifcs_l2_entry_key_t_mac_l2vni_set(pointer(l2_entry),
                       l2_entry.key.mac_l2vni)
               ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_mac_addr_set(pointer(l2_entry.key.mac_l2vni),
                       mac_addr)
               ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_l2vni_set(pointer(l2_entry.key.mac_l2vni),
                       l2vni_hdl)

               attr[0].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_DEST
               attr[0].value.handle = port_hdl
               attr[1].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
               attr[1].value.u32 = ifcs_ctypes.IFCS_L2_ENTRY_TYPE_STATIC
               rc = ifcs_ctypes.ifcs_l2_entry_create(self.cli.node_id, pointer(l2_entry), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
               assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create DMAC entry FAILED!!: rc = [" + str(rc) + "]"
               dmac_l2_entry_array.append(l2_entry)
           log("Created l2_entries for DMAC for REVERSE flow")
       except:
           log("Hit except (DMAC) config 1")
           dst_l2entry_create_failed = 1
           pass

       try:
           # SYSPORT attr set
           #Build Sysport attr for Default VID config
           sp_attr_ct = 3
           sp_attr = (ifcs_ctypes.ifcs_attr_t * sp_attr_ct)()

           for i, port in enumerate(devport_stats.devport_list):
               sp_attr[0].id = ifcs_ctypes.IFCS_SYSPORT_ATTR_DEFAULT_CVID
               if i % 2 != 0: #Even
                   if port == devport_stats.devport_list[-1]:
                       sp_attr[0].value.u16 = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[devport_stats.devport_list[0]])
                   else:
                       sp_attr[0].value.u16 = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[devport_stats.devport_list[i + 1]])
               else: #Odd for Reverse flow
                   if port == devport_stats.devport_list[0]:
                       sp_attr[0].value.u16 = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[devport_stats.devport_list[-1]])
                   else:
                       sp_attr[0].value.u16 = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[devport_stats.devport_list[i - 1]])
               sp_attr[1].id = ifcs_ctypes.IFCS_SYSPORT_ATTR_EGRESS_UNTAGGED_VLAN_ID
               sp_attr[1].value.u16 = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[port])
               sp_attr[2].id = ifcs_ctypes.IFCS_SYSPORT_ATTR_EGRESS_UNTAGGED_VLAN_ID_ENABLE
               sp_attr[2].value.data = ifcs_ctypes.IFCS_BOOL_TRUE

               rc = ifcs_ctypes.ifcs_sysport_attr_set(self.cli.node_id, port_sp_hdl[port], 3, compat_pointer(sp_attr, ifcs_ctypes.ifcs_attr_t))
               assert rc == ifcs_ctypes.IFCS_SUCCESS, "SSP default PVID set FAILED!!: rc = [" + str(rc) + "]"
           log("Configured CVID and Untagged VID for all sysports")
       except:
           log("Hit except (Sysport) config")
           sysport_attr_set_failed = 1
           pass


    def config(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)

        # PMA is not supported on ETH ports in K2
        device_type = ifcs_ctypes.im_nmgr_node_device_type_get(self.cli.node_id)
        if device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_K2:
            choices_lb = ['NONE', 'PCS']
        else:
            choices_lb = ['NONE', 'PCS', 'PMA']

        parser = argparse.ArgumentParser(description='Snake test config', prog='snake config', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-p', type=str, default="all", help='Port list')
        parser.add_argument('-lb', type=str, choices=choices_lb, default='NONE', help='Loopback type')
        parser.add_argument('-sdd', help='Disable serdes tx on ports; used if lb is not NONE', action="store_true")
        parser.add_argument('-id', type=int, default=None, help='User defined snake id  [1-1023]')
        parser.add_argument('-shp', type=str, choices=['NONE', 'P_SHP', 'Q_SHP', 'ALL'], default='NONE', help='Shaping type')
        parser.add_argument('-v', help='Verbose', action="store_true")
        parser.add_argument('-b',  help='Bi-directional cross(2-3, 4-5,...,32-1)  traffic from first and last ports', action="store_true")
        parser.add_argument('-bs', help='Bi-directional straight(1-2, 3-4,...,31-32) traffic from first and last ports', action="store_true")

        try:
            res = parser.parse_args(self.arg_list)
        except:
            return 'FAILED'

        log("L2Snake Version: {}\n".format(self.ver_disp))
        # user can't config bidirectional and loopback together
        if res.b or res.bs:
            if res.lb != 'NONE':
                log("loopback and bidirectional config can't co-exist")
                return 'FAILED'

        '''
        If -p arg not given, default port range is all ports.
        '''
        max_dev_port = self.get_max_devport()
        max_devport_range = "1-2"
        if max_dev_port:
            max_devport_range = "1-%d"%(max_dev_port)

        if res.p == 'all':
            # Port range not given, default to all ports
            devport_arg = max_devport_range
            devport_arg_list = max_devport_range.split(",")
        else:
            # Use given devport range
            try:
                devport_arg = res.p
                devport_arg_list = res.p.split(",")
            except:
                devport_arg = max_devport_range
                devport_arg_list = max_devport_range.split(",")

        # Allocate run's data object which saves config and stats
        devport_stats = DevportStats()
        devport_list = devport_stats.devport_list

        find = False
        if res.id != None:
            for instance in Snake.devport_stats_runs:
                if instance.id == res.id:
                    log('Snake id already in use!\n')
                    return 'FAILED'
            devport_stats.id = res.id
        else:
            for index in range(1, 1024):
                find = False
                for instance in Snake.devport_stats_runs:
                    if instance.id == index:
                        find = True
                        break
                if find == False:
                    devport_stats.id = index
                    break
                if index == 1023:
                    log("Can not alloc snake id")
                    return 'FAILED'

        for i, dp in enumerate(devport_arg_list):
            if '-' in dp:
                dp_range = devport_arg.split(",")[i].split("-")
                for j in range(int(dp_range[0]), int(dp_range[1]) + 1):
                    devport_stats.devport_list.append(j)
            else:
                devport_stats.devport_list.append(int(dp))

        # check if devport_list of new snake is overlapping with devport list of existing snake(s), if yes, return FAILED
        new_devport_list = devport_stats.devport_list
        new_devport_set = set(new_devport_list)
        port_overlap = False
        for instance in Snake.devport_stats_runs:
            if instance:
                existing_devport_list = instance.devport_list
                existing_devport_set = set(existing_devport_list)
                if (existing_devport_set & new_devport_set):
                    port_overlap = True
                    break;
        if port_overlap:
            log("one or more ports in the devport list is already part of an existing snake. use ports that are not part of any existing snake(s)")
            return 'FAILED'

        allowed_lb_types = ['none', 'pcs', 'pma']
        if (res.lb.upper() not in map(str.upper, allowed_lb_types)):
            log("Invalid Loopback type specified: ", lb_type)
            return 'FAILED'
        lb_type = res.lb
        devport_stats.lb_type = res.lb
        shp_type = res.shp

        verbose = res.v
        devport_stats.verbose = res.v

        bidir = res.b
        bidir_straight = res.bs

        sdd = res.sdd
        devport_stats.sdd = sdd

        if bidir:
            devport_stats.type = "bidir_cross"
        elif bidir_straight:
            devport_stats.type = "bidir_straight"
        else:
            devport_stats.type = "unidir"

        config_fdb_methods = {"unidir": self.config_snake_unidir,
                              "bidir" : self.config_snake_bidir,
                              "bidir_straight": self.config_snake_bidir_straight
        }

        # locals
        sysport_hdl_get_failed = 0
        stp_create_failed = 0
        stp_port_set_failed = 0
        l2vni_create_failed = 0
        l2vni_stp_config_failed = 0
        l2vni_member_config_failed = 0
        src_l2entry_create_failed = 0
        dst_l2entry_create_failed = 0
        sysport_attr_set_failed = 0
        devport_lb_config_failed = 0
        devport_shp_config_failed = 0
        queue_shp_config_failed = 0

        # Configure
        dport = devport_stats.devport_list[0]
        ret = ifcs_ctypes.ifcs_status_t()
        vni_hdl = ifcs_ctypes.ifcs_handle_t()
        attr = (ifcs_ctypes.ifcs_attr_t * 1)()
        vni_attr = (ifcs_ctypes.ifcs_attr_t * 2)()

        attr[0].id = ifcs_ctypes.IFCS_LINKSCAN_ATTR_ENABLE
        attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE

        '''
        rc = ifcs_ctypes.ifcs_linkscan_attr_set(0, 1, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Linkscan disable FAILED!!. RC " + str(rc)
        if (verbose == 1):
            log("Linkscan disabled")
        '''

        maxPorts = MAX_DEV_PORTS
        port_sp_hdl = devport_stats.port_sp_hdl
        port_sp_hdl.clear()

        dmac_l2_entry_array = devport_stats.dmac_l2_entry_array
        smac_l2_entry_array = devport_stats.smac_l2_entry_array
        cpu_sp_hdl = devport_stats.cpu_sp_hdl
        stp_hdl = devport_stats.stp_hdl

        try:
            for port in devport_stats.devport_list:
                port_sp_hdl[port] = getSysportHandleFromDevPort(devport_stats.node_id, port)
            port = cpu_port
            cpu_sp_hdl.value = getSysportHandleFromDevPort(devport_stats.node_id, cpu_port)
        except:
            log("Sysport get FAILED for devport {}".format(port))
            sysport_hdl_get_failed = 1
            return

        if shp_type.upper() == 'P_SHP' or shp_type.upper() == 'ALL':
            try:
                for devport in devport_stats.devport_list:
                    attrCount = 3
                    attrList = (ifcs_ctypes.ifcs_attr_t * attrCount)()
                    #Set the max_rate shaper to 1Gbps
                    attrList[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_MAX_RATE_ENABLE
                    attrList[0].value.data = 1
                    attrList[1].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_MAX_RATE
                    attrList[1].value.u64 = 10 * 1000 * 1000 #max_rate config is in th Kbps units
                    attrList[2].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_MAX_BURST_SIZE
                    attrList[2].value.u32 = 160000
                    ret = ifcs_ctypes.ifcs_devport_attr_set(0, devport, attrCount, compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t))
                    assert ret == ifcs_ctypes.IFCS_SUCCESS

            except:
                log("Devport Shaper config FAILED!!")
                devport_shp_config_failed = 1
                pass

        if shp_type.upper() == 'Q_SHP' or shp_type.upper() == 'ALL':
            try:
                attr = (ifcs_ctypes.ifcs_attr_t * ifcs_ctypes.IFCS_QUEUE_ATTR_MAX_COUNT)()
                queue = ifcs_ctypes.ifcs_queue_t()
                attr_val = ifcs_ctypes.ifcs_uint32_t()
                ifcs_ctypes.ifcs_queue_t_init(pointer(queue))
                for devport in devport_stats.devport_list:
                    for i in range(0,8):
                        queue.devport = devport
                        queue.queue_id = i
                        ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, 0))
                        ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, 1))
                        ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, 2))
                        ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, 0), ifcs_ctypes.IFCS_QUEUE_ATTR_MAX_RATE_ENABLE)
                        ifcs_ctypes.ifcs_attr_t_value_data_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, 0), ifcs_ctypes.IFCS_BOOL_TRUE)
                        ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, 1), ifcs_ctypes.IFCS_QUEUE_ATTR_MAX_RATE)
                        ifcs_ctypes.ifcs_attr_t_value_u64_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, 1), 20000000000)
                        ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, 2), ifcs_ctypes.IFCS_QUEUE_ATTR_MAX_RATE_BURST_SIZE)
                        ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, 2), 160000)
                        rc = ifcs_ctypes.ifcs_queue_attr_set(0, pointer(queue), 3, compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, 0))
                        assert ifcs_ctypes.IFCS_STATUS_REASON(rc) == ifcs_ctypes.IFCS_SUCCESS

            except:
                log("Queue Shaper config FAILED!!")
                queue_shp_config_failed = 1
                pass


        ####### STEP0 #######
        ###### STP CONFIG #######
        try:
            stp_hdl.value = ifcs_ctypes.IFCS_NULL_HANDLE
            ret = ifcs_ctypes.ifcs_stp_create(0, pointer(stp_hdl), 0, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "STP instance creation FAILED!!"
        except:
            log("STP create FAILED!!")
            stp_create_failed = 1
            pass

        try:
            #mbrs=OrderedDict()
            #for mbr in port_sp_hdl:
            #    mbrVal = ifcs_ctypes.IFCS_HANDLE_VALUE(mbr)
            #    mbrs[mbr] = ifcs_ctypes.IFCS_HANDLE_SYSPORT(mbrVal)

            mbrs = port_sp_hdl
            member_count = len(mbrs)
            member_list = (ifcs_ctypes.ifcs_handle_t * member_count)()
            member_attr_count = 0
            member_attr_list = (ifcs_ctypes.ifcs_attr_t * member_attr_count)()
            count=0
            for mbr in mbrs:
                member_list[count] = mbrs[mbr]
                count += 1

            stp_attr_count = 1
            stp_attr = ifcs_ctypes.ifcs_attr_t()
            stp_attr.id        = ifcs_ctypes.IFCS_STP_PORT_ATTR_STP_STATE;
            stp_attr.value.u32 = ifcs_ctypes.IFCS_STP_PORT_STATE_FORWARDING;

            ret = ifcs_ctypes.ifcs_stp_port_add(0, stp_hdl, count, compat_pointer(member_list, ifcs_ctypes.ifcs_handle_t), stp_attr_count, pointer(stp_attr))
            assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                   "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                    str(l2vni)
            #for mbr in mbrs:
            #    ret = ifcs_ctypes.ifcs_stp_port_attr_set(0, stp_hdl, mbrs[mbr], stp_attr_count, pointer(stp_attr))
            #    assert ret == ifcs_ctypes.IFCS_SUCCESS,\
            #           "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
            #            str(l2vni)
        except:
            stp_port_set_failed = 1
            log("STP port set FAILED!!")
            pass

        ###### VNI CONFIG ######
        # Create VNI and add members
        try:
            ###### VNI CONFIG ######
            # Create VNI and add members
            l2vni_hdl = ifcs_ctypes.ifcs_handle_t()
            for i in devport_stats.devport_list:
                sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[i])
                l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(sp)
                ret = ifcs_ctypes.ifcs_l2vni_create(0, pointer(l2vni_hdl), 0, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
                assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                       "ERR during L2VNI creation " + str(i)
        except:
            log("Hit except L2VNI create config")
            l2vni_create_failed = 1
            pass

        try:
            # Set STP instance for created VNI
            vni_attr[0].id = ifcs_ctypes.IFCS_L2VNI_ATTR_STP_INSTANCE
            vni_attr[0].value.handle = stp_hdl
            ret = ifcs_ctypes.ifcs_l2vni_attr_set(0, l2vni_hdl, 1, compat_pointer(vni_attr, ifcs_ctypes.ifcs_attr_t))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "STP instance vni attr set FAILED!!"
        except:
            l2vni_stp_config_failed = 1
            log("Hit except L2VNI stp config")
            pass

        try:
            for i in devport_stats.devport_list:
                sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[i])
                l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(sp)
                ret = ifcs_ctypes.ifcs_l2vni_member_add(0, l2vni_hdl,
                                             member_count, compat_pointer(member_list, ifcs_ctypes.ifcs_handle_t),
                                             member_attr_count, compat_pointer(member_attr_list, ifcs_ctypes.ifcs_attr_t))
                assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                       "ERR during L2VNI mbr add " + str(l2vni_hdl)

                #Add CPU port to VNI membership if not already
                if cpu_port not in devport_stats.devport_list:
                    ret = ifcs_ctypes.ifcs_l2vni_member_add(0, l2vni_hdl,
                                                1, pointer(cpu_sp_hdl),
                                                member_attr_count, compat_pointer(member_attr_list, ifcs_ctypes.ifcs_attr_t))
                    assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                        "ERR during L2VNI mbr add for CPU port" + str(l2vni_hdl)
        except:
            log("Hit except L2VNI member config")
            l2vni_member_config_failed = 1
            pass

        ####### config FDB based on unidir topo or bidir topo #######
        if bidir:
            config_fdb_methods['bidir'](devport_stats)
        elif bidir_straight:
            config_fdb_methods['bidir_straight'](devport_stats)
        else:
            config_fdb_methods['unidir'](devport_stats)

        ##### Config Loopback mode #######
        if (lb_type.upper() != 'NONE'):
            try:
                # Disable all the ports
                devport_attr_ct = 1
                devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
                devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE;
                devport_attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE;

                for port in devport_stats.devport_list:
                    if port == cpu_port:
                        continue
                    rc = ifcs_ctypes.ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t))
                    assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                        "ERR during port admin disable:" + str(port)

                devport_attr_ct = 1
                devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
                for port in devport_stats.devport_list:
                    if port == cpu_port:
                        continue
                    if (lb_type.upper() == 'PCS'):
                        lb = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_PCS
                    elif (lb_type.upper() == 'PMA'):
                        lb = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_PMA
                    else:
                        lb = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_NONE
                    devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LOOPBACK
                    devport_attr[0].value.u32 = lb
                    rc = ifcs_ctypes.ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t))
                    assert rc == ifcs_ctypes.IFCS_SUCCESS, "Set port loopback FAILED!!: rc = [" + str(rc) + "]"

                # Enable all the ports
                devport_attr_ct = 0
                devport_attr = (ifcs_ctypes.ifcs_attr_t * 2)()
                devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE;
                devport_attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_TRUE;
                devport_attr_ct += 1
                if devport_stats.sdd == 1:
                    devport_attr[1].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SD_TX_OUTPUT_ENABLE;
                    devport_attr[1].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE;
                    devport_attr_ct += 1

                for port in devport_stats.devport_list:
                    if port == cpu_port:
                        continue
                    rc = ifcs_ctypes.ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t))
                    assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                        "ERR during port admin disable:" + str(port)
            except:
                log("Hit except (Devport loopback) config")
                devport_lb_config_failed = 1
        else:
             try:
                # Enable all the ports
                devport_attr_ct = 1
                devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
                devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE;
                devport_attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_TRUE;

                for port in devport_stats.devport_list:
                    if port == cpu_port:
                        continue
                    rc = ifcs_ctypes.ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t))
                    assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                        "ERR during port admin enable:" + str(port)
             except:
                log("Hit except (Devport loopback NONE) config")
                devport_lb_config_failed = 1


        # Create trap hdl on first snake config; used when validate_on_stop is specified
        if self.run == -1:
            self.trap_hdl.value = ifcs_ctypes.IFCS_HANDLE_HOSTIF_TRAP(self.trap_id)
            attr_count = 0
            attr = (ifcs_ctypes.ifcs_attr_t * 1)()
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_HOSTIF_TRAP_ATTR_QUEUE_NUM)
            ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), self.cpu_queue_num)
            attr_count += 1
            rc = ifcs_ctypes.ifcs_hostif_trap_create(self.cli.node_id,
                                                     pointer(self.trap_hdl),
                                                     attr_count,
                                                     compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err(
                    "Hostif trap create failed for cpu queue {} with rc: {}".
                    format(self.cpu_queue_num, rc))
                assert 0, "ERR during trap handle create; rc: {}".format(rc)

            
            attr_count = 0
            attr = (ifcs_ctypes.ifcs_attr_t * 2)()
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_UC_DYNAMIC_THRESHOLD_MAX_ENABLE)
            ifcs_ctypes.ifcs_attr_t_value_data_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_BOOL_FALSE)
            attr_count += 1
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_NONUC_DYNAMIC_THRESHOLD_MAX_ENABLE)
            ifcs_ctypes.ifcs_attr_t_value_data_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_BOOL_FALSE)
            attr_count += 1
            rc = ifcs_ctypes.ifcs_cpu_queue_attr_set(self.cli.node_id,
                                                     self.cpu_queue_num,
                                                     attr_count,
                                                     compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err(
                    "Dynamic threshold attribute set failed for cpu queue {} with rc: {}"
                    .format(self.cpu_queue_num, rc))
                assert 0, "ERR during cpu_queue threshold attr set; rc: {}".format(
                    rc)

        if sysport_hdl_get_failed or stp_create_failed or stp_port_set_failed or \
           l2vni_create_failed or l2vni_stp_config_failed or l2vni_member_config_failed or \
           src_l2entry_create_failed or dst_l2entry_create_failed or sysport_attr_set_failed or \
           devport_lb_config_failed or devport_shp_config_failed or queue_shp_config_failed:
            log("Snake test configuration failed")
            return 'FAILED'
        else:
            # Config success, save the config data useful for report generation
            self.insert_run_data(devport_stats)

        Snake.state = SNAKE_CONFIGD

        if (self.quiet == "false"):
            #display config
            devport_stats.display_config(devport_stats.id)

        # Wait for all ports to go link-up for 5 secs
        if (lb_type.upper() != 'NONE'):
            timer_val=5
        else:
            timer_val=15
        wait_time=0
        devport_attr_ct = 1
        devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
        devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LINK_STATUS;
        devport_attr[0].value.u32 = 0;
        actual_count = c_uint32()
        link_status=True
        while wait_time<timer_val:
            link_status=True
            for devport in devport_stats.devport_list:
                rc = ifcs_ctypes.ifcs_devport_attr_get (devport_stats.node_id, devport, 1,
                                 compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t), pointer(actual_count));
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err(
                        "link status attribute get for devport {} failed with rc: {}"
                        .format(devport, rc))
                    assert 0, "ERR during port admin enable: {}".format(devport)

                if (devport_attr[0].value.u32 != 1):
                    link_status=False
            if link_status:
                break;
            else:
                wait_time+=0.1
                time.sleep(0.1)

        if link_status != True:
            log_err("Not all devports are up")
            assert 0, "Not all devports are up"


        return 'PASS'


    def config_show(self, args):
        for instance in Snake.devport_stats_runs:
            devport_stats = instance
            table = PrintTable()
            header = []
            header.append("Devports")
            header.append("Loopback type")
            header.append("Snake id")
            header.append("Snake type")
            table.add_row(header)

            data = []
            data.append(str(devport_stats.devport_list)[1:-1])
            data.append(str(devport_stats.lb_type))
            data.append(str(devport_stats.id))
            data.append(str(devport_stats.type))
            table.add_row(data)
            table.print_table()
            table.reset_table()
        return 'PASS'

    # Note: If you are using cables to link up the ports and run l2snake with ixia traffic(unidir)
    # Then ports should be connected like 1<->2, 3<->4, 5<->6, ..., 31<->32.
    def start_traffic(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Snake test start_traffic', prog='snake start_traffic', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=0, help='Snake id needed if more than one snake configured')
        parser.add_argument('-n', type=int, default=100, help='Number of packets')
        parser.add_argument('-s', type=int, default=1500, help='Packet size')
        parser.add_argument('-payload', type=str, choices=['zero', 'incremental', 'stress', 'rrstress', 'custom'], default='incremental', help='Packet payload')
        parser.add_argument('-seed', type=int, default=0, help='Optional seed value. Used if payload is of type stress')
        parser.add_argument('-custom_value', type=auto_int, default=None, help='16-bit custom payload. Used if payload is of type custom')
        parser.add_argument('-v', help='Verbose', action="store_true")
        parser.add_argument('-b', default=None, help='Bi-directional cross(2-3, 4-5,...,32-1)  traffic from first and last ports', action="store_true")
        parser.add_argument('-bs', default=None, help='Bi-directional straight(1-2, 3-4,...,31-32) traffic from first and last ports', action="store_true")
        parser.add_argument('-vos', default=None, help='Validate-on-stop. If selected, upon stop_traffic, the traffic is terminated back to CPU and compared against injected packets. Supported only for uni-dir, loopback=PCS or PMA, single snake only', action="store_true")

        try:
            res = parser.parse_args(self.arg_list)
        except:
            return "FAILED"

        log("L2Snake Version: {}\n".format(self.ver_disp))

        if res.id:
            if res.id == -1:
                devport_stats = self.get_cur_run_data()
            else:
                find = False
                for instance in Snake.devport_stats_runs:
                    if instance.id == res.id:
                        devport_stats = instance
                        find = True
                        break
                if find == False:
                    log("Snake with id",res.id,"doesn't exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in Snake.devport_stats_runs:
                snake_count += 1
            if snake_count > 1:
                log("More than one snake configured. Use snake id to start traffic on a specific snake")
                return 'FAILED'
            devport_stats = self.get_cur_run_data()

        length = res.s
        num_pkt = res.n
        type = devport_stats.type
        bidir = False
        bidir_straight = False
        devport_stats.vos_gen_pkts = []
        devport_stats.payload_type = ""

        if type == 'bidir_cross':
            bidir = True
        elif type == 'bidir_straight':
            bidir_straight = True

        try:
            devport_stats.num_pkt[length] += num_pkt
        except (KeyError):
            devport_stats.num_pkt[length] = num_pkt

        if (length < 64):
            length = 64

        payload_data = res.custom_value

        if res.seed and (res.payload not in ['stress', 'rrstress']):
            log("ERROR: seed can be used only with payload of type stress/rrstress")
            return 'FAILED'

        seed = 0
        if res.seed == 0:
            seed = random.randrange(sys.maxsize)
        else:
            seed = res.seed

        log("Seed used: {}".format(seed))
        rng = random.Random(seed)

        if payload_data and res.payload != 'custom':
            log("ERROR: custom_value can be used only with payload of type custom")
            return 'FAILED'

        if (res.payload == 'custom') and (payload_data == None):
            log("ERROR: custom_value is mandatory for payload type custom")
            return 'FAILED'

        max_custom_val = 0xffff
        devport_stats.payload_type = res.payload

        if payload_data and payload_data not in range(max_custom_val):
            log("ERROR: custom_value valid range is 0-{0}".format(max_custom_val))
            return 'FAILED'

        if res.vos:
            if type == 'bidir_cross' or type == 'bidir_straight':
                log("ERROR: Validate-on-stop is supported only on unidir snake")
                return 'FAILED'

            if devport_stats.lb_type == 'NONE':
                log("ERROR: Validate-on-stop is not supported for loopback-type NONE")
                return 'FAILED'

            devport_stats.vos = 1
        else:
            devport_stats.vos = 0


        length = length - 4
        # Start traffic
        data = (c_byte * length)()
        curByte = 65
        smac_dmac_sz = 12 # 12 bytes
        for j in range(smac_dmac_sz):
            if (j == 0):
                data_bytes = compat_chr(0)
            elif (j == 5):
                if bidir:
                    data_bytes += compat_chr(0xBB)
                elif bidir_straight:
                    data_bytes += compat_chr(0xAA)
                else:
                    data_bytes += compat_chr(0xAA)
            elif (j == 11):
                if bidir:
                    data_bytes += compat_chr(0xAA)
                elif bidir_straight:
                    data_bytes += compat_chr(0xBB)
                else:
                    data_bytes += compat_chr(0xBB)
            else:
                data_bytes += compat_chr(0)

        if payload_data:
            payload_data_odd_byte = payload_data & 0xff
            payload_data_even_byte = (payload_data >> 8) & 0xff
            if (payload_data_even_byte == 0):
                payload_data_even_byte = payload_data_odd_byte

        signature_bytes = 0
        pktid_idx = 0
        pktid_bytes = 0
        if devport_stats.vos:
            
            data_bytes += compat_chr(0xBE)
            data_bytes += compat_chr(0xBA)
            data_bytes += compat_chr(0xFE)
            data_bytes += compat_chr(0xCA)

            data_bytes += compat_chr(devport_stats.id)

            pktid_idx = smac_dmac_sz + 4 + 1
            signature_bytes = 5
            data_bytes += compat_chr(0x0)
            data_bytes += compat_chr(0x0)
            data_bytes += compat_chr(0x0)
            pktid_bytes = 3

        for j in range(length - smac_dmac_sz - signature_bytes - pktid_bytes):
           if(res.payload == 'stress' or res.payload == 'rrstress'):
               curByte = rng.randint(0, 255)
               data_bytes += compat_chr(curByte)
           elif(res.payload == 'incremental'):
               data_bytes += compat_chr(curByte)
               curByte = (curByte + 1) & 0xff
           elif (res.payload == 'custom'):
                if (j%2):
                    #odd byte position
                    data_bytes += compat_chr(payload_data_odd_byte)
                else:
                    #even byte position
                    data_bytes += compat_chr(payload_data_even_byte)
           else:
               data_bytes += compat_chr(0)

        data = data_bytes

        pdata = cast(data, c_void_p)
        if devport_stats.vos == 1:
            devport_stats.vos_gen_pkts.insert(0, data)
        try:
            packet = ifcs_ctypes.ifcs_hostif_packet_info_t()
            ifcs_ctypes.ifcs_hostif_packet_info_t_init(byref(packet))
            packet.tx_type = ifcs_ctypes.IFCS_HOSTIF_TX_TYPE_PIPELINE_BYPASS
            dport = devport_stats.devport_list[0]
            packet.dsp = getSysportHandleFromDevPort(devport_stats.node_id, dport)
            packet.pkt_buf = pdata
            packet.pkt_buf_len = length
        except Exception as e:
            log("exc", e)
        tx_busy_count = 0
        for loop in range(0, num_pkt):
            while (1):
                rc = ifcs_ctypes.ifcs_hostif_send_packet(devport_stats.node_id, pointer(packet))
                if (rc == ifcs_ctypes.IFCS_SUCCESS):
                    if devport_stats.vos == 1:
                        devport_stats.vos_num_gen_pkts += 1
                    break
                if (rc != ifcs_ctypes.IFCS_BUSY):
                    log_err("Packet send to pcie failed")
                    log('Packet send to pcie failed, rc %d' %(rc))
                    return 'FAILED'
                tx_busy_count += 1
                time.sleep(0.001)

            if loop > 0 and devport_stats.vos == 1 and devport_stats.payload_type == 'rrstress':
                devport_stats.vos_gen_pkts.insert(loop, data)

            if(res.v == True):
                if loop == 0 or devport_stats.payload_type == 'rrstress':
                    log("Sent Packet-id {0}:".format(loop))
                    log(":".join("{:02x}".format(compat_ord(c)) for c in data))

            if res.payload == 'rrstress':
                data = data[0:smac_dmac_sz+signature_bytes]
                if devport_stats.vos:
                    data += compat_chr((loop+1) & 0xff)
                    data += compat_chr(((loop+1) & 0xff00) >> 8)
                    data += compat_chr(((loop+1) & 0xff0000) >> 16)
                for j in range(length - smac_dmac_sz - signature_bytes - pktid_bytes):
                    curByte = rng.randint(0, 255)
                    data += compat_chr(curByte)

                pdata = cast(data, c_void_p)
                packet.pkt_buf = pdata
                packet.pkt_buf_len = length

        if(res.v == True):
            if devport_stats.payload_type != 'rrstress':
                log("Sent {} packets with same Packet-id".format(num_pkt))

        # Start traffic - rev flow
        # send rev flow traffic only for bidir snake
        if bidir or bidir_straight:
            data = (c_byte * length)()
            curByte = 65
            smac_dmac_sz = 12 # 12 bytes
            for j in range(smac_dmac_sz):
                if (j == 0):
                    data_bytes = compat_chr(0)
                elif (j == 5):
                    if bidir:
                        data_bytes += compat_chr(0xAA)
                    elif bidir_straight:
                        data_bytes += compat_chr(0xCC)
                elif (j == 11):
                    if bidir:
                        data_bytes += compat_chr(0xBB)
                    elif bidir_straight:
                        data_bytes += compat_chr(0xBB)
                else:
                    data_bytes += compat_chr(0)
            for j in range(length - smac_dmac_sz):
               if(res.payload == 'stress' or res.payload == 'rrstress'):
                   curByte = rng.randint(0, 255)
                   data_bytes += compat_chr(curByte)
               elif(res.payload == 'incremental'):
                   data_bytes += compat_chr(curByte)
                   curByte = (curByte + 1) & 0xff
               elif (res.payload == 'custom'):
                    if (j%2):
                        #odd byte position
                        data_bytes += compat_chr(payload_data_odd_byte)
                    else:
                        #even byte position
                        data_bytes += compat_chr(payload_data_even_byte)
               else:
                   data_bytes += compat_chr(0)

            data = data_bytes
            pdata = cast(data, c_void_p)
            try:
                packet = ifcs_ctypes.ifcs_hostif_packet_info_t()
                ifcs_ctypes.ifcs_hostif_packet_info_t_init(byref(packet))
                packet.tx_type = ifcs_ctypes.IFCS_HOSTIF_TX_TYPE_PIPELINE_BYPASS
                dport = devport_stats.devport_list[-1]
                packet.dsp = getSysportHandleFromDevPort(devport_stats.node_id, dport)
                packet.pkt_buf = pdata
                packet.pkt_buf_len = length
            except Exception as e:
                log("exc", e)

            tx_busy_count = 0
            for loop in range(0, num_pkt):
                while (1):
                    rc = ifcs_ctypes.ifcs_hostif_send_packet(devport_stats.node_id, pointer(packet))
                    if (rc == ifcs_ctypes.IFCS_SUCCESS):
                        break
                    if (rc != ifcs_ctypes.IFCS_BUSY):
                        log_err("Packet send to pcie failed")
                        log('Packet send to pcie failed, rc %d' %(rc))
                        return 'FAILED'
                    tx_busy_count += 1
                    time.sleep(0.001)

                if(res.v == True):
                    log("Packet {0}:".format(loop+1))
                    log(":".join("{:02x}".format(compat_ord(c)) for c in data))

                if res.payload == 'rrstress':
                    data = data[0:smac_dmac_sz]
                    for j in range(length - smac_dmac_sz):
                        curByte = rng.randint(0, 255)
                        data += compat_chr(curByte)
                    pdata = cast(data, c_void_p)

        Snake.state = SNAKE_RUNNING
        devport_stats.state = SNAKE_RUNNING
        log('Started traffic on snake id %d' %(devport_stats.id))
        return 'PASS'

    def stop_traffic(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Snake test stop_traffic', prog='snake stop_traffic', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=0, help='Snake id needed if more than one snake configured')
        parser.add_argument('-b', default=None,  help='Bi-directional cross(2-3, 4-5,...,32-1) traffic from first and last ports', action="store_true")
        parser.add_argument('-bs',  default=None, help='Bi-directional straight(1-2, 3-4,...,31-32) traffic from first and last ports', action="store_true")

        try:
            res = parser.parse_args(self.arg_list)
        except:
            return "FAILED"

        log("L2Snake Version: {}\n".format(self.ver_disp))

        if res.id:
            if res.id == -1:
                devport_stats = self.get_cur_run_data()
            else:
                find = False
                for instance in Snake.devport_stats_runs:
                    if instance.id == res.id:
                        devport_stats = instance
                        find = True
                        break
                if find == False:
                    log("Snake with id",res.id,"doesn't exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in Snake.devport_stats_runs:
                snake_count += 1
            if snake_count > 1:
                log("More than one snake configured. Use snake id to stop traffic on a specific snake")
                return 'FAILED'
            devport_stats = self.get_cur_run_data()
        type = devport_stats.type

        dmac_l2_entry_array = devport_stats.dmac_l2_entry_array
        smac_l2_entry_array = devport_stats.smac_l2_entry_array
        port_sp_hdl = devport_stats.port_sp_hdl
        cpu_sp_hdl = devport_stats.cpu_sp_hdl
        stp_hdl = devport_stats.stp_hdl

        mac_addr_t = c_uint8 * 6
        devport_obj = Devport(self.cli)

        verbose = devport_stats.verbose
        devport_list = devport_stats.devport_list

        ##################################
        # stop unidir traffic
        ##################################
        port = devport_list[0]
        port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[port])
        port_hdl = ifcs_ctypes.ifcs_handle_t()
        l2vni_hdl = ifcs_ctypes.ifcs_handle_t()
        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xAA)
        port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)
        l2_entry = ifcs_ctypes.ifcs_l2_entry_key_t()
        ifcs_ctypes.ifcs_l2_entry_key_t_init(pointer(l2_entry))
        l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(port_sp)

        ifcs_ctypes.ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry),
                ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
        ifcs_ctypes.ifcs_l2_entry_key_t_mac_l2vni_set(pointer(l2_entry),
                l2_entry.key.mac_l2vni)
        ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_mac_addr_set(pointer(l2_entry.key.mac_l2vni),
                mac_addr)
        ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_l2vni_set(pointer(l2_entry.key.mac_l2vni),
                l2vni_hdl)

        attr_count = 0
        attr = (ifcs_ctypes.ifcs_attr_t * 2)()
        fwd_policy = ifcs_ctypes.ifcs_fwd_policy_t()
        ifcs_ctypes.ifcs_fwd_policy_t_init(pointer(fwd_policy))
        fwd_policy.fwd_action = ifcs_ctypes.IFCS_FWD_ACTION_DROP
        ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_FWD_POLICY)
        ifcs_ctypes.ifcs_attr_t_value_fwd_policy_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), pointer(fwd_policy))
        attr_count += 1

        if devport_stats.vos == 1:
            # Register rx callback
            Snake.rx_cbfn = ifcs_ctypes.ifcs_hostif_packet_notify_t(pkt_vos_cb)
            if (ifcs_ctypes.ifcs_hostif_register_rx_packet_notify(self.cli.node_id, None, Snake.rx_cbfn) != ifcs_ctypes.IFCS_SUCCESS):
                log("ERROR: Registering Packet Callback Function")

            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_CTC_POLICY)
            ctc_policy = ifcs_ctypes.ifcs_ctc_policy_t()
            ifcs_ctypes.ifcs_ctc_policy_t_init(pointer(ctc_policy))
            ctc_policy.ctc_action = ifcs_ctypes.IFCS_COPY_TO_CPU_ENABLE
            if self.trap_hdl.value == 0:
                log_err("ctc policy trap handle is 0")
                assert 0, "ctc policy trap handle is 0"
            ctc_policy.trap_handle = self.trap_hdl

            ifcs_ctypes.ifcs_attr_t_value_ctc_policy_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), pointer(ctc_policy))
            attr_count += 1

        rc = ifcs_ctypes.ifcs_l2_entry_attr_set(0, pointer(l2_entry), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err(
                "l2 entry attribute set for Drop FDB failed with rc: {}".format(
                    rc))
            assert 0, "Attr set to Drop FDB entry FAILED!!: rc = [{}]".format(
                rc)

        time.sleep(4)

        port_stats = []
        port_stats = devport_obj.stats_get(port)
        pre_counts = compat_listrange(2)
        pre_counts[0] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_OK]
        pre_counts[1] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_OK]

        time.sleep(1)

        port_stats = []
        port_stats = devport_obj.stats_get(port)
        post_counts = compat_listrange(2)
        post_counts[0] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_OK]
        post_counts[1] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_OK]

        if (((post_counts[1] - pre_counts[1]) > 0) or ((post_counts[0] - pre_counts[0]) > 0)):
            pass

        time.sleep(1)

        attr_count = 0
        fwd_policy = ifcs_ctypes.ifcs_fwd_policy_t()
        ifcs_ctypes.ifcs_fwd_policy_t_init(pointer(fwd_policy))
        fwd_policy.fwd_action = ifcs_ctypes.IFCS_FWD_ACTION_FORWARD
        ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_FWD_POLICY)
        ifcs_ctypes.ifcs_attr_t_value_fwd_policy_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), pointer(fwd_policy))
        attr_count += 1

        ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_CTC_POLICY)
        ctc_policy = ifcs_ctypes.ifcs_ctc_policy_t()
        ifcs_ctypes.ifcs_ctc_policy_t_init(pointer(ctc_policy))
        ctc_policy.ctc_action = ifcs_ctypes.IFCS_COPY_TO_CPU_DISABLE
        ctc_policy.trap_handle = self.trap_hdl

        ifcs_ctypes.ifcs_attr_t_value_ctc_policy_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), pointer(ctc_policy))
        attr_count += 1

        rc = ifcs_ctypes.ifcs_l2_entry_attr_set(0, pointer(l2_entry), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err(
                "l2 entry attribute set for Fwd FDB failed with rc: {}".format(
                    rc))
            assert 0, "Attr set back to Fwd FDB entry FAILED!!: rc = [{}]".format(
                rc)

        if devport_stats.vos == 1:
            if (ifcs_ctypes.ifcs_hostif_unregister_rx_packet_notify(self.cli.node_id) != ifcs_ctypes.IFCS_SUCCESS):
                log("ERROR: Unregistering Packet Callback Function")

        # resetting to defaults
        devport_stats.vos = 0
        devport_stats.payload_type = 'incremental'

        ###########################################
        # bidir stop traffic
        ###########################################
        # stop fwd traffic
        type = devport_stats.type
        bidir = False
        bidir_straight = False

        if type == 'bidir_cross':
            bidir = True
        elif type == 'bidir_straight':
            bidir_straight = True

        if bidir:
            mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xBB)
            mac_addr1 = mac_addr_t(0, 0, 0, 0, 0, 0xAA)
        elif bidir_straight:
            mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xBB)
            mac_addr1 = mac_addr_t(0, 0, 0, 0, 0, 0xCC)

        if bidir or bidir_straight:
            port = devport_list[0]
            port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[port])
            port_hdl = ifcs_ctypes.ifcs_handle_t()
            l2vni_hdl = ifcs_ctypes.ifcs_handle_t()

            port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)
            port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port)
            l2_entry = ifcs_ctypes.ifcs_l2_entry_key_t()
            ifcs_ctypes.ifcs_l2_entry_key_t_init(pointer(l2_entry))
            l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(port_sp)

            port1 = devport_list[-1]
            port_sp1 = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[port1])
            port1_hdl = ifcs_ctypes.ifcs_handle_t()
            l2vni1_hdl = ifcs_ctypes.ifcs_handle_t()
            port1_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp1)

            port1_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port1)
            l2_entry1 = ifcs_ctypes.ifcs_l2_entry_key_t()
            ifcs_ctypes.ifcs_l2_entry_key_t_init(pointer(l2_entry1))
            l2vni1_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(port_sp1)

            ifcs_ctypes.ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry),
                    ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
            ifcs_ctypes.ifcs_l2_entry_key_t_mac_l2vni_set(pointer(l2_entry),
                    l2_entry.key.mac_l2vni)
            ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_mac_addr_set(pointer(l2_entry.key.mac_l2vni),
                    mac_addr)
            ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_l2vni_set(pointer(l2_entry.key.mac_l2vni),
                    l2vni_hdl)

            # stop rev traffic
            ifcs_ctypes.ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry1),
                    ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
            ifcs_ctypes.ifcs_l2_entry_key_t_mac_l2vni_set(pointer(l2_entry1),
                    l2_entry1.key.mac_l2vni)
            ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_mac_addr_set(pointer(l2_entry1.key.mac_l2vni),
                    mac_addr1)
            ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_l2vni_set(pointer(l2_entry1.key.mac_l2vni),
                    l2vni1_hdl)

            attr_count = 0
            attr = (ifcs_ctypes.ifcs_attr_t * 2)()
            fwd_policy = ifcs_ctypes.ifcs_fwd_policy_t()
            ifcs_ctypes.ifcs_fwd_policy_t_init(pointer(fwd_policy))
            fwd_policy.fwd_action = ifcs_ctypes.IFCS_FWD_ACTION_DROP
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_FWD_POLICY)
            ifcs_ctypes.ifcs_attr_t_value_fwd_policy_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), pointer(fwd_policy))
            attr_count += 1

            rc = ifcs_ctypes.ifcs_l2_entry_attr_set(0, pointer(l2_entry), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err(
                    "l2 entry attribute set for Drop FDB failed with rc: {}".
                    format(rc))
                assert 0, "Attr set to Drop FDB entry FAILED!!: rc = [{}]".format(
                    rc)

            rc = ifcs_ctypes.ifcs_l2_entry_attr_set(0, pointer(l2_entry1), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err(
                    "l2 entry attribute set for Drop FDB failed with rc: {}".
                    format(rc))
                assert 0, "Attr set to Drop FDB entry FAILED!!: rc = [{}]".format(
                    rc)

            time.sleep(1)

            port_stats = []
            port_stats = devport_obj.stats_get(port)
            pre_counts = compat_listrange(2)
            pre_counts[0] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_OK]
            pre_counts[1] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_OK]

            time.sleep(1)

            port_stats = []
            port_stats = devport_obj.stats_get(port)
            post_counts = compat_listrange(2)
            post_counts[0] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_OK]
            post_counts[1] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_OK]

            if (((post_counts[1] - pre_counts[1]) > 0) or ((post_counts[0] - pre_counts[0]) > 0)):
                pass

            attr_count = 0
            fwd_policy = ifcs_ctypes.ifcs_fwd_policy_t()
            ifcs_ctypes.ifcs_fwd_policy_t_init(pointer(fwd_policy))
            fwd_policy.fwd_action = ifcs_ctypes.IFCS_FWD_ACTION_FORWARD
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_FWD_POLICY)
            ifcs_ctypes.ifcs_attr_t_value_fwd_policy_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), pointer(fwd_policy))
            attr_count += 1

            rc = ifcs_ctypes.ifcs_l2_entry_attr_set(0, pointer(l2_entry), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err("l2 entry attribute set for Fwd FDB failed with rc: {}".
                        format(rc))
                assert 0, "Attr set back to Fwd FDB entry FAILED!!: rc = [{}]".format(
                    rc)
            rc = ifcs_ctypes.ifcs_l2_entry_attr_set(0, pointer(l2_entry1), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err("l2 entry attribute set for Fwd FDB failed with rc: {}".
                        format(rc))
                assert 0, "Attr set back to Fwd FDB entry FAILED!!: rc = [{}]".format(
                    rc)

        Snake.state = SNAKE_STOPPED
        devport_stats.state = SNAKE_STOPPED
        log('Stopped traffic on snake id %d' %(devport_stats.id))
        return 'PASS'


    def gen_report(self, args, display = True, skipPop = False):
        if not skipPop:
            self.arg_list.pop(0)
            self.arg_list.pop(0)
            self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Snake test gen_report', prog='snake gen_report', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-t', type=int, default=10, help='Time in seconds to collect stats')
        parser.add_argument('-v', type=int, default=0, help=argparse.SUPPRESS)
        parser.add_argument('-c', help='Clear the counter for this snake config', action="store_true")
        parser.add_argument('-id', type=int, default=0, help='Snake id needed if more than one snake configured')
        pre_timestamp = [0] * MAX_DEV_PORTS
        new_timestamp = [0] * MAX_DEV_PORTS

        try:
            res, unknown = parser.parse_known_args(self.arg_list)
        except:
            return "FAILED"

        if res.id:
            if res.id == -1:
                devport_stats = self.get_cur_run_data()
            else:
                find = False
                for instance in Snake.devport_stats_runs:
                    if instance.id == res.id:
                        devport_stats = instance
                        find = True
                        break
                if find == False:
                    log("Snake with id",res.id,"doesn't exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in Snake.devport_stats_runs:
                snake_count += 1
            if snake_count > 1:
                log("More than one snake configured. Use snake id to generate report for a specific snake")
                return 'FAILED'
            devport_stats = self.get_cur_run_data()
        devport_stats.time = res.t
        verbose = res.v

        #Account for Inter-frame/packet-gap(12B) + preamble(8B)
        IPG_LEN = 12
        PREAMBLE_LEN = 8
        misc_delta_bytes = IPG_LEN + PREAMBLE_LEN

        devport_obj = Devport(self.cli)

        for p in range(MAX_DEV_PORTS):
            # Get current stats
            if p not in devport_stats.devport_list:
                continue

            port_stats = devport_obj.stats_get(p)
            pre_timestamp[p] = round(time.time(),4)
            devport_stats.devport_rx_frames[p] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_OK]
            if p != cpu_port:
                devport_stats.devport_rx_bytes[p] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_BYTES_OK]
            else:
                devport_stats.devport_rx_bytes[p] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_BYTES_ALL]
            devport_stats.devport_tx_frames[p] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_OK]
            if p != cpu_port:
                devport_stats.devport_tx_bytes[p] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_BYTES_OK]
            else:
                devport_stats.devport_tx_bytes[p] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_BYTES_ALL]
            devport_stats.devport_rx_errors[p] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_ERR_ANY]
            devport_stats.devport_tx_errors[p] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_ERR_ANY]

        # Sleep for given time and get stats again to calculate rate
        rx_rate = [0] * MAX_DEV_PORTS
        tx_rate = [0] * MAX_DEV_PORTS

        if display:
            log("Devport stats rate calculation being done, please wait %d secs" %(devport_stats.time))

        if (verbose):
            devport_stats.display()

        #Sleeping
        time.sleep(devport_stats.time)

        for p in range(MAX_DEV_PORTS):
            if p not in devport_stats.devport_list:
                continue
            port_stats = devport_obj.stats_get(p)
            new_timestamp[p] = round(time.time(),4)
            new_devport_rx_frames = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_OK]
            if p != cpu_port:
                new_devport_rx_bytes = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_BYTES_OK]
            else:
                new_devport_rx_bytes = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_BYTES_ALL]
            new_devport_tx_frames = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_OK]
            if p != cpu_port:
                new_devport_tx_bytes = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_BYTES_OK]
            else:
                new_devport_tx_bytes = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_BYTES_ALL]

            #Calculate Delta
            delta_rx_frames = new_devport_rx_frames - devport_stats.devport_rx_frames[p]
            delta_tx_frames = new_devport_tx_frames - devport_stats.devport_tx_frames[p]
            delta_rx_bytes = new_devport_rx_bytes - devport_stats.devport_rx_bytes[p]
            delta_tx_bytes = new_devport_tx_bytes - devport_stats.devport_tx_bytes[p]
            delta_timestamp = float(new_timestamp[p] - pre_timestamp[p])

            delta_tx_bytes += (delta_tx_frames * misc_delta_bytes)
            delta_rx_bytes += (delta_rx_frames * misc_delta_bytes)

            rx_rate[p] = float(float(delta_rx_bytes * 8)/float(1000*1000*1000*delta_timestamp))
            tx_rate[p] = float(float(delta_tx_bytes * 8)/float(1000*1000*1000*delta_timestamp))

            devport_stats.devport_rx_frames[p] = new_devport_rx_frames
            devport_stats.devport_rx_bytes[p] = new_devport_rx_bytes
            devport_stats.devport_tx_frames[p] = new_devport_tx_frames
            devport_stats.devport_tx_bytes[p] = new_devport_tx_bytes
            devport_stats.devport_rx_gbps[p] = rx_rate[p]
            devport_stats.devport_tx_gbps[p] = tx_rate[p]

        if display:
            devport_stats.display()

        if res.c:
            for p in range(MAX_DEV_PORTS):
                # Clear current stats
                if p not in devport_stats.devport_list:
                    continue
                port_stats = devport_obj.stats_clear(p)
                if devport_stats.state == SNAKE_STOPPED:
                    devport_stats.num_pkt.clear()

        '''
        for i in range(len(Snake.devport_stats_runs)):
            log("Run %d config and stats:" %(i+1))
            log("-----------------------")
            Snake.devport_stats_runs[i].display()
        '''
        pass

    def show_vos_stats(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Snake test show_vos_stats', prog='snake show_vos_stats', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=0, help='Snake id needed if more than one snake configured')

        try:
            res = parser.parse_args(self.arg_list)
        except:
            return "FAILED"

        log("L2Snake Version: {}\n".format(self.ver_disp))
        if res.id:
            if res.id == -1:
                devport_stats = self.get_cur_run_data()
            else:
                find = False
                for instance in Snake.devport_stats_runs:
                    if instance.id == res.id:
                        devport_stats = instance
                        find = True
                        break
                if find == False:
                    log("Snake with id",res.id,"doesn't exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in Snake.devport_stats_runs:
                snake_count += 1
            if snake_count > 1:
                log("More than one snake configured. Use snake id to stop traffic on a specific snake")
                return 'FAILED'
            devport_stats = self.get_cur_run_data()

        log("Total CPU packets sent                   : %d" %(devport_stats.vos_num_gen_pkts))
        log("Total CPU packets received               : %d" %(devport_stats.vos_num_rcvd_total))
        log("Good CPU packets received                : %d" %(devport_stats.vos_num_rcvd_good))
        log("Bad CPU packets received                 : %d" %(devport_stats.vos_num_rcvd_bad))
        if Snake.vos_glob_mismatch > 0:
            log("Global (across all snakes) errors    : %d" %(Snake.vos_glob_mismatch))

        # Print PASS/FAIL
        if devport_stats.vos_num_gen_pkts == 0:
            log("\nVOS_PFSTATUS: FAIL (Traffic not sent yet)")
            return 'FAILED'

        #TODO: Snake.vos_glob_mismatch is conceptually a global counter (across multiple snakes)
        # Revisit the second condition below when multi-snake support is needed
        if devport_stats.vos_num_rcvd_bad != 0 or Snake.vos_glob_mismatch != 0:
            # signature is good but payload is corrupted is caught here
            log("\nVOS_PFSTATUS: FAIL (Bad packets received)")
            return 'FAILED'

        if devport_stats.vos_num_rcvd_total != devport_stats.vos_num_gen_pkts:
            
            log("\nVOS_PFSTATUS: FAIL (Mismatch between sent and received pkts OR some packets with bad hdr received)")
            return 'FAILED'

        log("\nVOS_PFSTATUS: PASS")
        return 'PASS'

    def clear_vos_stats(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Snake test clear_vos_stats', prog='snake clear_vos_stats', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=0, help='Snake id needed if more than one snake configured')

        try:
            res = parser.parse_args(self.arg_list)
        except:
            return "FAILED"

        log("L2Snake Version: {}\n".format(self.ver_disp))

        if res.id:
            if res.id == -1:
                devport_stats = self.get_cur_run_data()
            else:
                find = False
                for instance in Snake.devport_stats_runs:
                    if instance.id == res.id:
                        devport_stats = instance
                        find = True
                        break
                if find == False:
                    log("Snake with id",res.id,"doesn't exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in Snake.devport_stats_runs:
                snake_count += 1
            if snake_count > 1:
                log("More than one snake configured. Use snake id to stop traffic on a specific snake")
                return 'FAILED'
            devport_stats = self.get_cur_run_data()

        devport_stats.vos_num_gen_pkts = 0
        devport_stats.vos_num_rcvd_total = 0
        devport_stats.vos_num_rcvd_good = 0
        devport_stats.vos_num_rcvd_bad = 0
        Snake.vos_glob_mismatch = 0
        return 'PASS'


    def verify(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Snake test verify_traffic', prog='snake verify', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-rate', type=float, default=0, help='rx in gbps')
        parser.add_argument('-display', type=int, default=1, help='Log verbose')
        parser.add_argument('-ports', nargs='+', type=int, help=argparse.SUPPRESS)
        parser.add_argument('-id', type=int, default=0, help='Snake id needed if more than one snake configured')

        try:
            res, unknown = parser.parse_known_args(self.arg_list)
        except:
            return "FAIL"
        rate = res.rate

        if res.id:
            if res.id == -1:
                devport_stats = self.get_cur_run_data()
            else:
                find = False
                for index, instance in enumerate(Snake.devport_stats_runs):
                    if instance.id == res.id:
                        devport_stats = instance
                        find = True
                        res.id = index
                        break
                if find == False:
                    log("Snake with id",res.id,"doesn't exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in Snake.devport_stats_runs:
                snake_count += 1
            if snake_count > 1:
                log("More than one snake configured. Use snake id to verify a specific snake")
                return 'FAILED'
            devport_stats = self.get_cur_run_data()
            res.id = -1

        # Caluculate rate
        self.gen_report(args, display = res.display, skipPop = True)
        ret = "PASS"

        num_ports = 0
        if res.ports is not None:
            num_ports = len(res.ports)

        # Verify the Tx and Rx rate for a given port pair
        if num_ports != 0:
            tx_port = res.ports[0]
            rx_port = res.ports[1]
            if (devport_stats.devport_tx_gbps[tx_port] == 0) or devport_stats.devport_rx_gbps[rx_port] == 0:
                ret = "FAIL"
                log(ret)
                return ret

            if rate != 0:
               #if (devport_stats.devport_rx_gbps[p] < (rate - 1)) or (devport_stats.devport_rx_gbps[p] > (rate + 1)):
               #400G and 200G line rate traffic test failing with above validation. Modifying as below to be generic
               if (abs(devport_stats.devport_rx_gbps[rx_port]-rate)/rate > 0.01):
                   ret = "FAIL"
                   log(ret)
                   return ret
        else:
            for p in devport_stats.devport_list:
                # If any of the configured ports rate is 0, snake test has problem
                if (devport_stats.devport_rx_gbps[p] == 0):
                    ret = "FAIL"
                    break
                if rate != 0:
                   #if (devport_stats.devport_rx_gbps[p] < (rate - 1)) or (devport_stats.devport_rx_gbps[p] > (rate + 1)):
                   if (abs(devport_stats.devport_rx_gbps[p]-rate)/rate > 0.01):
                       ret = "FAIL"
                       break
        log(ret)
        return ret

    def dump_report(self, args):
        pass

    def unconfig(self, args):
        parser = argparse.ArgumentParser(description='Snake unconfig', prog='snake unconfig', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=0, help='Snake id needed if more than one snake configured')

        try:
            res, unknown = parser.parse_known_args(self.arg_list)
        except:
            return "FAILED"

        if res.id:
            if res.id == -1:
                devport_stats = self.get_cur_run_data()
            else:
                find = False
                for index, instance in enumerate(Snake.devport_stats_runs):
                    if instance.id == res.id:
                        devport_stats = instance
                        find = True
                        res.id = index
                        break
                if find == False:
                    log("Snake with id",res.id,"doesn't exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in Snake.devport_stats_runs:
                snake_count += 1
            if snake_count > 1:
                log("More than one snake configured. Use snake id to unconfig a specific snake")
                return 'FAILED'
            devport_stats = self.get_cur_run_data()
            res.id = -1

        verbose = devport_stats.verbose
        devport_list = devport_stats.devport_list

        dmac_l2_entry_array = devport_stats.dmac_l2_entry_array
        smac_l2_entry_array = devport_stats.smac_l2_entry_array
        port_sp_hdl = devport_stats.port_sp_hdl
        cpu_sp_hdl = devport_stats.cpu_sp_hdl
        stp_hdl = devport_stats.stp_hdl

        # Set Loopback state to NONE
        try:
            # Disable all the ports
            devport_attr_ct = 0
            devport_attr = (ifcs_ctypes.ifcs_attr_t * 2)()
            devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE;
            devport_attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE;
            devport_attr_ct += 1
            if devport_stats.sdd == 1:
                devport_attr[1].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SD_TX_OUTPUT_ENABLE;
                devport_attr[1].value.u32 = ifcs_ctypes.IFCS_BOOL_TRUE;
                devport_attr_ct += 1

            for port in devport_stats.devport_list:
                rc = ifcs_ctypes.ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t))
                assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                    "ERR during port admin disable:" + str(port)

            devport_attr_ct = 1
            devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
            for port in devport_stats.devport_list:
                lb = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_NONE
                devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LOOPBACK
                devport_attr[0].value.u32 = lb
                rc = ifcs_ctypes.ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t))
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Loopback set FAILED!!: rc = [" + str(rc) + "]"

        except:
            log("Hit except (Devport loopback) config")

        member_count = len(port_sp_hdl)
        member_list = (ifcs_ctypes.ifcs_handle_t * member_count)()

        for count, port in enumerate(port_sp_hdl):
            member_list[count] = port_sp_hdl[port]

        if verbose:
            log("Removing L2 entry")

        try:
            #for l2_entry in smac_l2_entry_array:
            while smac_l2_entry_array:
                l2_entry = smac_l2_entry_array.pop(0)
                rc = ifcs_ctypes.ifcs_l2_entry_delete(0, pointer(l2_entry))
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Delete SMAC L2 entry FAILED!!: rc = [" + str(rc) + "]"
        except:
            log("Hit except (SMAC L2entry) delete")
            pass

        try:
            #for l2_entry in dmac_l2_entry_array:
            while dmac_l2_entry_array:
                l2_entry = dmac_l2_entry_array.pop(0)
                rc = ifcs_ctypes.ifcs_l2_entry_delete(0, pointer(l2_entry))
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Delete DMAC L2 entry FAILED!!: rc = [" + str(rc) + "]"
        except:
            log("Hit except (DMAC L2entry) delete")
            pass

        if verbose:
            log("Removing L2VNI members")
        try:
            for i in devport_list:
                sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[i])
                l2vni_hdl = ifcs_ctypes.ifcs_handle_t()
                l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(sp)
                ret = ifcs_ctypes.ifcs_l2vni_member_remove(0, l2vni_hdl,
                                               member_count, compat_pointer(member_list, ifcs_ctypes.ifcs_handle_t))
                assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                       "ERR during L2VNI mbr remove " + str(i)

                #Remove CPU port to VNI membership
                if cpu_port not in devport_list:
                    ret = ifcs_ctypes.ifcs_l2vni_member_remove(0, l2vni_hdl,
                                                   1, pointer(cpu_sp_hdl))
                    assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                           "ERR during L2VNI mbr remove for CPU port" + str(i)
        except:
            log("Hit except L2VNI member delete")
            pass

        try:
            for i in devport_list:
                sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[i])
                l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(sp)
                try:
                    vni_attr = (ifcs_ctypes.ifcs_attr_t * 1)()
                    vni_attr[0].id = ifcs_ctypes.IFCS_L2VNI_ATTR_STP_INSTANCE
                    vni_attr[0].value.handle = 0
                    ret = ifcs_ctypes.ifcs_l2vni_attr_set(0, l2vni_hdl, 1, compat_pointer(vni_attr, ifcs_ctypes.ifcs_attr_t))
                    assert ret == ifcs_ctypes.IFCS_SUCCESS, "STP instance vni attr set FAILED!!"
                except:
                    log("L2VNI STP reset failed")

                ret = ifcs_ctypes.ifcs_l2vni_delete(0, l2vni_hdl.value)
                assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                       "ERR during L2VNI delete " + str(i)
        except:
            log("Hit except L2VNI delete")
            pass


        try:
            ret = ifcs_ctypes.ifcs_stp_delete(0, stp_hdl)
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "ERR during STP delete"
        except:
            log("Hit except STP delete")
            pass

        # set sysport cvid attr to default
        sp_attr_ct = 3
        sp_attr = (ifcs_ctypes.ifcs_attr_t * sp_attr_ct)()

        try:
            for i, port in enumerate(devport_stats.devport_list):
                sp_attr[0].id = ifcs_ctypes.IFCS_SYSPORT_ATTR_DEFAULT_CVID
                sp_attr[0].value.u16 = 0
                sp_attr[1].id = ifcs_ctypes.IFCS_SYSPORT_ATTR_EGRESS_UNTAGGED_VLAN_ID
                sp_attr[1].value.u16 = 0
                sp_attr[2].id = ifcs_ctypes.IFCS_SYSPORT_ATTR_EGRESS_UNTAGGED_VLAN_ID_ENABLE
                sp_attr[2].value.data = ifcs_ctypes.IFCS_BOOL_FALSE

                rc = ifcs_ctypes.ifcs_sysport_attr_set(self.cli.node_id, port_sp_hdl[port], 3, compat_pointer(sp_attr, ifcs_ctypes.ifcs_attr_t))
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "SSP default PVID set FAILED!!: rc = [" + str(rc) + "]"
        except:
            log("Hit except sysport cvid default")

        # Set Loopback state to NONE
        try:
            # Disable all the ports
            devport_attr_ct = 1
            devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
            devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE;
            devport_attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE;

            for port in devport_stats.devport_list:
                rc = ifcs_ctypes.ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t))
                assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                    "ERR during port admin disable:" + str(port)

            devport_attr_ct = 1
            devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
            for port in devport_stats.devport_list:
                lb = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_NONE
                devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LOOPBACK
                devport_attr[0].value.u32 = lb
                rc = ifcs_ctypes.ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t))
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "SSP default PVID set FAILED!!: rc = [" + str(rc) + "]"

        except:
            log("Hit except (Devport loopback) config")

        Snake.state = SNAKE_UNCONFIG

        if res.id != -1:
            del Snake.devport_stats_runs[res.id]
        else:
            Snake.devport_stats_runs.pop()
        Snake.run -= 1

        if self.run == -1:
            
            attr_count = 0
            attr = (ifcs_ctypes.ifcs_attr_t * 2)()
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_UC_DYNAMIC_THRESHOLD_MAX_ENABLE)
            ifcs_ctypes.ifcs_attr_t_value_data_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_BOOL_TRUE)
            attr_count += 1
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_NONUC_DYNAMIC_THRESHOLD_MAX_ENABLE)
            ifcs_ctypes.ifcs_attr_t_value_data_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_BOOL_TRUE)
            attr_count += 1
            rc = ifcs_ctypes.ifcs_cpu_queue_attr_set(self.cli.node_id,
                                                     self.cpu_queue_num,
                                                     attr_count,
                                                     compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err(
                    "Unconfigure snake id {}: dynamic threshold attribute set failed for cpu queue {} with rc: {}"
                    .format(devport_stats.id, self.cpu_queue_num, rc))
                assert 0, "ERR during cpu_queue threshold attr set; rc: {}".format(
                    rc)

            # Delete the trap on last snake unconfig
            rc = ifcs_ctypes.ifcs_hostif_trap_delete(self.cli.node_id, self.trap_hdl)
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err(
                    "Unconfigure snake id {}: hostif trap delete failed for cpu queue {} with rc: {}"
                    .format(devport_stats.id, self.cpu_queue_num, rc))
                assert 0, "ERR during trap handle create"
        log('Unconfigured snake id %d' %(devport_stats.id))
        return 'PASS'
