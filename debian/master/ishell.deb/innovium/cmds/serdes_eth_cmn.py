#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import argparse
import copy
import distutils
import ifcs_ctypes as ifcs
from utils.compat_util import *

default_ib_list = [0]
default_pic_list = [0]
default_lane_list = [0]
default_devport_list = None
lane_label = {}

# Intended for use with argparse: convert a string to a list of integers:
# '5' => [5], '3,8,2' => [3, 8, 2], '4-6' => [4,5,6]
def parse_list(s):
    out = []
    if s == 'all':
        return []
    for item in s.split(','):
        if ':' in item:
            itemlist = item.split(':', 2)
        elif '-' in item:
            itemlist = item.split('-', 2)
        else:
            itemlist = [item]
        first = int(itemlist[0], 0)
        if len(itemlist) == 1:
            out.append(int(itemlist[0], 0))
        elif len(itemlist) == 2:
            last = int(itemlist[1], 0)
            if first <= last:
                for x in range(first, last+1):
                    out.append(x)
            else:
                for x in range(first, last-1, -1):
                    out.append(x)
        else:
            raise ValueError("Error parsing list argument")
    return out

# also for argparse:
def Hex(s):
    return int(s,16)

#devport translation to ib/pic/picport
def devport_to_ib_pic_picport(devport):
    info = ifcs.im_devport_info_t()
    rc = ifcs.im_devport_info_get(0, devport, ifcs.pointer(info));
    if rc != ifcs.IFCS_SUCCESS:
       log_err("Failed to get devport info\n");
       return

    return (info.pi_ib, info.pi_pic_id, info.pi_pic_port, info.pi_num_lanes)


# devport translation to ib/pic/laneidx
def devport_portlane_to_ib_pic_piclane(devport, portlane):
    info = ifcs.im_devport_info_t()
    rc = ifcs.im_devport_info_get(0, devport, ifcs.pointer(info));
    if portlane > (info.pi_num_lanes - 1):
        raise ValueError("Lane number %d is greater than max lanes index (%d) for devport %d"
                         %(portlane, info.pi_num_lanes - 1, devport))

    serdes_info = ifcs.im_serdes_info_t()
    rc = ifcs.im_devport_get_serdes_info(0, devport, portlane, ifcs.pointer(serdes_info))
    if rc != ifcs.IFCS_SUCCESS:
       log_err("Failed to get serdes info\n");
       return

    return (info.pi_ib, info.pi_pic_id, serdes_info.serdes_num)

def get_all_devports():
    attr = ifcs.ifcs_attr_t()
    actual_count = ifcs.c_uint32()
    attr.id = ifcs.IFCS_LINKSCAN_ATTR_DEVPORTS_COUNT
    ifcs.ifcs_linkscan_attr_get(0, 1, ifcs.pointer(attr), ifcs.pointer(actual_count))
    devport_count = attr.value.u32

    memberList = (ifcs.ifcs_devport_t * devport_count)()
    actual_count = ifcs.c_uint32(0)
    rc = ifcs.ifcs_linkscan_devports_get(0, devport_count, compat_pointer(memberList, ifcs.ifcs_devport_t), ifcs.pointer(actual_count))

    devport_list = []
    for d in memberList:
        info = ifcs.im_devport_info_t()
        ifcs.im_devport_info_get(0, d, ifcs.pointer(info))
        if info.pi_type == ifcs.IFCS_DEVPORT_TYPE_ETH:
            devport_list += [d]
    return sorted(devport_list)

def get_all_pics(ib):
    pic_list = []
    num_pics = ifcs.im_node_num_eth_pics(0)
    for pic in range(num_pics):
        pic_info = ifcs.im_devport_pic_info_t()
        ifcs.im_node_devport_pic_info_get(0, ib, pic, ifcs.pointer(pic_info))
        if pic_info.max_lanes > 0:
            pic_list += [pic]
    return pic_list

# helper func to keep track of / update the passed-in lane arguments and provide the current list
def get_full_lane_list(args):
    global default_ib_list, default_pic_list, default_lane_list, default_devport_list
    global lane_label, port_label
    if args.devport is not None and args.ib is not None:
        raise ValueError("Specify only one of --ib or --devport")
    if args.devport is not None and args.pic is not None:
        raise ValueError("Specify only one of --pic or --devport")
    if args.ib is not None:
        max_ib = ifcs.im_node_num_ibs(0)
        if args.ib == []:   # 'all' was given
            args.ib = compat_listrange(max_ib)
        if max(args.ib) >= max_ib:
            raise ValueError("Invalid IB number, valid choice [0-%d]" % max_ib)
        default_ib_list = args.ib
        default_devport_list = None
    if args.pic is not None:
        if len(args.pic) > 0 and max(args.pic) > 7:
                raise ValueError("Invalid PIC number, valid choice [0...7]")
        default_pic_list = args.pic
        if default_ib_list is None:
            raise ValueError("--pic specified but no IB specified")
    if args.devport is not None:
        if args.devport == []:   # 'all' was given
            args.devport = get_all_devports()
        default_devport_list = args.devport
        default_ib_list = None

    if args.lane is not None and len(args.lane) > 0 and max(args.lane) > 7:
        raise ValueError("Invalid lane number, valid choice [0...7]")

    if args.lane is not None:
        if any(la > 7 for la in args.lane):
            parser.error("Invalid lane number, valid choice [0...7]")
        default_lane_list = [la for la in args.lane if la <= 7]

    lane_label = {}
    port_label = {}
    full_lane_list = []
    if default_ib_list is not None:
        for ib in default_ib_list:
            if default_pic_list == []:  # i.e. 'all'
                pic_list = get_all_pics(ib)
            else:
                pic_list = default_pic_list
            for pic in pic_list:
                if default_lane_list == []:  # i.e. 'all'
                    lane_list = compat_listrange(ifcs.im_node_picports_per_pic(0))
                else:
                    lane_list = default_lane_list
                for piclane in lane_list:
                    full_lane = (ib,pic,piclane)
                    lane_label[full_lane] = 'IB %d PIC %d Lane %d:' % (ib,pic,piclane)
                    port_label[full_lane] = 'IB %d PIC %d Lane %d:' % (ib,pic,piclane)
                    full_lane_list += [full_lane]
    else:
        for devport in default_devport_list:
            if default_lane_list == []:  # i.e. 'all'
                info = ifcs.im_devport_info_t()
                rc = ifcs.im_devport_info_get(0, devport, ifcs.pointer(info));
                lane_list = compat_listrange(info.pi_num_lanes)
            else:
                lane_list = default_lane_list
            for portlane in lane_list:
                full_lane = devport_portlane_to_ib_pic_piclane(devport, portlane)
                lane_label[full_lane] = 'Devport: %d PortLane %d:' % (devport, portlane)
                port_label[full_lane] = 'Devport: %d:' % (devport)
                full_lane_list += [full_lane]

    return full_lane_list

def print_lane_id(lane, no_linefeed=False):
    global lane_label
    if no_linefeed:
        log_no_newline(lane_label[lane])
    else:
        log(lane_label[lane])

def print_port_id(lane, no_linefeed=False):
    global port_label
    if no_linefeed:
        log_no_newline(port_label[lane])
    else:
        log(port_label[lane])

def do_for_lane_list(start_func, each_func, args):
    full_lane_list = get_full_lane_list(args)

    if start_func is not None:
        start_func(full_lane_list, args)

    for full_lane in full_lane_list:
        # let the called function overwrite args without affecting other lanes
        args_subset = copy.deepcopy(args)
        try:  # 'save' arguments are open files, so don't use a deep copy, use it as-is
            args_subset.save = args.save
        except:
            pass
        args_subset.ib = None            # also, remove non-optional args
        args_subset.pic = None           # so cli_xxx can determine if no args
        args_subset.lane = None          # were passed
        args_subset.devport = None
        args_subset.func = None
        args_subset.subcmd = None
        each_func(full_lane, args_subset)

def multi_callback(start_func, each_func):
    """helper func to create a callback func for subcommands to manage default lanes and iterate"""
    return lambda args: do_for_lane_list(start_func, each_func, args)

def add_parser(parser, cli_funcs, valid_speed_parser, serdes_type):
    parser.add_argument('--ib', type=parse_list, default=None, metavar='IB_LIST',
                        help=argparse.SUPPRESS)
    parser.add_argument('--pic', type=parse_list, default=None, metavar='PIC_LIST',
                        help=argparse.SUPPRESS)
    parser.add_argument('--devport', type=parse_list, default=None, metavar='PORT_LIST',
                        help="Port number or list or 'all' (sticky)")
    parser.add_argument('--lane', type=parse_list, default=None, metavar='LANE_LIST',
                        help="Lane number or list or 'all' (sticky)")
    subparsers = parser.add_subparsers(help='All numerical arguments in hex')

    if "firmware" in cli_funcs:
        parser_fw = subparsers.add_parser('firmware', help='load firmware')
        parser_fw.add_argument('filename', type=str, nargs='?', help='If none, show Hash/CRC of current FW')
        parser_fw.set_defaults(func=multi_callback(*cli_funcs["firmware"]))

    if "status" in cli_funcs:
        parser_status = subparsers.add_parser('status', help='show status')
        if serdes_type == "condor":
            parser_status.add_argument('-r', '--reset-ber', dest='reset_ber', action='store_true',
                                       help='reset BER error counts, then delay 0.1 sec')
        if serdes_type == "magpie":
            parser_status.add_argument('-b', '--brief', action='store_true',
                                       help='One line output')
        parser_status.add_argument('-v', '--verbose', action='store_true')
        parser_status.set_defaults(func=multi_callback(*cli_funcs["status"]))

    if "config" in cli_funcs:
        parser_config = subparsers.add_parser('config', help='set configuration')
        if serdes_type == "magpie":
            parser_config.add_argument('--pre3', type=int, help='Pre3 Tap value')
        parser_config.add_argument('--pre2', type=int, help='Pre2 Tap value')
        parser_config.add_argument('--pre1', type=int, help='Pre1 Tap value')
        parser_config.add_argument('--main', type=int, help='Main Tap value')
        parser_config.add_argument('--post1', type=int, help='Post1 Tap value')
        if serdes_type == "magpie":
            parser_config.add_argument('--db', type=float, help='Loss value in dB')
            parser_config.add_argument('--ppr', type=float, help='post to pre ratio')
            parser_config.add_argument('--scale', type=float, help='scale of taps')
        if serdes_type == "condor":
            parser_config.add_argument('--post2', type=int, help='Post2 Tap value')

        if valid_speed_parser is not None:
            parser_config.add_argument('--speed', type=valid_speed_parser)
        if serdes_type == "condor":
            parser_config.add_argument('--div4', metavar='<bool>', type=distutils.util.strtobool, help=argparse.SUPPRESS)

        tx_type_group = parser_config.add_mutually_exclusive_group(required=False)
        tx_type_group.add_argument('--tx-core', dest='tx_core', default=None, action='store_true', help='Disable test patterns, transmit normal data')
        if serdes_type == "condor":
            tx_type_group.add_argument('--tx-test', dest='tx_test', type=str.upper, choices=['PRBS9', 'PRBS15', 'PRBS23', 'PRBS31',
                                                                                             'PRBS13', 'PRBS13Q', 'PRBS31Q', 'JP03A',
                                                                                             'JP03B', 'LINEARITY'])
            tx_type_group.add_argument('--tx-pattern', dest='tx_pattern', type=Hex, help='Custom Tx test pattern, e.g. 0xaaaaaaaaaaaaaaaa')
            parser_config.add_argument('--tx-enable', dest='tx_enable', type=distutils.util.strtobool)
        if serdes_type == "magpie":
            tx_type_group.add_argument('--tx-test', dest='tx_test', type=str.upper, choices=['PRBS9', 'PRBS13', 'PRBS31', 'PRBS63'])

        tx_type_group.add_argument('--tx-loopback', dest='tx_loopback', default=None, action='store_true', help='Rx is decoded and sent back out Tx')
        parser_config.add_argument('--tx-msblsb', dest='tx_msblsb', metavar='<bool>', type=distutils.util.strtobool)
        parser_config.add_argument('--tx-precode', dest='tx_precode', metavar='<bool>', type=distutils.util.strtobool)
        parser_config.add_argument('--tx-graycode', dest='tx_graycode', metavar='<bool>', type=distutils.util.strtobool)
        parser_config.add_argument('--tx-polarity', dest='tx_polarity', metavar='<bool>', type=distutils.util.strtobool)
        if serdes_type == "magpie":
            parser_config.add_argument('--tx-reset', dest='tx_reset', action='store_true', default=False)

        if serdes_type == "condor":
            parser_config.add_argument('--rx-input', dest='rx_input', type=str.lower, choices=['ac', 'dc'])
        parser_config.add_argument('--rx-precode', dest='rx_precode', metavar='<bool>', type=distutils.util.strtobool)
        parser_config.add_argument('--rx-graycode', dest='rx_graycode', metavar='<bool>', type=distutils.util.strtobool)
        parser_config.add_argument('--rx-polarity', dest='rx_polarity', metavar='<bool>', type=distutils.util.strtobool)
        parser_config.add_argument('--rx-msblsb', dest='rx_msblsb', metavar='<bool>', type=distutils.util.strtobool)

        if serdes_type == "condor":
            parser_config.add_argument('--rx-check', dest='rx_check', type=str.upper, choices=['PRBS9', 'PRBS15', 'PRBS23', 'PRBS31',
                                                                                               'PRBS13', 'PRBS13Q', 'PRBS31Q', 'OFF'])
        if serdes_type == "magpie":
            parser_config.add_argument('--rx-check', dest='rx_check', type=str.upper, choices=['PRBS9', 'PRBS13', 'PRBS31', 'PRBS63', 'OFF'])

        parser_config.add_argument('--tune', type=str.lower, choices=['on', 'off', 'bounce'], help='FW Tuning setup')

        if serdes_type == "condor":
            parser_config.add_argument('--optical', dest='optical', metavar='<bool>', type=distutils.util.strtobool)
            parser_config.add_argument('--los-holdoff', dest='los_holdoff', metavar='<bool>', type=distutils.util.strtobool)
            parser_config.add_argument('--reset', default=None, action='store_true')
        parser_config.add_argument('--verbose', '-v', default=None, action='store_true')
        parser_config.set_defaults(func=multi_callback(*cli_funcs["config"]))

    if "bathtub" in cli_funcs:
        parser_bathtub = subparsers.add_parser('bathtub', help = 'show bathtub plot')
        parser_bathtub.add_argument('-C', '--collect', nargs='?', type=int, const=7, metavar='DEPTH', help='collect eye data (default depth 7)')
        parser_bathtub.add_argument('-H', '--horizontal', action='store_true', help='show horizontal bathtub plot (default is vertical)')
        #parser_bathtub.add_argument('-t', '--top', action='store_true', help='top eye')
        #parser_bathtub.add_argument('-b', '--bottom', action='store_true', help='bottom eye')
        #parser_bathtub.add_argument('-c', '--center', action='store_true', help='center eye')
        parser_bathtub.add_argument('-p', '--plot', nargs='?', type=int, default=None, const=15, metavar='DEPTH', help='plot bathtub [DEPTH: default 15]')
        parser_bathtub.add_argument('-s', '--sizes', nargs='?', type=parse_list, default=None, metavar='BERS', const=[8, 12, 15],
                                    help='print size at specified depth (default 8,12,15)')
        parser_bathtub.add_argument('-S', '--save', action='store_true', help='save data to file')
        parser_bathtub.add_argument('-q', '--q-scale', dest='q_scale', action='store_true', help='plot as q-scale, not BER')
        parser_bathtub.add_argument('--cols', type=int, default=None, help='number of columns in textual plot')
        parser_bathtub.set_defaults(func=multi_callback(*cli_funcs["bathtub"]))

    if "eye" in cli_funcs:
        parser_eye = subparsers.add_parser('eye', help = 'eye plot characterization')
        parser_eye.add_argument('-C', '--collect', nargs='?', type=int, const=7, metavar='DEPTH', help='collect eye data (default depth 7)')
        parser_eye.add_argument('-s', '--sizes', nargs='?', type=parse_list, default=None, metavar='BERS', const=[8, 12, 15],
                                help='print width/height.  Default BERs: 8,12,15')
        parser_eye.add_argument('-p', '--plot', action='store_true', help='display eye plot')
        parser_eye.add_argument('-c', '--color', type=str.lower, choices=['gray', 'none'], default='normal')
        parser_eye.add_argument('-i', '--invert', action='store_true', help='Invert color scale')
        parser_eye.add_argument('--cols', type=int, default=None, help='Columns in textual plot')
        parser_eye.add_argument('-S', '--save', type=argparse.FileType('w'), default=None, help='save data to file')
        parser_eye.set_defaults(func=multi_callback(*cli_funcs["eye"]))

    if "hist" in cli_funcs:
        parser_hist = subparsers.add_parser('hist', help = 'show histogram')
        parser_hist.add_argument('-C', '--collect', nargs='?', type=int, const=7, metavar='DEPTH', help='collection depth (default depth 7)')
        parser_hist.add_argument('-p', '--plot', nargs='?', type=int, default=None, const=15, metavar='DEPTH', help='plot histogram [DEPTH: default 15]')
        parser_hist.add_argument('-s', '--sizes', nargs='?', type=parse_list, default=None, metavar='BERS', const=[8, 12, 15],
                                 help='print effective eye height at specified depth (default 8,12,15)')
        parser_hist.add_argument('-b', '--ber', action='store_true', default=False, help="Estimate BER from histogram data")
        parser_hist.add_argument('-c', '--color', type=str.lower, choices=['gray', 'none'], default='gray')
        parser_hist.add_argument('-S', '--save', type=argparse.FileType('w'), default=None, help="save data to file")
        parser_hist.set_defaults(func=multi_callback(*cli_funcs["hist"]))

    if "ber" in cli_funcs:
        parser_ber = subparsers.add_parser('ber', help = 'show ber')
        if serdes_type == "condor":
            parser_ber.add_argument('--reset', '-r', action='store_true', help='reset error counts at start of BER collection')
            parser_ber.add_argument('--time', '-t', type=int, default=5, help='maximum time for BER in seconds (def. 5)')
        if serdes_type == "magpie":
            parser_ber.add_argument('--continue', '-c', dest='continuation', action='store_true', help='continue previous BER collection')
            parser_ber.add_argument('--time', '-t', type=int, default=None, help='maximum time for BER in seconds (def. 5 if not --continue)')
            parser_ber.add_argument('--no-rx-eq', '-n', dest='no_rx_eq', action='store_true', help='Bypass Rx EQ for listed ports that have not equalized, or would attempt to re-equalize')
            parser_ber.add_argument('--color', '-C', action='store_true')
        parser_ber.set_defaults(func=multi_callback(*cli_funcs["ber"]))

    if "pcsber" in cli_funcs:
        if serdes_type == "COMPHY_N5C112GX45PLL":
            parser_pcsber = subparsers.add_parser('pcsber', help = 'show PCS ber')
            parser_pcsber.add_argument("--time", "-t", type=int, default=5, help="in seconds")
            parser_pcsber.add_argument("--continuous", "-C", action='store_true', help="Continuous measurement, hit return to exit")
            parser_pcsber.add_argument("--continue", "-c", dest='continuation', action='store_true', help="continue previous measurement, do not reset counters")
            parser_pcsber.add_argument("--plot", "-p", action='store_true', help='plot hist of uncorrectable errors')
            parser_pcsber.add_argument("--verbose", "-v", action='store_true', help='prints histogram bin values')
            parser_pcsber.set_defaults(func=multi_callback(*cli_funcs["pcsber"]))

    return subparsers
