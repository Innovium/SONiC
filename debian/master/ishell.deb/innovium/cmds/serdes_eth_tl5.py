
#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2018
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

import argparse
import shlex
import copy
import itertools

from ctypes import *
from ifcs_ctypes import *
from cmdmgr import Command
from testutil import eyeplot

# fixme: move away from "import *" below
from testutil.condor import *
import sys,traceback
from utils.compat_util import *

lane_label = {}

valid_speed_lookup = {10:       10.3125,
                      10.3125:  10.3125,
                      25:       25.78125,
                      25.78125: 25.78125,
                      50:       53.12500,
                      53:       53.12500,
                      53.12500: 53.12500}
valid_speed_list = list(set(compat_listvalues(valid_speed_lookup)))

# Intended for use with argparse: convert a string to a list of integers:
# '5' => [5], '3,8,2' => [3, 8, 2], '4-6' => [4,5,6]
def parse_list(s):
    out = []
    if s == 'all':
        return []
    for item in s.split(','):
        if ':' in item:
            itemlist = item.split(':', 2)
        elif '-' in item:
            itemlist = item.split('-', 2)
        else:
            itemlist = [item]
        first = int(itemlist[0], 0)
        if len(itemlist) == 1:
            out.append(int(itemlist[0], 0))
        elif len(itemlist) == 2:
            last = int(itemlist[1], 0)
            if first <= last:
                for x in range(first, last+1):
                    out.append(x)
            else:
                for x in range(first, last-1, -1):
                    out.append(x)
        else:
            raise ValueError("Error parsing list argument")
    return out

def devport_portlane_to_ib_pic_piclane(devport, portlane):
    info = im_devport_info_t()
    rc = im_devport_info_get(0, devport, pointer(info));
    if portlane > (info.pi_num_lanes - 1):
        raise ValueError("Lane number %d is greater than max lanes index (%d) for devport %d"
                         %(portlane, info.pi_num_lanes - 1, devport))

    serdes_info = im_serdes_info_t()
    rc = im_devport_get_serdes_info(0, devport, \
                                    portlane, pointer(serdes_info))
    if rc != IFCS_SUCCESS:
       log_err("Failed to get serdes info\n");
       return

    return (info.pi_ib, info.pi_pic_id, serdes_info.serdes_num)

def get_all_devports():
    attr = ifcs_attr_t()
    actual_count = c_uint32()
    attr.id = IFCS_LINKSCAN_ATTR_DEVPORTS_COUNT
    ifcs_linkscan_attr_get(0, 1, pointer(attr), pointer(actual_count))
    devport_count = attr.value.u32

    memberList = (ifcs_devport_t * devport_count)()
    actual_count = c_uint32(0)
    rc = ifcs_linkscan_devports_get(0, devport_count, compat_pointer(memberList, ifcs_devport_t), pointer(actual_count))

    devport_list = []
    for d in memberList:
        info = im_devport_info_t()
        im_devport_info_get(0, d, pointer(info))
        if info.pi_type == IFCS_DEVPORT_TYPE_ETH:
            devport_list += [d]
    return sorted(devport_list)

def get_all_pics(ib):
    pic_list = []
    num_pics = im_node_num_eth_pics(0)
    for pic in range(num_pics):
        pic_info = im_devport_pic_info_t()
        im_node_devport_pic_info_get(0, ib, pic, pointer(pic_info))
        if pic_info.max_lanes > 0:
            pic_list += [pic]
    return pic_list

def print_lane_id(lane, no_linefeed=False):
    global lane_label
    if no_linefeed:
        log_no_newline(lane_label[lane])
    else:
        log(lane_label[lane])



def cli_load_fw(lane, args):
    if args.filename is None:
        # Check if custom fw is loaded

        print_lane_id(lane)
        if (serdes_check_custom_fw_loaded(lane)):
            hash_code,date,crc = serdes_check_custom_fw_loaded(lane)
            # Print data
            #print("Custom FW Info")
            log("Firmware CRC :  %s" % crc)
            log("Firmware date: 0x%x (%s)" % (date[0], date[1]))
            log("Firmware hash: %s" % hash_code)
            log("Firmware rev : %s_%s" % (date[1],hash_code))
        else:
            # Get data from SDK
            sd_rev = im_serdes_rev_info_t()
            rc = im_node_serdes_fw_rev_get(0, pointer(sd_rev))
            if rc != IFCS_SUCCESS:
                log_err("Failed to get serdes rev info\n");
                return

            d = datetime.date(1970, 1, 1) + datetime.timedelta(sd_rev.fw_date)
            date_str = "%04d%02d%02d" % (d.year, d.month, d.day)
            log("Firmware CRC : 0x%x" % sd_rev.fw_crc)
            log("Firmware date: 0x%x (%s)" % (sd_rev.fw_date, date_str))
            log("Firmware hash: 0x%x" % sd_rev.fw_hash_code)
            log("Firmware rev : %s"   % sd_rev.eth_rev_str)

    else:
        serdes_fw_load(args.filename, lane)

def cli_status(lane, args):
    print_lane_id(lane)
    if args.reset_ber:
        prbs_rst(lane)
        time.sleep(.1)

    rx_monitor_capture(lane, rst=0)

    actual_data_rate, actual_baud_rate, fvco, pll_n, pll_fracn, pll_cap, div4 = get_pll(lane=lane)

    adap_count = fw_tuning_counter(lane=lane)
    [tx_pre2,tx_pre1,tx_main,tx_post1,tx_post2] = get_tx_taps(lane=lane)
    ctle_val,ctle1,ctle2 = ctle(lane=lane)
    ctle_f = ctle_fine(lane=lane)
    dacq_reg = rregBits(params(lane).dac_sel_addr, params(lane).dac_sel_bit_loc, lane)
    tx_tap_str = '%g, %g, %g, %g, %g' % (tx_pre2, tx_pre1, tx_main, tx_post1, tx_post2)
    channel_est = fw_channel_estimate(lane=lane)
    of_count, hf_count = fw_channel_of_hf(lane=lane)

    [ctle_gain1_bin,ffe_gain1_bin,ctle_gain2_bin,ffe_gain2_bin] = dc_gain(lane=lane)
    edge1 = rregLane(edge1_addr, lane)
    ext_rch    = rregLane(ext_rch_en_addr,  lane)
    ctle_gains = '%d, %d' % (ctle_gain1_bin, ctle_gain2_bin)
    ffe_gains = '%d, %d' % (ffe_gain1_bin, ffe_gain2_bin)

    berstr = 'Off'
    if get_ber_valid(lane):
        ber, ber_time = get_ber_since_reset(lane)
        if ber is None:
            berstr = 'Overflow'
        else:
            berstr = '%-5.1e' % ber
            if ber_time < 5:
                berstr += ' in %.1fs' % ber_time
            else:
                berstr += ' in %ds' % ber_time

    phy_status = 'PHY RDY' if get_phy_rdy(lane) else 'PHY DOWN'
    sig_detect = 'SIGNAL' if get_sig_detect(lane) else 'NO SIG'
    tot_status = (phy_status + ', ' + sig_detect)
    tx_out_str = get_tx_type(lane)
    if tx_idle_get(lane):
        tx_out_str = 'Disabled [%s]' % tx_out_str

    if optical_status(lane):
        optical_str = 'On'
    else:
        optical_str = 'Off'
    los_str = los_holdoff_status(lane)

    out_left = []
    out_right = []

    log('--'*12)
    # "%-18s: %-20s"
    out_left += [['Encoding', get_mode(lane)]] ; out_right += [['Data Rate(Gbps)', '%-9.5f' % actual_data_rate]]
    out_left += [['Status', tot_status]]       ; out_right += [['Adapt Count', '%d' % fw_tuning_counter(lane)]]
    out_left += [['DAC', dacq_reg]]            ; out_right += [['Tx Taps', tx_tap_str]]

    if get_mode(lane) == 'pam4':
        f0, f1     = get_pam4_dfe(lane=lane)
        fm1 = ((rregBits(pam4_tap_addr,pam4_tap_bit_loc,lane))+64)%128 - 64
        ffe_pol1 = rregBits(ffe_pol_addr,ffe_po11_bit_loc,lane)
        ffe_pol2 = rregBits(ffe_pol_addr,ffe_po12_bit_loc,lane)
        ffe_pol3 = rregBits(ffe_pol_addr,ffe_po13_bit_loc,lane)
        ffe_pol4 = rregBits(ffe_pol_addr,ffe_po14_bit_loc,lane)
        ffe_pol    = rregLane(ffe_pol_addr,    lane)
        delta1 = delta_ph(lane = lane)
        edge1      = rregLane(edge1_addr,       lane)
        att = attenuator(lane=lane)
        ctle_gains += ' / %d' % att

        [ffe_tap1_bin,ffe_tap234,ffe_tap2_bin,ffe_tap34,ffe_tap3_bin,ffe_tap4_bin] = ffe_taps(lane=lane)
        prefec_cnt = rx_mon_prefec_cnt[lane]
        postfec_cnt = rx_mon_postfec_cnt[lane]
        prefec_ber = '%.2e' % rx_mon_prefec_ber[lane]
        postfec_ber = '%.2e' % rx_mon_postfec_ber[lane]
        ffe_tap_str = '%02X, %02X, %02X, %02X, %02X, %02X' % (ffe_tap1_bin,ffe_tap2_bin,ffe_tap3_bin,ffe_tap4_bin,ffe_tap34,ffe_tap234)
        dfe_tap_str = '%.2f, %.2f, %.2f' % (f0, f1, fm1/64.0)
        f13 = f1over3(lane=lane)
        tx_msblsb = get_tx_msblsb(lane)
        rx_msblsb = get_rx_msblsb(lane)

        out_left += [['Eye0', rx_mon_eye0[lane]]]          ; out_right += [['Tx/Rx Polarity', '%d/%d' % (get_tx_polarity(lane), get_rx_polarity(lane))]]
        out_left += [['Eye1', rx_mon_eye1[lane]]]          ; out_right += [['FFE Taps', ffe_tap_str]]
        out_left += [['Eye2', rx_mon_eye2[lane]]]          ; out_right += [['FFE Tap Polarity', '%d, %d, %d, %d' % (ffe_pol1,ffe_pol2,ffe_pol3,ffe_pol4)]]

        out_left += [['CTLE Gains / Attn', ctle_gains]]    ; out_right += [['CTLE Idx,1,2,F', '%d, %d, %d, %d' % (ctle_val, ctle1, ctle2, ctle_f)]]
        out_left += [['FFE Gains', ffe_gains]]             ; out_right += [['ChanEst, Of, Hf', '%f, %d, %d' % (channel_est, of_count, hf_count)]]
        out_left += [['DFE F0,F1,Fm1', dfe_tap_str]]       ; out_right += [['F13, Delta, Edges', '%d, %d, %04X' % (f13, delta1, edge1)]]

        out_left += [['','']]                              ; out_right += [['Tx/Rx PRBS msblsb', '%d/%d' % (tx_msblsb, rx_msblsb)]]
        out_left += [['PreFEC Cnt', prefec_cnt]]           ; out_right += [['PostFEC Cnt', postfec_cnt]]
        out_left += [['PreFEC BER', prefec_ber]]           ; out_right += [['PostFEC BER', postfec_ber]]
    else:  # NRZ
        delta1, f1, f2, f3 = get_nrz_dfe(lane)
        dfe_tap_str = '%d, %d, %d' % (f1,f2,f3)
        # scaled dfe values: f1 * (dacq_reg * 50 + 200) / 64

        out_left += [['Eye0', rx_mon_eye0[lane]]]          ; out_right += [['Tx/Rx Polarity', '%d/%d' % (get_tx_polarity(lane), get_rx_polarity(lane))]]
        out_left += [['CTLE Gains', ctle_gains]]           ; out_right += [['CTLE Idx,1,2,F', '%d, %d, %d, %d' % (ctle_val, ctle1, ctle2, ctle_f)]]
        out_left += [['FFE Gains', ffe_gains]]             ; out_right += [['ChanEst, Of, Hf', '%f, %d, %d' % (channel_est, of_count, hf_count)]]
        out_left += [['DFE F1,F2,F3', dfe_tap_str]]        ; out_right += [['Delta, Edges', '%d, %04X' % (delta1, edge1)]]

    out_left += [['Tx Data', tx_out_str]]              ; out_right += [['Rx Match', get_rx_pat_match(lane)]]
    out_left += [['Rx Match Err Cnt', get_prbs_cnt_raw(lane)]] ; out_right += [['PRBS BER', berstr]]
    out_left += [['Optical Mode', optical_str]]        ; out_right += [['LOS Holdoff', los_str]]

    def add_colon(elems):
        if len(elems[0]) > 0 or len(elems[1]) > 0:
            return '%-18s: %-20s' % (elems[0], elems[1])
        else:
            return '%-18s  %-20s' % ('','')

    for (left, right) in zip(out_left, out_right):
        log(add_colon(left), add_colon(right))

    if get_mode(lane) == 'pam4':
        isi = dump_isi(lane)
        log('ISI: ' + ', '.join(map(str, isi)))
    else:
        isi = dump_nrz_isi(lane)
        log('NRZ ISI: ' + ', '.join(map(str, isi)))
    log("")

def cli_bathtub_plot(lane, args):
    print_lane_id(lane)

    if get_mode(lane) == 'pam4':
        centers = [('Top ', em_separator(lane)[0] + 1), ('Center ', em_separator(lane)[2] + 1), ('Bottom ', em_separator(lane)[4] + 1)]
        x_offset = -63
        hi_ctr_idx = em_separator(lane)[0] - x_offset
        sep_hi = em_separator(lane)[1] - x_offset
        mid_ctr_idx = em_separator(lane)[2] - x_offset
        sep_lo = em_separator(lane)[3] - x_offset
        lo_ctr_idx = em_separator(lane)[4] - x_offset
        eye_ranges = [[0, hi_ctr_idx, sep_hi], [sep_hi+1, mid_ctr_idx, sep_lo], [sep_lo+1, lo_ctr_idx, -1]]
    else:  # NRZ
        centers = [('', 0)]
        eye_ranges = [[0, None, -1]]

    outplots = []
    titles = []
    sizes = []
    if args.sizes is not None:
        bers = [10.0**(-abs(level)) for level in args.sizes]

    if args.horizontal:
        for c_lbl, c_pos in centers:
            x, errs, samples = horiz_bathtub_data(lane, c_pos, args.save)
            if x is None:
                log("No valid bathtub data for lane (use --collect)")
                return
            if args.plot is not None:
                outplots += [eyeplot.ascii_bathtub(x, errs, samples, 10**-abs(args.plot), [1e-5, 1e-2], columns=args.cols, qscale=args.q_scale)]
            if args.sizes is not None:
                titles += [c_lbl + 'Width (UI)']
                sizes += eyeplot.bathtub_widths(x, errs, samples, [1e-5, 1e-2], bers)
    else:  # vertical
        x, errs, samples = vert_bathtub_data(lane, False)
        if x is None:
            log("No valid bathtub data for lane (use --collect)")
            return
        if args.plot is not None:
            outplots += [eyeplot.ascii_bathtub(x, errs, samples, 10**-abs(args.plot), [1e-5, 1e-2], columns=args.cols, eye_ranges=eye_ranges, qscale=args.q_scale)]
        if args.sizes is not None:
            titles = [c_lbl + 'Height (mV)' for c_lbl, c_pos in centers]
            sizes = eyeplot.bathtub_widths(x, errs, samples, [1e-5, 1e-2], bers, eye_ranges=eye_ranges)

    if args.plot is not None:
        for lines in zip(*outplots):   # transpose columns to rows/lines
            log("    ".join(lines))
        if args.sizes:
            log("")

    if args.sizes is not None:
        eyeplot.print_size_table(bers, titles, sizes)

def cli_eye(lane, args):
    log("")
    print_lane_id(lane)
    log("----------------------")

    eye_data = get_eye_data(lane)
    if eye_data is None:
        log("No valid eye data for lane (use --collect)")
        return

    if args.plot:
        eyeplot.print_ascii_eye_plot(eye_data, True, color=(args.color != 'none'), invert=args.invert, columns=args.cols)
        log('')

    if args.save is not None:
        for line in eye_data:
            for pt in line:
                args.save.write('%.2e ' % pt)
            args.save.write('\n')
        args.save.flush()

    if args.sizes is not None:
        bers = [10.0**(-abs(level)) for level in args.sizes]

        if get_mode(lane) == 'pam4':
            centers = [('Top ', em_separator(lane)[0] + 1), ('Center ', em_separator(lane)[2] + 1), ('Bottom ', em_separator(lane)[4] + 1)]
            x_offset = -63
            hi_ctr_idx = em_separator(lane)[0] - x_offset
            sep_hi = em_separator(lane)[1] - x_offset
            mid_ctr_idx = em_separator(lane)[2] - x_offset
            sep_lo = em_separator(lane)[3] - x_offset
            lo_ctr_idx = em_separator(lane)[4] - x_offset
            eye_ranges = [[0, hi_ctr_idx, sep_hi], [sep_hi+1, mid_ctr_idx, sep_lo], [sep_lo+1, lo_ctr_idx, -1]]
        else:  # NRZ
            centers = [('', 0)]
            eye_ranges = [[0, None, -1]]
        x, errs, samples = vert_bathtub_data(lane, False)
        heights = eyeplot.bathtub_widths(x, errs, samples, [1e-5, 1e-2], bers, eye_ranges=eye_ranges)
        titles = []
        sizes = []
        for c_lbl, c_pos in centers:
            x, errs, samples = horiz_bathtub_data(lane, c_pos, False)
            if x is None:
                log('No Horizontal eye/bathtub data')
                return
            titles += [c_lbl + 'Width (UI)']
            sizes += eyeplot.bathtub_widths(x, errs, samples, [1e-5, 1e-2], bers)

            titles += [c_lbl + 'Height (mV)']
            sizes += [heights.pop(0)]

        eyeplot.print_size_table(bers, titles, sizes)

def ber_collect_multi(lane_list, args):
    global ber_vals
    ber_vals = get_ber_multi(lane_list, rst=args.reset, accum_time=args.time, print_status=True)

def cli_ber(lane, args):
    prbs_accum_time, prbs_error_cnt, ber_val3, log_ber3, lane_status = ber_vals[lane]
    print_lane_id(lane, no_linefeed=True)
    log("  Lane [status: %s] BER (%ds) %7.1e " % (lane_status_str[lane_status], prbs_accum_time, ber_val3))

def cli_read(lane, args):
    #print args
    print_lane_id(lane)
    if args.wide:
        for idx in range(args.num):
            val = rreg32Lane(args.addr + idx * 2, lane=lane)
            log('%04x: %08x' % (args.addr + idx, val))
    else:
        for idx in range(args.num):
            val = rregLane(args.addr + idx, lane=lane)
            log('%04x: %04x' % (args.addr + idx, val))

def cli_readbits(lane, args):
    #print args
    print_lane_id(lane)
    outval = 0
    outlist = ''
    for idx in range(args.num):
        # val = rregBits(args.addr + offset, args.bits[::-1], lane=lane)
        val = rregLane(args.addr + idx, lane=lane)
        for bit_idx in args.bits:
            bitval = (val >> bit_idx) & 1
            outval = outval << 1 | bitval
            outlist += '%d' % bitval
        log("%04x%s: 'b%s : 0x%x" % (args.addr + idx, str(args.bits), outlist, outval))

def cli_writebits(lane, args):
    #print args
    regval = rregLane(args.addr, lane=lane)
    val_to_stuff = args.value
    for bit_idx in args.bits[::-1]:  # work low->high, and peel bits off of (val_to_stuff & 1)
        bitmask = (1 << bit_idx)
        if val_to_stuff & 1:
            regval = regval | bitmask
        else:
            regval = (regval & (0xffff - bitmask))

        val_to_stuff = val_to_stuff >> 1
    log('%04x: %04x' % (args.addr, regval))
    wregLane(args.addr, regval, lane=lane)

def cli_write(lane, args):
    #print args
    wregLane(args.addr, args.value, lane=lane)

def cli_config(lane, args):
    verbose = args.verbose
    args.verbose = None

    if all(v is None for v in vars(args).values()):
        # no arguments passed: just show the current config
        print_lane_id(lane)
        pll(lane=lane, verbose=verbose)
        return
    #print vars(args)
    #print [v for v in vars(args).values()]

    #mgmt.print_writes = True

    tx_idx = 0

    if args.tx_enable is not None:
        tx_idle_set(not args.tx_enable, lane=lane)

    if args.tx_loopback:
        rx_tx_serial_loopback(True, lane=lane)
    elif args.tx_core or args.tx_test or args.tx_pattern:
        if get_rx_tx_serial_loopback(lane):
            rx_tx_serial_loopback(False, lane=lane)

    if args.tx_core:
        set_tx_test(False, lane=lane)

    change_speed = (args.speed is not None) or (args.div4 is not None)

    orig_speed, _, _, _, _, _, orig_div4 = get_pll(lane=lane)

    if args.speed is None:
        args.speed = orig_speed
    if args.div4 is None:
        if change_speed:
            args.div4 = 1  # default to div4 being on, if unspecified and setting speed
        else:
            args.div4 = orig_div4
    if args.rx_input is None:
        args.rx_input = get_rx_input_mode(lane)
    if args.rx_precode is None:
        args.rx_precode = get_rx_precode(lane)
    if args.tx_precode is None:
        args.tx_precode = get_tx_precode(lane)
    if args.rx_graycode is None:
        args.rx_graycode = get_rx_graycode(lane)
    if args.tx_graycode is None:
        args.tx_graycode = get_tx_graycode(lane)
    if args.rx_polarity is None:
        args.rx_polarity = get_rx_polarity(lane)
    if args.tx_polarity is None:
        args.tx_polarity = get_tx_polarity(lane)
    if args.tx_msblsb is None:
        args.tx_msblsb = get_tx_msblsb(lane)
    if args.rx_msblsb is None:
        args.rx_msblsb = get_rx_msblsb(lane)
    if args.optical is None:
        args.optical = optical_status(lane)
    if args.los_holdoff is None:
        args.los_holdoff = (los_holdoff_status(lane) != 'Off')

    orig_pre2, orig_pre1, orig_main, orig_post1, orig_post2 = get_tx_taps(lane)
    pre2 = args.pre2 if args.pre2 is not None else orig_pre2
    pre1 = args.pre1 if args.pre1 is not None else orig_pre1
    main = args.main if args.main is not None else orig_main
    post1 = args.post1 if args.post1 is not None else orig_post1
    post2 = args.post2 if args.post2 is not None else orig_post2

    if args.reset:
        soft_reset(lane)

    if ((args.pre2 is not None) or (args.pre1 is not None) or
        (args.main is not None) or (args.post1 is not None) or
        (args.post2 is not None) or args.reset):
        set_tx_taps_safe(pre2, pre1, main, post1, post2, lane=lane)

    # find the key in fw_data_rate_map closest to the target data rate

    int_rate = min(compat_listkeys(fw_data_rate_map), key=lambda x:abs(x - args.speed))
    fw_data_rate = fw_data_rate_map[int_rate]

    set_tx_graycode(args.tx_graycode, lane)
    set_rx_graycode(args.rx_graycode, lane)
    set_tx_precode(args.tx_precode, lane)
    set_rx_precode(args.rx_precode, lane)

    if args.rx_check:
        set_rx_prbs(args.rx_check, lane=lane)

    if args.rx_input == 'dc':
        wregBits(0xF7, [12], 0, lane)
    elif args.rx_input == 'ac':
        wregBits(0xF7, [12], 1, lane)

    if args.tune == 'off' or args.tune == 'bounce':
        wregBits(0x980F, [15], 0, lane) # Clear go bit
        #wregBits(0x8440, [15], 0, lane) # Disables AN/LT lane swapping

    # Tuning: NRZ write 8001, PAM4 write 9e01 , stop tuning via bit 15
    if change_speed:
        print_lane_id(lane)

        log("----------------------")
        if int_rate <=28:   # NRZ
            half_rate = 1 if int_rate <= 16 else 0
            config_nrz_tx(tx_idx, half_rate=half_rate, lane=lane)  # This enables PRBS so we need to put this first
            fw_cmd(0x80C0, detail=fw_data_rate, expected_response=8, lane=lane)
            config_nrz_fw_rx(optical_mode=args.optical, lane=lane)
            pll(rate=args.speed, div4=args.div4, lane=lane, verbose=verbose)

        else:  # changing speeds, PAM4
            config_pam4_tx(tx_idx, lane)        # This enables PRBS so we need to put this first
            config_pam4_fw_rx(optical_mode=args.optical, lane=lane) # This clears polarity, so before connection
            fw_cmd(0x80D0, detail=fw_data_rate, expected_response=8, lane=lane)
            pll(rate=args.speed, div4=args.div4, lane=lane, verbose=verbose)

    set_tx_polarity(args.tx_polarity, lane)
    set_rx_polarity(args.rx_polarity, lane)
    set_tx_msblsb(args.tx_msblsb, lane)
    set_rx_msblsb(args.rx_msblsb, lane)

    if args.tx_test:
        set_tx_prbs(args.tx_test, lane=lane)
        set_tx_test(True, lane=lane)

    if args.tx_pattern:
        set_tx_pattern(args.tx_pattern, lane=lane)
        set_tx_prbs('PATTERN', lane=lane)
        set_tx_test(True, lane=lane)

    if change_speed or args.rx_check:
        prbs_rst(lane)

    if args.tune == 'on' or args.tune == 'bounce':
        # bit 15 is 'go'.  We should maybe have finer-grained control over other bits (auto-CTLE, etc)
        if get_mode(lane) == 'pam4':
            wregLane(0x980f, 0x9e01, lane=lane)
        else:
            wregLane(0x980f, 0x8001, lane=lane)
        fw_show_tuning(True, True, lane=lane)

    optical_set(args.optical, lane)
    los_holdoff_set(args.los_holdoff, lane)

def cli_dump_isi(lane, args):
    print_lane_id(lane)
    log(dump_isi(lane=lane))
def cli_dump_nrz_isi(lane, args):
    print_lane_id(lane)
    log(dump_nrz_isi(lane=lane))
def cli_dump_exit_code(lane, args):
    print_lane_id(lane)
    log(dump_exit_code(lane=lane))
def cli_dump_ths(lane, args):
    print_lane_id(lane)
    log(dump_ths(lane=lane))
def cli_dump_ffe(lane, args):
    print_lane_id(lane)
    log(dump_ffe(lane=lane))
def cli_dump_ffe_wt(lane, args):
    print_lane_id(lane)
    log(dump_ffe_wt(lane=lane))
def cli_dump_an(lane, args):
    print_lane_id(lane)
    log(AN_dump_fw(lane=lane))
def cli_dump_fw_reg(lane, args):
    print_lane_id(lane)
    log(fw_reg(lane=lane))
def cli_get_dfe(lane, args):
    print_lane_id(lane)
    if get_mode(lane) == 'pam4':
        log(get_pam4_dfe(lane))
    else:
        log(get_nrz_dfe(lane))

def cli_get_fw_reg(lane, args):
    print_lane_id(lane)
    retval = get_fw_reg(args.index, lane, args.section)
    log("FW reg read: index = %d, section = %d, val = 0x%04x" %(args.index, args.section, retval))

def cli_set_fw_reg(lane, args):
    print_lane_id(lane)
    set_fw_reg(args.index, args.value, lane, args.section)
    retval = get_fw_reg(args.index, lane, args.section)
    log("FW reg: index = %d, section = %d, val = 0x%04x" %(args.index, args.section, retval))

def cli_pt_debug(lane, args):
    print_lane_id(lane)
    start_idx = args.index #don't modify args
    for i in range(args.num):
        dbg_val = PT_debug(args.section, start_idx, lane)
        log("PT_debug: Index=%d, section=%d, val = 0x%04x" %(args.index, args.section, dbg_val))
        start_idx = start_idx + 1

def Hex(s):
    return int(s,16)

def valid_speed_parser(speed_str):
    try:
        return valid_speed_lookup[float(speed_str)]
    except:
        raise argparse.ArgumentTypeError('value not in %s' % valid_speed_list)

default_ib_list = [0]
default_pic_list = [0]
default_lane_list = [0]
default_devport_list = None

def get_full_lane_list(args):
    global default_ib_list, default_pic_list, default_lane_list, default_devport_list
    global lane_label
    if args.devport is not None and args.ib is not None:
        raise ValueError("Specify only one of --ib or --devport")
    if args.devport is not None and args.pic is not None:
        raise ValueError("Specify only one of --pic or --devport")
    if args.ib is not None:
        if args.ib == []:   # 'all' was given
            args.ib = compat_listrange(im_node_num_ibs(0))
        if max(args.ib) > 1:
            raise ValueError("Invalid IB number, valid choice [0, 1]")
        default_ib_list = args.ib
        default_devport_list = None
    if args.pic is not None:
        if len(args.pic) > 0 and max(args.pic) > 7:
                raise ValueError("Invalid PIC number, valid choice [0...7]")
        default_pic_list = args.pic
        if default_ib_list is None:
            raise ValueError("--pic specified but no IB specified")
    if args.devport is not None:
        if args.devport == []:   # 'all' was given
            args.devport = get_all_devports()
        default_devport_list = args.devport
        default_ib_list = None

    if args.lane is not None and len(args.lane) > 0 and max(args.lane) > 7:
        raise ValueError("Invalid lane number, valid choice [0...7]")

    if args.lane is not None:
        default_lane_list = args.lane

    lane_label = {}
    full_lane_list = []
    if default_ib_list is not None:
        for ib in default_ib_list:
            if default_pic_list == []:  # i.e. 'all'
                pic_list = get_all_pics(ib)
            else:
                pic_list = default_pic_list
            for pic in pic_list:
                if default_lane_list == []:  # i.e. 'all'
                    lane_list = compat_listrange(im_node_picports_per_pic(0))
                else:
                    lane_list = default_lane_list
                for piclane in lane_list:
                    full_lane = mgmt.lane_from_ib_pic_piclane(ib,pic,piclane)
                    lane_label[full_lane] = 'IB %d PIC %d Lane %d:' % (ib,pic,piclane)
                    full_lane_list += [full_lane]
    else:
        for devport in default_devport_list:
            if default_lane_list == []:  # i.e. 'all'
                info = im_devport_info_t()
                rc = im_devport_info_get(0, devport, pointer(info));
                lane_list = compat_listrange(info.pi_num_lanes)
            else:
                lane_list = default_lane_list
            for portlane in lane_list:
                full_lane = mgmt.lane_from_ib_pic_piclane(*devport_portlane_to_ib_pic_piclane(devport, portlane))
                lane_label[full_lane] = 'Devport: %d PortLane %d:' % (devport, portlane)
                full_lane_list += [full_lane]
    for lane in default_lane_list:
        if lane > 7:
            parser.error("Invalid lane number, valid choice [0...7]")
    return full_lane_list

def do_for_lane_list(func, args):
    full_lane_list = get_full_lane_list(args)

    if func == cli_eye and args.collect:
        eye_mon_collect_multi(full_lane_list, depth=args.collect)
    if func == cli_bathtub_plot and args.collect:
        eye_mon_collect_multi(full_lane_list, depth=args.collect, is_vert_bathtub=(not args.horizontal))
    if func == cli_eye or func == cli_bathtub_plot:
        if (not args.plot) and (not args.sizes):
            if not args.collect:
                raise ValueError('*** Must specify at least one of -C, -s, or -p')
            # else we have already done the collection... no need for lane-by-lane empty print
            return

    if func == cli_ber:
        ber_collect_multi(full_lane_list, args)

    for full_lane in full_lane_list:
        args_subset = copy.deepcopy(args) # let the called function overwrite args
        try:  # 'save' arguments are open files, so don't use a deep copy, use it as-is
            args_subset.save = args.save
        except:
            pass
        args_subset.ib = None             # without affecting other lanes
        args_subset.pic = None            # also, remove non-optional args
        args_subset.lane = None           # so cli_xxx can determine if no args
        args_subset.devport = None        # were passed
        args_subset.func = None
        args_subset.subcmd = None
        func(full_lane, args_subset)

def make_per_lane_cb(func):
    """helper func to create a callback func for subcommands to manage default lanes and iterate"""
    return lambda args: do_for_lane_list(func, args)

def add_parser(parser):
    parser.add_argument('--ib', type=parse_list, default=None, metavar='IB_LIST',
                        help=argparse.SUPPRESS)
    parser.add_argument('--pic', type=parse_list, default=None, metavar='PIC_LIST',
                        help=argparse.SUPPRESS)
    parser.add_argument('--devport', type=parse_list, default=None, metavar='PORT_LIST',
                        help="Port number or list or 'all' (sticky)")
    parser.add_argument('--lane', type=parse_list, default=None, metavar='LANE_LIST',
                        help="Lane number or list or 'all' (sticky)")
    subparsers = parser.add_subparsers(help='All numerical arguments in hex')

    parser_fw = subparsers.add_parser('firmware', help='load firware')
    parser_fw.add_argument('filename', type=str, nargs='?', help='If none, show Hash/CRC of current FW')
    parser_fw.set_defaults(func=make_per_lane_cb(cli_load_fw))

    parser_status = subparsers.add_parser('status', help='show status')
    parser_status.add_argument('--reset-ber', '-r', dest='reset_ber', action='store_true', help='reset BER error counts, then delay 0.1 sec')
    parser_status.add_argument('--verbose', '-v', action='store_true')
    parser_status.set_defaults(func=make_per_lane_cb(cli_status))

    parser_config = subparsers.add_parser('config', help='set configuration')
    parser_config.add_argument('--pre2', type=int, help='Pre2 Tap value')
    parser_config.add_argument('--pre1', type=int, help='Pre1 Tap value')
    parser_config.add_argument('--main', type=int, help='Main Tap value')
    parser_config.add_argument('--post1', type=int, help='Post1 Tap value')
    parser_config.add_argument('--post2', type=int, help='Post2 Tap value')
    parser_config.add_argument('--speed', type=valid_speed_parser, metavar=str(valid_speed_list))
    parser_config.add_argument('--div4', metavar='<bool>', type=distutils.util.strtobool, help=argparse.SUPPRESS)
    tx_type_group = parser_config.add_mutually_exclusive_group(required=False)
    tx_type_group.add_argument('--tx-core', dest='tx_core', default=None, action='store_true', help='Disable test patterns, transmit normal data')
    tx_type_group.add_argument('--tx-test', dest='tx_test', type=str.upper, choices=['PRBS9', 'PRBS15', 'PRBS23', 'PRBS31', 'PRBS13', 'PRBS13Q', 'PRBS31Q', 'JP03A', 'JP03B', 'LINEARITY'])
    tx_type_group.add_argument('--tx-pattern', dest='tx_pattern', type=Hex, help='Custom Tx test pattern, e.g. 0xaaaaaaaaaaaaaaaa')
    tx_type_group.add_argument('--tx-loopback', dest='tx_loopback', default=None, action='store_true', help='Rx is decoded and sent back out Tx')
    parser_config.add_argument('--tx-enable', dest='tx_enable', type=distutils.util.strtobool)
    parser_config.add_argument('--tx-msblsb', dest='tx_msblsb', metavar='<bool>', type=distutils.util.strtobool)
    parser_config.add_argument('--tx-precode', dest='tx_precode', metavar='<bool>', type=distutils.util.strtobool)
    parser_config.add_argument('--tx-graycode', dest='tx_graycode', metavar='<bool>', type=distutils.util.strtobool)
    parser_config.add_argument('--tx-polarity', dest='tx_polarity', metavar='<bool>', type=distutils.util.strtobool)
    #parser_config.add_argument('--rx-enable', dest='rx_enable', type=distutils.util.strtobool)    # no good method to do this right now

    parser_config.add_argument('--rx-input', dest='rx_input', type=str.lower, choices=['ac', 'dc'])
    parser_config.add_argument('--rx-precode', dest='rx_precode', metavar='<bool>', type=distutils.util.strtobool)
    parser_config.add_argument('--rx-graycode', dest='rx_graycode', metavar='<bool>', type=distutils.util.strtobool)
    parser_config.add_argument('--rx-polarity', dest='rx_polarity', metavar='<bool>', type=distutils.util.strtobool)
    parser_config.add_argument('--rx-msblsb', dest='rx_msblsb', metavar='<bool>', type=distutils.util.strtobool)

    parser_config.add_argument('--rx-check', dest='rx_check', type=str.upper, choices=['PRBS9', 'PRBS15', 'PRBS23', 'PRBS31', 'PRBS13', 'PRBS13Q', 'PRBS31Q', 'OFF'])
    parser_config.add_argument('--tune', type=str.lower, choices=['on', 'off', 'bounce'], help='FW Tuning setup')

    parser_config.add_argument('--optical', dest='optical', metavar='<bool>', type=distutils.util.strtobool)
    parser_config.add_argument('--los-holdoff', dest='los_holdoff', metavar='<bool>', type=distutils.util.strtobool)

    parser_config.add_argument('--reset', default=None, action='store_true')
    parser_config.add_argument('--verbose', '-v', default=None, action='store_true')
    parser_config.set_defaults(func=make_per_lane_cb(cli_config))

    parser_bathtub = subparsers.add_parser('bathtub', help = 'show bathtub plot')
    parser_bathtub.add_argument('-C', '--collect', nargs='?', type=int, const=7, metavar='DEPTH', help='collect eye data (default depth 7)')
    parser_bathtub.add_argument('-H', '--horizontal', action='store_true', help='show horizontal bathtub plot (default is vertical)')
    #parser_bathtub.add_argument('-t', '--top', action='store_true', help='top eye')
    #parser_bathtub.add_argument('-b', '--bottom', action='store_true', help='bottom eye')
    #parser_bathtub.add_argument('-c', '--center', action='store_true', help='center eye')
    parser_bathtub.add_argument('-p', '--plot', nargs='?', type=int, default=None, const=15, metavar='DEPTH', help='plot bathtub [DEPTH: default 15]')
    parser_bathtub.add_argument('-s', '--sizes', nargs='?', type=parse_list, default=None, metavar='BERS', const=[8, 12, 15],
                                help='print size at specified depth (default 8,12,15)')
    parser_bathtub.add_argument('-S', '--save', action='store_true', help='save data to file')
    parser_bathtub.add_argument('-q', '--q-scale', dest='q_scale', action='store_true', help='plot as q-scale, not BER')
    parser_bathtub.add_argument('--cols', type=int, default=None, help='number of columns in textual plot')
    parser_bathtub.set_defaults(func=make_per_lane_cb(cli_bathtub_plot))

    parser_eye = subparsers.add_parser('eye', help = 'eye plot characterization')
    parser_eye.add_argument('-C', '--collect', nargs='?', type=int, const=7, metavar='DEPTH', help='collect eye data (default depth 7)')
    parser_eye.add_argument('-s', '--sizes', nargs='?', type=parse_list, default=None, metavar='BERS', const=[8, 12, 15],
                            help='print width/height.  Default BERs: 8,12,15')
    parser_eye.add_argument('-p', '--plot', action='store_true', help='display eye plot')
    parser_eye.add_argument('-c', '--color', type=str.lower, choices=['gray', 'none'], default='normal')
    parser_eye.add_argument('-i', '--invert', action='store_true', help='Invert color scale')
    parser_eye.add_argument('--cols', type=int, default=None, help='Columns in textual plot')
    parser_eye.add_argument('-S', '--save', type=argparse.FileType('w'), default=None, help='save data to file')
    parser_eye.set_defaults(func=make_per_lane_cb(cli_eye))

    parser_ber = subparsers.add_parser('ber', help = 'show ber')
    parser_ber.add_argument('--reset', action='store_true', help='reset error counts at start of BER collection')
    parser_ber.add_argument('--time', type=int, default=5, help='maximum time for BER in seconds (def. 5)')
    parser_ber.set_defaults(func=make_per_lane_cb(cli_ber))

    parser_vendor = subparsers.add_parser('vendor', help='SerDes vendor-specific commands')
    subparser_vendor = parser_vendor.add_subparsers()
    parser_read = subparser_vendor.add_parser('read', help='read SerDes register')
    parser_read.add_argument('addr', type=Hex, help='address')
    parser_read.add_argument('--num', '-n', type=int, default=1, help='number of entries to read')
    parser_read.add_argument('--wide', '-w', action='store_true', help='32-bit read')
    parser_read.set_defaults(func=make_per_lane_cb(cli_read))

    parser_readbits = subparser_vendor.add_parser('readbits', help='read bits from register')
    parser_readbits.add_argument('addr', type=Hex, help='address')
    parser_readbits.add_argument('bits', type=parse_list, help='bits to read, e.g: 3-1 or 7,5')
    parser_readbits.add_argument('--num', '-n', type=int, default=1, help='number of entries to read')
    parser_readbits.set_defaults(func=make_per_lane_cb(cli_readbits))

    parser_write = subparser_vendor.add_parser('write', help='write SerDes register')
    parser_write.add_argument('addr', type=Hex, help='address')
    parser_write.add_argument('value', type=Hex, help='value')
    parser_write.set_defaults(func=make_per_lane_cb(cli_write))

    parser_writebits = subparser_vendor.add_parser('writebits', help='write SerDes register')
    parser_writebits.add_argument('addr', type=Hex, help='address')
    parser_writebits.add_argument('bits', type=parse_list, help='bits to write')
    parser_writebits.add_argument('value', type=Hex, help='value to unpack into those bits')
    parser_writebits.set_defaults(func=make_per_lane_cb(cli_writebits))

    parser_di = subparser_vendor.add_parser('isi', help='Dump utils')
    parser_di.set_defaults(func=make_per_lane_cb(cli_dump_isi))
    parser_dni = subparser_vendor.add_parser('nrz-isi', help='Dump utils')
    parser_dni.set_defaults(func=make_per_lane_cb(cli_dump_nrz_isi))
    parser_dec = subparser_vendor.add_parser('exit-code', help='Dump utils')
    parser_dec.set_defaults(func=make_per_lane_cb(cli_dump_exit_code))
    parser_dt = subparser_vendor.add_parser('ths', help='Dump utils')
    parser_dt.set_defaults(func=make_per_lane_cb(cli_dump_ths))
    parser_df = subparser_vendor.add_parser('ffe', help='Dump utils')
    parser_df.set_defaults(func=make_per_lane_cb(cli_dump_ffe))
    parser_dfw = subparser_vendor.add_parser('ffe-wt', help='Dump utils')
    parser_dfw.set_defaults(func=make_per_lane_cb(cli_dump_ffe_wt))
    parser_da = subparser_vendor.add_parser('an', help='Dump utils')
    parser_da.set_defaults(func=make_per_lane_cb(cli_dump_an))
    parser_dfr = subparser_vendor.add_parser('fw-reg', help='Dump utils')
    parser_dfr.set_defaults(func=make_per_lane_cb(cli_dump_fw_reg))
    parser_dfe = subparser_vendor.add_parser('dfe', help='Dump utils')
    parser_dfe.set_defaults(func=make_per_lane_cb(cli_get_dfe))
    parser_dgfw = subparser_vendor.add_parser('get_fw_reg', help='get FW register')
    parser_dgfw.add_argument('index', type=Hex, help='index')
    parser_dgfw.add_argument('section', type=Hex, help='section')
    parser_dgfw.set_defaults(func=make_per_lane_cb(cli_get_fw_reg))
    parser_dsfw = subparser_vendor.add_parser('set_fw_reg', help='set FW register')
    parser_dsfw.add_argument('index', type=Hex, help='index')
    parser_dsfw.add_argument('section', type=Hex, help='section')
    parser_dsfw.add_argument('value', type=Hex, help='write value')
    parser_dsfw.set_defaults(func=make_per_lane_cb(cli_set_fw_reg))
    parser_dptd = subparser_vendor.add_parser('pt_debug', help='PT debug')
    parser_dptd.add_argument('index', type=Hex, help='index')
    parser_dptd.add_argument('section', type=Hex, help='section')
    parser_dptd.add_argument('--num', '-n', type=int, default=1, help='number of entries to read')
    parser_dptd.set_defaults(func=make_per_lane_cb(cli_pt_debug))

# for direct use from python
def run_cmd(arglist):
    try:
        arglist = ['--help' if a == 'help' else a for a in arglist]  # replace any 'help' arguments with '--help'

        parser = argparse.ArgumentParser(prog='diagtest serdes eth')
        add_parser(parser)
        args = parser.parse_args(arglist)
        args.func(args)
    except ValueError as ex:
        log("Value Error: %s" % ":".join(ex.args))
    except Exception as ex:
        traceback.print_exc(file=sys.stdout)
        log("exception: ", type(ex).__name__, ex.args)
    except:
        pass
