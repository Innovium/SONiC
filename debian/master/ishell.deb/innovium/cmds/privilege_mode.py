#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2016
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

import shlex
from cmdmgr import Command
from utils.compat_util import *
from verbosity import log_dbg, log_err, log

class Privilege_mode(Command):
    def __init__(self, cli):
        # Add sub cmds
        self.sub_cmds = {'show'    : self.show,
                         'set'     : self.set,
                         'help'    : self.help,
                         '?'       : self.help
                        }

        # Add commands based on privilege mode
        if cli.privilege_mode >= 1:
            self.sub_cmds.update({'admin_cmd' : self.admin_cmd})

        # Add help cmds
        self.help_cmds = {'show'    : 'privilege show          - show privilege mode',
                          'set'     : 'privilege set <level>   - set privilege mode to <level>',
                          'help'    : 'privilege help or ?     - show this text',
                         }

        # Add help commands based on privilege mode
        if cli.privilege_mode >= 1:
            self.help_cmds.update({'admin_cmd' : 'privilege admin_cmd     - show this admin_cmd help'})

        super(Privilege_mode, self).__init__()
        self.cli = cli
        self.arg_list = []
        return

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def run_cmd(self, args):
        log_dbg(1, "In privilege mode run_cmd")
        self.arg_list = shlex.split(args)
        try:
            return self.sub_cmds[self.arg_list[1]](args)
        except:
            log("Could not set privilege mode")
            return -1

    def show(self, args):
        log("CLI privilege mode set to %d" % self.cli.privilege_mode)

    def set(self, args):
        arg_list = shlex.split(args)
        # set privilege mode
        self.cli.privilege_mode = int(arg_list[2])
        self.cli.init_cmds()
        log("CLI privilege mode set to %d" % self.cli.privilege_mode)

    def help(self, args):
        log("Usage:")
        for key, value in compat_iteritems(self.help_cmds):
            log(value)

    def admin_cmd(self, args):
        log("WARNING: This is a hidden command. Are you really an admin?")
