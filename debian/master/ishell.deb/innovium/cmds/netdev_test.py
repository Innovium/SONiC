
#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2018
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

import shlex
import argparse
import itertools
import time
import json
import socket
import os
import time
from utils.compat_util import *
from verbosity import *
from cmdmgr import Command
from ctypes import *
from collections import OrderedDict
from ifcs_ctypes import *
from ifcs_cmds.sysport import Sysport as sysport
from ifcs_cmds.devport import Devport as Devport
from ifcs_cmds.node import Node as node
from print_table import PrintTable
from testutil.util import hexdump
from threading import Thread

def getSysportHandleFromDevPort(node_id, devPort):
    attr = ifcs_attr_t()
    actual_count = ctypes.c_uint32()

    attr.id = IFCS_DEVPORT_ATTR_SYSPORT
    ret = ifcs_devport_attr_get(node_id, devPort, 1, pointer(attr),
                            pointer(actual_count))
    assert ret == IFCS_SUCCESS, "port sysport handle get: ret = [" + str(ret) + "]"

    return attr.value.handle

def create_ctc_trap(node_id):
    ctc_trap_handle = ifcs_handle_t()
    ctc_trap_handle.value = IFCS_NULL_HANDLE

    attr = (ifcs_attr_t * 1 )()

    attr[0].id = IFCS_HOSTIF_TRAP_ATTR_QUEUE_NUM
    attr[0].value.u32 = 0

    rc = ifcs_hostif_trap_create(node_id, pointer(ctc_trap_handle), 1, compat_pointer(attr, ifcs_attr_t))
    assert rc == IFCS_SUCCESS, "COPY to CPU trap creation FAILED"

    return ctc_trap_handle

def create_ctc_trap(node_id):
    ctc_trap_handle = ifcs_handle_t()
    ctc_trap_handle.value = IFCS_NULL_HANDLE

    attr = (ifcs_attr_t * 1 )()

    attr[0].id = IFCS_HOSTIF_TRAP_ATTR_QUEUE_NUM
    attr[0].value.u32 = 0

    rc = ifcs_hostif_trap_create(node_id, pointer(ctc_trap_handle), 1, compat_pointer(attr, ifcs_attr_t))
    assert rc == IFCS_SUCCESS, "COPY to CPU trap creation FAILED"

    return ctc_trap_handle

def delete_ctc_trap(node_id, ctc_trap_handle):
    rc = ifcs_hostif_trap_delete(node_id, ctc_trap_handle);
    assert rc == IFCS_SUCCESS, "COPY to CPU trap deletion FAILED"
    return

def rx_verify_lb(node_id, packet_data, packet):
    global rx_verify_status_lb
    global lb_pkt_cnt

    data = packet_data[16:]
    if (ord(data[0]) == 0xde and ord(data[1]) == 0xad and \
            ord(data[2]) == 0xbe and ord(data[3]) == 0xef):
        lb_pkt_cnt = lb_pkt_cnt + 1
        rx_verify_status_lb = 'PASSED'
    else:
        hexdump(data)
        rx_verify_status_lb = 'FAILED'


class Netdev(Command):
    def __init__(self, cli):
        self.sub_cmds = {
                         'single'      : self.single
                        }
        self.cli = cli
        self.arg_list = []
        super(Netdev, self).__init__()

    def __del__(self):
        return

    def init(self, ifname):
        self.sock = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.htons(3)) #3 = ETH_P_ALL
        self.ifname = ifname
        self.sock.bind((ifname, 0))
        self.thread = Thread(target = self.netdev_rx_th, args = (0, ))
        self.thread.daemon = True
        self.thread.start()

    def deinit(self):
        self.sock.close()

    def run_cmd(self, args):
        self.arg_list = shlex.split(args)
        try:
            rc = self.sub_cmds[self.arg_list[2]](args)
            return rc
        except (KeyError):
            log_dbg(1, "Invalid cmd")
            self.help(args)
            return IFCS_PARAM
        except Exception as ex:
            self.cli.error()
            self.help(args)

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def send(self, msg):
        sent = self.sock.send(msg)
        if sent == 0:
            raise RuntimeError("socket connection broken")
        return sent

    def receive(self):
        try:
            chunk = self.sock.recv(9000)
        except socket.error:
            return ""
        if chunk == '':
            raise RuntimeError("socket connection broken")
        return ''.join(chunk)

    def single(self, args):
        global lb_pkt_cnt
        global rx_verify_status_lb

        os.system('echo 1 > /proc/sys/net/ipv6/conf/all/disable_ipv6')
        os.system('ifconfig inno0 up')
        self.init("inno0")
        lb_pkt_cnt = 0
        rx_verify_status_lb = None
        port_cnt  = 4
        first_port = 1
        node_id = self.cli.node_id
        num_ports = first_port + port_cnt
        self.portlb(first_port, port_cnt)
        # Send packets
        for devport in range(first_port, num_ports):
            dst_sp_hdl = getSysportHandleFromDevPort(node_id, devport)
            bytes = chr(0xaa) + chr(0x00) + chr(0x00) + chr(devport) + chr(0x00) + chr(0x00)
            bytes += chr(0x00) + chr(0x00) + chr(0x00) + chr(0x00) + chr(0x00) + chr(0x00)
            bytes += chr(0x00) + chr(0x00) + chr(0x00) + chr(0x00) + chr(0x00) + chr(0x00)
            bytes += chr(0x00) + chr(0x00) + chr(0x00) + chr(0x00) + chr(0x00) + chr(0x00)
            bytes += chr(0x00) + chr(0x00) + chr(0x00) + chr(0x00) + chr(0x00) + chr(1)
            bytes += chr(0x00) + chr(0x00) + chr(0x00) + chr(0x00) + chr(0x00) + chr(devport+1)
            bytes += chr(0x81) + chr(0x00) + chr(0x00) + chr(0x64)
            bytes += chr(0xde) + chr(0xad) + chr(0xbe) + chr(0xef)
            length = 100
            for j in range(length - 44):
                bytes += chr(0xff)
            self.send(bytes)

        retry_cnt = 0;
        # Verify if the packets were received
        while rx_verify_status_lb == None or lb_pkt_cnt < (num_ports-first_port):
            time.sleep(0.1)
            retry_cnt = retry_cnt + 1
            if (retry_cnt > 10):
                rx_verify_status_lb = 'FAILED'
                break

        self.portlb_rem(first_port, port_cnt)
        log("Netdev Single Interface test\t\t:\t" + rx_verify_status_lb)

        self.deinit()
        return rx_verify_status_lb

    def netdev_rx_th(self,arg):
        while 1:
            buf = self.receive()
            if buf == "":
                break
            rx_verify_lb(self.cli.node_id, buf[24:], buf)

    def portlb(self, first_port, port_cnt):
        global lb_pkt_cnt
        global rx_verify_status_lb
        global l2entry_array
        global l2entry_dst
        global l2vni_hdl
        global ctc_trap_handle
        global stp_hdl

        node_id = self.cli.node_id
        attr = ifcs_attr_t()
        vni_attr = ifcs_attr_t()
        vni_hdl = ifcs_handle_t()
        stp_hdl = ifcs_handle_t()
        mac_addr_t = c_uint8 * 6

        lb_pkt_cnt = 0
        rx_verify_status_lb = None
        num_ports = first_port + port_cnt
        attr_count = 1
        attr_list_p = (ifcs_attr_t * attr_count)()

        # Disable all the ports
        attr_list_p[0].id = IFCS_DEVPORT_ATTR_ADMIN_STATE;
        attr_list_p[0].value.u32 = IFCS_BOOL_FALSE;

        for devport in range(first_port, num_ports):
            rc = ifcs_devport_attr_set (node_id, devport,
                             attr_count, compat_pointer(attr_list_p, ifcs_attr_t));
            assert rc == IFCS_SUCCESS,\
                "ERR during port admin disable:" +\
                str(devport)

        # Set all the ports in loopback
        attr_list_p[0].id = IFCS_DEVPORT_ATTR_LOOPBACK;
        attr_list_p[0].value.u32 = IFCS_DEVPORT_LOOPBACK_PCS;

        for devport in range(first_port, num_ports):
            rc = ifcs_devport_attr_set (node_id, devport,
                             attr_count, compat_pointer(attr_list_p, ifcs_attr_t));
            assert rc == IFCS_SUCCESS,\
                "ERR during port loopback set:" +\
                str(devport)

        # Enable all the ports
        attr_list_p[0].id = IFCS_DEVPORT_ATTR_ADMIN_STATE;
        attr_list_p[0].value.u32 = IFCS_BOOL_TRUE;

        for devport in range(first_port, num_ports):
            rc = ifcs_devport_attr_set (node_id, devport,
                             attr_count, compat_pointer(attr_list_p, ifcs_attr_t));
            assert rc == IFCS_SUCCESS,\
                "ERR during port admin enable:" +\
                str(devport)

        # Wait for all ports to go link-up for 5 secs
        wait_time=0
        attr_list_p[0].id = IFCS_DEVPORT_ATTR_LINK_STATUS;
        attr_list_p[0].value.u32 = 0;
        actual_count = ctypes.c_uint32()
        link_status=True
        while wait_time<5:
            link_status=True
            for devport in range(first_port, num_ports):
                rc = ifcs_devport_attr_get (node_id, devport, 1,
                                 compat_pointer(attr_list_p, ifcs_attr_t), pointer(actual_count));
                assert rc == IFCS_SUCCESS,\
                    "ERR during port admin enable:" +\
                    str(devport)

                if (attr_list_p[0].value.u32 != 1):
                    link_status=False
            if link_status:
                break;
            else:
                wait_time+=0.1
                time.sleep(0.1)

        assert link_status == True, "Not all devports are up"

        l2vni = 0x64

        ###### VNI CONFIG ######
        # Create VNI and add members
        l2vni_hdl = ifcs_handle_t()
        l2vni_hdl.value = IFCS_HANDLE_L2VNI(l2vni)
        ret = ifcs_l2vni_create(node_id, pointer(l2vni_hdl), 0, pointer(attr))
        assert ret == IFCS_SUCCESS or ret == IFCS_EXIST,\
               "ERR during L2VNI creation " + str(l2vni)

        ctc_trap_handle = create_ctc_trap(node_id)

        ####### STEP0 #######
        ###### STP CONFIG #######
        stp_hdl.value = IFCS_NULL_HANDLE
        ret = ifcs_stp_create(node_id, pointer(stp_hdl),
                                         0, pointer(attr))
        assert ret == IFCS_SUCCESS or ret == IFCS_EXIST, "STP instance creation FAILED"

        dst_sp_hdl = getSysportHandleFromDevPort(node_id, 0)
        dst_sp = IFCS_HANDLE_VALUE(dst_sp_hdl)
        mbr1 = IFCS_HANDLE_SYSPORT(dst_sp)

        member_count = 1
        member_list = (ifcs_handle_t * member_count)()

        member_attr_count = 0
        member_attr_list = (ifcs_attr_t * member_attr_count)()

        member_list[0] = mbr1

        ret = ifcs_l2vni_member_add(node_id, l2vni_hdl,
                                     member_count, compat_pointer(member_list, ifcs_handle_t),
                                     member_attr_count, compat_pointer(member_attr_list, ifcs_attr_t))
        assert ret == IFCS_SUCCESS or ret == IFCS_EXIST,\
               "ERR during L2VNI mbr add " + str(l2vni)

        stp_attr_count = 1
        stp_attr = ifcs_attr_t()
        stp_attr.id        = IFCS_STP_PORT_ATTR_STP_STATE;
        stp_attr.value.u32 = IFCS_STP_PORT_STATE_FORWARDING;
        #ret = ifcs_stp_port_attr_set(node_id, stp_hdl, mbr1,\
        #                             stp_attr_count, pointer(stp_attr))
        ret = ifcs_stp_port_add(node_id, stp_hdl, member_count, compat_pointer(member_list, ifcs_handle_t),\
                                     stp_attr_count, pointer(stp_attr))
        assert ret == IFCS_SUCCESS or ret == IFCS_EXIST,\
               "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                str(l2vni) + ", Port Hdl: " + str(hex(mbr1.value))


        # 1.2
        ###### FDB Config #######
        attr_count = 4
        attr = (ifcs_attr_t * attr_count)()

        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 1)
        dst_port_hdl = ifcs_handle_t()
        dst_port_hdl.value = IFCS_HANDLE_SYSPORT(dst_sp)

        l2entry_dst = ifcs_l2_entry_key_t
        l2_entry = ifcs_l2_entry_key_t()
        l2_entry.key_type = IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI
        l2_entry.key.mac_l2vni.mac_addr = mac_addr
        l2_entry.key.mac_l2vni.l2vni = l2vni_hdl
        l2entry_dst = l2_entry

        attr[0].id = IFCS_L2_ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = dst_port_hdl
        attr[1].id = IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = IFCS_L2_ENTRY_TYPE_STATIC
        attr[2].id = IFCS_L2_ENTRY_ATTR_ENTRY_FWD_POLICY
        attr[2].value.fwd_policy.fwd_action = IFCS_FWD_ACTION_DROP
        attr[3].id = IFCS_L2_ENTRY_ATTR_ENTRY_CTC_POLICY
        attr[3].value.ctc_policy.ctc_action = IFCS_COPY_TO_CPU_ENABLE
        attr[3].value.ctc_policy.trap_handle = ctc_trap_handle
        rc = ifcs_l2_entry_create(node_id, pointer(l2entry_dst), attr_count, compat_pointer(attr, ifcs_attr_t))
        assert rc == IFCS_SUCCESS or rc == IFCS_EXIST, "Create FDB entry FAILED: rc = [" + str(rc) + "]"

        l2entry_array = (ifcs_l2_entry_key_t * num_ports)()
        src_port_hdl = ifcs_handle_t()

        # Set up an L2entry with CTC
        for devport in range(first_port, num_ports):
            src_sp_hdl = getSysportHandleFromDevPort(node_id, devport)
            src_sp = IFCS_HANDLE_VALUE(src_sp_hdl)

            ####### STEP1 #######
            # 1.1

            mbr2 = IFCS_HANDLE_SYSPORT(src_sp)

            member_count = 1
            member_list = (ifcs_handle_t * member_count)()

            member_attr_count = 0
            member_attr_list = (ifcs_attr_t * member_attr_count)()

            member_list[0] = mbr2

            ret = ifcs_l2vni_member_add(node_id, l2vni_hdl,
                                         member_count, compat_pointer(member_list, ifcs_handle_t),
                                         member_attr_count, compat_pointer(member_attr_list, ifcs_attr_t))
            assert ret == IFCS_SUCCESS or ret == IFCS_EXIST,\
                   "ERR during L2VNI mbr add " + str(l2vni)

            stp_attr_count = 1
            stp_attr = ifcs_attr_t()
            stp_attr.id        = IFCS_STP_PORT_ATTR_STP_STATE;
            stp_attr.value.u32 = IFCS_STP_PORT_STATE_FORWARDING;
            #ret = ifcs_stp_port_attr_set(node_id, stp_hdl, mbr2,\
            #                             stp_attr_count, pointer(stp_attr))
            ret = ifcs_stp_port_add(node_id, stp_hdl, member_count, compat_pointer(member_list, ifcs_handle_t),\
                                         stp_attr_count, pointer(stp_attr))
            assert ret == IFCS_SUCCESS or ret == IFCS_EXIST,\
                   "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                    str(l2vni) + ", Port Hdl: " + str(hex(mbr2.value))

            mac_addr = mac_addr_t(0, 0, 0, 0, 0, devport+1)
            src_port_hdl.value = IFCS_HANDLE_SYSPORT(src_sp)
            attr_count = 2

            l2_entry = ifcs_l2_entry_key_t()
            l2_entry.key_type = IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI
            l2_entry.key.mac_l2vni.mac_addr = mac_addr
            l2_entry.key.mac_l2vni.l2vni = l2vni_hdl
            l2entry_array[devport] = l2_entry
            attr[0].id = IFCS_L2_ENTRY_ATTR_ENTRY_DEST
            attr[0].value.handle = src_port_hdl
            attr[1].id = IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
            attr[1].value.u32 = IFCS_L2_ENTRY_TYPE_STATIC
            rc = ifcs_l2_entry_create(node_id, compat_pointerAtIndex(l2entry_array, ifcs_l2_entry_key_t, devport), attr_count, compat_pointer(attr, ifcs_attr_t))
            assert rc == IFCS_SUCCESS or rc == IFCS_EXIST, "Create FDB entry FAILED: rc = [" + str(rc) + "]"


            ssp_attr = ifcs_attr_t()
            ssp_attr.id = IFCS_SYSPORT_ATTR_DEFAULT_CVID
            ssp_attr.value.u32 = l2vni
            ret = ifcs_sysport_attr_set(node_id, src_sp_hdl, 1, pointer(ssp_attr))
            assert ret == IFCS_SUCCESS or rc == IFCS_EXIST, "SSP default PVID set FAILED: ret = [" + str(ret) + "]"


        # Set STP instance for created VNI
        vni_attr.id = IFCS_L2VNI_ATTR_STP_INSTANCE
        vni_attr.value.handle = stp_hdl
        ret = ifcs_l2vni_attr_set(node_id, l2vni_hdl, 1, pointer(vni_attr))
        assert ret == IFCS_SUCCESS or rc == IFCS_EXIST, "STP instance vni attr set FAILED"

    def portlb_rem(self, first_port, port_cnt):
        global l2entry_array
        global l2entry_dst
        global l2vni_hdl
        global ctc_trap_handle
        global stp_hdl
        node_id = self.cli.node_id
        num_ports = first_port + port_cnt
        mac_addr_t = c_uint8 * 6
        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 1)

        attr_count = 1
        attr_list_p = (ifcs_attr_t * attr_count)()
        # Disable all the ports
        attr_list_p[0].id = IFCS_DEVPORT_ATTR_ADMIN_STATE;
        attr_list_p[0].value.u32 = IFCS_BOOL_FALSE;

        for devport in range(first_port, num_ports):
            rc = ifcs_devport_attr_set (node_id, devport,
                             attr_count, compat_pointer(attr_list_p, ifcs_attr_t));
            assert rc == IFCS_SUCCESS,\
                "ERR during port admin disable:" +\
                str(devport)

        # Take all the ports out of loopback
        attr_list_p[0].id = IFCS_DEVPORT_ATTR_LOOPBACK;
        attr_list_p[0].value.u32 = IFCS_DEVPORT_LOOPBACK_NONE;
        attr_count = 1
        for devport in range(first_port, num_ports):
            rc = ifcs_l2_entry_delete(node_id, compat_pointerAtIndex(l2entry_array, ifcs_l2_entry_key_t, devport))
            assert rc == IFCS_SUCCESS,\
                "ERR during l2entry delete on devport :" +\
                str(devport)

            rc = ifcs_devport_attr_set (node_id, devport,
                             attr_count, compat_pointer(attr_list_p, ifcs_attr_t));
            assert rc == IFCS_SUCCESS,\
                "ERR during port loopback remove:" +\
                str(devport)

        rc = ifcs_l2_entry_delete(node_id, pointer(l2entry_dst))
        assert rc == IFCS_SUCCESS,\
                "ERR during l2entry delete on devport :" +\
                str(0)

        rc = ifcs_l2vni_delete(node_id, l2vni_hdl)
        assert rc == IFCS_SUCCESS,\
              "ERR during l2vni delete:" +\
              str(l2vni)

        rc = ifcs_stp_delete(node_id, stp_hdl)
        assert rc == IFCS_SUCCESS,\
              "ERR during stp delete:" +\
              str(IFCS_HANDLE_VALUE(stp_hdl))

        delete_ctc_trap(node_id, ctc_trap_handle)

    def help(self, args):
        log("Usage:: \n" \
              "  diagtest netdev single\n")
