#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2020
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

import shlex
import argparse
import os
import datetime
import signal
import sys
import re
from utils.compat_util import *
from verbosity import *
from cmdmgr import Command
from ctypes import *
from print_table import PrintTable
if COMPAT_PY2:
    from exceptions import IOError

ifcs_ctypes = sys.modules['ifcs_ctypes']


# Class implements top level Show commands
class Show(Command):
    def __init__(self, cli):
        self.sub_cmds = {
                         'techsupport' : self.techsupport,
                         'help'        : self.help,
                         '?'           : self.help
                        }

        self.cli = cli
        self.arg_list = []
        super(Show, self).__init__()

    def __del__(self):
        return

    def run_cmd(self, args):
        log_dbg(1, "In Show run")
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        try:
            rc = self.sub_cmds[self.arg_list[1]](args)
            return rc
        except (KeyError):
            log_dbg(1, "KeyError")
            self.help(args)
            return ifcs_ctypes.IFCS_INVAL
        except (ValueError):
            log_dbg(1, "ValueError")
            self.help(args)
            return ifcs_ctypes.IFCS_INVAL
        except Exception as e:
            log(e)
            log_dbg(1, "OtherError")
            self.help(args)
            return ifcs_ctypes.IFCS_INVAL

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def complete_techsupport(self, text):
        return

    def getShowType(self, args):
        log_dbg(1,"In getShowType with args: " + str(args))

        show_type = args.split()[2]

        # This if condition needs to be expanded for other show types
        if show_type == 'techsupport':
            return show_type
        else:
            return 'unsupported'

    def help(self, args):
        log("Usage: show techsupport [-i <input file>] [-o <output file> [-nozip]]")
        log(" ")
        log(" -i <input file> Input Command File (default: shell/show_techsupport_infile)")
        log(" ")
        log(" -o <output file> Command Output File (default: stdout, showtech_outfile_<timestamp>.gz)")
        log(" ")
        log(" -nozip do not compress the output file if specified (default: output file compressed)")

        return ifcs_ctypes.IFCS_SUCCESS

    def signal_handler(signal, frame):
        log("Ctrl-C Pressed, Quiting process")
        sys.exit(0)

    def parseArgsTechSupport(self, cmd, args):
        log_dbg(1, "In parseArgsTechSupport args: " + args)
        arg_list = args.split()

        if len(arg_list) > 0:
            parser = argparse.ArgumentParser(prog='show techsupport')
            parser.add_argument('cmd', help='show')
            parser.add_argument('obj', help='techsupport')
            parser.add_argument('-i', dest='infile', default='shell/show_techsupport_infile', required=False)
            parser.add_argument('-o', dest='outfile', required=False, help='Output File [-nozip]')
            opts, rem_args = parser.parse_known_args(arg_list)
            if opts.obj == 'techsupport':
                if opts.outfile:
                    parser.add_argument('-nozip', dest='dontzip', action="store_true", required=False, default=False)

                parsed_res = parser.parse_args(arg_list)
                return parsed_res

        return None

    def bordered(self, text):
        timeNow = datetime.datetime.now()
        textToFormat = timeNow.strftime("%Y-%m-%d %H:%M:%S.%f\n") + text

        lines = textToFormat.splitlines()
        res = ['+' + '=' * 76 + '+']

        for s in lines:
            res.append('+' + (s + ' ' * 76)[:76] + '+')

        res.append('+' + '=' * 76 + '+')

        return '\n'.join(res)

    def techsupport(self, args):
        rc = ifcs_ctypes.IFCS_SUCCESS
        log_dbg(1, "In techsupport with args: " + args)

        # parse arguments
        parsed_res = self.parseArgsTechSupport("show", args)

        if parsed_res.infile != None:
            try:
                self.inFile = open(parsed_res.infile, "r")
            except IOError:
                log("Cannot find file \"{}\"".format(parsed_res.infile))
                return ifcs_ctypes.IFCS_INVAL

        orig_stdout = sys.stdout

        prt_to_screen = True
        if parsed_res.outfile != None:
            outFile = parsed_res.outfile
            prt_to_screen = False
        else:
            outFile = "showtech_outfile_" + datetime.datetime.now().strftime("%Y%m%d-%H%M%S")

        self.outFile = open(outFile, "w")

        options = vars(parsed_res)

        if 'dontzip' in options.keys():
            dontzip = options['dontzip']
        else:
            dontzip = False

        sys.stdout = mystdout = compat_StringIO()

        Lines = self.inFile.readlines()
        for line in Lines:
            if re.match("^\s*$", line):
                continue
            if re.match("^#.*", line) or re.match("^;.*", line):
                continue
            log(self.bordered(line))
            self.cli.onecmd(line)

            output = mystdout.getvalue()
            self.outFile.write(output)
            if prt_to_screen == True:
                orig_stdout.write(output)

            mystdout.truncate(0)
            mystdout.seek(0)

        # Close File after all lines written
        self.outFile.close()
        sys.stdout = orig_stdout

        if dontzip == False:
            try:
                zipCmd = "gzip " + outFile
                os.system(zipCmd)
                log("Zipped output to \"{}.gz\"".format(outFile))
            except:
                log("Not able to zip output file so leaving as is in \"{}\"".format(outFile))
        else:
            log("Leaving output file unzipped in \"{}\"".format(outFile))

        return rc
