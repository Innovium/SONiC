#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2017
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

import shlex
import time

from testutil import bincopy
from utils.compat_util import *
from verbosity import *
from cmdmgr import Command
from ctypes import *
from ifcs_ctypes import *
from testutil import mcu
from operator import add
from itertools import *
if COMPAT_PY2:
    from exceptions import IOError

# temporary, to provide backtrace on breakage
import sys,traceback

class Mcu(Command):
    def __init__(self, cli):
        self.sub_cmds = {'read'        : self.read_cmd,
                         'write'       : self.write_cmd,
                         'load'        : self.load,
                         'run'         : self.run,
                         'stop'        : self.stop,
                         'status'      : self.status,
                         'debug'       : self.debug,
                         'meminit'     : self.meminit,
                         'dump'        : self.dump,
                         'dumplog'     : self.dumplog,
                         'reset'       : self.reset,
                         'halt'        : self.halt,
                         'sysreset'    : self.sysreset,
                         'dbgreset'    : self.dbgreset,
                         'help'        : self.help,
                         '?'           : self.help
                        }
        self.cli = cli

        super(Mcu, self).__init__()

    # ------------
    # Read command
    # ------------
    def read_cmd(self, arg_list):
        if len(arg_list) < 2:
            self.cli_error()
            return
        mcu_num  = int(arg_list[0], 0)
        addr = int(arg_list[1], 0)

        if mcu.is_unsafe(mcu_num):
            raise IOError(1, "MCU subsystem is in reset, cannot read memory")

        if len(arg_list) > 2:
            count = int(arg_list[2], 0)
        else:
            count = 1

        read_vals = mcu.read32(mcu_num, addr, count)

        # Take output 4 words at a time
        for group in compat_izip_longest(*[iter(read_vals)]*4):
            log_no_newline("0x%08x: " % (addr))
            addr += 4 * 4
            for val in group:
                 if val is not None:
                     log_no_newline("0x%08x " % (val))
            log("")

    # ------------
    # Write command
    # ------------
    def write_cmd(self, arg_list):
        mcu_num  = int(arg_list[0], 0)
        addr = int(arg_list[1], 0)

        if mcu.is_unsafe(mcu_num):
            raise IOError(1, "MCU subsystem is in reset, cannot write memory")

        val_list = compat_listmap(lambda s:int(s, 0), arg_list[2:])
        mcu.write32(mcu_num, addr, val_list)

    # ------------
    # Load command
    # ------------
    def load(self, arg_list):
        if len(arg_list) < 2:
            self.cli_error()
            return
        mcu_num  = int(arg_list[0], 0)

        mcu.load(mcu_num, arg_list[1])


    # ------------
    # Run command
    # ------------
    def run(self, arg_list):
        if len(arg_list) < 2:
            self.cli_error()
            return
        mcu_num  = int(arg_list[0], 0)

        mcu.stop(mcu_num)
        time.sleep(1.05)
        mcu.load(mcu_num, arg_list[1])
        mcu.log_start(mcu_num)
        time.sleep(0.05)
        mcu.halt_clear(mcu_num)

    # ------------
    # Stop command
    # ------------
    def stop(self, arg_list):
        if len(arg_list) < 1:
            self.cli_error()
            return
        mcu_num  = int(arg_list[0], 0)

        log("mcu stop")

        mcu.stop(mcu_num)
        time.sleep(0.05)
        mcu.log_stop(mcu_num)

    def dumplog(self, arg_list):
        if len(arg_list) < 1:
            self.cli_error()
            return
        mcu_num  = int(arg_list[0], 0)

        log("%s" % mcu.get_existing_log(mcu_num))

    # ------------
    # Debug command
    # ------------
    def debug(self, arg_list):
        if len(arg_list) < 1:
            self.cli_error()
            return
        mcu_num  = int(arg_list[0], 0)

        mcu.stop(mcu_num)
        mcu.dbgreset_clear(mcu_num)
        mcu.load(mcu_num, "mcu_fw/hold.srec")
        mcu.log_start(mcu_num)
        time.sleep(0.05)
        mcu.halt_clear(mcu_num)
        log("Ready for debug...");

    # ------------
    # Dump command
    # ------------
    def dump(self, arg_list):
        if len(arg_list) < 3:
            self.cli_error()
            return
        mcu_num  = int(arg_list[0], 0)
        addr = int(arg_list[1], 0)
        num_bytes = int(arg_list[2], 0)
        if len(arg_list) > 3:
            filename = arg_list[3]
        else:
            filename = None

        if mcu.is_unsafe(mcu_num):
            raise IOError(1, "MCU subsystem is in reset, cannot read memory")

        word_data = mcu.read32(mcu_num, addr, (num_bytes + 3) / 4)  # round up if not on a word boundary
        bytedata = bytearray()
        for word in word_data:
            bytedata.append(word & 0xff)
            bytedata.append((word >> 8)  & 0xff)
            bytedata.append((word >> 16) & 0xff)
            bytedata.append((word >> 24) & 0xff)

        # if not on a word boundary, truncate
        bytedata = bytedata[:num_bytes]

        binfile = bincopy.BinFile()
        binfile.add_binary(bytedata, addr)

        if filename is None:
            log(binfile.as_hexdump())
        else:
            newfile = open(filename, 'wb')
            if filename.lower().endswith('srec'):
                newfile.write(binfile.as_srec())
            elif filename.lower().endswith('ihex'):
                newfile.write(binfile.as_ihex())
            else:
                newfile.write(bytedata)

    # ------------
    # Reset command
    # ------------
    def reset(self, arg_list):
        if len(arg_list) < 1:
            self.cli_error()
            return
        mcu_num  = int(arg_list[0], 0)

        if len(arg_list) == 1 or arg_list[1] == 'on':
            mcu.reset_set(mcu_num)
        elif arg_list[1] == 'off':
            mcu.reset_clear(mcu_num)
        else:
            self.cli.error()

    # ------------
    # SysReset command
    # ------------
    def sysreset(self, arg_list):
        if len(arg_list) < 1:
            self.cli_error()
            return
        mcu_num  = int(arg_list[0], 0)

        if len(arg_list) == 1 or arg_list[1] == 'on':
            mcu.sysreset_set(mcu_num)
        elif arg_list[1] == 'off':
            mcu.sysreset_clear(mcu_num)
        else:
            self.cli.error()

    # ------------
    # DbgReset command
    # ------------
    def dbgreset(self, arg_list):
        if len(arg_list) < 1:
            self.cli_error()
            return
        mcu_num  = int(arg_list[0], 0)

        if len(arg_list) == 1 or arg_list[1] == 'on':
            mcu.dbgreset_set(mcu_num)
        elif arg_list[1] == 'off':
            mcu.dbgreset_clear(mcu_num)
        else:
            self.cli.error()

    # ------------
    # Halt command
    # ------------
    def halt(self, arg_list):
        if len(arg_list) < 1:
            self.cli_error()
            return
        mcu_num  = int(arg_list[0], 0)

        if len(arg_list) == 1 or arg_list[1] == 'on':
            mcu.halt_set(mcu_num)
        elif arg_list[1] == 'off':
            mcu.halt_clear(mcu_num)
        else:
            cli.error()

    # ------------
    # Status command
    # ------------
    def status(self, arg_list):
        if len(arg_list) < 1:
            self.cli_error()
            return
        mcu_num  = int(arg_list[0], 0)

        halted = mcu.halt_is_active(mcu_num)
        reset = mcu.reset_is_active(mcu_num)
        sysreset = mcu.sysreset_is_active(mcu_num)
        dbgreset = mcu.dbgreset_is_active(mcu_num)
        onoff = {True: "on", False: "off"}

        out = "Status MCU%d: " % (mcu_num)
        if sysreset or reset or halted:
            out += "SysReset %s" % (onoff[sysreset])
            out += ", Reset %s" % (onoff[reset])
            out += ", Halt %s" % (onoff[halted])
        else:
            out += "Running"

        out += ", DbgReset %s" % (onoff[dbgreset])
        log(out)

    # ------------
    # MemInit command
    # ------------
    def meminit(self, arg_list):
        if len(arg_list) < 1:
            self.cli_error()
            return
        mcu_num  = int(arg_list[0], 0)

        if mcu.is_unsafe(mcu_num):
            raise IOError(1, "MCU subsystem is in reset, cannot access memory")

        mcu.write64(mcu_num, 0x00000000, [0x0000000000000000] * 32 * 1024)
        mcu.write64(mcu_num, 0x00800000, [0x0000000000000000] * 32 * 1024)
        mcu.write64(mcu_num, 0x00840000, [0x0000000000000000] * 32 * 1024)

    # MBOX command
    # ------------
    def mbox(self, arg_list):
        if len(arg_list) < 2:
            arg_list = ['help']
        else:
            num = int(arg_list[1])
        if len(arg_list) == 2 and arg_list[0] == 'read':
            values = mcu.mbox_read(num)
            log_no_newline("MBOX %d: [" % num)
            for v in values:
                log_no_newline("0x%08x" % v)
            log("]")
        elif len(arg_list) >= 3 and arg_list[0] == 'write':
            val_list = compat_listmap(lambda s:int(s, 0), arg_list[2:])
            mcu.mbox_write(num, val_list)
        else:
            log("Usage: 'mcu mbox read <#>', 'mcu mbox write <#> <value> [<value>...]'")

    def run_cmd(self, args):
        arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(arg_list))

        try:
            return self.sub_cmds[arg_list[1]](arg_list[2:])
        except Exception as ex:
            traceback.print_exc(file=sys.stdout)
            log("run cmd: ", type(ex).__name__, ex.args)
            self.cli.error()
            self.help(args)
            return
        except:
            log_dbg(1, "Mcu error")
            self.cli.error()
            self.help(args)
        return

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def help(self, args):
        log("Usage: ")
        log("mcu read 0|1 <addr> [count]               - Read <count> words from MCU TCM")
        log("mcu write 0|1 <addr> <val1> [<val2> ...]  - Write words to MCU TCM")
        log("mcu load 0|1 <filename>                   - Load MCU TCM from SREC file")
        log("mcu run 0|1 <filename>                    - Load, then start execution")
        log("mcu stop 0|1                              - Stops MCU core with reset pulse + halt")
        log("mcu status 0|1                            - Shows status of MCU Halt & Resets")
        log("mcu debug 0|1                             - Setup the MCU for interactive debugging")
        log("mcu meminit 0|1                           - Initialize MCU TCMs")
        log("mcu reset 0|1 (on|off)                    - Set MCU core Reset state")
        log("mcu sysreset 0|1 (on|off)                 - Set MCU core SysReset state")
        log("mcu dbgreset 0|1 (on|off)                 - Set MCU core ResetDBG state")
        log("mcu halt 0|1 (on|off)                     - Set MCU core Halt state")
        log("mcu dump 0|1 <addr> <len> [filename]      - Dump <len> bytes from MCU TCM")
        log("mcu mbox 0|1 (read|write) <#> [values...] - Read or Write to mailbox")
