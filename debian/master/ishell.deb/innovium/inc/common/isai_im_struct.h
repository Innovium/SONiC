/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2016
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */
#ifndef __ISAI_IM_STRUCT_H__
#define __ISAI_IM_STRUCT_H__

/**
 * @file isai_im_struct.h
 * @brief Header file defining the IFCS data struct
 */
#include "common/im_types.h"

struct isai_ii_nmgr;

/**
 * @brief iSAI global structure
 */
typedef struct isai_ifcs_s {
    struct isai_ii_nmgr *nodes[IFCS_MAX_NODES];                    ///< iSAI Node mgr pointers
} isai_ifcs_t;

#define ISAI_IFCS    (&isai_ifcs_ds)
extern isai_ifcs_t isai_ifcs_ds;
#define _ISAI_NODE_ENTRY(node_id)    ISAI_IFCS->nodes[node_id]


#endif
