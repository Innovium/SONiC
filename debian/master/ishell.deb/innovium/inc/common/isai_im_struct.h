/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */
#ifndef __ISAI_IM_STRUCT_H__
#define __ISAI_IM_STRUCT_H__

/**
 * @file isai_im_struct.h
 * @brief Header file defining the IFCS data struct
 */
#include "common/im_types.h"
//TODO: how to mark it different than IFCS

struct isai_ii_nmgr;

/**
 * @brief iSAI global structure
 */
typedef struct isai_ifcs_s {
    struct isai_ii_nmgr *nodes[IFCS_MAX_NODES];                    ///< iSAI Node mgr pointers
} isai_ifcs_t;

#define ISAI_IFCS    (&isai_ifcs_ds)
extern isai_ifcs_t isai_ifcs_ds;
#define _ISAI_NODE_ENTRY(node_id)    ISAI_IFCS->nodes[node_id]


#endif
