/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai.h
 * @brief Definition for IFCS SAI Interface
 */


#ifndef __IFCS_IFCS_SAI_H__
#define __IFCS_IFCS_SAI_H__

#include <sai.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <syslog.h>
#include <stdarg.h>
#include <assert.h>
#include <stdio.h>
#include "ifcs_types.h"
#include "ifcs_status.h"
#include "ifcs_init.h"

/**
 * @brief All the object types
 */
typedef enum ifcs_sai_oid_e {
    IFCS_SAI_OID_TYPE_BASE                     = 0,  ///< OID type IFCS_SAI_OID_TYPE_BASE
    IFCS_SAI_OID_TYPE_ACL_TABLE                = 1,  ///< OID type IFCS_SAI_OID_TYPE_ACL_TABLE
    IFCS_SAI_OID_TYPE_ACL_ENTRY                = 2,  ///< OID type IFCS_SAI_OID_TYPE_ACL_ENTRY
    IFCS_SAI_OID_TYPE_ACL_COUNTER              = 3,  ///< OID type IFCS_SAI_OID_TYPE_ACL_COUNTER
    IFCS_SAI_OID_TYPE_ACL_RANGE                = 4,  ///< OID type IFCS_SAI_OID_TYPE_ACL_RANGE
    IFCS_SAI_OID_TYPE_ACL_TABLE_GROUP          = 5,  ///< OID type IFCS_SAI_OID_TYPE_ACL_TABLE_GROUP
    IFCS_SAI_OID_TYPE_ACL_TABLE_GROUP_MEMBER   = 6,  ///< OID type IFCS_SAI_OID_TYPE_ACL_TABLE_GROUP_MEMBER
    IFCS_SAI_OID_TYPE_BRIDGE                   = 7,  ///< OID type IFCS_SAI_OID_TYPE_BRIDGE
    IFCS_SAI_OID_TYPE_BRIDGE_PORT              = 8,  ///< OID type IFCS_SAI_OID_TYPE_BRIDGE_PORT
    IFCS_SAI_OID_TYPE_BUFFER_POOL              = 9,  ///< OID type IFCS_SAI_OID_TYPE_BUFFER_POOL
    IFCS_SAI_OID_TYPE_INGRESS_PRIORITY_GROUP   = 10, ///< OID type IFCS_SAI_OID_TYPE_INGRESS_PRIORITY_GROUP
    IFCS_SAI_OID_TYPE_BUFFER_PROFILE           = 11, ///< OID type IFCS_SAI_OID_TYPE_BUFFER_PROFILE
    IFCS_SAI_OID_TYPE_COUNTER                  = 68, ///< OID type IFCS_SAI_OID_TYPE_COUNTER
    IFCS_SAI_OID_TYPE_DEBUG_COUNTER            = 12, ///< OID type IFCS_SAI_OID_TYPE_DEBUG_COUNTER
    IFCS_SAI_OID_TYPE_FDB_ENTRY                = 13, ///< OID type IFCS_SAI_OID_TYPE_FDB_ENTRY
    IFCS_SAI_OID_TYPE_HASH                     = 14, ///< OID type IFCS_SAI_OID_TYPE_HASH
    IFCS_SAI_OID_TYPE_FINE_GRAINED_HASH_FIELD  = 15, ///< OID type IFCS_SAI_OID_TYPE_FINE_GRAINED_HASH_FIELD
    IFCS_SAI_OID_TYPE_HOSTIF                   = 16, ///< OID type IFCS_SAI_OID_TYPE_HOSTIF
    IFCS_SAI_OID_TYPE_HOSTIF_TABLE_ENTRY       = 17, ///< OID type IFCS_SAI_OID_TYPE_HOSTIF_TABLE_ENTRY
    IFCS_SAI_OID_TYPE_HOSTIF_TRAP_GROUP        = 18, ///< OID type IFCS_SAI_OID_TYPE_HOSTIF_TRAP_GROUP
    IFCS_SAI_OID_TYPE_HOSTIF_TRAP              = 19, ///< OID type IFCS_SAI_OID_TYPE_HOSTIF_TRAP
    IFCS_SAI_OID_TYPE_HOSTIF_USER_DEFINED_TRAP = 20, ///< OID type IFCS_SAI_OID_TYPE_HOSTIF_USER_DEFINED_TRAP
    IFCS_SAI_OID_TYPE_HOSTIF_PACKET            = 21, ///< OID type IFCS_SAI_OID_TYPE_HOSTIF_PACKET
    IFCS_SAI_OID_TYPE_IPMC_ENTRY               = 22, ///< OID type IFCS_SAI_OID_TYPE_IPMC_ENTRY
    IFCS_SAI_OID_TYPE_IPMC_GROUP               = 23, ///< OID type IFCS_SAI_OID_TYPE_IPMC_GROUP
    IFCS_SAI_OID_TYPE_IPMC_GROUP_MEMBER        = 24, ///< OID type IFCS_SAI_OID_TYPE_IPMC_GROUP_MEMBER
    IFCS_SAI_OID_TYPE_ISOLATION_GROUP          = 25, ///< OID type IFCS_SAI_OID_TYPE_ISOLATION_GROUP
    IFCS_SAI_OID_TYPE_ISOLATION_GROUP_MEMBER   = 26, ///< OID type IFCS_SAI_OID_TYPE_ISOLATION_GROUP_MEMBER
    IFCS_SAI_OID_TYPE_L2MC_ENTRY               = 27, ///< OID type IFCS_SAI_OID_TYPE_L2MC_ENTRY
    IFCS_SAI_OID_TYPE_L2MC_GROUP               = 28, ///< OID type IFCS_SAI_OID_TYPE_L2MC_GROUP
    IFCS_SAI_OID_TYPE_L2MC_GROUP_MEMBER        = 29, ///< OID type IFCS_SAI_OID_TYPE_L2MC_GROUP_MEMBER
    IFCS_SAI_OID_TYPE_LAG                      = 30, ///< OID type IFCS_SAI_OID_TYPE_LAG
    IFCS_SAI_OID_TYPE_LAG_MEMBER               = 31, ///< OID type IFCS_SAI_OID_TYPE_LAG_MEMBER
    IFCS_SAI_OID_TYPE_MIRROR_SESSION           = 32, ///< OID type IFCS_SAI_OID_TYPE_MIRROR_SESSION
    IFCS_SAI_OID_TYPE_MY_MAC                   = 67, ///< OID type IFCS_SAI_OID_TYPE_MY_MAC
    IFCS_SAI_OID_TYPE_NEIGHBOR_ENTRY           = 33, ///< OID type IFCS_SAI_OID_TYPE_NEIGHBOR_ENTRY
    IFCS_SAI_OID_TYPE_NEXT_HOP                 = 34, ///< OID type IFCS_SAI_OID_TYPE_NEXT_HOP
    IFCS_SAI_OID_TYPE_NEXT_HOP_GROUP           = 35, ///< OID type IFCS_SAI_OID_TYPE_NEXT_HOP_GROUP
    IFCS_SAI_OID_TYPE_NEXT_HOP_GROUP_MEMBER    = 36, ///< OID type IFCS_SAI_OID_TYPE_NEXT_HOP_GROUP_MEMBER
    IFCS_SAI_OID_TYPE_NEXT_HOP_GROUP_MAP       = 65, ///< OID type IFCS_SAI_OID_TYPE_NEXT_HOP_GROUP_MAP
    IFCS_SAI_OID_TYPE_POLICER                  = 37, ///< OID type IFCS_SAI_OID_TYPE_POLICER
    IFCS_SAI_OID_TYPE_PORT                     = 38, ///< OID type IFCS_SAI_OID_TYPE_PORT
    IFCS_SAI_OID_TYPE_PORT_POOL                = 39, ///< OID type IFCS_SAI_OID_TYPE_PORT_POOL
    IFCS_SAI_OID_TYPE_PORT_CONNECTOR           = 40, ///< OID type IFCS_SAI_OID_TYPE_PORT_CONNECTOR
    IFCS_SAI_OID_TYPE_PORT_SERDES              = 41, ///< OID type IFCS_SAI_OID_TYPE_PORT_SERDES
    IFCS_SAI_OID_TYPE_QOS_MAP                  = 42, ///< OID type IFCS_SAI_OID_TYPE_QOS_MAP
    IFCS_SAI_OID_TYPE_QUEUE                    = 43, ///< OID type IFCS_SAI_OID_TYPE_QUEUE
    IFCS_SAI_OID_TYPE_ROUTE_ENTRY              = 44, ///< OID type IFCS_SAI_OID_TYPE_ROUTE_ENTRY
    IFCS_SAI_OID_TYPE_VIRTUAL_ROUTER           = 45, ///< OID type IFCS_SAI_OID_TYPE_VIRTUAL_ROUTER
    IFCS_SAI_OID_TYPE_ROUTER_INTERFACE         = 46, ///< OID type IFCS_SAI_OID_TYPE_ROUTER_INTERFACE
    IFCS_SAI_OID_TYPE_RPF_GROUP                = 47, ///< OID type IFCS_SAI_OID_TYPE_RPF_GROUP
    IFCS_SAI_OID_TYPE_RPF_GROUP_MEMBER         = 48, ///< OID type IFCS_SAI_OID_TYPE_RPF_GROUP_MEMBER
    IFCS_SAI_OID_TYPE_SAMPLEPACKET             = 49, ///< OID type IFCS_SAI_OID_TYPE_SAMPLEPACKET
    IFCS_SAI_OID_TYPE_SCHEDULER                = 50, ///< OID type IFCS_SAI_OID_TYPE_SCHEDULER
    IFCS_SAI_OID_TYPE_SCHEDULER_GROUP          = 51, ///< OID type IFCS_SAI_OID_TYPE_SCHEDULER_GROUP
    IFCS_SAI_OID_TYPE_STP                      = 52, ///< OID type IFCS_SAI_OID_TYPE_STP
    IFCS_SAI_OID_TYPE_STP_PORT                 = 53, ///< OID type IFCS_SAI_OID_TYPE_STP_PORT
    IFCS_SAI_OID_TYPE_SWITCH                   = 54, ///< OID type IFCS_SAI_OID_TYPE_SWITCH
    IFCS_SAI_OID_TYPE_SWITCH_TUNNEL            = 66, ///< OID type IFCS_SAI_OID_TYPE_SWITCH_TUNNEL
    IFCS_SAI_OID_TYPE_TUNNEL_MAP               = 55, ///< OID type IFCS_SAI_OID_TYPE_TUNNEL_MAP
    IFCS_SAI_OID_TYPE_TUNNEL                   = 56, ///< OID type IFCS_SAI_OID_TYPE_TUNNEL
    IFCS_SAI_OID_TYPE_TUNNEL_TERM_TABLE_ENTRY  = 57, ///< OID type IFCS_SAI_OID_TYPE_TUNNEL_TERM_TABLE_ENTRY
    IFCS_SAI_OID_TYPE_TUNNEL_MAP_ENTRY         = 58, ///< OID type IFCS_SAI_OID_TYPE_TUNNEL_MAP_ENTRY
    IFCS_SAI_OID_TYPE_UDF                      = 59, ///< OID type IFCS_SAI_OID_TYPE_UDF
    IFCS_SAI_OID_TYPE_UDF_MATCH                = 60, ///< OID type IFCS_SAI_OID_TYPE_UDF_MATCH
    IFCS_SAI_OID_TYPE_UDF_GROUP                = 61, ///< OID type IFCS_SAI_OID_TYPE_UDF_GROUP
    IFCS_SAI_OID_TYPE_VLAN                     = 62, ///< OID type IFCS_SAI_OID_TYPE_VLAN
    IFCS_SAI_OID_TYPE_VLAN_MEMBER              = 63, ///< OID type IFCS_SAI_OID_TYPE_VLAN_MEMBER
    IFCS_SAI_OID_TYPE_WRED                     = 64, ///< OID type IFCS_SAI_OID_TYPE_WRED
} ifcs_sai_oid_t;


extern sai_service_method_table_t g_services;
extern bool g_initialized;
#define UNUSED(expr)    do { (void)(expr); } while (0)

typedef uint32_t ifcs_sai_bitvec_t[32];   // do this dynammically
typedef uint32_t ifcs_sai_attr_info[128]; // max number of attributes.

/* Should be the same size as sai_object_id_t */
/* Should fix for big endian vs little endian */
typedef struct ifcs_sai_oid_base_s {
    uint8_t reserved[sizeof(sai_object_id_t) - 1];
    uint8_t type;
} ifcs_sai_oid_base_t;

sai_status_t
ifcs_sai_set_bit(ifcs_sai_bitvec_t vec,
                 uint32_t          bit);

sai_status_t
ifcs_sai_clear_bit(ifcs_sai_bitvec_t vec,
                   uint32_t          bit);

bool
ifcs_sai_test_bit(ifcs_sai_bitvec_t vec,
                  uint32_t          bit);

sai_status_t
ifcs_sai_parse_attr(ifcs_sai_bitvec_t     attrs,
                    ifcs_sai_attr_info    attr_info,
                    sai_attr_id_t         max_attr_id,
                    uint32_t              attr_count,
                    const sai_attribute_t *attr_list_p);

ifcs_status_t
ifcs_sai_get_sysport_from_devport(ifcs_node_id_t node_id,
                                  uint32_t       devport,
                                  uint32_t       *sysport);

typedef sai_status_t (*sai_to_ifcs_translate_key_fn)(

    const void *sai_key,
    void       *ifcs_key);
typedef sai_status_t (*sai_to_ifcs_translate_attr_fn)(
    sai_common_api_t      api_type,
    uint32_t              attr_count,
    const sai_attribute_t *attr_list_p,
    uint32_t              *ifcs_attr_count,
    ifcs_attr_t           **ifcs_attr_list_p);
typedef sai_status_t (*sai_to_ifcs_translate_object_id_fn)(
    sai_object_id_t sai_object_id,
    ifcs_handle_t   *ifcs_handle);
typedef sai_status_t (*ifcs_to_sai_translate_attr_fn)(
    uint32_t        ifcs_attr_count,
    ifcs_attr_t     *ifcs_attr_list_p,
    uint32_t        attr_count,
    sai_attribute_t *attr_list_p);
typedef sai_status_t (*ifcs_to_sai_translate_object_id_fn)(
    ifcs_handle_t   ifcs_handle,
    sai_object_id_t *sai_object_id);

/**
 * @brief Next Hop methods table retrieved with sai_api_query()
 */
typedef struct _sai_ifcs_shim_t {
    sai_to_ifcs_translate_key_fn       sai_to_ifcs_translate_key;
    sai_to_ifcs_translate_attr_fn      sai_to_ifcs_translate_attr;
    sai_to_ifcs_translate_object_id_fn sai_to_ifcs_translate_object_id;
    ifcs_to_sai_translate_attr_fn      ifcs_to_sai_translate_attr;
    ifcs_to_sai_translate_object_id_fn ifcs_to_sai_translate_object_id;
} sai_ifcs_shim_t;

extern sai_status_t
sai_api_shim_initialize(sai_api_t       sai_api_id,
                        sai_ifcs_shim_t *shim_ptr);

extern sai_ifcs_shim_t g_sai_api_shims[SAI_API_MAX];
typedef pthread_mutex_t ifcs_sai_shim_mlock_t;
extern ifcs_sai_shim_mlock_t g_switch_creation_lock;       /// < Mutex to protect switch creation

extern const sai_acl_api_t              acl_api;
extern const sai_bridge_api_t           bridge_api;
extern const sai_buffer_api_t           buffer_api;
extern const sai_counter_api_t          counter_api;
extern const sai_debug_counter_api_t    debug_counter_api;
extern const sai_fdb_api_t              fdb_api;
extern const sai_hash_api_t             hash_api;
extern const sai_hostif_api_t           hostif_api;
extern const sai_ipmc_api_t             ipmc_api;
extern const sai_ipmc_group_api_t       ipmc_group_api;
extern const sai_isolation_group_api_t  isolation_group_api;
extern const sai_l2mc_api_t             l2mc_api;
extern const sai_l2mc_group_api_t       l2mc_group_api;
extern const sai_lag_api_t              lag_api;
extern const sai_mirror_api_t           mirror_api;
extern const sai_my_mac_api_t           my_mac_api;
extern const sai_neighbor_api_t         neighbor_api;
extern const sai_next_hop_api_t         next_hop_api;
extern const sai_next_hop_group_api_t   next_hop_group_api;
extern const sai_policer_api_t          policer_api;
extern const sai_port_api_t             port_api;
extern const sai_qos_map_api_t          qos_map_api;
extern const sai_queue_api_t            queue_api;
extern const sai_route_api_t            route_api;
extern const sai_virtual_router_api_t   virtual_router_api;
extern const sai_router_interface_api_t router_interface_api;
extern const sai_rpf_group_api_t        rpf_group_api;
extern const sai_samplepacket_api_t     samplepacket_api;
extern const sai_scheduler_api_t        scheduler_api;
extern const sai_scheduler_group_api_t  scheduler_group_api;
extern const sai_stp_api_t              stp_api;
extern const sai_switch_api_t           switch_api;
extern const sai_tunnel_api_t           tunnel_api;
extern const sai_udf_api_t              udf_api;
extern const sai_vlan_api_t             vlan_api;
extern const sai_wred_api_t             wred_api;

/*
 * @brief Converts SAI key to IFCS key
 *
 * @param [in]  sai_api_id - SAI api ID
 * @param [in]  sai_key    - SAI Key
 * @param [out] ifcs_key   - IFCS key
 * @return sai_status_t
 */

sai_status_t
sai_to_ifcs_translate_key(sai_api_t  sai_api_id,
                          const void *sai_key,
                          void       *ifcs_key);

/*
 * @brief Converts SAI attr to IFCS attr
 *
 * @param [in]  sai_api_id       - SAI api ID
 * @param [in]  attr_count       - SAI Attr count
 * @param [in]  attr_list_p      - SAI Attr pointer
 * @param [out] ifcs_attr_count  - IFCS attr count
 * @param [out] ifcs_attr_list_p - IFCS attr list
 * @return sai_status_t
 */

sai_status_t
sai_to_ifcs_translate_attr(sai_api_t             sai_api_id,
                           sai_common_api_t      api_type,
                           uint32_t              attr_count,
                           const sai_attribute_t *attr_list_p,
                           uint32_t              *ifcs_attr_count,
                           ifcs_attr_t           **ifcs_attr_list_p);

/*
 * @brief Converts SAI object_id to ifcs handle
 *
 * @param [in]  sai_api_id    - SAI api ID
 * @param [in]  sai_object_id - SAI Object_id
 * @param [out] ifcs_handle   - ifcs handle
 * @return sai_status_t
 */

sai_status_t
sai_to_ifcs_translate_object_id(sai_api_t       sai_api_id,
                                sai_object_id_t sai_object_id,
                                ifcs_handle_t   *ifcs_handle);

/*
 * @brief Converts SAI attr to IFCS attr
 *
 * @param [in]  sai_api_id        - SAI api ID
 * @param [in]  ifcs_attr_count   - IFCS Attr count
 * @param [in]  ifcs_attr_list_p  - IFCS Attr pointer
 * @param [out] attr_count        - SAI attr count
 * @param [out] attr_list_p       - SAI attr list
 * @return sai_status_t
 */

sai_status_t
ifcs_to_sai_translate_attr(sai_api_t       sai_api_id,
                           uint32_t        ifcs_attr_count,
                           ifcs_attr_t     *ifcs_attr_list_p,
                           uint32_t        attr_count,
                           sai_attribute_t *attr_list_p);

/*
 * @brief Converts SAI object_id to ifcs handle
 *
 * @param [in] sai_api_id  - SAI api ID
 * @param [in] ifcs_handle - Ifcs Handle
 * @param [out] object_id  - SAI object_id
 * @return sai_status_t
 */

sai_status_t
ifcs_to_sai_translate_object_id(sai_api_t       sai_api_id,
                                ifcs_handle_t   ifcs_handle,
                                sai_object_id_t *object_id);

/*
 * @brief Converts IFCS status to SAI status
 *
 * @param [in] ifcs_status - Ifcs status
 * @param [out] sai_status - SAI status
 * return sai_status_t
 */
sai_status_t
ifcs_to_sai_translate_status(ifcs_status_t ifcs_status);
sai_status_t
sai_api_shim_init(void);

#endif /* __IFCS_IFCS_SAI_H__ */
