/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_hostif_util.h
 * @brief util for ifcs sai module host_interface
 */


#if !defined (__IFCS_SAI_HOSTIF_UTIL_H_)
#define __IFCS_SAI_HOSTIF_UTIL_H_

#include "ifcs_sai_hostif_util_dep.h"

/*
 * @brief Returns whether a given object id of a user defined trap
 *
 * @param [in] oid_p - Pointer to SAI object ID
 * @return ifcs_handle_t
 */
bool
isai_im_hostif_user_defined_trap_is_oid(const sai_object_id_t *const oid_p);



sai_status_t
isai_im_hostif_init(ifcs_node_id_t         node_id,
                    sai_switch_init_info_t *sai_switch_init_info_p);

sai_status_t
isai_im_hostif_deinit(ifcs_node_id_t           node_id,
                      sai_switch_deinit_info_t *sai_switch_deinit_info_p);

sai_status_t
isai_im_hostif_register_rx_callback(ifcs_node_id_t node_id);

ifcs_handle_t
isai_im_hostif_get_acl_table(ifcs_node_id_t node_id);

sai_status_t
isai_im_hostif_set_hostif_trap_group(ifcs_node_id_t        node_id,
                                     sai_object_id_t       trap_group_oid,
                                     const sai_attribute_t *attr_list_p);

/**
 * Get IB for the monitor/DCDP based on the bind object of type TRAP
 * As of not used only for samplepacket trap, but can be extended to any
 * trap in future
 */
sai_status_t
isai_im_hostif_get_trap_monitor_ib(ifcs_node_id_t  node_id,
                                   sai_object_id_t trap_oid,
                                   uint8_t         *ib_p);

sai_status_t
isai_im_hostif_user_defined_trap_get_info(
    ifcs_node_id_t                                node_id,
    sai_object_id_t                               udt_oid,
    ifcs_sai_shim_hostif_user_defined_trap_info_t *udt_info_p);


sai_status_t
isai_im_hostif_user_defined_trap_dec_ref_cnt(ifcs_node_id_t  node_id,
                                             sai_object_id_t udt_oid);


sai_status_t
isai_im_hostif_user_defined_trap_inc_ref_cnt(ifcs_node_id_t  node_id,
                                             sai_object_id_t udt_oid);
sai_status_t
isai_im_hostif_fdb_miss_packet_action_get(
    sai_object_id_t         switch_oid,
    sai_shim_fdb_pkt_type_t pkt_type,
    sai_packet_action_t     *action);

sai_status_t
isai_im_hostif_fdb_miss_packet_action_set(
    sai_object_id_t         switch_oid,
    sai_shim_fdb_pkt_type_t pkt_type,
    sai_packet_action_t     action);

sai_status_t
isai_im_hostif_get_ifcs_trap_for_ip2me(ifcs_node_id_t node_id,
                                       ifcs_handle_t  *trap_handle_p);

sai_status_t
isai_im_hostif_get_netdev_vlan_tag_action(ifcs_node_id_t  node_id,
                                          sai_object_id_t port_oid,
                                          uint32_t        *vlan_tag_action_p);

sai_status_t
isai_im_hostif_set_netdev_vlan_tag_action(ifcs_node_id_t  node_id,
                                          sai_object_id_t port_oid,
                                          uint32_t        vlan_tag_action);


sai_status_t
isai_im_hostif_trap_group_policer_get_stats(
    sai_object_id_t             trap_group_oid,
    uint32_t                    number_of_counters,
    ifcs_acl_counter_stats_id_t *ifcs_counter_ids_p,
    uint64_t                    *ifcs_counters_p);

sai_status_t
isai_im_hostif_trap_group_policer_clear_stats(
    sai_object_id_t             trap_group_oid,
    uint32_t                    number_of_counters,
    ifcs_acl_counter_stats_id_t *ifcs_counter_ids_p);

sai_status_t
isai_im_hostif_get_udt_on_trap_group(
    ifcs_node_id_t    node_id,
    sai_object_id_t   udt_oid,
    sai_object_list_t *udt_oid_list_p);


#endif /* __IFCS_SAI_HOSTIF_UTIL_H__ */
