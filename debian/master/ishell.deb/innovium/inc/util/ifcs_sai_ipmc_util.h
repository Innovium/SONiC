/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_ipmc_util.h
 * @brief ISAI Util Include file for IPMC module
 */

#ifndef __IFCS_SAI_IPMC_UTIL_H__
#define __IFCS_SAI_IPMC_UTIL_H__

#include "util/ifcs_sai_ipmc_util_dep.h"
#include "ifcs_mcast_route.h"
#include "ifcs_hostif.h"
#include "ifcs_intf.h"
#include "ifcs_mdg.h"

/*
 * @brief Initializes IPMC module
 *
 * @param [in]  sai_switch_init_info_p   -  Pointer to init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_ipmc_init(
    sai_switch_init_info_t *sai_switch_init_info_p);

/*
 * @brief Un-initializes router interface module
 *
 * @param [in]  switch_deinit_info_p  - Pointer to de-init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_ipmc_deinit(
    sai_switch_deinit_info_t *switch_deinit_info_p);

/**
 * @brief Processes IPMC output group member creation
 *
 *
 * @param [in] ipmcg_mem_oid   - IPMC Group Member OID
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_output_mem_create(
    sai_object_id_t ipmcg_mem_oid);

/**
 * @brief Processes IPMC output group member removal
 *
 *
 * @param [in] ipmcg_mem_oid   - IPMC Group Member OID
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_output_mem_remove(
    sai_object_id_t ipmcg_mem_oid);

/**
 * @brief Processes IPMC RPF group member creation
 *
 *
 * @param [in] rpfg_mem_oid   - IPMC Group Member OID
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_rpf_mem_create(
    sai_object_id_t rpfg_mem_oid);

/**
 * @brief Processes IPMC RPF group member removal
 *
 *
 * @param [in] rpfg_mem_oid   - IPMC RPF Group Member OID
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_rpf_mem_remove(
    sai_object_id_t rpfg_mem_oid);

/**
 * @brief Processes IPMC VLAN member creation
 *
 *
 * @param [in] vlan_mem_oid   - VLAN Member OID
 * @param [in] port_hdl       - VLAN Member Port Handle
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_vlan_mem_create(
    sai_object_id_t vlan_mem_oid,
    ifcs_handle_t   port_hdl);

/**
 * @brief Processes IPMC VLAN member removal
 *
 *
 * @param [in] vlan_mem_oid   - IPMC Group Member OID
 * @param [in] port_hdl       - VLAN Member Port Handle
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_vlan_mem_remove(
    sai_object_id_t vlan_mem_oid,
    ifcs_handle_t   port_hdl);

#endif /* __IFCS_SAI_IPMC_UTIL_H__ */
