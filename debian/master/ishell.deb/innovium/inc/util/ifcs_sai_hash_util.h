/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_hash_util.h
 * @brief ISAI Util Include file for HASH module
 */


#ifndef __IFCS_SAI_HASH_UTIL_H__
#define __IFCS_SAI_HASH_UTIL_H__

#include "util/ifcs_sai_hash_util_dep.h"


/*
 * @brief Get IFCS extended field list handles from HASH DS Entry
 *
 * @param [in] switch_id      - Switch object id
 * @param [in] attr_p         - Pointer to switch hash attribute
 * @param [in] ifcs_hdl_p     - Pointer to EFL IFCS handles
 * @return sai_status_t
 */
sai_status_t
isai_im_hash_get_efl_from_ds_entry(sai_object_id_t switch_id,
                                   sai_attribute_t *attr_p,
                                   ifcs_handle_t   *ifcs_hdl_p);


/*
 * @brief Set IFCS extended field list handles in HASH DS entry
 *
 * @param [in] switch_id      - Switch object id
 * @param [in] attr_p         - Pointer to switch hash attribute
 * @param [in] ifcs_handle_p  - Pointer to EFL IFCS handles
 * @return sai_status_t
 */
sai_status_t
isai_im_hash_set_efl_in_ds_entry(sai_object_id_t switch_id,
                                 sai_attribute_t *attr_p,
                                 ifcs_handle_t   *ifcs_hdl_p);



/*
 * @brief Create extended field list in IFCS from HASH DS entry
 *
 * @param [in] switch_id      - Switch object id
 * @param [in] attr_p         - Pointer to switch hash attribute
 * @param [out] ifcs_hdl_p    - Pointer to ifcs_handles
 * @return sai_status_t
 */
sai_status_t
isai_im_hash_create_efl_from_ds_entry(sai_object_id_t switch_id,
                                      sai_attribute_t *attr_p,
                                      ifcs_handle_t   *ifcs_hdl_p);

/**
 * @brief Delete extended field list from IFCS and update HASH DS Entry
 *
 * @param [in] switch_id      - Switch object id
 * @param [in] attr_p         - Pointer to switch hash attribute
 * @param [out] ifcs_hdl_p    - Pointer to ifcs_handles
 * @return sai_status_t
 */
sai_status_t
isai_im_hash_delete_efl_from_ifcs(sai_object_id_t switch_id,
                                  sai_attribute_t *attr_p,
                                  ifcs_handle_t   *ifcs_hdl_p);


#endif /* __IFCS_SAI_HASH_UTIL_H__ */
