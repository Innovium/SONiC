/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_ars_util.h
 * @brief ISAI Util Include file for ARS module
 */


#ifndef __IFCS_SAI_ARS_UTIL_H__
#define __IFCS_SAI_ARS_UTIL_H__

#include "util/ifcs_sai_ars_util_dep.h"

/**
 * @brief Initializes ARS module
 *
 * @param [in]  sai_switch_init_info_p   - Pointer to swith init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_ars_init(sai_switch_init_info_t *sai_switch_init_info_p);


/**
 * @brief Un-initializes ARS module
 *
 * @param [in]  switch_deinit_info_p   - Pointer to switch de-init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_ars_deinit(sai_switch_deinit_info_t *switch_deinit_info_p);

/**
 * @brief Retrieves the ARS handle for a given node and ARS object ID.
 *
 * @param node_id The ID of the node.
 * @param ars_oid The object ID of the ARS.
 * @param ars_handle_p Pointer to the ARS handle to be retrieved.
 * @return sai_status_t
 */
sai_status_t
isai_im_ars_get_ars_handle(ifcs_node_id_t node_id,
                           sai_object_id_t ars_oid,
                           ifcs_handle_t   *ars_handle_p);

/**
 * @brief Increments the reference count of the ARS handle for a given node.
 *
 * @param node_id The ID of the node.
 * @param ars_handle The ARS handle to be incremented.
 * @return sai_status_t
 */
sai_status_t
isai_im_ars_increment_ars_ref_count(ifcs_node_id_t node_id,
                                    sai_object_id_t ars_handle);

/**
 * @brief Decrements the reference count of the ARS handle for a given node.
 *
 * @param node_id The ID of the node.
 * @param ars_handle The ARS handle to be incremented.
 * @return sai_status_t
 */
sai_status_t
isai_im_ars_decrement_ars_ref_count(ifcs_node_id_t node_id,
                                    sai_object_id_t ars_handle);
// SAITL-4287
// sai_status_t
// isai_im_ars_get_total_count(ifcs_node_id_t node_id,
//                             uint32_t *total_count_p);

#endif /* __IFCS_SAI_ARS_UTIL_H__ */