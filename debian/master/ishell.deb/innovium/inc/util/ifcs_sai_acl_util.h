/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_acl_util.h
 * @brief ISAI Util Include file for ACL module
 */


#ifndef __IFCS_SAI_ACL_UTIL_H__
#define __IFCS_SAI_ACL_UTIL_H__

#include "util/ifcs_sai_acl_util_dep.h"
#include "ifcs_acl.h"



extern pkt_action_stoi_acl_action_t acl_pktaction_arr[];

/**
 * @brief De-initializes acl
 *
 * @return void
 */
sai_status_t
isai_im_acl_deinit(sai_switch_deinit_info_t *switch_deinit_info_p);

/**
 * @brief Initializes acl module
 *
 * @return sai_status_t
 */
sai_status_t
isai_im_acl_init(sai_switch_init_info_t *sai_switch_init_info_p);

/*
 * @brief Set the Ingress ACL table/group
 *
 * @param [in]     bind_oid   - SAI port/vlan/lag/rif object ID
 * @param [in] attr_p         - attribute containing ACL tbl oid
 * @return sai_status_t
 */
sai_status_t
isai_im_acl_ingress_acl_set(sai_object_id_t       bind_oid,
                            const sai_attribute_t *attr_p);

/*
 * @brief Get the Ingress ACL table/group
 *
 * @param [in]     bind_oid   - SAI port/vlan/lag/rif object ID
 * @param [in]     is_ingress - true if ingress
 * @param [in,out] attr_p     - switch attribute containing ACL tbl oid
 * @return sai_status_t
 */
sai_status_t
isai_im_acl_ingress_acl_get(sai_object_id_t bind_oid,
                            sai_attribute_t *attr_p);

/*
 * @brief Set the egress ACL table/group
 *
 * @param [in]     bind_oid   - SAI port/vlan/lag/rif object ID
 * @return sai_status_t
 */
sai_status_t
isai_im_acl_egress_acl_set(sai_object_id_t       bind_oid,
                           const sai_attribute_t *attr_p);

/*
 * @brief Get the egress ACL table/group
 *
 * @param [in]     bind_oid   - SAI port/vlan/lag/rif object ID
 * @param [in]     is_egress - true if egress
 * @param [in,out] attr_p     - switch attribute containing ACL tbl oid
 * @return sai_status_t
 */
sai_status_t
isai_im_acl_egress_acl_get(sai_object_id_t bind_oid,
                           sai_attribute_t *attr_p);

/*
 * Helper function to get the value an action attribute given ACE's
 * action set, interested action type and action attribute.
 * The value associated with the action (value/object) is returned
 * to the caller.
 * If the interested action type is not part of the ACE's action set
 * 'found' is returned as False.
 */
sai_status_t
isai_im_acl_action_get_attr(ifcs_node_id_t         node_id,
                            ifcs_acl_action_type_t ifcs_action_type,
                            ifcs_handle_list_t     ace_action_set,
                            ifcs_attr_t            *ifcs_attr_p,
                            uint32_t               *index_p,
                            bool                   *found);

/*
 * @brief Extern wrapper to create IFCS ACL table.
 *
 * All ISAI users MUST call this extern wrapper instead of directly creating
 * the ACL table on IFCS. This is because 'priority' is a mandatory IFCS
 * attribute for ACL table and hardware does not allow same priority values
 * across different ACL tables. Hence this extern wrapper is defined to manage
 * the priority space. Caller is NOT supposed to fill in the 'priority'
 * attribute in the IFCS attribute list. If it is filled in, this API treats
 * it as an error. Caller is expected to allocate sufficient space in the
 * attribute list to include the priority value also.
 * This API picks the highest available priority given the direction and uses
 * that to create the ACL table.
 *
 * @param [in]  node_id  - Node idIFCS Handle
 * @param [out]  acl_table_handle_p  - ACL table handle pointerNode idIFCS Handle
 * @param [in]  attr_count  - Attr count to create ACL table.
 * @param [in]  attr_list- IFCS Attr list to create ACL table.
 *
 * @return sai_status_t
 */
sai_status_t
isai_im_acl_create_acl_table_with_prio(ifcs_node_id_t node_id,
                                       ifcs_handle_t  *acl_table_handle_p,
                                       uint32_t       ifcs_attr_count,
                                       ifcs_attr_t    *ifcs_attr_list_p);

/*
 * NOTE: This API deletes the ACE, associated match and action handles. It does
 * not check if the matches/actions are shared across other ACEs. So if they
 * are shared, then the match/action delete will fail and IFCS error will be
 * logged.
 */
sai_status_t
isai_im_acl_delete_ace(ifcs_node_id_t node_id,
                       ifcs_handle_t  ifcs_ace_handle,
                       ifcs_handle_t  ifcs_acl_handle,
                       bool           delete_counters);

/*
 * Given the IFCS ACE handle, return the list of action handles.
 */
sai_status_t
isai_im_acl_get_ace_actionset(ifcs_node_id_t     node_id,
                              ifcs_handle_t      ace_hdl,
                              ifcs_handle_list_t *ace_action_set_p);

/**
 * @brief Get the list of ACEs under an ACL.
 *
 * @param[in] node_id         - Node ID
 * @param[in] acl_handle      - IFCS acl handle
 * @param[in] ace_hdl_list_p  - Ace handle list
 * @return sai_status_t
 */
sai_status_t
isai_im_acl_get_aces(ifcs_node_id_t     node_id,
                     ifcs_handle_t      acl_handle,
                     ifcs_handle_list_t *ace_hdl_list_p);

/*
 * @brief Attach a lag member to the ACL table/group.
 *
 * Typically called by LAG shim code when a member is added to lag
 * that has already been attached earlier to ACL table/group.
 * @param [in]     node_id    - Switch id
 * @param [in]     port_hdl   - IFCS port handle
 * @param [in]     acl_table_oid  - ACL tbl oid
 * @return ifcs_status_t
 */
sai_status_t
isai_im_acl_lag_member_set(ifcs_node_id_t  node_id,
                           sai_object_id_t port_oid,
                           sai_object_id_t acl_table_oid,
                           bool            add);

/*
 * Delete a list of ACE handles.
 * This is called when an ACL entry is deleted.
 */
sai_status_t
isai_im_acl_delete_ace_hdl_list(ifcs_node_id_t     node_id,
                                ifcs_handle_list_t ace_hdl_list,
                                ifcs_handle_t      acl_table_hdl,
                                bool               delete_counters);

/*
 * @brief Check if the SAI packet action is supported by ACL action.
 *
 * This should align with the packet types of acl_pktaction_arr
 * @param [in]  sai_pktaction           - SAI packet action
 * @param [in]  acl_action_count_p      - pointer to return the ACL action count
 * @return sai_status_t
 */
sai_status_t
isai_im_acl_stoi_pkt_acl_action_check(ifcs_node_id_t      node_id,
                                      sai_packet_action_t sai_pktaction,
                                      uint8_t             *acl_action_count_p);

/*
 * Delete the ACL counters associated with the ACL table.
 * Counters could be shared across ACEs in an ACL table. For this reason,
 * the counters cannot be deleted as and when the ACEs are deleted.
 * This function is typically called after deleting and removing all the ACEs
 * from an ACL table.
 * Deleting an ACL table without deleting the associated counters will fail.
 */
sai_status_t
isai_im_acl_table_counters_delete(ifcs_node_id_t node_id,
                                  ifcs_handle_t  acl_tbl_hdl);

/*
 * Following API is called from hostif whenever:
 * (a) Trap group on the User Defined Trap has changed and the policer
 *     on old and new trap groups are different.
 * (b) Policer on a trap group has changed. So this function will be called
 *     for all the UDTs under the trap group.
 */
sai_status_t
isai_im_acl_update_user_defined_trap_policer(ifcs_node_id_t  node_id,
                                             sai_object_id_t udt_oid,
                                             sai_object_id_t policer_oid_old,
                                             sai_object_id_t policer_oid_new);

/**
 * @brief Set mirror sample_rate on IFCS sysport
 *
 * @param [in]    node_id               - node_id
 * @param [in]    sysport_hdl           - ifcs sysport handle
 * @param [in]    sample_rate           - Mirror sample_rate
 * @return sai_status_t
 */
sai_status_t
isai_im_acl_set_mirror_sample_rate_port(ifcs_node_id_t node_id,
                                        ifcs_handle_t  sysport_hdl,
                                        uint32_t       sample_rate);

sai_status_t
isai_im_acl_update_user_defined_trap_admin_state(ifcs_node_id_t  node_id,
                                                 sai_object_id_t udt_oid,
                                                 bool            admin_state);
sai_status_t
isai_im_acl_available_groups_get(sai_object_id_t switch_oid,
                                 uint32_t        *avlabl_groups);


/**
 * @brief Get stats from ACL Entries mapped to given User Defined Trap.
 *
 * @param [in]    node_id               - node_id
 * @param [in]    udt_oid           - User Defined Trap Object ID.fcs sysport handle
 * @param [in]    num_counters           - Number of counter IDs
 * @param [in]    ifcs_counter_ids_p           - List of counter IDs
 * @param [out]   ifcs_counters_p           - Return counter stats in this list
 * @return sai_status_t
 */
sai_status_t
isai_im_acl_udt_policer_get_stats(ifcs_node_id_t              node_id,
                                  sai_object_id_t             udt_oid,
                                  uint32_t                    num_counters,
                                  ifcs_acl_counter_stats_id_t *ifcs_counter_ids_p,
                                  uint64_t                    *ifcs_counters_p);

/**
 * @brief Clear stats from ACL Entries mapped to given User Defined Trap.
 *
 * @param [in]    node_id               - node_id
 * @param [in]    udt_oid           - User Defined Trap Object ID.fcs sysport handle
 * @param [in]    num_counters           - Number of counter IDs
 * @param [in]    ifcs_counter_ids_p           - List of counter IDs
 * @return sai_status_t
 */
sai_status_t
isai_im_acl_udt_policer_clear_stats(ifcs_node_id_t              node_id,
                                    sai_object_id_t             udt_oid,
                                    uint32_t                    num_counters,
                                    ifcs_acl_counter_stats_id_t *ifcs_counter_ids_p);
/**
 * @brief Get Policer stats from ACL Entry
 *
 * @param [in]    node_id               - node_id
 * @param [in]    acl_entry_oid         - ACL Entry OID
 * @param [in]    num_counters          - Number of counter IDs
 * @param [in]    ifcs_counter_ids_p    - List of counter IDs
 * @param [out]   ifcs_counters_p       - Return counter stats in this list
 * @return sai_status_t
 */
sai_status_t
isai_im_acl_entry_policer_get_stats(ifcs_node_id_t              node_id,
                              sai_object_id_t             acl_entry_oid,
                              uint32_t                    num_counters,
                              ifcs_acl_counter_stats_id_t *ifcs_counter_ids_p,
                              uint64_t                    *ifcs_counters_p);
/**
 * @brief Clear polcier stats on the  ACL Entry
 *
 * @param [in]    node_id               - node_id
 * @param [in]    acl_entry_oid         - ACL Entry OID
 * @param [in]    num_counters          - Number of counter IDs
 * @param [in]    ifcs_counter_ids_p    - List of counter IDs
 * @return sai_status_t
 */
sai_status_t
isai_im_acl_entry_policer_clear_stats(ifcs_node_id_t              node_id,
                                sai_object_id_t             acl_entry_oid,
                                uint32_t                    num_counters,
                                ifcs_acl_counter_stats_id_t *ifcs_counter_ids_p);

/**
 * @brief UDT Get ACL Table OID
 *
 * @param [in]    node_id               - node_id
 * @param [in]    udt_oid               - User Defined Trap OID
 * @param [out]   acl_table_oid_p       - Pointer to return the ACL Table OID
 * @return sai_status_t
 *
 * @details Given a User Defined Trap object (UDT), return the ACL table OID
 * that has ACL entries referencing this UDT in its action list.
 * If there are no ACL entries referencing this UDT, SAI_NULL_OBJECT_ID is
 * returned in acl_table_oid_p.
 */
sai_status_t
isai_im_acl_get_udt_acl_table(ifcs_node_id_t  node_id,
                              sai_object_id_t udt_oid,
                              sai_object_id_t *acl_table_oid_p);

/*
 * @brief Set the Pre-Ingress ACL table/group
 *
 * @param [in]     switch_oid   - switch ID
 * @param [in]     preing_oid  - OID of ACL Table/ACL Group
 * @return sai_status_t
 */
sai_status_t
isai_im_acl_preingress_switch_acl_set(sai_object_id_t switch_oid,
                                      sai_object_id_t preing_oid);

sai_status_t
isai_im_acl_mirror_set_sample_rate(ifcs_node_id_t   node_id,
                                    sai_object_id_t acl_table_oid,
                                bool            is_set,
                                sai_object_id_t mirror_oid);
/*
 * @brief Enable/Disable mirror on drop. Update all user configured ACL entries
 *      with drop/deny packet action to be sent as drop pkt to mod cpu queue
 *
 * @param [in]     node_id      -  node id
 * @param [in]     mod_acl_trap - hostif trap handle to be used to copy to
 *                                drop/deny packets to mod cpu queue
 * @param [in]     enable       -  Enable/Disable mirror on drop
 * @return sai_status_t
 */
sai_status_t
isai_im_acl_mod_enable(ifcs_node_id_t    node_id,
                       ifcs_handle_t     mod_acl_trap,
                       bool              enable);

/*
 * @brief Update ace action_set to have copy_to_cpu with given trap_hdl action
 *
 * @param [in]     node_id      -  node id
 * @param [in]     ace_hdl      - ACE handle to be updated
 * @param [in]     trap_hdl     - trap handle to be used with ctc action
 * @return sai_status_t
 */
sai_status_t
isai_im_acl_update_ace_action_with_mod_trap(ifcs_node_id_t  node_id,
                                            ifcs_handle_t   ace_hdl,
                                            ifcs_handle_t   trap_hdl);
/*
 * @brief Update ace action_set to remove copy_to_cpu with given trap_hdl action
 *
 * @param [in]     node_id      -  node id
 * @param [in]     ace_hdl      - ACE handle to be updated
 * @param [in]     pkt_action   - packet action
 * @param [in]     trap_hdl     - trap handle to be used with ctc action
 * @return sai_status_t
 */
sai_status_t
isai_im_acl_remove_ace_action_with_mod_trap(ifcs_node_id_t  node_id,
                                            ifcs_handle_t   ace_hdl,
                                            sai_packet_action_t pkt_action,
                                            ifcs_handle_t   trap_hdl);

/**
 * @brief Create ace copy packet action in ifcs with given trap handle
 *
 * @param [in]     node_id          - Node id
 * @param [in]     ap_handle        - Action profile handle
 * @param [in]     ctc_acl_trap     - Trap handle to be used with ctc action
 * @param [out]    new_action_hdl   - ifcs action handle
 * @return ifcs_status_t
 */
sai_status_t
isai_im_acl_create_copy_action(ifcs_node_id_t   node_id,
                               ifcs_handle_t    ap_handle,
                               ifcs_handle_t    ctc_acl_trap,
                               ifcs_handle_t    *new_action_hdl);
#endif /* __IFCS_SAI_ACL_UTIL_H__ */
