/*******************************************************************************
*              (c), Copyright 2020, Marvell International Ltd.                 *
* THIS CODE CONTAINS CONFIDENTIAL INFORMATION OF MARVELL SEMICONDUCTOR, INC.   *
* NO RIGHTS ARE GRANTED HEREIN UNDER ANY PATENT, MASK WORK RIGHT OR COPYRIGHT  *
* OF MARVELL OR ANY THIRD PARTY. MARVELL RESERVES THE RIGHT AT ITS SOLE        *
* DISCRETION TO REQUEST THAT THIS CODE BE IMMEDIATELY RETURNED TO MARVELL.     *
* THIS CODE IS PROVIDED "AS IS". MARVELL MAKES NO WARRANTIES, EXPRESSED,       *
* IMPLIED OR OTHERWISE, REGARDING ITS ACCURACY, COMPLETENESS OR PERFORMANCE.   *
********************************************************************************
*/

/**
 * @file  ifcs_sai_counter_util.h
 * @brief ISAI Util Include file for Counter module
 */


#ifndef __IFCS_SAI_COUNTER_UTIL_H__
#define __IFCS_SAI_COUNTER_UTIL_H__

#include "util/ifcs_sai_counter_util_dep.h"
#include "ifcs_sysport.h"

sai_status_t
isai_im_counter_init(sai_switch_init_info_t * sai_switch_init_info_p);

sai_status_t
isai_im_counter_get_flex_pool_counter(ifcs_node_id_t        node_id,
                                      sai_object_id_t       counter_oid,
                                      bool                  alloc,
                                      ifcs_handle_t         *flex_pool_counter);
sai_status_t
isai_im_counter_free_flex_pool_counter(ifcs_node_id_t    node_id,
                                       sai_object_id_t   counter_oid);
#endif /* __IFCS_SAI_COUNTER_UTIL_H__ */

