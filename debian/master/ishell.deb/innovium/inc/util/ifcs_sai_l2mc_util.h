
/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2021
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_l2mc_util.h
 * @brief ISAI Util Include file for TUNNEL module
 */


#ifndef __IFCS_SAI_L2MC_UTIL_H__
#define __IFCS_SAI_L2MC_UTIL_H__

#include "util/ifcs_sai_l2mc_util_dep.h"

#endif /* __IFCS_SAI_L2MC_UTIL_H__ */
