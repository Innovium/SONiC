/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_switch.h
 * @brief ISAI IM Include file for SWITCH module
 */


#ifndef __IFCS_SAI_SWITCH_H__
#define __IFCS_SAI_SWITCH_H__


#define ISAI_MODULE_LOCK_SWITCH    1ULL


#include "isai_im_nmgr.h"
#include "ifcs_sai_port.h"
#include "ifcs_sai_vlan.h"
#include "ifcs_sai_stp.h"
#include "ifcs_sai_router.h"
#include "ifcs_sai_routerintf.h"
#include "ifcs_sai_nexthop.h"
#include "ifcs_sai_neighbor.h"
#include "ifcs_sai_route.h"
#include "ifcs_sai_tunnel.h"
#include "ifcs_sai_bridge.h"
#include "ifcs_sai_acl.h"
#include "ifcs_sai_hostif.h"
#include "ifcs_sai_hash.h"
#include "ifcs_sai_qosmap.h"
#include "ifcs_sai_queue.h"
#include "ifcs_sai_samplepacket.h"
#include "ifcs_sai_fdb.h"
#include "ifcs_sai_buffer.h"
#include "ifcs_sai_isolation_group.h"
#include "ifcs_sai_wred.h"
#include "ifcs_sai_lag.h"
#include "ifcs_sai_mirror.h"
#include "ifcs_sai_debug_counter.h"
#include "ifcs_sai_udf.h"
#endif /* __IFCS_SAI_SWITCH_H__ */
