#!/bin/bash

#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------
export PYTHONPATH=${PYTHONPATH}:./
export PYTHONPATH=${PYTHONPATH}:cmds/
export PYTHONPATH=${PYTHONPATH}:scripts/
export PYTHONPATH=${PYTHONPATH}:utils/
export PYTHONPATH=${PYTHONPATH}:testutil/
export PYTHONPATH=${PYTHONPATH}:pyctypes/
export PYTHONPATH=${PYTHONPATH}:../pyctypes/
export PYTHONPATH=${PYTHONPATH}:isai_cmds/
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:./
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:../install/lib/
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:../lib/

# Help message
printhelp() {
    echo "Usage: $0 [-h]"
    echo "          (-r INET_PORT | -s UNIX_DOMAIN_SOCKET)"
    echo "          [-C COMMAND] [-b {2,3}] [-n]"
    echo ""
    echo "Remote Innovium CLI client"
    echo ""
    echo "One of the following arguments is required:"
    echo "  -r INET_PORT          Start Innovium CLI in remote mode (inet)"
    echo "  -s UNIX_DOMAIN_SOCKET Start Innovium CLI in remote mode (unix domain socket)"
    echo ""
    echo "Optional arguments:"
    echo "  -h                    Show this message and exit"
    echo "  -C COMMAND            Run the command and exit. Wrap command in double quotes."
    echo "  -b {2,3}              Python version (2 or 3 ). (default: 2)"
    echo "  -n                    Do not create log file"
}

# Set the environment
ENV="switch"
NOLOG=0
PYVER=2

while getopts "C:r:s:nhb:" opt; do
    case $opt in
        h)
            printhelp
            exit 1
            ;;
        r)
            PORT=$OPTARG
            ;;
        s)
            SERVER=$OPTARG
            ;;
        C)
            CMD=$OPTARG
            ;;
        n)
            NOLOG=1
            ;;
        b)
            PYVER=$OPTARG
            ;;
        \?)
            printhelp
            exit 1
            ;;
    esac
done

# User should export PATH and LD_LIBRARY_PATH to point to bin and lib, respectively
if [ $PYVER == 2 ]; then
    PYTHON=python2.7
elif [ $PYVER == 3 ]; then
    PYTHON=python3.7
else
    echo "Invalid Python version (-b) argument"
    printhelp
    exit 1
fi

# Handle user options
if [ -n "$CMD" ]; then
    if [ $PORT ]; then
       CMD="$PYTHON ifcsrshell.py -e $ENV -p $PORT -s \"$CMD\""
    elif [ $SERVER ]; then
       CMD="$PYTHON ifcsrshell.py -e $ENV -u $SERVER -s \"$CMD\""
    else
       echo "Remote port (-r) / server (-s) not provided"
       printhelp
       exit 1
    fi
else
    if [ $PORT ]; then
       CMD="$PYTHON ifcsrshell.py -e $ENV -p $PORT"
    elif [ $SERVER ]; then
       CMD="$PYTHON ifcsrshell.py -e $ENV -u $SERVER"
    else
       echo "Remote port (-r) / server (-s) not provided"
       printhelp
       exit 1
    fi
fi

if [ $NOLOG == 1 ]; then
    bash -c "$CMD"
else
    # Prepare file name
    TIMESTAMP=$(date +"%b%d%Y_%H%M%S%3N")
    FILE=ifcsrshell.$TIMESTAMP.log

    # Start the shell
    script -c "$CMD" ${FILE}

    # Handle logging
    $(cat ${FILE} >> ifcsrshell.log.bkup)
    echo "Exiting shell, backup is ifcsrshell.log.bkup"
fi
