
#-------------------------------------------------------------------------------
# * Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

from ctypes import *
from ifcs_cmds.cli_types import *
from itertools import *
from time import *
from ifcs_cmds.l3vni import *
from print_table import PrintTable
import ifcs_ctypes


def show_l3vni_extension_usage_detail_helper(l3vni):
    usage_p = ifcs_ctypes.ifcs_usage_t()
    usage_obj_p = ifcs_ctypes.ifcs_usage_obj_t()

    ifcs_ctypes.ifcs_usage_t_obj_api_class_id_set(
        pointer(usage_p), ifcs_ctypes.IFCS_USAGE_OBJ_API_CLASS_ID_L3VNI)
    usage_obj_p.l3vni = ifcs_ctypes.IFCS_USAGE_OBJ_L3VNI_DEFAULT
    ifcs_ctypes.ifcs_usage_t_obj_type_set(
        pointer(usage_p), pointer(usage_obj_p))

    rc = ifcs_ctypes.ifcs_l3vni_usage_detail_get(
           0, 0, None, pointer(usage_p))

    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to get l3vni usage. rc: {1}".format(
            convert_error_code_to_string(rc)))
        return

    table = PrintTable()
    table.add_row(["used", "max", "available"])
    table.add_row([usage_p.current, usage_p.max, \
                   usage_p.available])
    table.print_table()
    log("NOTE: Above counts include l3vnis reserved for internal use\n")
    table.reset_table()

    return

def show_l3vni_extension_usage_detail(arg1, arg2, l3vni):
    log_dbg(1, " Inside extension usage detail show")

    show_l3vni_extension_usage_detail_helper(l3vni)
    return
