
#-------------------------------------------------------------------------------
# * Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

from ctypes import *
from ifcs_cmds.cli_types import *
from itertools import *
from time import *
from ifcs_cmds.intf import *
from utils.compat_util import *
from verbosity import *
from print_table import PrintTable
import sys
from utils.compat_util import *
ifcs_ctypes = sys.modules['ifcs_ctypes']

filter_option_all = [
    'l3port_shared_txonly',
    'l3port_shared_rxonly',
    'l3port_shared_bidir',
    'svi_shared_txonly',
    'svi_shared_rxonly',
    'svi_shared_bidir',
    'l3_port_cvid_shared_txonly',
    'l3_port_cvid_shared_rxonly',
    'l3_port_cvid_shared_bidir',
    'reserved_shared_bidir',
    'ip_in_ipv4_shared_txonly',
    'ip_in_ipv4_shared_rxonly',
    'ip_in_ipv4_shared_bidir',
    'ip_in_ipv4_p2p_txonly',
    'ip_in_ipv4_p2p_rxonly',
    'ip_in_ipv4_p2p_bidir',
    'ip_in_ipv6_shared_txonly',
    'ip_in_ipv6_shared_rxonly',
    'ip_in_ipv6_shared_bidir',
    'ip_in_ipv6_p2p_txonly',
    'ip_in_ipv6_p2p_rxonly',
    'ip_in_ipv6_p2p_bidir',
    'ip_in_ipv4_gre_shared_txonly',
    'ip_in_ipv4_gre_shared_rxonly',
    'ip_in_ipv4_gre_shared_bidir',
    'ip_in_ipv4_gre_p2p_txonly',
    'ip_in_ipv4_gre_p2p_rxonly',
    'ip_in_ipv4_gre_p2p_bidir',
    'ip_in_ipv6_gre_shared_txonly',
    'ip_in_ipv6_gre_shared_rxonly',
    'ip_in_ipv6_gre_shared_bidir',
    'ip_in_ipv6_gre_p2p_txonly',
    'ip_in_ipv6_gre_p2p_rxonly',
    'ip_in_ipv6_gre_p2p_bidir',
    'ip_in_ipv4_gre_key_shared_txonly',
    'ip_in_ipv4_gre_key_shared_rxonly',
    'ip_in_ipv4_gre_key_shared_bidir',
    'ip_in_ipv4_gre_key_p2p_txonly',
    'ip_in_ipv4_gre_key_p2p_rxonly',
    'ip_in_ipv4_gre_key_p2p_bidir',
    'ip_in_ipv6_gre_key_shared_txonly',
    'ip_in_ipv6_gre_key_shared_rxonly',
    'ip_in_ipv6_gre_key_shared_bidir',
    'ip_in_ipv6_gre_key_p2p_txonly',
    'ip_in_ipv6_gre_key_p2p_rxonly',
    'ip_in_ipv6_gre_key_p2p_bidir',
    'reserved_shared_txonly',
    'l2_in_ipv4_vxlan_shared_txonly',
    'l2_in_ipv4_vxlan_shared_rxonly',
    'l2_in_ipv4_vxlan_shared_bidir',
    'l2_in_ipv4_vxlan_p2p_txonly',
    'l2_in_ipv4_vxlan_p2p_rxonly',
    'l2_in_ipv4_vxlan_p2p_bidir',
    'l2_in_ipv6_vxlan_shared_txonly',
    'l2_in_ipv6_vxlan_shared_rxonly',
    'l2_in_ipv6_vxlan_shared_bidir',
    'l2_in_ipv6_vxlan_p2p_txonly',
    'l2_in_ipv6_vxlan_p2p_rxonly',
    'l2_in_ipv6_vxlan_p2p_bidir',
    'reserved_shared_rxonly']

intf_type_dict = {
    ifcs_ctypes.IFCS_INTF_TYPE_L3PORT: "L3PORT",
    ifcs_ctypes.IFCS_INTF_TYPE_SVI: "SVI",
    ifcs_ctypes.IFCS_INTF_TYPE_L3_PORT_CVID: "L3_PORT_CVID",
    ifcs_ctypes.IFCS_INTF_TYPE_IP_IN_IPV4: "IP_IN_IPV4",
    ifcs_ctypes.IFCS_INTF_TYPE_IP_IN_IPV6: "IP_IN_IPV6",
    ifcs_ctypes.IFCS_INTF_TYPE_IP_IN_IPV4_GRE: "IP_IN_IPV4_GRE",
    ifcs_ctypes.IFCS_INTF_TYPE_IP_IN_IPV6_GRE: "IP_IN_IPV6_GRE",
    ifcs_ctypes.IFCS_INTF_TYPE_IP_IN_IPV4_GRE_KEY: "IP_IN_IPV4_GRE_KEY",
    ifcs_ctypes.IFCS_INTF_TYPE_IP_IN_IPV6_GRE_KEY: "IP_IN_IPV6_GRE_KEY",
    ifcs_ctypes.IFCS_INTF_TYPE_L2_IN_IPV4_VXLAN: "L2_IN_IPV4_VXLAN",
    ifcs_ctypes.IFCS_INTF_TYPE_L2_IN_IPV6_VXLAN: "L2_IN_IPV6_VXLAN",
}

intf_mode_dict = {
    ifcs_ctypes.IFCS_INTF_MODE_SHARED: "SHARED",
    ifcs_ctypes.IFCS_INTF_MODE_P2P: "P2P",
}

intf_dir_dict = {
    ifcs_ctypes.IFCS_INTF_DIRECTION_BIDIR: "BIDIR",
    ifcs_ctypes.IFCS_INTF_DIRECTION_TXONLY: "TXONLY",
    ifcs_ctypes.IFCS_INTF_DIRECTION_RXONLY: "RXONLY",
}

intf_tier_dict = {
    ifcs_ctypes.IFCS_USAGE_OBJ_INTF_DEFAULT: "",
    ifcs_ctypes.IFCS_USAGE_OBJ_INTF_NON_TUNNEL: "Non-Tunnel",
    ifcs_ctypes.IFCS_USAGE_OBJ_INTF_TUNNEL_L3: "L3 Tunnel",
    ifcs_ctypes.IFCS_USAGE_OBJ_INTF_TUNNEL_L2: "L2 Tunnel",
}


def show_intf_extension_usage_detail_helper(filter_option):

    if filter_option not in filter_option_all:
        log_err("Invalid filter option {0}". format(filter_option))
        return

    # Default direction is BIDIR
    if 'txonly' in filter_option:
        intf_dir_val = ifcs_ctypes.IFCS_INTF_DIRECTION_TXONLY
    elif 'rxonly' in filter_option:
        intf_dir_val = ifcs_ctypes.IFCS_INTF_DIRECTION_RXONLY
    else:
        intf_dir_val = ifcs_ctypes.IFCS_INTF_DIRECTION_BIDIR

    # Default mode is SHARED
    if 'p2p' in filter_option:
        intf_mode_val = ifcs_ctypes.IFCS_INTF_MODE_P2P
    else:
        intf_mode_val = ifcs_ctypes.IFCS_INTF_MODE_SHARED

    if 'l3_port_cvid' in filter_option:
        intf_type_val = ifcs_ctypes.IFCS_INTF_TYPE_L3_PORT_CVID
    elif 'l3port' in filter_option:
        intf_type_val = ifcs_ctypes.IFCS_INTF_TYPE_L3PORT
    elif 'svi' in filter_option:
        intf_type_val = ifcs_ctypes.IFCS_INTF_TYPE_SVI
    elif 'ipv4_gre_key' in filter_option:
        intf_type_val = ifcs_ctypes.IFCS_INTF_TYPE_IP_IN_IPV4_GRE_KEY
    elif 'ipv4_gre' in filter_option:
        intf_type_val = ifcs_ctypes.IFCS_INTF_TYPE_IP_IN_IPV4_GRE
    elif 'ipv4_vxlan' in filter_option:
        intf_type_val = ifcs_ctypes.IFCS_INTF_TYPE_L2_IN_IPV4_VXLAN
    elif 'ipv4' in filter_option:
        intf_type_val = ifcs_ctypes.IFCS_INTF_TYPE_IP_IN_IPV4
    elif 'ipv6_gre_key' in filter_option:
        intf_type_val = ifcs_ctypes.IFCS_INTF_TYPE_IP_IN_IPV6_GRE_KEY
    elif 'ipv6_gre' in filter_option:
        intf_type_val = ifcs_ctypes.IFCS_INTF_TYPE_IP_IN_IPV6_GRE
    elif 'ipv6_vxlan' in filter_option:
        intf_type_val = ifcs_ctypes.IFCS_INTF_TYPE_L2_IN_IPV6_VXLAN
    elif 'ipv6' in filter_option:
        intf_type_val = ifcs_ctypes.IFCS_INTF_TYPE_IP_IN_IPV6
    elif 'reserved' in filter_option:
        intf_type_val = ifcs_ctypes.IFCS_INTF_TYPE_MAX

    attr_count = 0
    num_attr = 3
    attr_list = (ifcs_ctypes.ifcs_attr_t * num_attr)()
    usage_p = ifcs_ctypes.ifcs_usage_t()
    usage_obj_p = ifcs_ctypes.ifcs_usage_obj_t()

    ifcs_ctypes.ifcs_attr_t_id_set(
        compat_pointerAtIndex(
            attr_list,
            ifcs_ctypes.ifcs_attr_t,
            attr_count),
        ifcs_ctypes.IFCS_INTF_ATTR_TYPE)
    ifcs_ctypes.ifcs_attr_t_value_u32_set(
        compat_pointerAtIndex(
            attr_list,
            ifcs_ctypes.ifcs_attr_t,
            attr_count),
        intf_type_val)
    attr_count += 1

    ifcs_ctypes.ifcs_attr_t_id_set(
        compat_pointerAtIndex(
            attr_list,
            ifcs_ctypes.ifcs_attr_t,
            attr_count),
        ifcs_ctypes.IFCS_INTF_ATTR_DIRECTION)
    ifcs_ctypes.ifcs_attr_t_value_u32_set(
        compat_pointerAtIndex(
            attr_list,
            ifcs_ctypes.ifcs_attr_t,
            attr_count),
        intf_dir_val)
    attr_count += 1

    ifcs_ctypes.ifcs_attr_t_id_set(
        compat_pointerAtIndex(
            attr_list,
            ifcs_ctypes.ifcs_attr_t,
            attr_count),
        ifcs_ctypes.IFCS_INTF_ATTR_MODE)
    ifcs_ctypes.ifcs_attr_t_value_u32_set(
        compat_pointerAtIndex(
            attr_list,
            ifcs_ctypes.ifcs_attr_t,
            attr_count),
        intf_mode_val)
    attr_count += 1

    ifcs_ctypes.ifcs_usage_t_obj_api_class_id_set(
        pointer(usage_p), ifcs_ctypes.IFCS_USAGE_OBJ_API_CLASS_ID_INTF)
    usage_obj_p.intf = ifcs_ctypes.IFCS_USAGE_OBJ_INTF_DEFAULT
    ifcs_ctypes.ifcs_usage_t_obj_type_set(
        pointer(usage_p), pointer(usage_obj_p))

    rc = ifcs_ctypes.ifcs_intf_usage_detail_get(
        0, attr_count, attr_list, pointer(usage_p))

    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to get {0} intf usage rc: {1}".format(
            filter_option, convert_error_code_to_string(rc)))
        return

    row = {}
    if intf_type_val != ifcs_ctypes.IFCS_INTF_TYPE_MAX:
        row['type'] = intf_type_dict[intf_type_val]
        row['mode'] = intf_mode_dict[intf_mode_val]
        row['dir'] = intf_dir_dict[intf_dir_val]
    else:
        if intf_dir_val == ifcs_ctypes.IFCS_INTF_DIRECTION_BIDIR:
            row['type'] = "RESERVED NON_TUNNEL"
        if intf_dir_val == ifcs_ctypes.IFCS_INTF_DIRECTION_TXONLY:
            row['type'] = "RESERVED TUNNEL_L3"
        if intf_dir_val == ifcs_ctypes.IFCS_INTF_DIRECTION_RXONLY:
            row['type'] = "RESERVED TUNNEL_L2"
        row['mode'] = ""
        row['dir'] = ""

    row['max'] = usage_p.max
    row['current'] = usage_p.current

    return row


def process_add_row(filter_option, row, table1, nz):

    if (nz == True and row['current'] > 0) or nz == False:
        table1.add_row([row['type'], row['mode'], row['dir'], row['current']])

    return


def get_intf_summary_table():

    usage_p = (ifcs_ctypes.ifcs_usage_t * 3)()
    obj = (ifcs_ctypes.ifcs_usage_obj_t * 3)()

    ifcs_ctypes.ifcs_usage_t_obj_api_class_id_set(
        compat_pointerAtIndex(
            usage_p,
            ifcs_ctypes.ifcs_usage_t,
            0),
        ifcs_ctypes.IFCS_USAGE_OBJ_API_CLASS_ID_INTF)
    obj[0].intf = ifcs_ctypes.IFCS_USAGE_OBJ_INTF_NON_TUNNEL
    ifcs_ctypes.ifcs_usage_t_obj_type_set(
        compat_pointerAtIndex(
            usage_p, ifcs_ctypes.ifcs_usage_t, 0), compat_pointerAtIndex(
            obj, ifcs_ctypes.ifcs_usage_obj_t, 0))
    rc = ifcs_ctypes.ifcs_intf_usage_detail_get(
        0, 0, None, compat_pointerAtIndex(
            usage_p, ifcs_ctypes.ifcs_usage_t, 0))
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to get {0} intf usage rc: {1}".format(
            filter_option, convert_error_code_to_string(rc)))
        return

    ifcs_ctypes.ifcs_usage_t_obj_api_class_id_set(
        compat_pointerAtIndex(
            usage_p,
            ifcs_ctypes.ifcs_usage_t,
            1),
        ifcs_ctypes.IFCS_USAGE_OBJ_API_CLASS_ID_INTF)
    obj[1].intf = ifcs_ctypes.IFCS_USAGE_OBJ_INTF_TUNNEL_L3
    ifcs_ctypes.ifcs_usage_t_obj_type_set(
        compat_pointerAtIndex(
            usage_p, ifcs_ctypes.ifcs_usage_t, 1), compat_pointerAtIndex(
            obj, ifcs_ctypes.ifcs_usage_obj_t, 1))
    rc = ifcs_ctypes.ifcs_intf_usage_detail_get(
        0, 0, None, compat_pointerAtIndex(
            usage_p, ifcs_ctypes.ifcs_usage_t, 1))
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to get {0} intf usage rc: {1}".format(
            filter_option, convert_error_code_to_string(rc)))
        return

    ifcs_ctypes.ifcs_usage_t_obj_api_class_id_set(
        compat_pointerAtIndex(
            usage_p,
            ifcs_ctypes.ifcs_usage_t,
            2),
        ifcs_ctypes.IFCS_USAGE_OBJ_API_CLASS_ID_INTF)
    obj[2].intf = ifcs_ctypes.IFCS_USAGE_OBJ_INTF_TUNNEL_L2
    ifcs_ctypes.ifcs_usage_t_obj_type_set(
        compat_pointerAtIndex(
            usage_p, ifcs_ctypes.ifcs_usage_t, 2), compat_pointerAtIndex(
            obj, ifcs_ctypes.ifcs_usage_obj_t, 2))
    rc = ifcs_ctypes.ifcs_intf_usage_detail_get(
        0, 0, None, compat_pointerAtIndex(
            usage_p, ifcs_ctypes.ifcs_usage_t, 2))
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to get {0} intf usage rc: {1}".format(
            filter_option, convert_error_code_to_string(rc)))
        return

    table = PrintTable()
    table.add_row(["intf space", "used", "max", "available"])
    table.add_row([intf_tier_dict[obj[0].intf], usage_p[0].current,
                   usage_p[0].max, usage_p[0].max - usage_p[0].current])
    table.add_row([intf_tier_dict[obj[1].intf], usage_p[1].current,
                   usage_p[1].max, usage_p[1].max - usage_p[1].current])
    table.add_row([intf_tier_dict[obj[2].intf], usage_p[2].current,
                   usage_p[2].max, usage_p[2].max - usage_p[2].current])

    return table


def get_ip_summary_table(ip_str):

    usage_p = ifcs_ctypes.ifcs_usage_t()
    obj = ifcs_ctypes.ifcs_usage_obj_t()

    ifcs_ctypes.ifcs_usage_t_obj_api_class_id_set(
        pointer(usage_p), ifcs_ctypes.IFCS_USAGE_OBJ_API_CLASS_ID_INTF)

    if 'sip' in ip_str:
        obj.intf = ifcs_ctypes.IFCS_USAGE_OBJ_INTF_SIP
    elif 'dip' in ip_str:
        obj.intf = ifcs_ctypes.IFCS_USAGE_OBJ_INTF_DIP
    else:
        log_err("Input string {0} is invalid".format(ip_str))
        return

    ifcs_ctypes.ifcs_usage_t_obj_type_set(pointer(usage_p), pointer(obj))
    rc = ifcs_ctypes.ifcs_intf_usage_detail_get(0, 0, None, pointer(usage_p))
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to get {0} intf usage rc: {1}".format(
            filter_option, convert_error_code_to_string(rc)))
        return

    table = PrintTable()
    table.add_row(["IP addr space", "used", "max"])

    if 'sip' in ip_str:
        table.add_row(["Tunnel SIP", usage_p.current, usage_p.max])
    elif 'dip' in ip_str:
        table.add_row(["Tunnel DIP", usage_p.current, usage_p.max])

    return table


def print_tables(
        table_intf,
        table_intf_summary,
        table_sip_summary,
        table_dip_summary,
        intf_total):
    log("Total intf count: {0}".format(intf_total))
    table_intf.print_table(brief=True)
    log("Total intf count: {0}\n".format(intf_total))
    table_intf_summary.print_table(brief=True)
    log("NOTE: interface counts include interfaces reserved for internal use\n")
    table_sip_summary.print_table(brief=True)
    log("NOTE: v6 SIP entries use 4 slots, v4 SIP entries use 1 slot\n")
    table_dip_summary.print_table(brief=True)
    log("NOTE: v6 DIP entries use 2 slots, v4 DIP entries use 1 slot\n")

    table_intf.reset_table()
    table_intf_summary.reset_table()
    table_sip_summary.reset_table()
    table_dip_summary.reset_table()
    return


def show_intf_extension_usage_detail(arg1, arg2, intf):
    log_dbg(1, " Inside extension usage detail show")
    table = PrintTable()
    table.add_row(["type", "mode", "direction", "count"])
    total = 0
    if intf.filter_option == {}:
        for filter_option in filter_option_all:
            row = show_intf_extension_usage_detail_helper(filter_option)
            process_add_row(filter_option, row, table, False)
            total += row['current']
        table2 = get_intf_summary_table()
        table3 = get_ip_summary_table("sip")
        table4 = get_ip_summary_table("dip")
        print_tables(table, table2, table3, table4, total)

    else:
        filter_option = (intf.filter_option['filter']).strip()
        if filter_option == 'nz':
            for nz_filter_option in filter_option_all:
                row = show_intf_extension_usage_detail_helper(nz_filter_option)
                process_add_row(nz_filter_option, row, table, True)
                total += row['current']
            table2 = get_intf_summary_table()
            table3 = get_ip_summary_table("sip")
            table4 = get_ip_summary_table("dip")
            print_tables(table, table2, table3, table4, total)
        else:
            row = show_intf_extension_usage_detail_helper(filter_option)
            table.add_row([row['type'], row['mode'],
                           row['dir'], row['current']])
            table.print_table(brief=True)
            log("NOTE: interface counts include interfaces reserved for internal use\n")
            table.reset_table()

    return
