
#-------------------------------------------------------------------------------
# * Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
# *-----------------------------------------------------------------------------

import copy
import socket
import struct
from ctypes import *
from ifcs_cmds.cli_types import *
from itertools import *
from time import *
from utils.compat_util import *
from verbosity import log
from ifcs_cmds.l2_entry import *
from print_table import PrintTable
from utils.mac_util import mac_addr_to_str
import sys
ifcs_ctypes=sys.modules['ifcs_ctypes']

key_type_dict = {
    ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI : "mac_l2vni",
    ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_IP_SG_L2VNI : "ip_sg_l2vni",
    ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_IP_STARG_L2VNI : "ip_starg_l2vni",
    ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_ONLY : "mac_only",
    ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2IIF_L2VNI_ID : "mac_l2iif_l2vni_id",
}

def get_mac_addr_from_l2_entry(l2_entry):
    if l2_entry.contents.key_type == ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_ONLY:
        return (mac_addr_to_str(l2_entry.contents.key.mac_only.mac_addr))
    elif l2_entry.contents.key_type == ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2IIF_L2VNI_ID:
        return (mac_addr_to_str(l2_entry.contents.key.mac_l2iif_l2vni_id.mac_addr))
    else:
        return (mac_addr_to_str(l2_entry.contents.key.mac_l2vni.mac_addr))

def get_mac_mask_from_l2_entry(l2_entry):
    if l2_entry.contents.key_type == ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_ONLY:
        return (mac_addr_to_str(l2_entry.contents.key.mac_only.mac_mask))
    elif l2_entry.contents.key_type == ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2IIF_L2VNI_ID:
        return (mac_addr_to_str(l2_entry.contents.key.mac_l2iif_l2vni_id.mac_mask))
    else:
        return " * "

def get_group_ip_addr_from_l2_entry(l2_entry):
    if l2_entry.contents.key_type == ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_IP_SG_L2VNI:
        if l2_entry.contents.key.ip_starg_l2vni.group.addr_family == ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4:
            return (
                socket.inet_ntoa(
                    struct.pack(
                        '!L',
                        l2_entry.contents.key.ip_sg_l2vni.group.addr.ipv4)))
        else:
            return (
                socket.inet_ntop(
                    socket.AF_INET6,
                    l2_entry.contents.key.ip_sg_l2vni.group.addr.ipv6))
    else:
        if l2_entry.contents.key.ip_starg_l2vni.group.addr_family == ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4:
            return (
                socket.inet_ntoa(
                    struct.pack(
                        '!L',
                        l2_entry.contents.key.ip_starg_l2vni.group.addr.ipv4)))
        else:
            return (
                socket.inet_ntop(
                    socket.AF_INET6,
                    l2_entry.contents.key.ip_starg_l2vni.group.addr.ipv6))

def get_source_ip_addr_from_l2_entry(l2_entry):
    if l2_entry.contents.key_type == ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_IP_SG_L2VNI:
        if l2_entry.contents.key.ip_sg_l2vni.source.addr_family == ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4:
            return (
                socket.inet_ntoa(
                    struct.pack(
                        '!L',
                        l2_entry.contents.key.ip_sg_l2vni.source.addr.ipv4)))
        else:
            return (
                socket.inet_ntop(
                    socket.AF_INET6,
                    l2_entry.contents.key.ip_sg_l2vni.source.addr.ipv6))
    else:
        if l2_entry.contents.key.ip_starg_l2vni.source.addr_family == ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4:
            return (
                socket.inet_ntoa(
                    struct.pack(
                        '!L',
                        l2_entry.contents.key.ip_starg_l2vni.source.addr.ipv4)))
        else:
            return (
                socket.inet_ntop(
                    socket.AF_INET6,
                    l2_entry.contents.key.ip_starg_l2vni.source.addr.ipv6))

def get_l2vni_from_l2_entry(l2_entry):
    if l2_entry.contents.key_type == ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_IP_SG_L2VNI:
        return (l2_entry.contents.key.ip_sg_l2vni.l2vni)
    elif l2_entry.contents.key_type == ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_IP_STARG_L2VNI:
        return (l2_entry.contents.key.ip_starg_l2vni.l2vni)
    elif l2_entry.contents.key_type == ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI:
        return (l2_entry.contents.key.mac_l2vni.l2vni)
    else:
        return 0


def get_l2iif_from_l2_entry(entry, l2_entry_obj):
    l2iif = "0"
    if entry.contents.key_type == ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2IIF_L2VNI_ID:
        if entry.contents.key.mac_l2iif_l2vni_id.l2iif != ifcs_ctypes.IFCS_NULL_HANDLE:
            l2iif = l2_entry_obj.handle_to_str(
                entry.contents.key.mac_l2iif_l2vni_id.l2iif, True)
    return l2iif


def get_l2iif_mask_from_l2_entry(entry, l2_entry_obj):
    l2iif_mask = "0"
    if entry.contents.key_type == ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2IIF_L2VNI_ID:
        if entry.contents.key.mac_l2iif_l2vni_id.l2iif_mask != ifcs_ctypes.IFCS_NULL_HANDLE:
            l2iif_mask = l2_entry_obj.handle_to_str(
                entry.contents.key.mac_l2iif_l2vni_id.l2iif_mask, True)
    return l2iif_mask


def get_l2vni_id_from_l2_entry(entry, l2_entry_obj):
    l2vni_id = "0"
    if entry.contents.key_type == ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2IIF_L2VNI_ID:
        if entry.contents.key.mac_l2iif_l2vni_id.l2vni_id:
            l2vni_id = "{},{}".format(
                entry.contents.key.mac_l2iif_l2vni_id.l2vni_id,
                str(hex(int(entry.contents.key.mac_l2iif_l2vni_id.l2vni_id))))
    return l2vni_id


def get_l2vni_id_mask_from_l2_entry(entry, l2_entry_obj):
    l2vni_id_mask = "0"
    if entry.contents.key_type == ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2IIF_L2VNI_ID:
        if entry.contents.key.mac_l2iif_l2vni_id.l2vni_id_mask:
            l2vni_id_mask = "{},{}".format(
                entry.contents.key.mac_l2iif_l2vni_id.l2vni_id_mask,
                str(hex(int(entry.contents.key.mac_l2iif_l2vni_id.l2vni_id_mask))))
    return l2vni_id_mask


def get_key_from_l2_entry(entry, l2_entry_obj):
    source = " * "
    group = " * "
    mac_addr = " * "
    mac_mask = " * "
    l2iif = "0"
    l2iif_mask = "0"
    l2vni_id = "0"
    l2vni_id_mask = "0"
    if entry.contents.key_type == ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_IP_SG_L2VNI:
        source = get_source_ip_addr_from_l2_entry(entry)
        group = get_group_ip_addr_from_l2_entry(entry)
    elif entry.contents.key_type == ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_IP_STARG_L2VNI:
        group = get_group_ip_addr_from_l2_entry(entry)
    elif entry.contents.key_type == ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI:
        mac_addr = get_mac_addr_from_l2_entry(entry)
    elif entry.contents.key_type == ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_ONLY:
        mac_addr = get_mac_addr_from_l2_entry(entry)
        mac_mask = get_mac_mask_from_l2_entry(entry)
    elif entry.contents.key_type == ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2IIF_L2VNI_ID:
        mac_addr = get_mac_addr_from_l2_entry(entry)
        mac_mask = get_mac_mask_from_l2_entry(entry)
        l2iif = get_l2iif_from_l2_entry(entry, l2_entry_obj)
        l2iif_mask = get_l2iif_mask_from_l2_entry(entry, l2_entry_obj)
        l2vni_id = get_l2vni_id_from_l2_entry(entry, l2_entry_obj)
        l2vni_id_mask = get_l2vni_id_mask_from_l2_entry(entry, l2_entry_obj)

    return source, group, mac_addr, mac_mask, l2iif, l2iif_mask, l2vni_id, l2vni_id_mask


def show_l2_entry_extension_brief(args, l2_entry):
    log_dbg(1, " Inside l2_entry extension brief show")

    try:
        if args:
            rc, all_keys = l2_entry.bulk_get_all_l2_entry_keys(args)
        else:
            rc, all_keys = l2_entry.bulk_get_all_l2_entry_keys()
    except BaseException:
        log_err(" Failed to get all l2entries ")
        return

    table = PrintTable()

    field_names = [
        'key_type',
        'mac_addr',
        'mac_mask',
        'source',
        'group',
        'l2vni',
        'entry_dest',
        'entry_type',
        'fwd_policy',
        'ctc_policy',
        'user_cookie',
        'hitbit']
    table.add_row(field_names)

    attr_ids = [
        ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_TYPE,
        ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_DEST,
        ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_FWD_POLICY,
        ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_CTC_POLICY,
        ifcs_ctypes.IFCS_L2_ENTRY_ATTR_HITBIT,
        ifcs_ctypes.IFCS_L2_ENTRY_ATTR_USER_COOKIE
    ]
    attr_count = len(attr_ids)

    log("Total l2_entry count: {0} ".format(len(all_keys)))
    count = 0

    for key_idx in range(len(all_keys)):
        row = []
        key_ptr = all_keys[key_idx]
        key_type = key_type_dict[key_ptr.contents.key_type]
        source, group, mac_addr, mac_mask, l2iif, l2iif_mask, l2vni_id, l2vni_id_mask = get_key_from_l2_entry(key_ptr, l2_entry)

        # Get all attributes
        attr_list = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        for attr_idx in range(attr_count):
            attr_list[attr_idx].id = attr_ids[attr_idx]
        attr_p = compat_pointer(attr_list, ifcs_ctypes.ifcs_attr_t)

        try:
            actual_count = l2_entry.getAttr(key_ptr, attr_list, attr_p, attr_count, True)
            actual_count = actual_count.value
            if actual_count != attr_count:
                msg = "Attribute count different in show l2_entry. expected: {}, actual: {}".format(attr_count,
                actual_count)
                raise KeyError(msg)
        except KeyError:
            einfo = "{}".format(sys.exc_info())
            log_dbg(1, "KeyError in show l2_entry. route_entry: {}, error: {}".
                    format(key_ptr, einfo))
            if l2_entry.not_found_exc_msg.format(
                ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                # Don't display error message for expected exception.
                # Skip the instance as the object is not found.
                continue
            log_err("Failed to get attributes for l2_entry")
            raise
        except BaseException:
            log_dbg(
                1, "OtherError in show l2_entry. route_entry: {}, error: {}". format(key_ptr, sys.exc_info()))
            log_err("Failed to get attributes for l2_entry ")
            raise KeyError

        # Process attribute values and display
        count += 1
        for attr_idx in range(attr_count):
            if attr_list[attr_idx].id == ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_FWD_POLICY:
                fwd_policy = attr_list[attr_idx].value.fwd_policy
                fwd_policy = l2_entry.handle_to_str(fwd_policy.pp_drop_reason), l2_entry.enum_to_str('fwd_action', fwd_policy.fwd_action)
                continue
            elif attr_list[attr_idx].id == ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_CTC_POLICY:
                ctc_policy = attr_list[attr_idx].value.ctc_policy
                ctc_policy = l2_entry.handle_to_str(ctc_policy.trap_handle), l2_entry.enum_to_str('copy_to_cpu', ctc_policy.ctc_action)
                continue
            elif attr_list[attr_idx].id == ifcs_ctypes.IFCS_L2_ENTRY_ATTR_USER_COOKIE:
                cookie = attr_list[attr_idx].value.u32
                continue
            elif attr_list[attr_idx].id == ifcs_ctypes.IFCS_L2_ENTRY_ATTR_HITBIT:
                hitbit = attr_list[attr_idx].value.u32
                continue
            elif attr_list[attr_idx].id == ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_DEST:
                entrydest = attr_list[attr_idx].value.handle
                entrydest = l2_entry.handle_to_str(entrydest)
                continue
            elif attr_list[attr_idx].id == ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_TYPE:
                entrytype = attr_list[attr_idx].value.u32
                entrytype = l2_entry.enum_to_str('entry_type', entrytype)
                continue

        l2vni = l2_entry.handle_to_str(get_l2vni_from_l2_entry(key_ptr))

        row.append(key_type)
        row.append(mac_addr)
        row.append(mac_mask)
        row.append(source)
        row.append(group)
        row.append(l2vni)
        row.append(entrydest)
        row.append(entrytype)
        row.append(fwd_policy)
        row.append(ctc_policy)
        row.append(cookie)
        row.append(hitbit)
        table.add_row(row)
    table.print_table(brief=True)
    table.reset_table()
    log("Total l2_entry count: {0} \n".format(len(all_keys)))

    return


def show_l2_entry_extension_key_helper(entry, l2_entry_obj):
    log_dbg(1, " Inside l2_entry extension key helper")
    key_type = key_type_dict[entry.contents.key_type]
    source, group, mac_addr, mac_mask, l2iif, l2iif_mask, l2vni_id, l2vni_id_mask = get_key_from_l2_entry(
        entry, l2_entry_obj)
    if entry.contents.key_type == ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI:
        return [('key_type', key_type),
                ('mac_addr', l2_entry_obj.get_mac_addr_from_l2_entry(entry)),
                ('l2vni', l2_entry_obj.get_l2vni_from_l2_entry(entry))]
    elif entry.contents.key_type == ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_IP_SG_L2VNI:
        return [('key_type', key_type), ('source', source), ('group', group),
                ('l2vni', l2_entry_obj.get_l2vni_from_l2_entry(entry))]
    elif entry.contents.key_type == ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_IP_STARG_L2VNI:
        return [('key_type', key_type), ('group', group),
                ('l2vni', l2_entry_obj.get_l2vni_from_l2_entry(entry))]
    elif entry.contents.key_type == ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_ONLY:
        return [('key_type', key_type), ('mac_addr', mac_addr),
                ('mac_mask', mac_mask)]
    elif entry.contents.key_type == ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2IIF_L2VNI_ID:
        return [('key_type', key_type), ('mac_addr', mac_addr),
                ('mac_mask', mac_mask), ('l2iif', l2iif),
                ('l2iif_mask', l2iif_mask), ('l2vni_id', l2vni_id),
                ('l2vni_id_mask', l2vni_id_mask)]
    else:
        return []


def show_l2_entry_extension_usage_helper(l2_entry, filter_option):
    usage_p = ifcs_ctypes.ifcs_usage_t()

    if filter_option not in ['mac_l2vni', 'v4_sg', 'v4_starg', 'v6_starg', 'mac_only', 'mac_l2iif_l2vni_id']:
        log_err("Invalid filter option {0}".format(filter_option))
        return

    group = ifcs_ctypes.ifcs_ip_prefix_t()
    ifcs_ctypes.ifcs_ip_prefix_t_init(pointer(group))

    if 'v4' in filter_option:
        ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(group), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)
    elif 'v6' in filter_option:
        ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(group), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

    l2_entry_key = ifcs_ctypes.ifcs_l2_entry_key_t()
    ifcs_ctypes.ifcs_l2_entry_key_t_init(pointer(l2_entry_key))
    if 'sg' in filter_option:
        ifcs_ctypes.ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry_key), ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_IP_SG_L2VNI)
        ifcs_ctypes.ifcs_l2_entry_key_ip_sg_l2vni_t_group_set(pointer(l2_entry_key.key.ip_sg_l2vni), pointer(group))
        ifcs_ctypes.ifcs_l2_entry_key_t_ip_sg_l2vni_set(pointer(l2_entry_key),l2_entry_key.key.ip_sg_l2vni)
    elif 'starg' in filter_option:
        ifcs_ctypes.ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry_key), ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_IP_STARG_L2VNI)
        ifcs_ctypes.ifcs_l2_entry_key_ip_starg_l2vni_t_group_set(pointer(l2_entry_key.key.ip_starg_l2vni),pointer(group))
        ifcs_ctypes.ifcs_l2_entry_key_t_ip_starg_l2vni_set(pointer(l2_entry_key),l2_entry_key.key.ip_starg_l2vni)
    elif 'mac_l2iif_l2vni_id' in filter_option:
        ifcs_ctypes.ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry_key), ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2IIF_L2VNI_ID)
    elif 'l2vni' in filter_option:
        ifcs_ctypes.ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry_key), ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
    elif 'only' in filter_option:
        ifcs_ctypes.ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry_key), ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_ONLY)

    rc = ifcs_ctypes.ifcs_l2_entry_usage_get(0, pointer(l2_entry_key), 0, None, pointer(usage_p))
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err(
            "Failed to get all {0} l2_entry rc: {1}".format(filter_option, convert_error_code_to_string(rc)))
        return

    log("Usage for {0} l2 entries".format(filter_option))

    table = PrintTable()
    table.add_row(["Current", "Max"])
    table.add_row([usage_p.current, usage_p.max])
    table.print_table()
    table.reset_table()

    return

def show_l2_entry_extension_usage(arg1, arg2, l2_entry):
    log_dbg(1, " Inside extension usage show")

    if l2_entry.filter_option == {}:
        for filter_option in ['mac_l2vni', 'v4_sg', 'v4_starg', 'v6_starg', 'mac_only', 'mac_l2iif_l2vni_id']:
            show_l2_entry_extension_usage_helper(l2_entry, filter_option)
            log("\n")
    else:
        filter_option = (l2_entry.filter_option['filter']).strip()
        show_l2_entry_extension_usage_helper(l2_entry, filter_option)

    return
