
#-------------------------------------------------------------------------------
# * Copyright (c) Innovium, Inc., 2017
# *
# * This material is proprietary to Innovium. All rights reserved.
# * The methods and techniques described herein are considered trade secrets
# * and/or confidential. Reproduction or distribution, in whole or in part, is
# * forbidden except by express written permission of Innovium.
# *-----------------------------------------------------------------------------
#-------------------------------------------------------------------------------

from ctypes import *
from ifcs_cmds.cli_types import *
from itertools import *
from time import *
from utils.compat_util import *
from verbosity import log, log_dbg
from ifcs_cmds.route_entry import *
from print_table import PrintTable
import sys
import socket
import struct
ifcs_ctypes=sys.modules['ifcs_ctypes']

key_type_dict = {
    ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_L3VNI : "ip_dest_l3vni",
    ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_ONLY : "ip_dest_only",
}

def get_ip_dest_from_route_entry(route_entry):
    ip_addr = " * "
    ip_mask = " * "

    if route_entry.contents.key_type == ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_ONLY:
        if route_entry.contents.key.ip_dest_only.ip_dest.addr_family == ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4:
            ip_addr = socket.inet_ntoa(struct.pack( '!L',
                        route_entry.contents.key.ip_dest_only.ip_dest.addr.ipv4))
            ip_mask = socket.inet_ntoa(struct.pack( '!L',
                        route_entry.contents.key.ip_dest_only.ip_dest.mask.ipv4))
        else:
            ip_addr = socket.inet_ntop(socket.AF_INET6,
                    route_entry.contents.key.ip_dest_only.ip_dest.addr.ipv6)
            ip_mask = socket.inet_ntop(socket.AF_INET6,
                    route_entry.contents.key.ip_dest_only.ip_dest.mask.ipv6)
    else:
        if route_entry.contents.key.ip_dest_l3vni.ip_dest.addr_family == ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4:
            ip_addr = socket.inet_ntoa(struct.pack( '!L',
                        route_entry.contents.key.ip_dest_l3vni.ip_dest.addr.ipv4))
            ip_mask = socket.inet_ntoa(struct.pack( '!L',
                        route_entry.contents.key.ip_dest_l3vni.ip_dest.mask.ipv4))
        else:
            ip_addr = socket.inet_ntop(socket.AF_INET6,
                    route_entry.contents.key.ip_dest_l3vni.ip_dest.addr.ipv6)
            ip_mask = socket.inet_ntop(socket.AF_INET6,
                    route_entry.contents.key.ip_dest_l3vni.ip_dest.mask.ipv6)

    return ip_addr, ip_mask


def show_route_entry_extension_brief(args, route_entry):
    log_dbg(1, " Inside route_entry extension brief show")

    try:
        rc, all_keys = route_entry.bulk_get_all_route_entry_keys()
    except Exception as e:
        log_err(" Failed to get all route_entry : {0} ".format(e))
        raise e

    table = PrintTable()
    #field_names = ['ip_addr','ip_mask','l3vni','fwd_action','ctc_action','trap','nexthop_handle','local_destination']
    field_names = [
        'key_type',
        'ip_addr',
        'ip_mask',
        'l3vni',
        'fwd_action',
        'ctc_action',
        'trap',
        'nexthop',
        'user_cookie',
        'ttl_check_profile']
    table.add_row(field_names)

    attr_ids = [
        ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_NEXTHOP,
        ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_FWD_POLICY,
        ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_CTC_POLICY,
        ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_USER_COOKIE,
        ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_TTL_CHECK_PROFILE
    ]
    attr_count = len(attr_ids)

    all_keys = sorted(all_keys,
                      key=lambda x: x.contents.key.ip_dest_l3vni.l3vni)
    log("Total route_entry count: {0} ".format(len(all_keys)))
    count = 0

    for key_idx in range(len(all_keys)):
        row = []
        key_ptr = all_keys[key_idx]
        key_type = key_type_dict[key_ptr.contents.key_type]

        # Get all attributes
        attr_list = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        for attr_idx in range(attr_count):
            attr_list[attr_idx].id = attr_ids[attr_idx]
        attr_p = compat_pointer(attr_list, ifcs_ctypes.ifcs_attr_t)
        try:
            actual_count = route_entry.getAttr(key_ptr, attr_list, attr_p,
                                               attr_count, True)
            actual_count = actual_count.value
            if actual_count != attr_count:
                msg = "Attribute count different in show route_entry. expected: {}, actual: {}".format(
                    attr_count, actual_count)
                raise KeyError(msg)
        except KeyError:
            einfo = "{}".format(sys.exc_info())
            log_dbg(
                1, "KeyError in show route_entry. route_entry: {}, error: {}".
                format(key_ptr, einfo))
            if route_entry.not_found_exc_msg.format(
                    ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                # Don't display error message for expected exception.
                # Skip the instance as the object is not found.
                continue
            log_err("Failed to get attributes for route_entry ")
            raise
        except BaseException:
            log_dbg(
                1, "OtherError in show route_entry. route_entry: {}, error: {}".
                format(key_ptr, sys.exc_info()))
            log_err("Failed to get attributes for route_entry ")
            raise KeyError

        # Process attribute values and display
        count += 1
        for attr_idx in range(attr_count):
            if attr_list[attr_idx].id == ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_NEXTHOP:
                nexthop = attr_list[attr_idx].value.handle
            elif attr_list[attr_idx].id == ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_FWD_POLICY:
                attr_val = attr_list[attr_idx].value.fwd_policy.fwd_action
                fwd_action = route_entry.enum_to_str('fwd_action', attr_val)
            elif attr_list[attr_idx].id == ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_CTC_POLICY:
                trap_handle = attr_list[attr_idx].value.ctc_policy.trap_handle
                attr_val = attr_list[attr_idx].value.ctc_policy.ctc_action
                ctc_action = route_entry.enum_to_str('copy_to_cpu', attr_val)
            elif attr_list[attr_idx].id == ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_USER_COOKIE:
                user_cookie = attr_list[attr_idx].value.u32
            elif attr_list[attr_idx].id == ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_TTL_CHECK_PROFILE:
                ttl_check_profile = attr_list[attr_idx].value.u32

        l3vni = route_entry.get_l3vni_from_route_entry(key_ptr)
        #ip_addr = route_entry.get_ip_addr_from_route_entry(key_ptr)
        #ip_mask = route_entry.get_ip_mask_from_route_entry(key_ptr)
        ip_addr, ip_mask = get_ip_dest_from_route_entry(key_ptr)

        row.append(key_type)
        row.append(ip_addr)
        row.append(ip_mask)
        row.append(l3vni)
        row.append(fwd_action)
        row.append(ctc_action)
        row.append(route_entry.handle_to_str(trap_handle))
        row.append(route_entry.handle_to_str(nexthop))
        row.append(user_cookie)
        row.append(ttl_check_profile)
        table.add_row(row)
    table.print_table(brief=True)
    table.reset_table()
    log("Total route_entry count: {0} \n".format(count))
    return


def show_route_entry_extension_usage_helper(route_entry, filter_option):
    usage_p = ifcs_ctypes.ifcs_usage_t()

    if filter_option not in ['v4_prefix', 'v6_prefix', 'v4_host', 'v6_host', 'v4_fallback', 'v6_fallback', 'srp2', 'srp1', 'pth']:
        log_err("Invalid filter option {0}".format(filter_option))
        return

    ip_dest = ifcs_ctypes.ifcs_ip_prefix_t()
    ifcs_ctypes.ifcs_ip_prefix_t_init(pointer(ip_dest))

    if 'v4' in filter_option:
        ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)
    else: # v6 filter
        ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

    route_key = ifcs_ctypes.ifcs_route_entry_key_t()
    ifcs_ctypes.ifcs_route_entry_key_t_init(pointer(route_key))
    if 'fallback' in filter_option:
        ifcs_ctypes.ifcs_route_entry_key_t_key_type_set(pointer(route_key), ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_ONLY)
        ifcs_ctypes.ifcs_route_entry_key_t_ip_dest_only_set(pointer(route_key), route_key.key.ip_dest_only)
        ifcs_ctypes.ifcs_route_entry_key_ip_dest_only_t_ip_dest_set(pointer(route_key.key.ip_dest_only), pointer(ip_dest))
    else: # IP_DEST_L3VNI
        ifcs_ctypes.ifcs_route_entry_key_t_key_type_set(pointer(route_key), ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_L3VNI)
        ifcs_ctypes.ifcs_route_entry_key_t_ip_dest_l3vni_set(pointer(route_key), route_key.key.ip_dest_l3vni)
        ifcs_ctypes.ifcs_route_entry_key_ip_dest_l3vni_t_ip_dest_set(pointer(route_key.key.ip_dest_l3vni), pointer(ip_dest))

    attr = ifcs_ctypes.ifcs_attr_t()
    ifcs_ctypes.ifcs_attr_t_id_set(pointer(attr), ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_USAGE_GET_ROUTE_TYPE)

    if 'prefix' in filter_option:
        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_PREFIX)
    elif 'host' in filter_option:
        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_HOST)
    elif 'srp2' in filter_option:
        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_SRP2)
    elif 'srp1' in filter_option:
        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_SRP1)
    elif 'pth' in filter_option:
        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_PTH)

    if 'fallback' in filter_option:
        rc = ifcs_ctypes.ifcs_route_entry_usage_get(0, pointer(route_key), 0, None, pointer(usage_p))
    else:
        rc = ifcs_ctypes.ifcs_route_entry_usage_get(0, pointer(route_key), 1, pointer(attr), pointer(usage_p))
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err(
            "Failed to get all {0} route_entry rc: {1}".format(filter_option,
                convert_error_code_to_string(rc)))
        return

    # If max is zero, we need not display it
    if usage_p.max == 0:
        return

    log("Usage for {0} route entries".format(filter_option))

    table = PrintTable()
    table.add_row(["Current", "Max"])
    table.add_row([usage_p.current, usage_p.max])
    table.print_table()
    table.reset_table()
    log("\n")

    return


def show_route_entry_extension_usage(arg1, arg2, route_entry):
    log_dbg(1, " Inside extension usage show")

    if route_entry.filter_option == {}:
        for filter_option in ['v4_prefix', 'v6_prefix', 'v4_host', 'v6_host', 'v4_fallback', 'v6_fallback', 'srp2', 'srp1', 'pth']:
            show_route_entry_extension_usage_helper(route_entry, filter_option)
    else:
        filter_option = (route_entry.filter_option['filter']).strip()
        show_route_entry_extension_usage_helper(route_entry, filter_option)

    return
