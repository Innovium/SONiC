#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

# Filename: log_utils.py
from ctypes import *
from ifcs_ctypes import *

def get_logfile_name():
    logname_str = c_char_p(b" " * 1024)
    rc = im_get_logfile_name(logname_str, 1024)
    assert rc == IFCS_SUCCESS, "Couldnt get log filename "
    return str(logname_str.value.decode())

def get_apidata_name():
    logname_str = c_char_p(b" " * 1024)
    rc = im_get_apidata_name(logname_str, 1024)
    assert rc == IFCS_SUCCESS, "Couldnt get api data filename "
    return str(logname_str.value.decode())

def raiseExpOnFail(status, msg):
    '''Raise an exception based on status
       The status is IFCS status, and the exception corresponds to the
       ifcs_status_t'''

    status_string = [
        (IFCS_SUCCESS, "ifcs_success"),
        (IFCS_UNINIT, "ifcs_uninit"),
        (IFCS_BUSY, "ifcs_busy"),
        (IFCS_CONFIG, "ifcs_config"),
        (IFCS_MEMORY, "ifcs_memory"),
        (IFCS_PARAM, "ifcs_param"),
        (IFCS_EXIST, "ifcs_exist"),
        (IFCS_MULTI_EXIST, "ifcs_multi_exist"),
        (IFCS_ENTRY_REPLACED, "ifcs_entry_replaced"),
        (IFCS_LENGTH_MISMATCH, "ifcs_length_mismatch"),
        (IFCS_NOTFOUND, "ifcs_notfound"),
        (IFCS_INVAL, "ifcs_inval"),
        (IFCS_UNSUPPORTED, "ifcs_unsupported"),
        (IFCS_RESOURCE_FULL, "ifcs_resource_full"),
        (IFCS_TIMEOUT, "ifcs_timeout")
    ]

    if status == IFCS_SUCCESS:
        return None

    #INFO(msg + ' rc: {}'.format(status))
    log(msg + ' rc: {}'.format(status))
    for index in range(len(status_string)):
        if status == status_string[index][0]:
            expStr = status_string[index][1]
            raise Exception(expStr, status)

    INFO("Unknown IFCS Status Returned by API")
    raise ValueError("Unknown Status Returned by IFCS")
