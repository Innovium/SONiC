#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2020
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

from __future__ import print_function
from ctypes import pointer, cast, POINTER, byref, sizeof, c_voidp
import re
from sys import version
import itertools

# ctypesgen compatibility functions
def compat_pointer(obj, obj_type):
    class_type = str(type(obj))
    if re.search(r'_Array_\d+\'>$', class_type):
        # Current ctype requires cast for array of objects.
        return cast(obj, POINTER(obj_type))
    else:
        return pointer(obj)

# Pointer to an object in an array of objects.
def compat_pointerAtIndex(obj, obj_type, index):
    class_type = str(type(obj))
    if not re.search(r'_Array_\d+\'>$', class_type):
        raise TypeError("Cannot take pointer to element at index {} of non-array object".format(index))
    return cast(byref(obj, sizeof(obj_type) * index), POINTER(obj_type))

# Pointer to callback function
def compat_funcPointer(func, func_type):
    # Current ctype requires cast for call back functions from c
    return cast(func, POINTER(func_type))

# Python compatibility functions
COMPAT_PY2 = (version[0] == '2')
COMPAT_PY3 = (version[0] == '3')

# Dictionary methods
if COMPAT_PY2:
    def compat_itervalues(d):
        return d.itervalues()

    def compat_iteritems(d):
        return d.iteritems()

    def compat_iterkeys(d):
        return d.iterkeys()

    def compat_listkeys(d):
        return d.keys()

    def compat_listvalues(d):
        return d.values()

    def compat_listitems(d):
        return d.items()
elif COMPAT_PY3:
    def compat_itervalues(d):
        return iter(d.values())

    def compat_iteritems(d):
        return iter(d.items())

    def compat_iterkeys(d):
        return iter(d.keys())

    def compat_listkeys(d):
        return list(d.keys())

    def compat_listvalues(d):
        return list(d.values())

    def compat_listitems(d):
        return list(d.items())

# range in assignments and return
if COMPAT_PY2:
    def compat_listrange(*argv):
        return range(*argv)

    compat_xrange = xrange
elif COMPAT_PY3:
    def compat_listrange(*argv):
        return list(range(*argv))

    compat_xrange = range

# unicode
if COMPAT_PY2:
    compat_text_type = unicode
elif COMPAT_PY3:
    compat_text_type = str

# whether integer type instance
if COMPAT_PY2:
    def compat_isIntegerInstance(obj):
        return isinstance(obj, (int, long))
elif COMPAT_PY3:
    def compat_isIntegerInstance(obj):
        return isinstance(obj, int)

# chr function
if COMPAT_PY2:
    def compat_chr(int_val):
        return chr(int_val)
elif COMPAT_PY3:
    def compat_chr(int_val):
        # Returns a bytes string
        return bytes([int_val])

# ord function for bytes string
if COMPAT_PY2:
    def compat_ord(byte_string_char):
        return ord(byte_string_char)
elif COMPAT_PY3:
    def compat_ord(byte_string_char):
        return byte_string_char

# map in assignments and return
if COMPAT_PY2:
    def compat_listmap(*argv):
        return map(*argv)
elif COMPAT_PY3:
    def compat_listmap(*argv):
        return list(map(*argv))

# izip_longest for iterating
if COMPAT_PY2:
    compat_izip_longest = itertools.izip_longest
elif COMPAT_PY3:
    compat_izip_longest = itertools.zip_longest

# raw_input
if COMPAT_PY2:
    compat_raw_input = raw_input
elif COMPAT_PY3:
    compat_raw_input = input

# StringIO
if COMPAT_PY2:
    import cStringIO
    compat_StringIO = cStringIO.StringIO
elif COMPAT_PY3:
    # TODO: Need to revisit this
    import io
    compat_StringIO = io.StringIO

# reload
if COMPAT_PY2:
    compat_reload = reload
elif COMPAT_PY3:
    import importlib
    compat_reload = importlib.reload

if COMPAT_PY2:
    def compat_long(v, base=10):
        # Some callers pass numeric, some pass string for v. In case of numeric, giving a base gives error
        # TypeError: long() can't convert non-string with explicit base
        if base == 10:
            return long(v)
        else:
            return long(v, base)
elif COMPAT_PY3:
    def compat_long(v, base=10):
        if base == 10:
            return int(v)
        else:
            return int(v, base)

# Convert bytes-string to String
if COMPAT_PY2:
    def compat_bytesToStr(b):
        return b
elif COMPAT_PY3:
    def compat_bytesToStr(b):
        return b.decode(encoding="utf-8")

# Convert String to bytes-string
if COMPAT_PY2:
    def compat_strToBytes(s):
        return s
elif COMPAT_PY3:
    def compat_strToBytes(s):
        return s.encode("utf-8")

#  Return a bytes representation of the Unicode string, encoded in utf-8
if COMPAT_PY2:
    def compat_strToBytesUtf8(s):
        return str(s)
elif COMPAT_PY3:
    def compat_strToBytesUtf8(s):
        return s.encode('utf-8')

# Encode a byte string to hex
if COMPAT_PY2:
    def compat_encodeBytesToHex(b):
        return b.encode('hex')
elif COMPAT_PY3:
    # Note that this works for both versions
    import binascii
    def compat_encodeBytesToHex(b):
        return binascii.hexlify(b)

# / returns integer value in Py2, but float in Py3
# Py3's replacement for this functionality is to use // (ie, two slashes)
# However our obfuscation is removing all occurences of // as it thinks it is a comment.. Phew!!
if COMPAT_PY2:
    def compat_division(a, b):
        return a/b
elif COMPAT_PY3:
    def compat_division(a, b):
        return int(a/b)

if COMPAT_PY2:
    def compat_voidp(value):
        return cast(pointer(value),c_voidp)
elif COMPAT_PY3:
    def compat_voidp(value):
        return cast(pointer(value),c_voidp)

# print
def log(*argv):
    print(*argv)

def log_no_newline(*argv):
    print(*argv, end = " ")
