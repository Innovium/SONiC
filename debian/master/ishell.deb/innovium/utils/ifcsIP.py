#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2016
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

import random
from netaddr import *
import socket, struct
from ctypes import *
from ifcs_ctypes import *
import decimal
from netaddr import *
from utils.compat_util import *

supported_prefix_len = []

for i in compat_xrange(8, 31, 4):
    supported_prefix_len.append(i)

IPv4 = 0
IPv6 = 1

debug = 0
def generateIPinRange(startAddr, endAddr, num_entries=1, ipFam = 'ipv4', pfxRange = None):
    if ipFam == 'ipv4':
        ipv6 = False
    elif ipFam == 'ipv6':
        ipv6 = True
    else:
        assert 0, "Invalid ip family {}".format(ipFam)
    start = convertIpStrtoIpInt(startAddr, ipv6)
    end = convertIpStrtoIpInt(endAddr, ipv6)
    if ipv6:
        start = int(start, 16)
        end = int(end, 16)
    assert (end - start + 1) >= num_entries, "invalid range specified for {} entries".format(num_entries)
    assert num_entries >= 0, "negative num entries specified"
    addrs = []
    if pfxRange:
        pfx_start = pfxRange[0]
        pfx_end = pfxRange[1]
        assert pfx_start >= 1 and pfx_end - pfx_start >= 0, "Invalid prefix range"
        if ipv6:
            pfxmax = 128
            assert pfx_end < pfxmax, "IPv6 pfx len {} not in supported range".format(pfx_end)
        else:
            pfxmax = 32
            assert pfx_end < pfxmax, "IPv4 pfx len {} not in supported range".format(pfx_end)
    maxloop = 3
    loop = 0
    while not len(addrs) == num_entries:
        if loop == maxloop:
            log("Generate Random IP did not get enough random entries {} < expected {}".format(len(addrs), num_entries))
            break
        loop +=1
        random_list=[]
        for i in compat_xrange(compat_long(num_entries * 1.5)):
            pfxlen = None
            if pfxRange:
                pfxlen = random.randint(pfx_start, pfx_end)
                pfxstart = start >> (pfxmax - pfxlen)
                pfxend = end >> (pfxmax - pfxlen)
                ipaddr = random.randint(pfxstart, pfxend)
                ipaddr = ipaddr << (pfxmax - pfxlen)
                random_list.append((ipaddr, pfxlen))
            else:
                ipaddr = random.randint(start, end)
                random_list.append(ipaddr)
        addrs = list(set(addrs + random_list))[0:num_entries]
    if pfxlen:
        addrstr = [convertIpInttoIpStr(x[0], ipv6) + '/' + str(x[1])  for x in addrs]
    else:
        addrstr = [convertIpInttoIpStr(x, ipv6) for x in addrs]
    return addrs, addrstr

def generateIPList(prefix,num_entries=1):
    ip_addresses=[]
    while not len(ip_addresses) == num_entries:
       octList=[]
       random_list=[]
       for i in range(prefix):
           octList=octList+[random.randint(1, 223)]
       for i in compat_xrange(compat_long(num_entries * 1.5)):
           random_list.append(generateIPnow(octList))
       ip_addresses = list(set(ip_addresses + random_list))[0:num_entries]
    return ip_addresses

def generateIPnow(octList):
    if len(octList) >= 1:
        oct1 = octList[0]
    else:
        oct1 = random.randint(1, 223) # Oct1 to not include MC/Rsvd IPv4 range
        if oct1 == 127:
            oct1 = 128
    if len(octList) >= 2:
        oct2 = octList[1]
    else:
        oct2 = random.randint(1, 223) # Oct1 to not include MC/Rsvd IPv4 range
    if len(octList) >= 3:
        oct3 = octList[2]
    else:
        oct3 = random.randint(1, 223) # Oct1 to not include MC/Rsvd IPv4 range
    if len(octList) >= 4:
        oct4 = octList[3]
    else:
        oct4 = random.randint(1, 223) # Oct1 to not include MC/Rsvd IPv4 range

    ip = str(oct1) + "." + str(oct2) + "." + str(oct3) + "." + str(oct4)

    if (debug > 0):
        DEBUG("IfcsIP: " + ip)
    return ip

def generateIP(oct1 = None, oct2 = None, oct3 = None, oct4 = None):
    if oct1 == None:
        oct1 = random.randint(1, 223) # Oct1 to not include MC/Rsvd IPv4 range
        if oct1 == 127:
            oct1 = 128
    if oct2 == None:
        oct2 = random.randint(1, 255)
    if oct3 == None:
        oct3 = random.randint(1, 255)
    if oct4 == None:
        oct4 = random.randint(1, 255)


    ip = str(oct1) + "." + str(oct2) + "." + str(oct3) + "." + str(oct4)

    if (debug > 0):
        DEBUG("IfcsIP: " + ip)
    return ip

def generateIPv6List(prefix,num_entries):

    ip_addresses=[]
    while not len(ip_addresses) == num_entries:
       octList=[]
       random_list=[]
       for i in range(prefix):
           octList=octList+[(hex(random.randint(1,254)))[2:4]]
       for i in compat_xrange(compat_long(num_entries * 1.5)):
           random_list.append(generateIPv6withPrefix(octList)[1])
       ip_addresses = list(set(ip_addresses + random_list))[0:num_entries]

    return ip_addresses

def generateIPv6withPrefix(octList):
    if len(octList) >= 1:
        octet1 = octList[0]
    else:
        octet1 = (hex(random.randint(1,254)))[2:4]
    if len(octList) >= 2:
        octet2 = octList[1]
    else:
        octet2 = (hex(random.randint(0,255)))[2:4]
    if len(octList) >= 3:
        octet3 = octList[2]
    else:
        octet3 = (hex(random.randint(0,255)))[2:4]
    if len(octList) >= 4:
        octet4 = octList[3]
    else:
        octet4 = (hex(random.randint(0,255)))[2:4]
    if len(octList) >= 5:
        octet5 = octList[4]
    else:
        octet5 = (hex(random.randint(0,255)))[2:4]
    if len(octList) >= 6:
        octet6 = octList[5]
    else:
        octet6 = (hex(random.randint(0,255)))[2:4]
    if len(octList) >= 7:
        octet7 = octList[6]
    else:
        octet7 = (hex(random.randint(0,255)))[2:4]
    if len(octList) >= 8:
        octet8 = octList[7]
    else:
        octet8 = (hex(random.randint(0,255)))[2:4]
    if len(octList) >= 9:
        octet9 = octList[8]
    else:
        octet9 = (hex(random.randint(0,255)))[2:4]
    if len(octList) >= 10:
        octet10 = octList[9]
    else:
        octet10 = (hex(random.randint(0,255)))[2:4]
    if len(octList) >= 11:
        octet11 = octList[10]
    else:
        octet11 = (hex(random.randint(0,255)))[2:4]
    if len(octList) >= 12:
        octet12 = octList[11]
    else:
        octet12 = (hex(random.randint(0,255)))[2:4]
    if len(octList) >= 13:
        octet13 = octList[12]
    else:
        octet13 = (hex(random.randint(0,255)))[2:4]
    if len(octList) >= 14:
        octet14 = octList[13]
    else:
        octet14 = (hex(random.randint(0,255)))[2:4]
    if len(octList) >= 15:
        octet15 = octList[14]
    else:
        octet15 = (hex(random.randint(0,255)))[2:4]
    if len(octList) >= 16:
        octet16 = octList[15]
    else:
        octet16 = (hex(random.randint(0,255)))[2:4]

    return IPAddress(str(octet1)+str(octet2)+':'+str(octet3)+str(octet4)+':'+\
                    str(octet5)+str(octet6)+':'+str(octet7)+str(octet8)+':'+\
                    str(octet9)+str(octet10)+':'+str(octet11)+str(octet12)+':'+\
                    str(octet13)+str(octet14)+':'+str(octet15)+str(octet16)), (
                    int('0x'+str(octet1),16),int('0x'+str(octet2),16),
                    int('0x'+str(octet3),16),int('0x'+str(octet4),16),
                    int('0x' + str(octet5), 16), int('0x'+str(octet6),16),
                    int('0x'+str(octet7),16), int('0x'+str(octet8),16),
                    int('0x'+str(octet9),16), int('0x'+str(octet10),16),
                    int('0x'+str(octet11),16), int('0x' + str(octet12), 16),
                    int('0x'+str(octet13),16), int('0x'+str(octet14),16),
                    int('0x'+str(octet15),16), int('0x'+str(octet16),16))

def generateIPv6(octet1=None, octet2=None, octet3=None, octet4=None, octet5=None,
             octet6=None, octet7=None, octet8=None, octet9=None, octet10=None,
             octet11=None, octet12=None, octet13=None, octet14=None,
             octet15=None, octet16=None):
    if octet1 is None:
        octet1 = (hex(random.randint(1,253)))[2:4]
        if len(str(octet1)) == 1: octet1 = '0'+ str(octet1)
    if octet2 is None:
        octet2 = (hex(random.randint(0,255)))[2:4]
        if len(str(octet2)) == 1: octet2 = '0'+ str(octet2)
    if octet3 is None:
        octet3 = (hex(random.randint(0,255)))[2:4]
        if len(str(octet3)) == 1: octet3 = '0'+ str(octet3)
    if octet4 is None:
        octet4 = (hex(random.randint(0,255)))[2:4]
        if len(str(octet4)) == 1: octet4 = '0'+ str(octet4)
    if octet5 is None:
        octet5 = (hex(random.randint(0,255)))[2:4]
        if len(str(octet5)) == 1: octet5 = '0'+ str(octet5)
    if octet6 is None:
        octet6 = (hex(random.randint(0,255)))[2:4]
        if len(str(octet6)) == 1: octet6 = '0'+ str(octet6)
    if octet7 is None:
        octet7 = (hex(random.randint(0,255)))[2:4]
        if len(str(octet7)) == 1: octet7 = '0'+ str(octet7)
    if octet8 is None:
        octet8 = (hex(random.randint(0,255)))[2:4]
        if len(str(octet8)) == 1: octet8 = '0'+ str(octet8)
    if octet9 is None:
        octet9 = (hex(random.randint(0,255)))[2:4]
        if len(str(octet9)) == 1: octet9 = '0'+ str(octet9)
    if octet10 is None:
        octet10 = (hex(random.randint(0,255)))[2:4]
        if len(str(octet10)) == 1: octet10 = '0'+ str(octet10)
    if octet11 is None:
        octet11 = (hex(random.randint(0,255)))[2:4]
        if len(str(octet11)) == 1: octet11 = '0'+ str(octet11)
    if octet12 is None:
        octet12 = (hex(random.randint(0,255)))[2:4]
        if len(str(octet12)) == 1: octet12 = '0'+ str(octet12)
    if octet13 is None:
        octet13 = (hex(random.randint(0,255)))[2:4]
        if len(str(octet13)) == 1: octet13 = '0'+ str(octet13)
    if octet14 is None:
        octet14 = (hex(random.randint(0,255)))[2:4]
        if len(str(octet14)) == 1: octet14 = '0'+ str(octet14)
    if octet15 is None:
        octet15 = (hex(random.randint(0,255)))[2:4]
        if len(str(octet15)) == 1: octet15 = '0'+ str(octet15)
    if octet16 is None:
        octet16 = (hex(random.randint(0,255)))[2:4]
        if len(str(octet16)) == 1: octet16 = '0'+ str(octet16)
    return IPAddress(str(octet1)+str(octet2)+':'+str(octet3)+str(octet4)+':'+\
                    str(octet5)+str(octet6)+':'+str(octet7)+str(octet8)+':'+\
                    str(octet9)+str(octet10)+':'+str(octet11)+str(octet12)+':'+\
                    str(octet13)+str(octet14)+':'+str(octet15)+str(octet16)), (
                    int('0x'+str(octet1),16),int('0x'+str(octet2),16),
                    int('0x'+str(octet3),16),int('0x'+str(octet4),16),
                    int('0x' + str(octet5), 16), int('0x'+str(octet6),16),
                    int('0x'+str(octet7),16), int('0x'+str(octet8),16),
                    int('0x'+str(octet9),16), int('0x'+str(octet10),16),
                    int('0x'+str(octet11),16), int('0x' + str(octet12), 16),
                    int('0x'+str(octet13),16), int('0x'+str(octet14),16),
                    int('0x'+str(octet15),16), int('0x'+str(octet16),16))



def generatePfxLen():
    prefix_len = random.choice(supported_prefix_len)
    if (debug > 0):
        DEBUG("IfcsIP: " + prefix_len)
    return prefix_len

def convertIpStrtoCbyte(ipStr, ipv6=True, ipv6format='.'):
    if (ipv6 == True):
        octets = ipStr.split(ipv6format)
        if ipv6format == ':':
            newoctets = []
            for octet in octets:
                if len(octet) < 4:
                    octet = '0'*(4-len(octet))+octet
                newoctets.append(octet[0:2])
                newoctets.append(octet[2:4])
            octets = newoctets
        ip6Addr = (c_ubyte*len(octets))()
        for i in range(len(octets)):
            ip6Addr[i] = compat_long(octets[i], 16)
        return ip6Addr
    else:
        octets = ipStr.split(".")
        ipAddr = (c_ubyte*len(octets))()
        return ipAddr

def IPv4_mask_to_len(ipv4_mask):
    plen = IPAddress(ipv4_mask).bits().replace('.','').find('0')
    return plen

def prfx_to_tuple(maskLen):
    bits = 0
    for i in compat_xrange(128-maskLen,128):
        bits |= (1 << i)
    octet16 = int(bits % 256)
    octet15 = int((bits >> 8) % 256)
    octet14 = int((bits >> 16) % 256)
    octet13 = int((bits >> 24) % 256)
    octet12 = int((bits >> 32) % 256)
    octet11 = int((bits >> 40) % 256)
    octet10 = int((bits >> 48) % 256)
    octet9 = int((bits >> 56) % 256)
    octet8 = int((bits >> 64) % 256)
    octet7 = int((bits >> 72) % 256)
    octet6 = int((bits >> 80) % 256)
    octet5 = int((bits >> 88) % 256)
    octet4 = int((bits >> 96) % 256)
    octet3 = int((bits >> 104) % 256)
    octet2 = int((bits >> 112) % 256)
    octet1 = int((bits >>120) % 256)

    return  (octet1,octet2,octet3,octet4,octet5,octet6,octet7,octet8,
            octet9, octet10, octet11, octet12, octet13, octet14,
            octet15, octet16)

def IPv4_mask_to_IPv6_mask(mask_v4):
    mask_len = IPv4_mask_to_len(mask_v4)
    return prfx_to_tuple(mask_len)

def IPv4_prfx_to_IPv6_prfx(prfx_v4):
    octets = []
    for i in range(16):
        octets.append(0x00)

    octets[0] = (prfx_v4 >> 24) & 0xFF
    octets[1] = (prfx_v4 >> 16) & 0xFF
    octets[2] = (prfx_v4 >> 8) & 0xFF
    octets[3] = (prfx_v4) & 0xFF

    return(octets[0], octets[1], octets[2], octets[3],
           octets[4], octets[5], octets[6], octets[7],
           octets[8], octets[9], octets[10], octets[11],
           octets[12], octets[13], octets[14], octets[15])

def convertIpv6InttoTuple(ipv6Int):
    octet16 = ipv6Int & 0xff
    octet15 = (ipv6Int >>  8) & 0xff
    octet14 = (ipv6Int >>  16) & 0xff
    octet13 = (ipv6Int >>  24) & 0xff
    octet12 = (ipv6Int >>  32) & 0xff
    octet11 = (ipv6Int >>  40) & 0xff
    octet10 = (ipv6Int >>  48) & 0xff
    octet9 = (ipv6Int >>  56) & 0xff
    octet8 = (ipv6Int >>  64) & 0xff
    octet7 = (ipv6Int >> 72) & 0xff
    octet6 = (ipv6Int >> 80) & 0xff
    octet5 = (ipv6Int >> 88) & 0xff
    octet4 = (ipv6Int >> 96) & 0xff
    octet3 = (ipv6Int >> 104) & 0xff
    octet2 = (ipv6Int >> 112) & 0xff
    octet1 = (ipv6Int >> 120) & 0xff

    return  (octet1,octet2,octet3,octet4,octet5,octet6,octet7,octet8,
            octet9, octet10, octet11, octet12, octet13, octet14,
            octet15, octet16)

def convertIpStrtoIpInt(ipStr, ipv6=False):
    octets = ipStr.split(".")
    words = ipStr.split(":")
    v6split = ipStr.split("::")
    if (ipv6 == False):
        ipInt = (int(octets[0]) << 24) + (int(octets[1]) << 16) +\
                (int(octets[2]) << 8) + (int(octets[3]))
    else:
        ipInt = compat_long(0)
        if len(octets) > 1:
            for i in range(len(octets)):
                shift = 8*((len(octets)-1)-i)
                ipInt = ipInt + (int(octets[i]) << shift)
        elif len(words) > 1:
            # handle abbreviated form
            if len(v6split) == 2:
                words0 = v6split[0].split(":")
                words1 = v6split[1].split(":")
                mid0 = 8 - len(words0) - len(words1)
                for i in range(mid0):
                    words0.append('0000')
                words = words0 + words1
            ipInt = ''.join(words)

    return ipInt

def convertIpInttoIpStr(ipInt, v6=False):
    if v6 == False:
        ipStr = socket.inet_ntoa(struct.pack('>I', ipInt))
        return ipStr
    else:
        return str(IPAddress(ipInt,version=6).format(ipv6_verbose))

def calcDottedNetmask(maskLen, ipFamily = IPv4):
    if ipFamily == IPv4:
        bits = 0
        for i in compat_xrange(32-maskLen,32):
            bits |= (1 << i)
        return convertIpInttoIpStr(bits)

def convertMaskLenToMaskInt(maskLen, ipFamily = IPv4):
    bits = 0
    if ipFamily == IPv4:
        for i in compat_xrange(32-maskLen,32):
            bits |= (1 << i)
    elif ipFamily == IPv6:
        for i in compat_xrange(128-maskLen, 128):
            bits |= (1 <<i)
    return bits

def convertIpPrefixToIpPfxStr(ip, pfxLen, ipFamily = IPv4):
    lpmDictEntry = {}
    mask = 0
    ipLen = 32 if (ipFamily == IPv4) else 64
    ipPfx = int(IPAddress(ip))
    if ipFamily == IPv4:
        mask = int(ctypes.c_uint(~((1 << (ipLen - pfxLen)) - 1)).value)
    else:
        mask = convertMaskLenToMaskInt(pfxLen, ipFamily=IPv6)
    ipPfx = int(ipPfx) & int(mask)

    ipPfxStr = hex(ipPfx) + "/" + str(pfxLen)
    if ipFamily ==IPv4:
        return ipPfxStr
    else:
        return beautifyIPv6Pfx(ipPfxStr, prfxLen=str(pfxLen))

def beautifyIpPfxStr(ipPfxStr):
    ipStr = convertIpInttoIpStr(int(ipPfxStr.split("/")[0], 16))
    pfxLenStr = ipPfxStr.split("/")[1]
    return ipStr + "/" + pfxLenStr

def beautifyMacTuple(macTuple):
    return (''.join(map(hex,macTuple))).replace('0x',':')[1:]


def mcastip2mac(mcast_ip,ver = 'ipv4'):

    if ver == 'ipv6':
        mcast_ip = mcast_ip.split(':')
        octet = []
        octet.append(mcast_ip[6])
        octet.append(mcast_ip[7])
        for i in range(2):
            if len(octet[i]) == 3:
                octet[i] = '0' + octet[i]
            elif len(octet[i]) == 2:
                octet[i] = '00' + octet[i]
            elif len(octet[i]) == 1:
                octet[i] = '000' + octet[i]
        mcast_mac =  '33:33:'
        mcast_mac = mcast_mac + octet[0][0:2] +':' + octet[0][2:4] + ':' + octet[1][0:2] +':' + octet[1][2:4]
    else:
        mcast_mac =  '01:00:5e:'
        octets = mcast_ip.split('.')
        second_oct = int(octets[1]) & 127
        third_oct = int(octets[2])
        fourth_oct = int(octets[3])
        mcast_mac = mcast_mac + format(second_oct,'02x') + ':' + format(third_oct, '02x') + ':' + format(fourth_oct, '02x')
    return mcast_mac

def convertIPv6TupleToIpv6DottedStr(ipv6Tuple, delimiter='.'):
    ipv6_str =''
    if delimiter == '.':
        for i in range(len(ipv6Tuple)):
            ipv6_str = ipv6_str+'.'+str(ipv6Tuple[i])
        return ipv6_str[1:]
    elif delimiter == ':':
        if len(ipv6Tuple) != 16:
            #incorrect input
            sys.exit(1)
        for i in range(len(ipv6Tuple)):
            hex_val = hex(ipv6Tuple[i])[2:]
            if len(hex_val) ==1:
                hex_val = '0' + hex_val
            if i !=0 and i%2 == 0:
                ipv6_str = ipv6_str+':'+hex_val
            else:
                ipv6_str = ipv6_str+hex_val
        return ipv6_str
def beautifyIPv6Pfx(ipv6Net, ip_host = False, prfxLen = None):
    if ip_host == False:
        if ipv6Net.find("L") > 0:
            if len(ipv6Net) < 38 and len(prfxLen)==2:
                ipv6Net = '0x'+'0' * (38-len(ipv6Net))+ipv6Net[2:]
            elif len(ipv6Net) < 37 and len(prfxLen)==1:
                ipv6Net = '0x'+'0' * (37-len(ipv6Net))+ipv6Net[2:]
            ntwk= ipv6Net[2:34]
        else:
            if len(ipv6Net) < 37 and len(prfxLen)==2:
                ipv6Net = '0x'+'0' * (37-len(ipv6Net))+ipv6Net[2:]
            elif len(ipv6Net) < 36 and len(prfxLen)==1:
                ipv6Net = '0x'+'0' * (36-len(ipv6Net))+ipv6Net[2:]
            ntwk= ipv6Net[2:34]
        j = 0
        str_len = len(ntwk)
        for i in range(1,(str_len-1)):
            if i%4 ==0:
                ntwk= ntwk[:i+j]+':'+ntwk[i+j:]
                j +=1
        pfxlen = ipv6Net.split('/')[1]
        return ntwk+'/'+pfxlen
    else:
        if ipv6Net[-1]=='L':
            str_len=35
        else:
            str_len=34
        if len(ipv6Net) < str_len:
            ipv6Net = '0x'+'0' * (35-len(ipv6Net))+ipv6Net[2:]
        ntwk= ipv6Net[2:34]
        j = 0
        str_len = len(ntwk)
        for i in range(1,(str_len-1)):
            if i%4 ==0:
                ntwk= ntwk[:i+j]+':'+ntwk[i+j:]
                j +=1
        return ntwk

#ip_addr is string type
#ipv4: '62.141.199.202'
#ipv6: 'c271:43da:12d6:9fc5:52fc:e04a:3afb:a8fd'
def isUnicastIP(ip_addr, ipv6_family=False):
    if ipv6_family:
        if ip_addr.split(":")[0].startswith('ff') or ip_addr.split(":")[0].startswith('FF'):
            return False
    else:
        ip_addr = compat_listmap(int, ip_addr.split('.'))
        if 224 <= ip_addr[0] <=239 or ip_addr[0] == 255 or ip_addr[1] == 255 or ip_addr[2] == 255 or ip_addr[3] == 255:
            return False
    return True

def main():
    generateIP(10, 11)
    generateIP()
    generateIP(20,21,22)

if __name__ == "__main__":
    main()
