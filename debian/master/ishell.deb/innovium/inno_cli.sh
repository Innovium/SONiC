#!/bin/bash
#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
export PYTHONPATH=${PYTHONPATH}:./
export PYTHONPATH=${PYTHONPATH}:./cmds
export PYTHONPATH=${PYTHONPATH}:./scripts
export PYTHONPATH=${PYTHONPATH}:./utils/
export PYTHONPATH=${PYTHONPATH}:./pyctypes/
export PYTHONPATH=${PYTHONPATH}:../pyctypes/
export PYTHONPATH=${PYTHONPATH}:./testutil
export PYTHONPATH=${PYTHONPATH}:./isai_cmds/
export LD_LIBRARY_PATH=.:${LD_LIBRARY_PATH}:../lib/
export LD_LIBRARY_PATH=.:${LD_LIBRARY_PATH}:./

printhelp() {
    echo "Usage: $0 -c config_file [-g] [-p] [-b version] [-C command] [-F] [-R]"
    echo "       -g Start inno_cli under GDB (optional)"
    echo "       -p Start inno_cli under PDB (optional)"
    echo "       -c IFCS config file (required)"
    echo "       -b Python major version (value: 2 or 3, default: 2)"
    echo "       -C Command to execute after starting CLI (optional)"
    echo "          Repeat the option to specify more than one command"
    echo "          Example: -C \"node create 0\" -C \"ifcs show devport\" "
    echo "       -F Flush command output log file after each write. (optional)"
    echo "       -R Don't start interactive command prompt (optional)"
    echo "          Useful when starting remote shell server with -C option"
    echo "          Example: -C \"node create 0\" -C \"service remote_shell start -a all -l /tmp/myserverlog.txt -f 0\" -F -R"
    echo "       -h Show this message and exit"
}

CONFIGFILE=""
ENV="switch"
GDB=0
PDB=0
CMD=""
PYVER=2
CMD_LIST=()
CMD_LIST_OPT=""
FLUSH_EACH_WRITE=0
SKIP_INTERACTIVE=0

while getopts "gphFRc:e:b:C:" opt; do
    case $opt in
        h)
            printhelp
            exit 1
            ;;
        g)
            GDB=1
            ;;
        p)
            PDB=1
            ;;
        c)
            CONFIGFILE=$OPTARG
            ;;
        e)
            ENV=$OPTARG
            ;;
        b)
            PYVER=$OPTARG
            ;;
        C)
            CMD_LIST+=("$OPTARG")
            ;;
        F)
            FLUSH_EACH_WRITE=1
            ;;
        R)
            SKIP_INTERACTIVE=1
            ;;
        *)
            printhelp
            exit 1
            ;;
    esac
done

shift $(($OPTIND - 1))
REM_ARGS="$@"
if [ ! -z $REM_ARGS ]; then
    echo "Invalid extra argument : $REM_ARGS"
    printhelp
    exit 1
fi

if [ -z "$CONFIGFILE" ]; then
    echo "Config file not set"
    printhelp
    exit 1
fi

if [ ! -f "$CONFIGFILE" ]; then
    echo "Config file does not exist"
    printhelp
    exit 1
fi

if [ -e ifcsshell.log ]; then
    echo "moving ifcsshell.log to ifcsshell.log.bkp"
    mv ifcsshell.log ifcsshell.log.bkp
fi

# User should export PATH and LD_LIBRARY_PATH to point to bin and lib, respectively
if [ $PYVER == 2 ]; then
    PYTHON=python2.7
elif [ $PYVER == 3 ]; then
    PYTHON=python3
else
    echo "Invalid value for -b option"
    printhelp
    exit 1
fi

PDB_OPT=""
if [ $PDB == 1 ]; then
   PDB_OPT="-m pdb"
fi

if (( ${#CMD_LIST[@]} != 0 )); then
    CMD_LIST_OPT="-C "
    for a_cmd in "${CMD_LIST[@]}"; do
        CMD_LIST_OPT="$CMD_LIST_OPT \"$a_cmd\" "
    done
fi
if [ $FLUSH_EACH_WRITE == 1 ]; then
    SCRIPT_OPT="-f "
fi
if [ $SKIP_INTERACTIVE == 1 ]; then
    SKIP_INTERACTIVE_OPT="-R "
fi

if [ $GDB == 1 ]; then
   CMD="gdb --args ${PYTHON} ${PDB_OPT} ifcsshell.py -e $ENV -c $CONFIGFILE $CMD_LIST_OPT $SKIP_INTERACTIVE_OPT"
elif [ $PDB == 1 ]; then
   CMD="${PYTHON} -m pdb ifcsshell.py -e $ENV -c $CONFIGFILE $CMD_LIST_OPT $SKIP_INTERACTIVE_OPT"
else
   CMD="${PYTHON} ifcsshell.py -e $ENV -c $CONFIGFILE $CMD_LIST_OPT $SKIP_INTERACTIVE_OPT"
fi

script $SCRIPT_OPT -c "$CMD" ifcsshell.log
