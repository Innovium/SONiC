#-------------------------------------------------------------------------------
# * Copyright (c) Innovium, Inc., 2017
# *
# * This material is proprietary to Innovium. All rights reserved.
# * The methods and techniques described herein are considered trade secrets
# * and/or confidential. Reproduction or distribution, in whole or in part, is
# * forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------
"""PFC Stats display
  Typical command usage examples:

    For non-verbose output:
    run pfcstats

    For verbose output:
    run pfcstats --verbose
    run pfcstats -v

    For help in usage:
    run pfcstats -h
"""

import sys
import argparse
from collections import OrderedDict
from print_table import PrintTable
from verbosity import log, log_dbg, log_err
from utils.compat_util import *
import ctypes
ifcs_ctypes = sys.modules['ifcs_ctypes']


class PfcStats:

    def __init__(self, args):
        self._node_id = 0
        self._fp_devports = []
        self._stat_ids = [
            ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_PFC,
            ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_PFC
        ]
        self._stat_id_display_names = ['rx_frames_pfc', 'tx_frames_pfc']
        self._pfc_stats = OrderedDict()
        self._verbose_output = False

        try:
            self._parse_args(args)
            self._fetch_and_process_all_fp_ports()
            self._display_stats()
        except:
            log_dbg(
                1, 'Error occurred for pfcstats command with arguments {}:\n{}'.
                format(args, sys.exc_info()))

    def _status_to_string(self, rc):
        return compat_bytesToStr(ifcs_ctypes.ifcs_status_to_string(rc))

    def _parse_args(self, args):
        args = args.strip()
        if not args:
            return  # No parsing needed.
        args = args.split()
        log_dbg(1, 'pfcsstats command: parsing arguments: {}'.format(args))
        parser = argparse.ArgumentParser(
            prog='run pfcstats',
            description='Devport PFC Status',
            formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-v',
                            '--verbose',
                            dest='verbose',
                            help='Verbose output',
                            action='store_true')
        try:
            res = parser.parse_args(args)
            self._verbose_output = res.verbose
        except:
            if len(args) == 1 and args[0] in ['-h', '--help']:
                raise ValueError('Help option is provided to the command')
            msg = 'Missing arguments or invalid arguments provided'
            log_err(msg)
            raise ValueError(msg)

    def _fetch_and_process_all_fp_ports(self):
        log_dbg(1, 'pfcsstats command: fetch fp ports and get stats')

        # Fetch all ETH devports
        def myCallback(node_id, devport, attr_count, attr_list, user_data):
            self._fp_devports.append(devport)

        callback_type = ctypes.CFUNCTYPE(
            ifcs_ctypes.UNCHECKED(None), ifcs_ctypes.ifcs_node_id_t,
            ifcs_ctypes.ifcs_devport_t, ctypes.c_uint32,
            ctypes.POINTER(ifcs_ctypes.ifcs_attr_t), ctypes.POINTER(None))
        callback = callback_type(myCallback)
        callback_p = compat_funcPointer(callback,
                                        ifcs_ctypes.ifcs_devport_user_cb_t)
        devport_count = ctypes.c_uint32()

        attr = ifcs_ctypes.ifcs_attr_t()
        assert ifcs_ctypes.ifcs_attr_t_init(
            pointer(attr)) == ifcs_ctypes.IFCS_SUCCESS
        assert ifcs_ctypes.ifcs_attr_t_id_set(
            pointer(attr),
            ifcs_ctypes.IFCS_DEVPORT_ATTR_TYPE) == ifcs_ctypes.IFCS_SUCCESS
        assert ifcs_ctypes.ifcs_attr_t_value_u32_set(
            pointer(attr),
            ifcs_ctypes.IFCS_DEVPORT_TYPE_ETH) == ifcs_ctypes.IFCS_SUCCESS
        rc = ifcs_ctypes.ifcs_devport_get_all(self._node_id, 1, pointer(attr),
                                              callback_p, None,
                                              pointer(devport_count))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            msg = 'Failed to get all ETH devport rc: {0}'.format(
                self._status_to_string(rc))
            log_err(msg)
            raise KeyError(msg)

        log_dbg(1, 'pfcsstats command: fp ports {}'.format(self._fp_devports))

        # Get specific stats for all ETH devports
        actual_count = ctypes.c_uint32()
        stats_count = len(self._stat_ids)
        stat_id_list = (ifcs_ctypes.ifcs_devport_stats_id_t * stats_count)()
        for idx in range(stats_count):
            stat_id_list[idx] = self._stat_ids[idx]
        stat_id_list_ptr = compat_pointer(stat_id_list,
                                          ifcs_ctypes.ifcs_devport_stats_id_t)

        for devport in sorted(self._fp_devports):
            counter_list = (ctypes.c_uint64 * stats_count)()
            counter_list_ptr = compat_pointer(counter_list, ctypes.c_uint64)
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_devport_stats_get(self._node_id, devport,
                                                   stats_count,
                                                   stat_id_list_ptr,
                                                   counter_list_ptr,
                                                   pointer(actual_count)))
            if rc != ifcs_ctypes.IFCS_SUCCESS and rc != ifcs_ctypes.IFCS_UNSUPPORTED:
                msg = 'Stat get failed for ETH devport {} rc: {}'.format(
                    devport, self._status_to_string(rc))
                log_err(msg)
                raise KeyError(msg)
            self._pfc_stats[devport] = [x for x in counter_list]

    def _display_verbose_stats(self):
        log_dbg(1, 'pfcsstats command: display verbose stats')
        log('Total devport count: {} '.format(len(self._fp_devports)))
        table = PrintTable()
        table.add_row(['devport'] + self._stat_id_display_names)
        for devport in self._pfc_stats:
            table.add_row([devport] + self._pfc_stats[devport])
        table.print_table()
        table.reset_table()
        log('Total devport count: {0} '.format(len(self._fp_devports)))

    def _display_non_verbose_stats(self):
        log_dbg(1, 'pfcsstats command: display non-verbose stats')
        for devport in self._pfc_stats:
            res = [devport] + self._pfc_stats[devport]
            log(' '.join([str(x) for x in res]))

    def _display_stats(self):
        if self._verbose_output:
            self._display_verbose_stats()
        else:
            self._display_non_verbose_stats()


def main(args):
    x = PfcStats(args)
