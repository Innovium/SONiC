#*******************************************************************************
#*              (c), Copyright 2022, Marvell International Ltd.                *
#* THIS CODE CONTAINS CONFIDENTIAL INFORMATION OF MARVELL SEMICONDUCTOR, INC.  *
#* NO RIGHTS ARE GRANTED HEREIN UNDER ANY PATENT, MASK WORK RIGHT OR COPYRIGHT *
#* OF MARVELL OR ANY THIRD PARTY. MARVELL RESERVES THE RIGHT AT ITS SOLE       *
#* DISCRETION TO REQUEST THAT THIS CODE BE IMMEDIATELY RETURNED TO MARVELL.    *
#* THIS CODE IS PROVIDED "AS IS". MARVELL MAKES NO WARRANTIES, EXPRESSED,      *
#* IMPLIED OR OTHERWISE, REGARDING ITS ACCURACY, COMPLETENESS OR PERFORMANCE.  *
#*******************************************************************************
""" DTM partition shared size display
  Typical command usage examples:

    run partss
"""

import sys
from verbosity import log, log_dbg, log_err
from utils.compat_util import *
import ctypes
ifcs_ctypes = sys.modules['ifcs_ctypes']


class PartSs:

    def __init__(self, args):
        self._node_id = 0
        self._lossy_dtm_shared_size = 0
        self._lossless_dtm_shared_size = 0

        try:
            self._fetch_data()
            self._display_results()
        except:
            log_dbg(
                1, 'Error occurred for partss command with arguments {}:\n{}'.
                format(args, sys.exc_info()))

    def _status_to_string(self, rc):
        return compat_bytesToStr(ifcs_ctypes.ifcs_status_to_string(rc))


    def getAlldtm_buffer_partition(self):

        dtm_buffer_partition_list = []
        def myCallback(node_id, arg, attr_count, attr_list, user_data):
            key_obj = ifcs_ctypes.ifcs_dtm_buffer_partition_t()
            memmove(pointer(key_obj), arg, sizeof(key_obj))
            dtm_buffer_partition_list.append(pointer(key_obj))

        callback_type = ctypes.CFUNCTYPE(
            ifcs_ctypes.UNCHECKED(None),
            ifcs_ctypes.ifcs_node_id_t,
            ctypes.POINTER(ifcs_ctypes.ifcs_dtm_buffer_partition_t), ctypes.c_uint32,
            ctypes.POINTER(ifcs_ctypes.ifcs_attr_t), ctypes.POINTER(None))
        callback = callback_type(myCallback)
        callback_p = compat_funcPointer(
            callback, ifcs_ctypes.ifcs_dtm_buffer_partition_user_cb_t)

        try:
            rc = ifcs_ctypes.ifcs_dtm_buffer_partition_get_all(
                self._node_id, None, 0, None, callback_p, 0, None)

            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err("Failed to get all dtm_buffer_partition rc: {0}".format(
                    self._status_to_string(rc)))
        except Exception as e:
            log_err(" Failed to get all dtm_buffer_partition : {0} ".format(e))
            raise e
        return dtm_buffer_partition_list

    def getAttr(self,
                dtm_buffer_partition,
                attr,
                attrPtr,
                attrCount=1,
                ignore_notfound_err=False):
        actual_count = ctypes.c_uint32()
        actual_count_p = pointer(actual_count)

        rc = ifcs_ctypes.IFCS_STATUS_REASON(
            ifcs_ctypes.ifcs_dtm_buffer_partition_attr_get(
                self._node_id, dtm_buffer_partition, attrCount, attrPtr,
                actual_count_p))
        if ignore_notfound_err and rc == ifcs_ctypes.IFCS_NOTFOUND:
            # Don't display error message for an expected error code.
            # Raise exception for handling.
            log_dbg(
                1,
                "get attr: dtm_buffer_partition attr get first attempt failed. dtm_buffer_partition: {},  rc: {}"
                .format(dtm_buffer_partition, self._status_to_string(rc)))
            raise KeyError(self.not_found_exc_msg.format(rc))
        if rc != ifcs_ctypes.IFCS_SUCCESS and rc != ifcs_ctypes.IFCS_LENGTH_MISMATCH and rc != ifcs_ctypes.IFCS_UNSUPPORTED:
            log_err("dtm_buffer_partition getAttr failed: rc : {0} ".format(
                self._status_to_string(rc)))
            raise KeyError
        return actual_count

    def getType(self, dtm_buffer_partition, ignore_notfound_err=False):
        attr = ifcs_ctypes.ifcs_attr_t()
        attr_p = pointer(attr)
        attr.id = ifcs_ctypes.IFCS_DTM_BUFFER_PARTITION_ATTR_TYPE
        self.getAttr(dtm_buffer_partition, attr, attr_p, 1, ignore_notfound_err)

        if (attr.bitmap.u32) != 1:
            return None
        return attr.value.u32


    def getSharedSize(self, dtm_buffer_partition, ignore_notfound_err=False):
        attr = ifcs_ctypes.ifcs_attr_t()
        attr_p = pointer(attr)
        attr.id = ifcs_ctypes.IFCS_DTM_BUFFER_PARTITION_ATTR_SHARED_SIZE
        self.getAttr(dtm_buffer_partition, attr, attr_p, 1, ignore_notfound_err)
        if (attr.bitmap.u32) != 1:
            return None
        return attr.value.u32


    def _fetch_data(self):
        log_dbg(1, 'partss command: fetch DTM partition shared size')


        try:
            all_dtm_buffer_partition = self.getAlldtm_buffer_partition()
        except:
            log_err(" Failed to get all dtm_buffer_partition")
            return
        all_dtm_buffer_partition = sorted(all_dtm_buffer_partition,
                                          key=lambda x: str(x.contents.ib))
        all_dtm_buffer_partition = sorted(
            all_dtm_buffer_partition,
            key=lambda x: str(x.contents.partition_id))
        log_dbg(1, "Total dtm_buffer_partition count: {0} ".format(
            len(all_dtm_buffer_partition)))
        self._data = { "LOSSY":[], "LOSSLESS":[], "HYBRID":[] }
        for dtm_buffer_partition in all_dtm_buffer_partition:
            type = self.getType(dtm_buffer_partition, False)
            shared_size = self.getSharedSize(dtm_buffer_partition, False)
            if type == ifcs_ctypes.IFCS_BUFFER_PARTITION_TYPE_LOSSY:
                self._data["LOSSY"].append(shared_size)
            elif type == ifcs_ctypes.IFCS_BUFFER_PARTITION_TYPE_LOSSLESS:
                self._data["LOSSLESS"].append(shared_size)
            elif type == ifcs_ctypes.IFCS_BUFFER_PARTITION_TYPE_HYBRID:
                self._data["HYBRID"].append(shared_size)

    def _display_results(self):
        if len(self._data["LOSSY"]) > 0:
            log("LS: " + " ".join(str(x) for x in self._data["LOSSY"]))
        if len(self._data["LOSSLESS"]) > 0:
            log("LL: " + " ".join(str(x) for x in self._data["LOSSLESS"]))
        if len(self._data["HYBRID"]) > 0:
            log("HB: " + " ".join(str(x) for x in self._data["HYBRID"]))

def main(args):
    x = PartSs(args)
