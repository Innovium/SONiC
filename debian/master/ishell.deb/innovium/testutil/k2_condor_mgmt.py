#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2020
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

from ifcs_ctypes import *
from ctypes import *

APB_READ = 0
APB_WRITE = 1

# K2
NUM_IBS = 2
NUM_PICS_PER_IB = 8
NUM_LANES_PER_PIC = 8
NUM_LANES_PER_IB = NUM_PICS_PER_IB * NUM_LANES_PER_PIC
NUM_LANES = NUM_IBS * NUM_PICS_PER_IB * NUM_LANES_PER_PIC

def init():
    pass

def lane_from_ib_pic_piclane(ib, pic, piclane):
    return ib * NUM_LANES_PER_IB + pic * NUM_LANES_PER_PIC + piclane

def laneToIbPicLaneidx(lane):
    ib = lane // NUM_LANES_PER_IB
    lane_in_ib = lane - ib * NUM_LANES_PER_IB
    pic = lane_in_ib // NUM_LANES_PER_PIC
    lane_idx = lane_in_ib - pic * NUM_LANES_PER_PIC
    return (ib, pic, lane_idx)

def apb_write(addr, val, ib, pic, lane):
    val = (val + 0x10000) & 0xffff
    addr = (addr + 0x10000) & 0xffff

    rsp_data = c_uint(0)
    im_devport_apb_access(0, ib, pic, lane, APB_WRITE,
                          addr, val, byref(rsp_data))

def apb_read(addr, ib, pic, lane):
    rsp_data = c_uint(0)
    im_devport_apb_access(0, ib, pic, lane, APB_READ,
                          addr, 0, byref(rsp_data))
    return rsp_data.value

def rregLane(addr,lane=0):
    ib, pic, laneidx = laneToIbPicLaneidx(lane)
    return apb_read(addr, ib, pic, laneidx)

def rreg32Lane(addr, lane=0):
    ib, pic, laneidx = laneToIbPicLaneidx(lane)
    return ((apb_read(addr, ib, pic, laneidx) << 16) +
            apb_read(addr+1, ib, pic, laneidx))

def wregLane(addr, val, lane=0):
    ib, pic, laneidx = laneToIbPicLaneidx(lane)
    return apb_write(addr, val, ib, pic, laneidx)
