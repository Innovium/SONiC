#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2017
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

from ctypes import *
from ifcs_ctypes import *
from itertools import *
from utils.compat_util import *
import threading

midlock = threading.Lock()

def write32(addr, datalist):
    midlock.acquire()
    rc = node_pci_reg_write32(0, MID_ADR, addr)
    assert rc == IFCS_SUCCESS, "pci reg write failed: rc = " + str(rc)

    for data in datalist:
        rc = node_pci_reg_write32(0, MID_DAT32, data)
        assert rc == IFCS_SUCCESS, "pci reg write failed: rc = " + str(rc)
    midlock.release()

def write64(addr, datalist):
    midlock.acquire()
    regval = c_uint32(0)

    regval = addr;
    rc = node_pci_reg_write32(0, MID_ADR, regval)
    assert rc == IFCS_SUCCESS, "pci reg write failed: rc = " + str(rc)

    for data in datalist:
        regval = data & 0x00000000ffffffff
        rc = node_pci_reg_write32(0, MID_DAT64_LO, regval)
        assert rc == IFCS_SUCCESS, "pci reg write failed: rc = " + str(rc)

        regval = data >> 32
        rc = node_pci_reg_write32(0, MID_DAT64_HI, regval)
        assert rc == IFCS_SUCCESS, "pci reg write failed: rc = " + str(rc)
    midlock.release()

def read32(addr, count):
    midlock.acquire()
    rc = node_pci_reg_write32(0, MID_ADR, addr)
    assert rc == IFCS_SUCCESS, "pci reg write failed: rc = " + str(rc)
    regval = c_uint(0)
    out = []
    for _ in range(count):
        rc = node_pci_reg_read32(0, MID_DAT32, byref(regval))
        assert rc == IFCS_SUCCESS, "pci reg read failed: rc = " + str(rc)
        out.append(regval.value)
    midlock.release()
    return out

def read64(addr, count):
    midlock.acquire()
    rc = node_pci_reg_write32(0, MID_ADR, addr)
    assert rc == IFCS_SUCCESS, "pci reg write failed: rc = " + str(rc)

    data_val = c_uint64(0)
    lo_regval = c_uint32(0)
    hi_regval = c_uint32(0)
    out = []
    for _ in range(count):
        rc = node_pci_reg_read32(0, MID_DAT64_LO, byref(lo_regval))
        assert rc == IFCS_SUCCESS, "pci reg read failed: rc = " + str(rc)
        rc = node_pci_reg_read32(0, MID_DAT64_HI, byref(hi_regval))
        assert rc == IFCS_SUCCESS, "pci reg read failed: rc = " + str(rc)

        data_val.value = hi_regval.value
        data_val.value <<= 32
        data_val.value += lo_regval.value
        out.append(data_val.value)

    midlock.release()
    return out

# still requires 32-bit alignment, but takes data as little-endian bytearray
def write8(addr, data8):
    data8 = data8 + bytearray([0, 0, 0]) # last word will get dropped, so add 3 bytes of zeros to capture any remainder
    # little-endian packing into 32-bit words:
    data32 = data8[::4]
    data32 = compat_listmap(sum, zip(data32, [b << 8 for b in data8[1::4]]))
    data32 = compat_listmap(sum, zip(data32, [b << 16 for b in data8[2::4]]))
    data32 = compat_listmap(sum, zip(data32, [b << 24 for b in data8[3::4]]))

    write32(addr, data32)

def read8(addr, count):
    midlock.acquire()
    rc = node_pci_reg_write32(0, MID_ADR, addr & 0xfffffffc)
    assert rc == IFCS_SUCCESS, "pci reg write failed: rc = " + str(rc)
    regval = c_uint(0)
    out = []
    rc = node_pci_reg_read32(0, MID_DAT32, byref(regval))
    assert rc == IFCS_SUCCESS, "pci reg read failed: rc = " + str(rc)
    while (count):
        if ((addr & 0x3) == 0x00): out.append((regval.value & 0x000000ff))
        if ((addr & 0x3) == 0x01): out.append((regval.value & 0x0000ff00) >> 8)
        if ((addr & 0x3) == 0x02): out.append((regval.value & 0x00ff0000) >> 16)
        if ((addr & 0x3) == 0x03): out.append((regval.value & 0xff000000) >> 24)
        count -= 1
        if (count > 0 and ((addr & 0x3) == 0x03)):
            rc = node_pci_reg_read32(0, MID_DAT32, byref(regval))
            assert rc == IFCS_SUCCESS, "pci reg read failed: rc = " + str(rc)
        addr += 1
    midlock.release()
    return out
