#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

# -*- coding: utf-8 -*-
###################################################################################################
# CREDO Semiconductors Inc. Confidential
# Modifications / Additions Innovium Inc 2019
#
# Rev 4.0 PAM4 and NRZ SerDes Adaptation Routines, Supported Data Rates: 10G,12.5G,25G,37G,53G,56G
#
###################################################################################################

from __future__ import division
import re, sys, os, time
import collections
import math
import struct, datetime
from utils.compat_util import *

import k2_condor_mgmt as mgmt
from k2_condor_mgmt import rregLane
from k2_condor_mgmt import rreg32Lane
from k2_condor_mgmt import wregLane

try:
    import numpy
    numpyAvailable = True
except:
    numpyAvailable = False

from collections import Counter
import functools
import distutils.util
import pprint

reset_color_str = '\x1b[0m'
def color_block(val):
    return '\x1b[48;5;%dm ' % val

gDebugTuning = False # en/dis debug print-outs during Serdes Tuning mode
gDebugEngineering = False # en/dis debug print-outs during Serdes Engineering mode
#gFfeTune1En=False    # Run FFE Fine Search routine
#gFfeTune2En=False  # Run FFE Adaptation routine
gShowTuningSteps=True  # Show Tuning Step Numbers while running
gBackgroundCalEn=True

fw_file_hash_code=0
fw_file_crc_code=0

# fw hash_code to fw date
fw_hash_date_dict={}

#***********************************************************
# Pterosaur-LR Chip Library and PAM4/NRZ Register Map Definition
#***********************************************************

# FEC Analyzer timer
fec_timer= 'dis'

saved_prbs_err_reset_time = [None] * mgmt.NUM_LANES
saved_prbs_err_last_val = [0] * mgmt.NUM_LANES

#RX MONITOR Varaibles
rx_mon_time_keeper = [0] * mgmt.NUM_LANES
rx_mon_time_elapsed = [0] * mgmt.NUM_LANES
rx_mon_status = ['-'] * mgmt.NUM_LANES
rx_mon_eye0 = ['-'] * mgmt.NUM_LANES
rx_mon_eye1 = ['-'] * mgmt.NUM_LANES
rx_mon_eye2 = ['-'] * mgmt.NUM_LANES
rx_mon_daq = ['-'] * mgmt.NUM_LANES
rx_mon_prbs_cnt = ['-'] * mgmt.NUM_LANES
rx_mon_prbs_ber = ['-'] * mgmt.NUM_LANES
rx_mon_prefec_cnt = ['-'] * mgmt.NUM_LANES
rx_mon_prefec_ber = ['-'] * mgmt.NUM_LANES
rx_mon_postfec_cnt = ['-'] * mgmt.NUM_LANES
rx_mon_postfec_ber = ['-'] * mgmt.NUM_LANES

LANE_RDY = 0
LANE_NOT_RDY =  1
LANE_NOT_GOOD = 2

lane_status_str = ['Ready', 'Not Ready', 'Not Good']

MDIO_CONNECTED = 0
MDIO_DISCONNECTED =  1
MDIO_LOST_CONNECTION = 2

chip_name = 'Pterosaur_LR'
chip_reset_addr = 0x980d
chip_reset_bi_loc = 0 # [11,0]
chip_soft_reset_val  = 0x888
chip_reg_reset_val   = 0x999
chip_logic_reset_val = 0x777
chip_cpu_reset_val   = 0xAAA

# global gPam4NrzMode; gPam4NrzMode = ['pam4'] * NUM_LANES
global gRxInputMode; gRxInputMode = ['ac'] * mgmt.NUM_LANES

global gPolTX;      gPolTX = 0
global gPolRX;      gPolRX = 1
global gGCTX;       gGCTX = [1] * mgmt.NUM_LANES
global gGCRX;       gGCRX = [1] * mgmt.NUM_LANES
global gMSBLSBTX;   gMSBLSBTX = 0
global gMSBLSBRX;   gMSBLSBRX = 0
global gPCTX;       gPCTX = [1] * mgmt.NUM_LANES
global gPCRX;       gPCRX = [1] * mgmt.NUM_LANES


## PLL and Frequency related parameters
global gTargetDataRate; gTargetDataRate=[25] * mgmt.NUM_LANES
global gDataRate; gDataRate = [25] * mgmt.NUM_LANES
global gRefclkFreq;  gRefclkFreq = 156.25      # is constant

## Get VCO CAP from Table (True) or From PLL Lock (False)
#global gPllVcocapFromTable; gPllVcocapFromTable=False

global gMrMode; gMrMode='dis'
global gChannelEstimate; gChannelEstimate=[1.010] * mgmt.NUM_LANES
global gChannelOf; gChannelOf=[1] * mgmt.NUM_LANES
global gChannelHf; gChannelHf=[1] * mgmt.NUM_LANES
global gAdaptationTime; gAdaptationTime=1.0
global gAdaptationCount; gAdaptationCount=0
#global gNrzSubRateMode; gNrzSubRateMode=[False] * NUM_LANES
global gSoftResetRegList; gSoftResetRegList = []
global gReadOnlyRegList
global gReadOnlyRegListBuildEn; gReadOnlyRegListBuildEn=1
global gPreAdaptationFullRegList
global gPostAdaptationFullRegList
global gAdaptationRegList
global gDfeInitPointer; gDfeInitPointer = -1

## Common PAM4/NRZ Registers, Downloable Firmware Related
fw_load_magic_word_addr = 0x9814
fw_load_magic_word = 0x6a6a      # for NRZ+PAM4 FW

fw_cmd_addr = 0x9815
fw_cmd_detail_addr = 0x9816
fw_watchdog_timer_addr = 0x9810
fw_reg_value_addr = 0x9812

# Firmware commands
fw_halt_cmd = 0xD000
fw_crc_cmd = 0xF001
fw_hash_cmd = 0xF000
fw_reg_read_cmd = 0xE010
fw_reg_write_cmd = 0xE020
fw_eyemon_start_cmd = 0x1000
fw_eyemon_prog_cmd = 0x2000
fw_eyemon_read_cmd = 0x3000
fw_debug_cmd = 0xB000

# Firmware registers

## Common PAM4/NRZ Registers, Downloable Firmware Related
fw_tuning_start_bp = 'bp1'                 # 'bp1' for both PAM4 and NRZ tuning FWs
fw_tuning_ctrl_addr = 0x980F

fw_tuning_ctrl_go_bit_loc = [15]           # All modes - permission to proceed

fw_tuning_ctrl_optics_mode_bit_loc = [1]   # NRZ FW=> 1: Optics mode enabled, 0: Not optics mode
fw_tuning_ctrl_temp_track_en_bit_loc = [2] # NRZ FW=> 1: 25G Disable Temperture Tracking, 0: 25G Enable delta Temperture Tracking
fw_tuning_ctrl_rx_debug_mode_bit_loc=[4]   # NRZ FW=> 1: CTLE Full manual mode (overrides 980F[0]), 0: Not full manual mode (control given to 980F[0])

fw_tuning_ctrl_ffe_adapt_dis_bit_loc = [11]# PAM4 FW =>
fw_tuning_ctrl_background_cal_bit_loc=[10] # PAM4 FW =>
fw_tuning_ctrl_ffe_adapt_en_bit_loc = [9]  # PAM4 FW =>
fw_tuning_ctrl_data_rate_bit_loc = [5,3]   # PAM4 FW => speed indicator to FW: 0: 37G, 1: undefined, 2: 53G, 3: 56G

fw_nrz_data_rate_1 = 7
fw_nrz_data_rate_10 = 1
fw_nrz_data_rate_16 = 11
fw_nrz_data_rate_25 = 3
fw_nrz_data_rate_28 = 5

fw_pam4_data_rate_37 = 6
fw_pam4_data_rate_53 = 9
fw_pam4_data_rate_56 = 10

fw_data_rate_map = {
    1: fw_nrz_data_rate_1,
    10: fw_nrz_data_rate_10,
    16: fw_nrz_data_rate_16,
    25: fw_nrz_data_rate_25,
    28: fw_nrz_data_rate_28,
    37: fw_pam4_data_rate_37,
    53: fw_pam4_data_rate_53,
    56: fw_pam4_data_rate_56
}

fw_tuning_status_addr = 0x9811
fw_tuning_status_in_progress_bit_loc = [0]                 # PAM4 FW =>
fw_tuning_status_done_link_almost_rdy_bit_loc = [1] # PAM4 FW =>
fw_tuning_status_done_bit_loc = [2]                 # PAM4 FW =>
fw_tuning_status_done_link_not_rdy_bit_loc = [3]    # PAM4 FW =>

## Common PAM4/NRZ Registers, Analog registers
ctle_gain1_addr = 0xF5
ctle_gain1_bit_loc = [14,8]  # was [11,8], but set_serdes_globals overrode for 7.0
ctle_gain2_addr = 0xF5
ctle_gain2_bit_loc = [6,0]   # was [7,4], but set_serdes_globals overrode for 7.0
#ctle_map2_addr = 0x48
#ctle_map1_addr = 0x49
#ctle_map0_addr = 0x4a
ctle_fine_addr = 0xf9
ctle_fine_bit_loc = [12,10]

## Common PAM4/NRZ Registers, PLL and Frequency related registers
pll_div4_addr = 0xFF
pll_div4_bit_loc = [5]
pll_n_addr = 0xFD
pll_n_bit_loc = [15,7]
pll_nfrac_addr = 0x1FA
pll_lvcocap_addr = 0xFC
pll_lvcocap_bit_loc = [15,10]
pll_sdm_addr = 0x1ff
pll_sdm_en_bit_loc = [14]
pll_sdm_order_bit_loc = [10, 9]

pll_lvcocap_table=[[32.96875,  0], #   0, []
    [32.81250,   0], #   0, []
    [32.65625,   0], #   0, []
    [32.50000,   0], #   0, []
    [32.34375,   0], #   0, [0]
    [32.18750,   0], #   0, [0]
    [32.03125,   0], #   0, [0]
    [31.87500,   0], #   0, [0]
    [31.71875,   0], #   0, [0]
    [31.56250,   0], #   0, [0]
    [31.40625,   0], #   0, [0]
    [31.25000,   0], #   0, [0]
    [31.09375,   0], #   0, [0]
    [30.93750,   0], #   0, [0]
    [30.78125,   0], #   0, [0]
    [30.62500,   2], #   1, [0, 1, 2, 3]
    [30.46875,   2], #   1, [0, 1, 2, 3]
    [30.31250,   2], #   1, [0, 1, 2, 3]
    [30.15625,   2], #   1, [0, 1, 2, 3, 4]
    [30.00000,   2], #   1, [0, 1, 2, 3, 4]
    [29.84375,   2], #   1, [0, 1, 2, 3, 4]
    [29.68750,   3], #   1, [0, 1, 2, 3, 4, 5]
    [29.53125,   3], #   1, [0, 1, 2, 3, 4, 5]
    [29.37500,   3], #   1, [0, 1, 2, 3, 4, 5]
    [29.21875,   3], #   1, [0, 1, 2, 3, 4, 5, 6]
    [29.06250,   3], #   1, [0, 1, 2, 3, 4, 5, 6]
    [28.90625,   4], #   2, [0, 1, 2, 3, 4, 5, 6, 7]
    [28.75000,   4], #   2, [0, 1, 2, 3, 4, 5, 6, 7]
    [28.59375,   4], #   2, [0, 1, 2, 3, 4, 5, 6, 7]
    [28.43750,   5], #   2, [1, 2, 3, 4, 5, 6, 7, 8]
    [28.28125,   5], #   3, [1, 2, 3, 4, 5, 6, 7, 8]
    [28.12500,   5], #   3, [2, 3, 4, 5, 6, 7, 8]
    [27.96875,   6], #   4, [2, 3, 4, 5, 6, 7, 8, 9]
    [27.81250,   6], #   4, [2, 3, 4, 5, 6, 7, 8, 9]
    [27.65625,   6], #   4, [3, 4, 5, 6, 7, 8, 9]
    [27.50000,   7], #   5, [3, 4, 5, 6, 7, 8, 9, 10]
    [27.34375,   7], #   5, [4, 5, 6, 7, 8, 9, 10]
    [27.18750,   8], #   5, [4, 5, 6, 7, 8, 9, 10, 11]
    [27.03125,   8], #   5, [4, 5, 6, 7, 8, 9, 10, 11]
    [26.87500,   9], #   6, [5, 6, 7, 8, 9, 10, 11, 12]
    [26.71875,   9], #   6, [5, 6, 7, 8, 9, 10, 11, 12]
    [26.56250,  10], #   7, [6, 7, 8, 9, 10, 11, 12, 13]
    [26.40625,  10], #   7, [6, 7, 8, 9, 10, 11, 12, 13]
    [26.25000,  10], #  10, [7, 8, 9, 10, 11, 12, 13]
    [26.09375,  11], #  11, [7, 8, 9, 10, 11, 12, 13, 14]
    [25.93750,  11], #  11, [8, 9, 10, 11, 12, 13, 14]
    [25.78125,  12], #  12, [8, 9, 10, 11, 12, 13, 14, 15]
    [25.62500,  12], #  12, [8, 9, 10, 11, 12, 13, 14, 15]
    [25.46875,  13], #  13, [9, 10, 11, 12, 13, 14, 15, 16]
    [25.31250,  13], #  13, [10, 11, 12, 13, 14, 15, 16]
    [25.15625,  14], #  14, [10, 11, 12, 13, 14, 15, 16, 17]
    [25.00000,  14], #  14, [10, 11, 12, 13, 14, 15, 16, 17]
    [24.84375,  15], #  15, [11, 12, 13, 14, 15, 16, 17, 18]
    [24.68750,  16], #  16, [12, 13, 14, 15, 16, 17, 18, 19]
    [24.53125,  16], #  16, [12, 13, 14, 15, 16, 17, 18, 19]
    [24.37500,  17], #  17, [13, 14, 15, 16, 17, 18, 19, 20]
    [24.21875,  17], #  17, [13, 14, 15, 16, 17, 18, 19, 20]
    [24.06250,  18], #  18, [14, 15, 16, 17, 18, 19, 20, 21]
    [23.90625,  18], #  18, [14, 15, 16, 17, 18, 19, 20, 21]
    [23.75000,  19], #  19, [15, 16, 17, 18, 19, 20, 21, 22]
    [23.59375,  20], #  20, [16, 17, 18, 19, 20, 21, 22, 23]
    [23.43750,  20], #  20, [16, 17, 18, 19, 20, 21, 22, 23]
    [23.28125,  21], #  21, [17, 18, 19, 20, 21, 22, 23, 24]
    [23.12500,  22], #  22, [18, 19, 20, 21, 22, 23, 24, 25]
    [22.96875,  22], #  22, [18, 19, 20, 21, 22, 23, 24, 25]
    [22.81250,  23], #  23, [19, 20, 21, 22, 23, 24, 25, 26]
    [22.65625,  24], #  24, [20, 21, 22, 23, 24, 25, 26, 27]
    [22.50000,  24], #  24, [20, 21, 22, 23, 24, 25, 26, 27]
    [22.34375,  25], #  25, [21, 22, 23, 24, 25, 26, 27, 28]
    [22.18750,  26], #  26, [22, 23, 24, 25, 26, 27, 28, 29]
    [22.03125,  26], #  26, [23, 24, 25, 26, 27, 28, 29]
    [21.87500,  27], #  27, [24, 25, 26, 27, 28, 29, 30]
    [21.71875,  28], #  28, [24, 25, 26, 27, 28, 29, 30, 31]
    [21.56250,  29], #  29, [25, 26, 27, 28, 29, 30, 31, 32]
    [21.40625,  30], #  30, [26, 27, 28, 29, 30, 31, 32, 33]
    [21.25000,  31], #  31, [27, 28, 29, 30, 31, 32, 33, 34]
    [21.09375,  32], #  32, [28, 29, 30, 31, 32, 33, 34, 35]
    [20.93750,  32], #  32, [28, 29, 30, 31, 32, 33, 34, 35]
    [20.78125,  33], #  33, [29, 30, 31, 32, 33, 34, 35, 36]
    [20.62500,  34], #  34, [30, 31, 32, 33, 34, 35, 36, 37]
    [20.46875,  35], #  35, [31, 32, 33, 34, 35, 36, 37, 38]
    [20.31250,  36], #  36, [32, 33, 34, 35, 36, 37, 38, 39]
    [20.15625,  37], #  37, [33, 34, 35, 36, 37, 38, 39, 40]
    [20.00000,  38], #  38, [34, 35, 36, 37, 38, 39, 40, 41]
    [19.84375,  39], #  39, [35, 36, 37, 38, 39, 40, 41, 42]
    [19.68750,  40], #  40, [36, 37, 38, 39, 40, 41, 42, 43]
    [19.53125,  41], #  41, [37, 38, 39, 40, 41, 42, 43, 44]
    [19.37500,  42], #  42, [38, 39, 40, 41, 42, 43, 44, 45]
    [19.21875,  43], #  43, [40, 41, 42, 43, 44, 45, 46]
    [19.06250,  44], #  44, [41, 42, 43, 44, 45, 46, 47]
    [18.90625,  46], #  46, [42, 43, 44, 45, 46, 47, 48, 49]
    [18.75000,  47], #  47, [43, 44, 45, 46, 47, 48, 49, 50]
    [18.59375,  48], #  48, [44, 45, 46, 47, 48, 49, 50, 51]
    [18.43750,  49], #  49, [46, 47, 48, 49, 50, 51, 52]
    [18.28125,  50], #  51, [47, 48, 49, 50, 51, 52, 53]
    [18.12500,  52], #  52, [48, 49, 50, 51, 52, 53, 54, 55]
    [17.96875,  53], #  53, [50, 51, 52, 53, 54, 55, 56]
    [17.81250,  55], #  55, [51, 52, 53, 54, 55, 56, 57, 58]
    [17.65625,  56], #  56, [52, 53, 54, 55, 56, 57, 58, 59]
    [17.50000,  57], #  58, [54, 55, 56, 57, 58, 59, 60]
    [17.34375,  59], #  59, [55, 56, 57, 58, 59, 60, 61, 62]
    [17.18750,  60], #  60, [57, 58, 59, 60, 61, 62, 63]
    [17.03125,  61], #  61, [58, 59, 60, 61, 62, 63]
    [16.87500,  62], #  62, [60, 61, 62, 63]
    [16.71875,  63], #  63, [63]
    [16.56250,  63], #  63, [63]
    [16.40625,  63], #  63, []
    [16.25000,  63], #  63, []
    [16.09375,  63], #  63, []
    [15.93750,  63], #  63, []
    [15.78125,  63], #  63, []
    [15.62500,  63], #  63, []
    [15.46875,  63], #  63, []
    [15.31250,  63], #  63, []
    [15.15625,  63], #  63, []
    [15.00000,  63]] #  63, []
## Common PAM4/NRZ Registers, TX registers
tx_pol_addr=0xA0
tx_pol_bit_loc=[5] #
tx_test_patt_ctrl_addr=0xA0
tx_test_patt_ctrl_bit_loc=[15]
tx_test_patt_addr_4=0xA1
tx_test_patt_addr_3=0xA2
tx_test_patt_addr_2=0xA3
tx_test_patt_addr_1=0xA4
tx_test_patt_sel_addr=0xA0
tx_test_patt_sel_bit_loc=[9,8] # nrz:00=prbs9, 01=prbs15, 10=prbs23, 11=prbs31
                               # pam4:00=prbs9, 01=prbs13, 10=prbs15, 11=prbs31
tx_post2_addr = 0xA5 # Post2=0
tx_post2_bit_loc = [15,8]
tx_post1_addr = 0xA7 # Post1=0
tx_post1_bit_loc = [15,8]
tx_main_addr = 0xA9 # Main=0
tx_main_bit_loc = [15,8]
tx_pre1_addr = 0xAB # Pre1=0
tx_pre1_bit_loc = [15,8]
tx_pre2_addr = 0xAD # Pre2=0
tx_pre2_bit_loc = [15,8]
tx_taps_sum_limit = 31

tx_taps_scale_addr = 0xAF
tx_pre2_scale_bit_loc = [5]
tx_pre1_scale_bit_loc = [4]
tx_main_scale_bit_loc = [3]
tx_post1_scale_bit_loc= [2]
tx_post2_scale_bit_loc= [1]

tx_post1_bit_loc = [15,8]
tx_main_addr = 0xA9 # Main=0
tx_main_bit_loc = [15,8]
tx_pre1_addr = 0xAB # Pre1=0
tx_pre1_bit_loc = [15,8]
tx_pre2_addr = 0xAD # Pre2=0
tx_pre2_bit_loc = [15,8]

#################################################################
## PAM4 RX Register Definitions #################################
## PAM4 RX Input Network registers
rx_pam4_pol_addr=0x43
rx_pam4_pol_bit_loc=[7] #
rx_nrz_pol_addr =0x161
rx_nrz_pol_bit_loc=[14]

rx_pam4_msblsb_addr=0x43      # RX MSB-LSB Swap, | 0=MSB first | 1 = LSB first
rx_pam4_msblsb_bit_loc = [15]

tx_pam4_msblsb_addr=0xaf     # TX MSB-LSB Swap, | 0=MSB first | 1 = LSB first
tx_pam4_msblsb_bit_loc = [10]

rx_pam4_en_addr = 0x41 # RX PAM4 Mode En | 0=Dis | 1 = En  (Set this bit to en PAM4 RX)
rx_pam4_en_bit_loc = [15]
EM_mode_en_addr = 0x0F
EM_mode_en_bit = [15]
cntdr_corr_addr = 0x92## PAM4 State machine registers


## PAM4 Status related registers
pam4_eye_margin_addr = 0x32
pam4_eye_plus_margin_bit_loc = [15,4]
pam4_eye_minus_margin_upper_bit_loc = [3,0]
pam4_eye_margin_addr2 = 0x33
pam4_eye_minus_margin_lower_bit_loc = [15,8]

## PAM4 PRBS sync related registers
pam4_prbs_cnt_rst_addr=0x43
pam4_prbs_cnt_rst_bit_loc=[9]
pam4_prbs_cnt_addr=0x4e

## PAM4 RX related registers
delta_ph_ow_addr = 0x12
delta_ph_ow_en_bit_loc = [13]
delta_ph_ow_val_bit_loc = [12,6]

## NRZ RX related registers
nrz_dfe_delta_addr = 0x10d
nrz_dfe_delta_bit_loc = [6,0]
nrz_dfe_f1_addr = 0x12b
nrz_dfe_f1_bit_loc = [6,0]
nrz_dfe_f2_addr = 0x12c
nrz_dfe_f2_bit_loc = [14,8]
nrz_dfe_f3_addr = 0x12c
nrz_dfe_f3_bit_loc = [6,0]

## PAM4 RX related registers
ext_rch_en_addr = 0xEC
ext_rch_en_bit_loc = [8]
ext_rch_param1_bit_loc = [7,5]
ext_rch_param2_bit_loc = [4,2]

## PAM4 RX related registers
edge1_addr = 0xE5
edge1_bit_loc = [15,12]
edge2_addr = 0xE5
edge2_bit_loc = [11,8]
edge3_addr = 0xE5
edge3_bit_loc = [7,4]
edge4_addr = 0xE5
edge4_bit_loc = [3,0]

## PAM4 FFE related registers
ffe_en_addr = 0xF7
ffe_en_bit_loc =[14]
ffe_pol_addr = 0xF0
ffe_tap1_en_bit_loc = [11]
ffe_tap2_en_bit_loc = [13]
ffe_tap3_en_bit_loc = [15]
ffe_tap4_en_bit_loc = [14]
ffe_po11_bit_loc = [9]
ffe_po12_bit_loc = [8]
ffe_po13_bit_loc = [7]
ffe_po14_bit_loc = [6]
ffe_delay1234_ctrl_addr = 0xEF
ffe_delay5678_ctrl_addr = 0xEE
ffe_delay9_ctrl_addr = 0xED
ffe_delay1_bit_loc = [15,12]
ffe_delay2_bit_loc = [11,8]
ffe_delay3_bit_loc = [7,4]
ffe_delay4_bit_loc = [3,0]
ffe_delay5_bit_loc = [15,12]
ffe_delay6_bit_loc = [11,8]
ffe_delay7_bit_loc = [7,4]
ffe_delay8_bit_loc = [3,0]
ffe_delay9_bit_loc = [15,12]
ffe_tap3_addr = 0xF4
ffe_tap3_bit_loc = [15,8]
ffe_tap4_addr = 0xF4
ffe_tap4_bit_loc = [7,0]
ffe_tap2_addr = 0xF3
ffe_tap2_bit_loc = [15,8]
ffe_tap34_addr = 0xF3
ffe_tap34_bit_loc = [7,0]
ffe_tap1_addr = 0xF2
ffe_tap1_bit_loc = [15,8]
ffe_tap234_addr = 0xF2
ffe_tap234_bit_loc = [7,0]
ffe_gain1_addr = 0xF1
ffe_gain1_bit_loc = [11,8]
ffe_gain2_addr = 0xF1
ffe_gain2_bit_loc = [3,0]
ffe_pol_addr = 0xF0
ffe_pol_bit_loc = [9,6]

## PAM4 DFE related registers
pam4_dfe_sel_addr = 0x88
pam4_dfe_sel_bit_loc = [7,4]
pam4_dfe_read_addr = 0x2f
pam4_dfe_read_bit_loc = [15,4]
pam4_tap_addr = 0x40
pam4_tap_bit_loc = [6,0]
pam4_tap_sel_addr = 0x45
pam4_tap_sel_bit_loc = [6,3]

## PAM4 State machine registers
bp_addr = 0x11
bp1_en_bit_loc = [15]
bp2_en_bit_loc = [14]
bp1_bit_loc = [12,8]
bp2_bit_loc = [4,0]
bp_ctu_bit_loc = [13]
step_en_bit_loc = [7]
step_bit_loc = [6]

ow_mu_offset_addr = 0x87
ow_mu_offset_bit_loc = [10,9]
iter_s6_addr = 0x09
iter_s6_bit_loc = [3,0]
iter_s4_addr = 0x06
iter_s4_bit_loc = [15,12]
timer_s_addr = 0x07
timer_s5_bit_loc = [14,11]
timer_s1_addr = 0x00
timer_s1_bit_loc = [4,0]
th_ini_bit_loc = [14,8]
timer_s3_addr = 0x03
timer_s3_bit_loc = [15,11]
f1over3_addr = 0x04
f1over3_bit_loc = [11,5]

#################################################################
## NRZ RX Register Definitions ##################################
## NRZ PRBS sync related registers
nrz_prbs_cnt_rst_addr=0x161
nrz_prbs_cnt_rst_bit_loc=[15]
nrz_prbs_cnt_addr=0x166
nrz_restart_counter_addr = 0x14F
nrz_restart_counter_bit_loc = [4,0]

## NRZ RX related registers
nrz_10g_mode_addr = 0x179
nrz_10g_mode_bit_loc=[0]
nrz_bb_mode_addr=0x179
nrz_bb_mode_bit_loc=[6]
nrz_delta_adapt_en_addr=0x101
nrz_delta_adapt_en_bit_loc=[14]

## REV 5 Additions
loop_back_en_addr = 0x9803
loop_back_en_bit_loc = [15]
auto_zero_addr = 0x00cb
auto_zero_short_bit_loc = [14]
auto_zero_long_bit_loc = [15]
vhicurrent_inputbuf_addr = 0x00cb
vhicurrent_inputbuf_bit_loc = [1]

## REV 5 XCorr
xcorr_cntr_freeze_addr = 0x0074
xcorr_cntr_freeze_bit_loc = [15]

xcorr_c_qua_pol_addr = 0x0090
xcorr_c_qua_pol_bit_loc = [15]
xcorr_shift_tap_addr = xcorr_c_qua_pol_addr
xcorr_shift_tap_bit_loc = [14,12]
xcorr_timer_set_tap_addr = xcorr_c_qua_pol_addr
xcorr_timer_set_tap_bit_loc = [11,8]
xcorr_fixed_pat_addr = xcorr_c_qua_pol_addr
xcorr_fixed_pat_bit_loc = [7,4]
xcorr_cntdr_read_mux_addr = xcorr_c_qua_pol_addr
xcorr_cntdr_read_mux_bit_loc = [3,0]

xcorr_gate_addr = 0x0091
xcorr_gate_bit_loc = [8]
xcorr_cntf_freeze_dc_addr = xcorr_gate_addr
xcorr_cntf_freeze_dc_bit_loc = [4]
xcorr_cntr_freeze_tap_addr = xcorr_gate_addr
xcorr_cntr_freeze_tap_bit_loc = [3]
xcorr_result_clr_dc_addr = xcorr_gate_addr
xcorr_result_clr_dc_bit_loc = [2]
xcorr_result_clr_tap_addr = xcorr_gate_addr
xcorr_result_clr_tap_bit_loc = [1]
xcorr_timer_start_clr_tap_addr = xcorr_gate_addr
xcorr_timer_start_clr_tap_bit_loc = [0]

xcorr_cntdr_err_rlt_addr = 0x0093
xcorr_cntdr_err_rlt_bit_loc = [15,0]

# Rev 5 PAM4 MM mode
pam4mm_mm_dtl_en_addr = 0x0094
pam4mm_mm_dtl_en_bit_loc = [15]
pam4mm_quali_mode_addr = pam4mm_mm_dtl_en_addr
pam4mm_quali_mode_bit_loc = [14]
pam4mm_f0_fgt_addr = pam4mm_mm_dtl_en_addr
pam4mm_f0_fgt_bit_loc = [13,8]
pam4mm_mm_pol_addr = pam4mm_mm_dtl_en_addr
pam4mm_mm_pol_bit_loc = [7]
pam4mm_lev_update_addr = pam4mm_mm_dtl_en_addr
pam4mm_lev_update_bit_loc = [6]
pam4mm_f1_fgt_addr = pam4mm_mm_dtl_en_addr
pam4mm_f1_fgt_bit_loc = [5,0]

pam4mm_quant_lev0_addr = 0x0095
pam4mm_quant_lev0_bit_loc = [13,8]
pam4mm_quant_lev1_addr = pam4mm_quant_lev0_addr
pam4mm_quant_lev1_bit_loc = [5,0]

pam4mm_quant_lev2_addr = 0x0096
pam4mm_quant_lev2_bit_loc = [13,8]
pam4mm_quant_lev3_addr = pam4mm_quant_lev2_addr
pam4mm_quant_lev3_bit_loc = [5,0]

pam4mm_quant_lev4_addr = 0x0097
pam4mm_quant_lev4_bit_loc = [13,8]
pam4mm_quant_lev5_addr = pam4mm_quant_lev4_addr
pam4mm_quant_lev5_bit_loc = [5,0]

pam4mm_quant_lev6_addr = 0x0098
pam4mm_quant_lev6_bit_loc = [13,8]
pam4mm_quant_lev7_addr = pam4mm_quant_lev6_addr
pam4mm_quant_lev7_bit_loc = [5,0]

pam4mm_quant_lev8_addr = 0x0099
pam4mm_quant_lev8_bit_loc = [13,8]
pam4mm_quant_lev9_addr = pam4mm_quant_lev8_addr
pam4mm_quant_lev9_bit_loc = [5,0]

pam4mm_quant_lev10_addr = 0x009a
pam4mm_quant_lev10_bit_loc = [13,8]
pam4mm_quant_lev11_addr = pam4mm_quant_lev10_addr
pam4mm_quant_lev11_bit_loc = [5,0]

pam4mm_quant_lev11_addr = 0x009b
pam4mm_quant_lev11_bit_loc = [13,8]

pll_lvcocap_addr = 0xFC
#***********************************************************
# End of Pterosaur-LR Chip Library and Registers Definitions
#***********************************************************

EncParams = collections.namedtuple('EncParams', ['baud_rate_ratio',
                                                 'prbs_mode_sel_addr',
                                                 'prbs_mode_sel_bit_loc',
                                                 'sm_ctrl_addr',
                                                 'sm_ctrl_continue_addr',
                                                 'sm_ctrl_continue_bit_loc',
                                                 'sm_ctrl_bp1_state_addr',
                                                 'sm_status_addr',
                                                 'sm_status_bp1_bit_loc',
                                                 'sm_status_bp2_bit_loc',
                                                 'sm_state_num_bit_loc',
                                                 'eye_read_addr',
                                                 'eye_read_bit_loc',
                                                 'dac_sel_addr',
                                                 'dac_sel_bit_loc',
                                                 'dac_sel_ow_en_addr',
                                                 'dac_sel_ow_en_bit_loc',
                                                 'dac_sel_ow_addr',
                                                 'dac_sel_ow_bit_loc',
                                                 'cntr_target_init_addr',
                                                 'cntr_target_init_bit_loc',
                                                 'cntr_target_final_addr',
                                                 'cntr_target_final_bit_loc',
                                                 'sd_rdy_addr',
                                                 'rdy_bit_loc',
                                                 'sig_det_loc',
                                                 'lane_reset_addr',
                                                 'lane_reset_bit_loc',
                                                 'ctle_en_addr',
                                                 'ctle_en_bit_loc',
                                                 'ctle_val_addr',
                                                 'ctle_val_bit_loc',
                                                 'ctle_map2_addr',
                                                 'ctle_map1_addr',
                                                 'ctle_map0_addr',
                                                 'fw_tuning_ctrl_ctle_mode_bit_loc',
])

encoding_params = { 'pam4' : EncParams(baud_rate_ratio = 2,
                                       prbs_mode_sel_addr = 0x43,
                                       prbs_mode_sel_bit_loc = [6,5],   # pam4:00=prbs9, 01=prbs13, 10=prbs15, 11=prbs31
                                       sm_ctrl_addr = 0x11,
                                       sm_ctrl_continue_addr = 0x11,
                                       sm_ctrl_continue_bit_loc = [13],
                                       sm_ctrl_bp1_state_addr = 0x11,
                                       sm_status_addr = 0x28,
                                       sm_status_bp1_bit_loc = [15],
                                       sm_status_bp2_bit_loc = [14],
                                       sm_state_num_bit_loc = [13,9],
                                       eye_read_addr = 0x38,
                                       eye_read_bit_loc = [11,0],
                                       dac_sel_addr = 0x28,
                                       dac_sel_bit_loc = [8,5],
                                       dac_sel_ow_en_addr = 0x21,
                                       dac_sel_ow_en_bit_loc = [12],
                                       dac_sel_ow_addr = 0x21,
                                       dac_sel_ow_bit_loc = [11,8],
                                       cntr_target_init_addr = 0x01,
                                       cntr_target_init_bit_loc = [15,0],
                                       cntr_target_final_addr = 0x02,
                                       cntr_target_final_bit_loc = [15,0],
                                       sd_rdy_addr = 0x6a,
                                       rdy_bit_loc = [15],
                                       sig_det_loc = [7],
                                       lane_reset_addr = 0x00,
                                       lane_reset_bit_loc = [15],
                                       ctle_en_addr = 0x21,
                                       ctle_en_bit_loc = [7],
                                       ctle_val_addr = 0x21,
                                       ctle_val_bit_loc = [6,4],
                                       ctle_map2_addr = 0x48,
                                       ctle_map1_addr = 0x49,
                                       ctle_map0_addr = 0x4a,
                                       fw_tuning_ctrl_ctle_mode_bit_loc = [15,12],
),
                    'nrz'  : EncParams(baud_rate_ratio = 1,
                                       prbs_mode_sel_addr = 0x161,
                                       prbs_mode_sel_bit_loc = [13,12], # nrz:00=prbs9, 01=prbs15, 10=prbs23, 11=prbs31
                                       sm_ctrl_addr = 0x10B,
                                       sm_ctrl_continue_addr = 0x10C,
                                       sm_ctrl_continue_bit_loc = [15],
                                       sm_ctrl_bp1_state_addr = 0x10B,
                                       sm_status_addr = 0x10D,
                                       sm_status_bp1_bit_loc = [15],
                                       sm_status_bp2_bit_loc = [14],
                                       sm_state_num_bit_loc = [12,8],
                                       eye_read_addr = 0x12A,
                                       eye_read_bit_loc = [11,0],
                                       dac_sel_addr = 0x17F,
                                       dac_sel_bit_loc = [15,12],
                                       dac_sel_ow_en_addr = 0x14C,
                                       dac_sel_ow_en_bit_loc = [7],
                                       dac_sel_ow_addr = 0x14F,
                                       dac_sel_ow_bit_loc = [15,12],
                                       cntr_target_init_addr = 0x102,
                                       cntr_target_init_bit_loc = [15,4],
                                       cntr_target_final_addr = 0x102,
                                       cntr_target_final_bit_loc = [15,4],
                                       sd_rdy_addr = 0x12E,
                                       rdy_bit_loc = [2],
                                       sig_det_loc = [3],
                                       lane_reset_addr = 0x181,
                                       lane_reset_bit_loc = [11],
                                       ctle_en_addr = 0x14D,
                                       ctle_en_bit_loc = [15],
                                       ctle_val_addr = 0x14E,
                                       ctle_val_bit_loc = [13,11],
                                       ctle_map2_addr = 0x176,
                                       ctle_map1_addr = 0x177,
                                       ctle_map0_addr = 0x178,
                                       fw_tuning_ctrl_ctle_mode_bit_loc = [0]     # 1: NRZ FW Tuning disable (Manual-CTLE), 0: 1: NRZ FW Tuning enable (Auto-CTLE)
                    ) }
encoding_params['nrzbb'] = encoding_params['nrz']
encoding_params['nrzmm'] = encoding_params['nrz']

def params(lane):
    return encoding_params[get_mode(lane)]


LaneParams = collections.namedtuple('LaneParams', ['data_rate',   # determines PAM4/NRZ
                                                   'bbmode',      # only for NRZ: indicates NRZ-BB
                                                   'tx_idx',      # index of tx tap list, or the list itself, or None (use existing)
                                                   'rx_input',    # 'ac' or 'dc'
                                                   'prbs_pattern',
                                                   'pol_tx',
                                                   'pol_rx',
                                                   'msblsb_tx',
                                                   'msblsb_rx',
                                                   'gc_tx',
                                                   'gc_rx',
                                                   'pc_tx',
                                                   'pc_rx',
])

# Per-lane value of max sample count for each eye diagram point.  Keep on reload.
global eye_max_samples
# Per-lane indication of what is in eye data buffer
global eye_data_type
try:
    eye_max_samples, eye_data_type
except:
    eye_max_samples, eye_data_type = {}, {}

############################################
# State Get/Set
############################################
def set_speed(lane, target_data_rate):
    global gTargetDataRate; gTargetDataRate[lane]=target_data_rate

##
def get_mode(lane):
    is_nrz = rregBits(0xB0, [1], lane)
    return 'nrz' if is_nrz else 'pam4'

def is_halfrate(lane):
    return rregBits(nrz_10g_mode_addr, nrz_10g_mode_bit_loc, lane) != 0

##
def get_rx_input_mode(lane):
    if rregBits(0xF7, [12], lane):
        return 'ac'
    else:
        return 'dc'

def set_rx_input_mode(lane, rx_input_mode):
    global gRxInputMode;    gRxInputMode[lane] = rx_input_mode

##
def set_rx_mr_mode(lane, rx_mr_mode):
    global gMrMode;         gMrMode = rx_mr_mode

##
def get_rx_polarity(lane):
    if get_mode(lane) == 'pam4':
        return rregBits(rx_pam4_pol_addr, rx_pam4_pol_bit_loc, lane)
    else:
        return rregBits(rx_nrz_pol_addr, rx_nrz_pol_bit_loc, lane)

def set_rx_polarity(val, lane):
    wregBits(rx_nrz_pol_addr, rx_nrz_pol_bit_loc, val, lane)
    wregBits(rx_pam4_pol_addr, rx_pam4_pol_bit_loc, val, lane)

##
def get_tx_polarity(lane):
    return not rregBits(tx_pol_addr, tx_pol_bit_loc, lane)

def set_tx_polarity(val, lane=0):
    wregBits(tx_pol_addr, tx_pol_bit_loc, not val, lane)

def fracn_enabled(lane):
    return rregBits(pll_sdm_addr, pll_sdm_en_bit_loc, lane=lane)

## Innov functions to provide functionality of set_serdes_globals()
def serdes_set_params(lane, mode, target_data_rate=None, rx_mr_mode='dis',
                      rx_input_mode=None, div4=None,
                      prbs_pattern='PRBS31', poltx=0, polrx=1, gctx=1, gcrx=1,
                      msblsbtx=0, msblsbrx=0, pctx=0, pcrx=0):
    global gPolTX;          gPolTX = poltx
    global gPolRX;          gPolRX = polrx
    global gGCTX;           gGCTX[lane] = gctx
    global gGCRX;           gGCRX[lane] = gcrx
    global gMSBLSBTX;       gMSBLSBTX = msblsbtx
    global gMSBLSBRX;       gMSBLSBRX = msblsbrx
    global gPCTX;           gPCTX[lane] = pctx
    global gPCRX;           gPCRX[lane] = pcrx

    # options: 'pam4', 'nrz', 'nrz' + 'bb'/'mm' ('nrz'='nrzbb'=>BB Mode, 'nrzmm'=>MM Mode)
    set_mode(lane, mode)

    ## PLL and Frequency related parameters
    set_speed(lane, target_data_rate)
    set_rx_mr_mode(lane, rx_mr_mode)

    # options: 'ac' , 'dc'
    if rx_input_mode is not None:
        set_rx_input_mode(lane, rx_input_mode)
    else:
        set_rx_input_mode(lane, get_rx_input_mode(lane))

    global gDiv4;
    if div4 is not None:
        gDiv4 = div4
    else:
        # Pull current pll setup and store in gDiv4
        cur_data_rate, cur_baud_rate, fvco, pll_n, pll_fracn, pll_cap, gDiv4 = get_pll(lane=lane)

    set_pll(rate=gRefclkFreq, lane=lane, div4=div4)


######################################################
# Reads a standard SerDes setup file (a text file)
#
# format in hex values each line: register address _ register value
# example: 802A 034F
#
# Can also load setup files used by Credo GUI program
#
######################################################
def load_setup(filename="pam4_standard_setup.txt", lane=0):
    fw_unload()
    #fw_halt(print_en=0)
    wregLane(params(lane).sm_ctrl_addr, 0x0000, lane) # Clear Break points when running without FW
    wregBits(params(lane).sm_ctrl_continue_addr, params(lane).sm_ctrl_continue_bit_loc, 0, lane)
    wregBits(params(lane).sm_ctrl_continue_addr, params(lane).sm_ctrl_continue_bit_loc, 1, lane)
    wregBits(params(lane).sm_ctrl_continue_addr, params(lane).sm_ctrl_continue_bit_loc, 0, lane)
    #logic_reset()

    #### Preload from the file saved after each adaptation
    load_setup_orig(filename)

    f1over3(f1over3(),lane=lane)

    wregLane(params(lane).sm_ctrl_addr, 0x0000, lane) # Clear Break points when running without FW
    if gPam4NrzMode[lane] == 'pam4':  wregLane(0x87,0x800,lane=lane) #background_cal(0)
    lane_reset_toggle(lane=lane)
    time.sleep(5)
    if gPam4NrzMode[lane] == 'pam4':  background_cal(1,lane=lane)
    time.sleep(1)

    actual_data_rate, actual_baud_rate, fvco, pll_n, pll_fracn, pll_cap, div4, = get_pll(lane=lane)
    log("....Running at %7.4f Gbps" % (actual_data_rate))
    serdes_params(print_header=1,lane=lane)

####################################################################
# This function reads the register list requested
# and keeps a record of them in software (not saved to disk)
#
# returns: handle to the list of registers saved
#
# record of saved registers: captured_reg_list=[[addr0, value0],[addr1, value1]...]
#
# addr: can include based address for the lane (if applicable to this chip)
####################################################################
def reg_capture(addr_list=compat_listrange(0x0000, 0x0200), lane=0):

    captured_reg_list=[]
    for reg_index in range(len(addr_list)):
        #if gReadOnlyRegList[reg_index][1] != 'RO': # only keep track if not read-only
        captured_reg_list.append([])
        captured_reg_list[reg_index].append(addr_list[reg_index])                  # full_addr   = mod_reg_list[reg_index][0]
        captured_reg_list[reg_index].append(rregLane(addr_list[reg_index], lane))  # curr_val    = mod_reg_list[reg_index][1]
        #print("\n%3d, %04X, %04X" % (reg_index, captured_reg_list[reg_index][0],captured_reg_list[reg_index][1])),

    return captured_reg_list
####################################################################
# This function compared the two register lists
#
# assumes the two lists have the exact addresses sequentially and are equal lengths
#
# returns: a list of registers and their values in reg_list2
#          have different values from reg_list1
#
# returned registers format: delta_reg_list=[[addr0, value0],[addr1, value1]...]
#
####################################################################
def reg_delta(reg_list1, reg_list2):

    if len(reg_list1) != len(reg_list2):
        log("\n>>>> reg_delta() error: the two register lists to compare are different sizes!\n\n")
        return -1

    delta_reg_list=[]
    delta_reg_index=0

    for reg_index in range(len(reg_list1)):
        #if gReadOnlyRegList[reg_index][1] != 'RO': # only keep track if not read-only
        if reg_list1[reg_index][1] != reg_list2[reg_index][1]:
            delta_reg_list.append([])
            delta_reg_list[delta_reg_index].append(reg_list2[reg_index][0])  # full_addr   = mod_reg_list[reg_index][0]
            delta_reg_list[delta_reg_index].append(reg_list2[reg_index][1])  # curr_val    = mod_reg_list[reg_index][1]
            delta_reg_index+=1
            # print("\n%3d, %04X, %04X" % (reg_index, delta_reg_list[reg_index][0],delta_reg_list[reg_index][1])),

    return delta_reg_list
####################################################################
# This function restores the list of registers from the list passed to it.
#
# options:
#
# reg_list = 'post_opt' or 'all' to restore full regsiter list and their values after the most recent adaptation (default)
# reg_list = 'pre-opt' to restore initial settings used before the most recent adaptation started
# reg_list = 'opt' to restore just those regsisters whose values changed during the most recent adaptation
#
# returns: the number of registers restored
####################################################################
def preload(reg_list='file', lane=0, show=0):

    fw_unload()
    #fw_halt(print_en=0)
    wregLane(params(lane).sm_ctrl_addr, 0x0000, lane) # Clear Break points when running without FW
    wregBits(params(lane).sm_ctrl_continue_addr, params(lane).sm_ctrl_continue_bit_loc, 0, lane)
    wregBits(params(lane).sm_ctrl_continue_addr, params(lane).sm_ctrl_continue_bit_loc, 1, lane)
    wregBits(params(lane).sm_ctrl_continue_addr, params(lane).sm_ctrl_continue_bit_loc, 0, lane)
    #logic_reset()

    #### Preload from the file saved after each adaptation
    if (reg_list=='file'):
        load_setup('preload_setup.txt')

    #### Preload from the run-time saved register lists which are updated after each adapatation
    else:

        if (reg_list=='opt'):
            reg_list=gAdaptationRegList
            log_no_newline("\n....Preloaded SerDes with most recent adapted-values")
        elif (reg_list=='pre_opt'):
            reg_list=gPreAdaptationRegList
            log_no_newline("\n....Preloaded SerDes with Initial (pre-adaptation) settings")
        elif (reg_list=='post_opt' or reg_list=='all' or  reg_list==None):
            reg_list=gPostAdaptationFullRegList
            log_no_newline("\n....Preloaded SerDes with most recent adaptation")

        num_reg_restored=0
        for reg_index in range(len(reg_list)):
            #if gReadOnlyRegList[reg_index][1] != 'RO': # only restore those that are not read-only
            wregLane(reg_list[reg_index][0],reg_list[reg_index][1],0, lane)
            num_reg_restored+=1
            if show:
                if reg_index%16==0: log_no_newline("\nR%04X: " % (reg_list[reg_index][0]))
                log_no_newline("%04X," % (reg_list[reg_index][1]))

    f1over3(f1over3(),lane=lane)

    wregLane(params(lane).sm_ctrl_addr, 0x0000, lane) # Clear Break points when running without FW
    if gPam4NrzMode[lane] == 'pam4':  wregLane(0x87,0x800,lane) #background_cal(0)
    lane_reset_toggle(lane=lane)
    time.sleep(5)
    if gPam4NrzMode[lane] == 'pam4':  background_cal(1,lane=lane)
    time.sleep(1)

    actual_data_rate, actual_baud_rate, fvco, pll_n, pll_fracn, pll_cap, div4 = get_pll(lane=lane)
    log("....Running at %7.4f Gbps" % (actual_data_rate))
    serdes_params(print_header=1,lane=lane)
    #return num_reg_restored

#####################################################################
# This function determines if a register is a read-only type, and if yes, returns 1, else 0
# '
####################################################################
def is_register_read_only(full_addr,lane=0):

    curr_val = rregLane(full_addr,lane=lane)
    val_list=[0xaaaa, 0x5555]
    addr_type = 0 # 1:read_only register 0: write_read type
    for val in val_list:
        wregLane(full_addr, val,lane=lane)
        rd_val = rregLane(full_addr,lane=lane)
        if rd_val != val:
            addr_type=1 # it is read_only
    wregLane(full_addr, curr_val,lane=lane)
    return addr_type

########################################
#  Read FW Register                    #
########################################
def get_fw_reg(fw_addr,lane=0,section=0):
    fw_cmd(fw_reg_read_cmd+section, detail=fw_addr, expected_response=0xe, lane=lane)
    val = rregLane(fw_reg_value_addr, lane)
    return val
########################################
#  Write FW Register                   #
########################################
def set_fw_reg(fw_addr, val,lane=0,section=0):
    wregLane(fw_reg_value_addr, val, lane)
    fw_cmd(fw_reg_write_cmd+section, detail=fw_addr, expected_response=0xe, lane=lane)
########################################
#  FW Register access command          #
########################################
def fw_reg(fw_addr=None, val=None,lane=0, section=0):

    # dump all FW registers
    if(fw_addr==None and val==None):
        for fw_addr in range (0, 51):
            val = val_d = get_fw_reg(fw_addr, lane=lane, section=section)
            if val_d > 0x8000: val_d = val_d-0xFFFF;
            log("FW_Reg %2d: 0x%04X, %d" % (fw_addr,val,val_d))
    # read just the requested FW register address
    elif(fw_addr!=None and val==None):
        val = val_d = get_fw_reg(fw_addr, lane, section=section)
        if val_d > 0x8000: val_d = val_d-0xFFFF;
        log("FW_Reg %2d: 0x%04X, %d" % (fw_addr,val,val_d))
    # Write the the requested FW register with the val
    else:
        set_fw_reg(fw_addr, val, lane, section=section)
def fw_counter_get_set(addr, count_val=None, lane=0):
    if count_val is not None:
        set_fw_reg(addr, count_val, lane=lane)
    return get_fw_reg(addr, lane=lane)

fw_tuning_counter=lambda count_val=None, lane=0: fw_counter_get_set(5, count_val, lane)

fw_reset_counter=lambda count_val=None, lane=0: fw_counter_get_set(4, count_val, lane)
########################################
#  FW Tuning Counter command           #
########################################
def fw_tuning_counter(count_val=None,lane=0):
    fw_tuning_counter_addr = 5 #46
    if(count_val!=None):
        set_fw_reg(fw_tuning_counter_addr, count_val,lane)

    count = get_fw_reg(fw_tuning_counter_addr,lane)
    #print("\n FW Tuning Counter = %d"%val)
    return count
########################################
#  FW Retry Counter command           #
########################################
def fw_reset_counter(count_val=None,lane=0):
    fw_tuning_counter_addr = 4
    if(count_val!=None):
        set_fw_reg(fw_tuning_counter_addr, count_val,lane)

    count = get_fw_reg(fw_tuning_counter_addr,lane)
    #print("\n FW Reset Counter = %d"%val)
    return count
########################################
#  FW Tuning Channel Estimate command  #
########################################
def fw_channel_estimate(count_val=None,lane=0):
    count=float(fw_counter_get_set(11, count_val, lane))/256.0
    gChannelEstimate[lane] = count
    #print("\n FW Channel Estimate = %d"%val)
    return count
########################################
#  FW Tuning Channel Estimate command  #
########################################
def fw_channel_of_hf(lane=0):
    global gChannelEstimate
    fw_reg_addr_of = 9
    fw_reg_addr_hf = 10

    of_count = get_fw_reg(fw_reg_addr_of,lane)
    hf_count = get_fw_reg(fw_reg_addr_hf,lane)
    #print("\n FW Channel OF/HF = %d"%(of_count,hf_count))
    return of_count,hf_count
########################################
def soft_reset(lane=0):
    prev_clock_tree = rregLane(0x00C9, lane)
    log('Prev clock tree %04x' % prev_clock_tree)
    wregLane(chip_reset_addr, chip_soft_reset_val,lane) #
    global gSoftResetRegList
    global gReadOnlyRegList
    gSoftResetRegList = reg_capture(lane=lane)
    gReadOnlyRegList = build_read_only_reg_list(lane=lane)

    wregLane(chip_reset_addr, chip_soft_reset_val,lane)
    wregLane(0x00C9, prev_clock_tree, lane)

########################################
def reg_reset(lane=0):

    wregLane(chip_reset_addr, chip_reg_reset_val,lane)
    wregLane(chip_reset_addr, 0x0000,lane)
    global gSoftResetRegList
    global gReadOnlyRegList
    gSoftResetRegList = reg_capture(lane=lane)
    gReadOnlyRegList = build_read_only_reg_list(lane=lane)
    wregLane(chip_reset_addr, chip_reg_reset_val,lane)
    wregLane(chip_reset_addr, 0x0000,lane)
########################################
def logic_reset(lane=0):
    global chip
    wregLane(chip_reset_addr, chip_logic_reset_val,lane) #
    wregLane(chip_reset_addr, 0x0000,lane) # Logic Reset after new FW downloaded
########################################
def cpu_reset(lane=0):
    wregLane(chip_reset_addr, chip_cpu_reset_val,lane) #
    wregLane(chip_reset_addr, 0x0000,lane) # CPU Reset after new FW downloaded
#####################################################################
# This function determines if the register is read-only, and if yes, marks it as a 'RO' in the list passed, else ' '
# 'addr_list' must be full address including the base address+lane#, i.e. 0x80E3, etc.
####################################################################
def build_read_only_reg_list(addr_list=compat_listrange(0x0000, 0x0200),lane=0):
    num_read_only_registers=0
    read_only_reg_list=[]

    for reg_index in range(len(addr_list)):
        read_only_reg_list.append([])
        read_only_reg_list[reg_index].append(addr_list[reg_index]) # full_addr   = mod_reg_list[reg_index][0]
        if gReadOnlyRegListBuildEn==1:
            if is_register_read_only(addr_list[reg_index],lane=lane):
                read_only_reg_list[reg_index].append('RO')  # 'RO': read-only
                num_read_only_registers+=1
            else:
                read_only_reg_list[reg_index].append('  ')  # '  ': write-able
        else:
            read_only_reg_list[reg_index].append('??')      # '??': Unkown, not checked

       #print("\n%3d, %04X, %d" % (reg_index, read_only_reg_list[reg_index][0],read_only_reg_list[reg_index][1])),

    return read_only_reg_list

def fw_load(lfw_file_name=None, print_en=0, lane=0):
    global fw_file_name
    orig_fw_file_name = fw_file_name
    if lfw_file_name == None:
        lfw_file_name = fw_file_name
    else:
        fw_file_name = lfw_file_name

    if not os.path.exists(lfw_file_name):
        log("\n...Device %d FW LOAD ERROR: Error Opening FW File: %s\n" % (lane, lfw_file_name))
        fw_file_name = orig_fw_file_name
        return -1

    #set_top_pll(pll_side='both')  # Setup Top PLLs first
    ##### Mess up cap values to see if FW's top_pll_cal will recover them
    # wreg([0x9501,[12,6]], 45, lane);
    # wreg([0x9601,[12,6]], 46, lane);
    # pll_cap()

    fw_unload(lane=lane)
    log_no_newline("\n...Device %d Downloading FW: %s..." % (lane, fw_file_name))

    FW0 =0x9F00#+lane*0x2000 #0x9F00
    FW1 =0x980D#+lane*0x2000 #0x9802
    FW2 =0x9814#+lane*0x2000 #0x9805
#
    fw_file_ptr = open(fw_file_name, 'rb')
    fw_file_ptr.seek(0x1000)
    header = fw_file_ptr.read(20)
    hash_code, crc, date, entryPoint, length, ramAddr = struct.unpack(">IHHIII", header)
    d = datetime.date(1970, 1, 1) + datetime.timedelta(date)

    if print_en:
        log("fw_load Hash Code : 0x%06x" % hash_code)
        log("fw_load Date Code : 0x%02x (%04d-%02d-%02d)" % (date, d.year, d.month, d.day))
        log("fw_load  CRC Code : 0x%04x" % crc)
        log("fw_load    Length : %d" % length)
        log("fw_load     Entry : 0x%08x" % entryPoint)
        log("fw_load       RAM : 0x%08x" % ramAddr)

    data = fw_file_ptr.read()
    dataPtr = 0
    sections = (length + 23) / 24

    wregLane(FW2, 0xFFF0, lane)
    wregLane(FW1, 0x0AAA, lane)
    wregLane(FW1, 0x0000, lane)

    start_time = time.time()
    checkTime = 0
    status = rregLane(FW2,lane)
    while status != 0:
        status = rregLane(FW2, lane)
        checkTime += 1
        if checkTime > 100000:
            log_no_newline('\n...FW LOAD ERROR: : Wait for FW2=0 Timed Out! FW2 = 0x%X' % status)  # Wait for FW2=0: 0.000432 sec
            break
    stop_time = time.time()
    # print '\nfw_load: Wait for FW2=0: %2.6f sec'% (stop_time-start_time),
    # time.sleep(wait)
    wregLane(FW2, 0x0000, lane)

    i = 0
    while i < sections:
        checkSum = 0x800c
        wregLane(FW0 + 12, ramAddr >> 16, lane)
        wregLane(FW0 + 13, (ramAddr & 0xFFFF), lane)
        checkSum += (ramAddr >> 16) + (ramAddr & 0xFFFF)
        for j in range(12):
            if (dataPtr >= length):
                mdioData = 0x0000
            else:
                mdioData = struct.unpack_from('>H', data[dataPtr:dataPtr + 2])[0]
            wregLane(FW0 + j, mdioData, lane)
            checkSum += mdioData
            dataPtr += 2
            ramAddr += 2

        wregLane(FW0 + 14, (~checkSum + 1) & 0xFFFF,lane)
        wregLane(FW0 + 15, 0x800C, lane)
        # print '\nfw_load: section %d, Checksum %X' % (i, checkSum),

        checkTime = 0
        status = rregLane(FW0 + 15, lane)
        while status == 0x800c:
            status = rregLane(FW0 + 15, lane)
            checkTime += 1
            if checkTime > 1000:
                log_no_newline('\n...FW LOAD ERROR: Write to Ram Timed Out! FW0 = %x' % status)
                break

        if checkTime > 0:
            if print_en: log_no_newline('\nfw_load: section %d, CheckTime= %d' % (i, checkTime))

        if status != 0:
            log_no_newline("...FW LOAD ERROR: Invalid Write to RAM, section %d" % i)
        i += 1

    wregLane(FW0 + 12, entryPoint >> 16 ,lane)
    wregLane(FW0 + 13, (entryPoint & 0xFFFF),lane)
    checkSum = (entryPoint >> 16) + (entryPoint & 0xFFFF) + 0x4000
    wregLane(FW0 + 14, (~checkSum + 1) & 0xFFFF,lane)
    wregLane(FW0 + 15, 0x4000,lane)
    fw_file_ptr.close()
    log("Done!")
    time.sleep(.5)
    log("crc=%x" % fw_crc(lane))
    #fw_info()
    # pll_cap()
    fw_hash(lane)
    return 1

######################################## Read FW HASH Code
def fw_hash(lane=0):
    result=fw_cmd(fw_hash_cmd, expected_response=0xf, lane=lane)
    low_word = rregLane(fw_cmd_detail_addr, lane=lane)
    hash_code = ((result&0xff)<<16) | low_word
    #print("\n....FW Hash Code: 0x%06X" %(hash_code))
    return hash_code

########################################
def fw_crc(lane=0):
    fw_cmd(fw_crc_cmd, expected_response=0xf, lane=lane)
    checksum_code  = rregLane(fw_cmd_detail_addr, lane=lane)
    #print("\n....FW CRC Checksum: 0x%04X\n" %(checksum_code))
    return checksum_code

#####################################################################
# This function removes any FW already loaded in Serdes
#
####################################################################
def fw_unload(lane=0):
    wregLane(fw_load_magic_word_addr, 0xfff0,lane)
    cpu_reset(lane)
    time.sleep(0.1)
    wregLane(fw_load_magic_word_addr, 0x0,lane)
    wregLane(params(lane).sm_ctrl_addr, 0x0000,lane) # Clear Break points when running without FW
    log("....FW Unloaded")
######################################## Read FW HASH Code
def fw_halt(print_en=1,lane=0):
    if is_fw_running(): # FW is loaded and running, so HALT it
        result=fw_cmd(fw_halt_cmd, expected_response=0xD, lane=lane)
        if (print_en==1): log("\n....FW Halted. Halt Status Code: 0x%04X" % result)

    else: # FW NOT loaded or loaded but already HALTED,
        fw_load_info_code, actual_hash_code, actual_hash_code, actual_crc_code = fw_load_info()
        if (fw_load_info_code > 4): # Firmware Downloaded
            if (print_en==1): log("\n....Valid FW is loaded and already Halted!..To restart FW, Try fw_restart()")
        else:
            if (print_en==1): log("\n....No FW loaded. Nothing to Halt")

    wregLane(params(lane).sm_ctrl_addr, 0x0000) # Clear Break points when running without FW

######################################## Read FW HASH Code
def fw_restart(lane=0):
    cpu_reset()
    if is_fw_running(lane=lane):
        log("\n....FW is Running.")
        if get_mode(lane) != 'pam4':
            wregLane(params(lane).sm_ctrl_addr, 0x8100, 0,lane)
        else:
            wregLane(params(lane).sm_ctrl_addr, 0x8300, 0,lane)
    else:
        log("\n....FW is NOT Running or NOT loaded.")

#####################################################################
# This function determines if and which FW is loaded
#
# status :
#
# 000: no FW loaded
# xx1: correct magic word
# x1x: correct hash code
# 1xx: correct crc code
# 111: all fw info is as expected
#
####################################################################
def fw_load_info(expected_hash_code=None,lane=0):
    global fw_file_hash_code
    fw_load_info_code=0
    actual_magic_word = 0
    actual_hash_code = 0
    actual_crc_code = 0
    try:
        actual_magic_word = rregLane(fw_load_magic_word_addr,lane) # Validate FW magic word
        actual_hash_code = fw_hash(lane)
        actual_crc_code  = fw_crc(lane)
        if expected_hash_code==None: expected_hash_code=fw_file_hash_code

        if (actual_magic_word == fw_load_magic_word): # Firmware Downloaded and magic word is correct
                fw_load_info_code = fw_load_info_code | 1
        if (actual_hash_code == expected_hash_code): # Firmware Downloaded and hash code is correct (hash code readback is valid only if FW is not halted)
                fw_load_info_code = fw_load_info_code | 2
        if (actual_crc_code == fw_file_crc_code): # Firmware Downloaded and crc code is correct
                fw_load_info_code = fw_load_info_code | 4
    except:
        pass



    return fw_load_info_code, actual_magic_word, actual_hash_code, actual_crc_code


####################################################################
# This function checks:
#
# 1. Is any FW loaded, regardless if it is the correct FW , running or halted
#
####################################################################
def is_fw_loaded(lane=0):

    fw_load_info_code, actual_magic_word, actual_hash_code, actual_crc_code = fw_load_info(lane=lane)
    fw_load_stat = fw_load_info_code&1

    return fw_load_stat
#####################################################################
# This function checks:
#
# 1. If a FW is loaded and is running?
#
####################################################################
def is_fw_running(lane=0):
    # global fw_load_magic_word

    val0 = rregLane(fw_watchdog_timer_addr,lane) # check the watchdog counter to see if FW is incrementing it
    time.sleep(1.8) # wait more than one second
    val1 = rregLane(fw_watchdog_timer_addr,lane) # check the watchdog counter once more
    if val1 != val0: # watchdog counter is moving, then FW is loaded and running
        # wregLane(fw_load_magic_word_addr, fw_load_magic_word,lane) # if FW is loaded but magic word is corrupted, correct it
        fw_running_stat=2  # watchdog counter is moving, then FW is loaded and running
    else:
        fw_running_stat=0 # watchdog counter is not moving, then FW is not loaded or halted

    return fw_running_stat

###########################################
def bin2mdio(data, RdCheck,lane=0):
    #fun = self.usb.lib.eagle_bin2mdio
    c_ubyte_arr = c.c_ubyte * 65536
    ubyte_arr = c_ubyte_arr(*map(ord, data))
    fun(c.cast(ubyte_arr, c.POINTER(c.c_ubyte)), RdCheck)

####################################################################
def twos_to_int(twos_val, bitWidth):
    return twos_val - int((twos_val << 1) & 2**bitWidth)
def int_to_twos(value, bitWidth):
    return value - int((value << 1) & 2**bitWidth)
####################################################################
def Bin_Gray(bb=0):
    bb = int(bb)
    gg=bb^(bb>>1)
    return gg

def Gray_Bin(gg=0):
    for x in range(128):
        if Bin_Gray(x)==gg: return x

def get_signed_val(value, bits):
    """
    A small routine to convert a raw 2s complement register value to
    a signed integer

    Returns:
    int: The signed equivalent of the result
    """

    # Used to reverse the 2s complement
    max_val = (2**bits)
    # Values greater than this are negative
    pos_limit = (2**(bits-1)) - 1

    if value > pos_limit:
        result = value - max_val
    else:
        result = value

    if value >= max_val:
        raise ValueError('[get_signed_val] %i larger than a %i-bit number'%(value, bits))

    return result  # get_signed_val



############################################
def wregBits (addr, bits, value, lane=0):
    if (lane >= mgmt.NUM_LANES):
        log("\n****wregBits Error: Addr 0x%04X, Value: 0x%04X to lane %d,  Max Lane Number Exceeded!\n"%(addr, value, lane))
        return
    reg_val = rregLane(addr, lane)
    value_bref = 0
    if value > 2**(bits[0]-bits[-1]+1): # makes sure max value for the bits not exceeded
        value = (2**(bits[0]-bits[-1]+1)) -1
    for i in range(bits[0]-bits[-1]+1):
        value_bref = value_bref + pow(2,i)
        value_edit = reg_val & (0xffff - (value_bref << bits[-1]))
        value_valid = value_edit + ((value & value_bref)<<bits[-1])
    wregLane(addr, value_valid, lane=lane)
############################################
def rregBits(addr, bits, lane=0):
  if (lane >= mgmt.NUM_LANES):
    log("\n****rregBits Error: Max Lane Number Exceeded!\n")
    return 0
  value_all = rregLane(addr, lane)
  ref = 0
  for i in range(bits[0]-bits[-1]+1):
      ref = ref + pow(2,i)
  value = (value_all >> bits[-1]) & ref
  return value
############################################
def wfield (field_name, value, lane=0):
    if (lane >= mgmt.NUM_LANES):
        log("\n****wfield Error: Addr 0x%04X, Value: 0x%04X to lane %d,  Max Lane Number Exceeded!\n"%(addr, value, lane))
        return
    field_addr = field_name[0]
    field_bits = field_name[1]
    reg_val = rregLane(field_addr, lane)
    value_bref = 0
    if value > 2**(field_bits[0]-field_bits[-1]+1): # makes sure max value for the field_bits not exceeded
        value = (2**(field_bits[0]-field_bits[-1]+1)) -1
    for i in range(field_bits[0]-field_bits[-1]+1):
        value_bref = value_bref + pow(2,i)
        value_edit = reg_val & (0xffff - (value_bref << field_bits[-1]))
        value_valid = value_edit + ((value & value_bref)<<field_bits[-1])
    wregLane(field_addr, value_valid, lane=lane)
############################################
def rfield(field_name, lane=0):
  if (lane >= mgmt.NUM_LANES):
    log("\n****rfield Error: Max Lane Number Exceeded!\n")
    return 0
  field_addr = field_name[0]
  field_bits = field_name[1]
  value_all = rregLane(field_addr, lane)
  ref = 0
  for i in range(field_bits[0]-field_bits[-1]+1):
      ref = ref + pow(2,i)
  value = (value_all >> field_bits[-1]) & ref
  return value
########################################
# def reg(addr, val=None):

#     if val!=None:
#         for lane in lane_list:
#             wregLane(addr,val,lane)

#     for lane in lane_list:
#         val=rregLane(addr,lane)
#         print("\n\tREG 0x%04x: 0x%04x" % (addr,val) )
# ########################################
# def rreg(addr):

#     for lane in lane_list:
#         val=rregLane(addr,lane=lane)
#         print("\n\tREG 0x%04x: 0x%04x" % (addr,val) )

# ########################################
# def rreg_ISI(addr):

#     for lane in lane_list:
#         val=rregLane(addr,lane=lane)
#         #print("\n\tREG 0x%04x: 0x%04x" % (addr,val) )
#     return val
# ############################################
# def wreg(addr, val):
#   for lane in lane_list:
#     wregLane(addr,val, lane)

#############################################
def get_eye(lane=0):

    if get_mode(lane) != 'pam4': # NRZ Mode Eye Margin
        if is_fw_loaded(lane=lane):
            eye_reg = dump_nrz_eye(lane=lane)
        else:
            eye_reg = rregBits(params(lane).eye_read_addr, params(lane).eye_read_bit_loc, lane)
        DACQ_reg = rregBits(params(lane).dac_sel_addr, params(lane).dac_sel_bit_loc, lane)
        if eye_reg > 0: ###################### NRZ Eye Formula
            eye_mV= (float(eye_reg) / 2048.0) * ( 200.0 + (50.0 * float(DACQ_reg)))
        else:
            eye_mV=-1

    else: # PAM4 Mode Eye Margin
        bp_en=0
        retries=1000

        #wregBits(dfe_freeze_en_addr, dfe_freeze_bit_loc, 1, lane)
        if(bp_en==1):
            wregLane(0x11, 0x9500, lane)
            while True:
                retries-=1
                bp1_reached = rregBits(0x28, [15], lane)
                if bp1_reached == 1:
                    break
                if retries <= 0:
                    break

        DACQ_reg = rregBits(params(lane).dac_sel_addr, params(lane).dac_sel_bit_loc, lane)
        eye_reg = rregBits(params(lane).eye_read_addr, params(lane).eye_read_bit_loc, lane)
        if eye_reg > 0xFFF:
            time.sleep(.5)
            eye_reg = rregBits(params(lane).eye_read_addr, params(lane).eye_read_bit_loc, lane)
        if eye_reg > 0xFFF:
            eye_reg=-200
            #compat_raw_input("Hit a Key to Continue")

        if(bp_en==1):
            wregLane(0x11, 0x0000, lane)
            wregLane(0x11, 0x2000, lane)
            wregLane(0x11, 0x0000, lane)

        #wregBits(dfe_freeze_en_addr, dfe_freeze_bit_loc, 0, lane)
        if eye_reg > 0: ###################### PAM4 Eye Formula
            eye_mV= (float(eye_reg) / 2048.0) * ( 100.0 + (50.0 * float(DACQ_reg)))
        else:
            eye_mV=-1

        if eye_mV > 300:
            eye_mV=-2

    return eye_mV, DACQ_reg
#############################################
# def get_eye3_orig(lane=0):
#     DACQ_reg = rregBits(params(lane).dac_sel_addr, params(lane).dac_sel_bit_loc, lane)
#     eye_reg = rregBits(params(lane).eye_read_addr, params(lane).eye_read_bit_loc, lane)

#     if gPam4NrzMode[lane] != 'pam4': # NRZ Mode Eye Margin
#         if eye_reg > 0: ###################### NRZ Eye Formula
#             eye_mV= (float(eye_reg) / 2048.0) * ( 200.0 + (50.0 * float(DACQ_reg)))
#         else:
#             eye_mV=-1
#     else: # PAM4 Mode Eye Margin
#         eye0_mV = chip.Condor_Read_Eyemargin0(lane)
#         eye1_mV = chip.Condor_Read_margin1(lane)
#         eye2_mV = chip.Condor_Read_margin2(lane)

#     return eye0_mV[-1], eye1_mV[-1], eye2_mV[-1],  DACQ_reg

#############################################
def get_eye3(lane=0):
    DACQ_reg = rregBits(params(lane).dac_sel_addr, params(lane).dac_sel_bit_loc, lane)
    eye_reg = rregBits(params(lane).eye_read_addr, params(lane).eye_read_bit_loc, lane)

    if get_mode(lane) != 'pam4': # NRZ Mode Eye Margin
        if eye_reg > 0: ###################### NRZ Eye Formula
            eye_mV= (float(eye_reg) / 2048.0) * ( 200.0 + (50.0 * float(DACQ_reg)))
        else:
            eye_mV=-1
    if is_fw_loaded(lane=lane):
        eye0_mV = dump_eye(lane=lane)[0]
        eye1_mV = dump_eye(lane=lane)[1]
        eye2_mV = dump_eye(lane=lane)[2]
        DACQ_reg = rregBits(params(lane).dac_sel_addr, params(lane).dac_sel_bit_loc, lane)
    else: # PAM4 Mode Eye Margin
        eye_margin = []
        for eye_index in range (0,3):
            result = 0xffff
            for y in range (0,4):
                sel = 3*y + eye_index
                wregBits(pam4_dfe_sel_addr, [11,8], sel, lane)
                wregBits(pam4_dfe_sel_addr, [15,12], sel, lane)
                plus_margin = rregBits(pam4_eye_margin_addr, pam4_eye_plus_margin_bit_loc, lane)
                if (plus_margin > 0x7ff):
                    plus_margin = plus_margin - 0x1000
                minus_margin = (rregBits(pam4_eye_margin_addr, pam4_eye_minus_margin_upper_bit_loc, lane) << 8) + (rregBits(pam4_eye_margin_addr2, pam4_eye_minus_margin_lower_bit_loc, lane))
                if (minus_margin > 0x7ff):
                    minus_margin = minus_margin - 0x1000
                diff = plus_margin - minus_margin
                if ( diff < result):
                    result = diff
                else:
                    result = result
                #result = result + diff
            eye_margin.append((result))
        eye0_mV = (float(eye_margin[0])/2048.0) * (100.0 + (50.0 * float(DACQ_reg)))
        eye1_mV = (float(eye_margin[1])/2048.0) * (100.0 + (50.0 * float(DACQ_reg)))
        eye2_mV = (float(eye_margin[2])/2048.0) * (100.0 + (50.0 * float(DACQ_reg)))


    return eye0_mV, eye1_mV, eye2_mV,  DACQ_reg

#############################################
# def eye(print_en=1,lane=0):
#     if(print_en): print("")

#     if gPam4NrzMode[lane] == 'pam4': # PAM4 Mode 3 Eyes
#         for lane in lane_list:
#             eye_mV = chip.Condor_Read_margin0(lane)
#             if(print_en): print("%6.0f" % eye_mV[-1] ),
#             if (print_en and (lane==3 or lane==len(lane_list)-1)):
#                 print("  Eye0 Margin (mV)")
#             elif ((lane+1) % 4 == 0):
#                 print("")
#         for lane in lane_list:
#             eye_mV = chip.Condor_Read_margin1(lane)
#             if(print_en): print("%6.0f" % eye_mV[-1] ),
#             if (print_en and (lane==3 or lane==len(lane_list)-1)):
#                 print("  Eye1 Margin (mV)")
#             elif ((lane+1) % 4 == 0):
#                 print("")
#         for lane in lane_list:
#             eye_mV = chip.Condor_Read_margin2(lane)
#             if(print_en): print("%6.0f" % eye_mV[-1] ),
#             if (print_en and (lane==3 or lane==len(lane_list)-1)):
#                 print("  Eye2 Margin (mV)")
#             elif ((lane+1) % 4 == 0):
#                 print("\n")

#     for lane in lane_list:
#         eye_mV, dac  = get_eye(lane)
#         if(print_en): print("%6.0f" % eye_mV ),
#         if (print_en and (lane==3 or lane==len(lane_list)-1)):
#             print("  EyeMin Margin (mV)")
#         elif ((lane+1) % 4 == 0):
#             print("")
#     for lane in lane_list:
#         eye_mV, dac  = get_eye(lane)
#         if(print_en): print("%6d" % dac ),
#         if (print_en and (lane==3 or lane==len(lane_list)-1)):
#             print("  DACQ")
#         elif ((lane+1) % 4 == 0):
#             print("")

#####################################################
def dacq(ow_dac=None, lane=0):
    if ow_dac!=None:
        if ow_dac>0: # enable OW DAC
            wregBits(params(lane).dac_sel_ow_en_addr, params(lane).dac_sel_ow_en_bit_loc, 1, lane)
            wregBits(params(lane).dac_sel_ow_addr, params(lane).dac_sel_ow_bit_loc, ow_dac, lane)
        else: # DISABLE OW DAC, back to normal
            wregBits(params(lane).dac_sel_ow_en_addr, params(lane).dac_sel_ow_en_bit_loc, 0, lane)
            wregBits(params(lane).dac_sel_ow_addr, params(lane).dac_sel_ow_bit_loc, 0, lane)


    if rregBits(params(lane).dac_sel_ow_en_addr, params(lane).dac_sel_ow_en_bit_loc, lane): # if DAC OW is enabled, notify user
        log("\n>>>> Note: DACQ OW is Enabled (0x%04X[%d]=%d) !\n" % (params(lane).dac_sel_ow_en_addr,
                                                                       params(lane).dac_sel_ow_en_bit_loc[0],
                                                                       rregBits(params(lane).dac_sel_ow_en_addr,
                                                                                params(lane).dac_sel_ow_en_bit_loc, lane)))

    DACQ_reg = rregBits(params(lane).dac_sel_addr, params(lane).dac_sel_bit_loc, lane)

    return DACQ_reg

def fw_cmd(cmd, detail=None, expected_response=None, lane=0):
    if detail is not None:
        wregLane(fw_cmd_detail_addr, detail,lane=lane)
    wregLane(fw_cmd_addr, cmd, lane=lane)
    timeout=True
    for cnt in range(1000):
        result=rregLane(fw_cmd_addr, lane=lane)
        if (result!=cmd):
            timeout=False
            break
    if timeout:
        raise Exception("Command 0x%04x timeout, is firmware running?" % cmd)
    if expected_response is not None:
        response = (result>>8)&0xf
        if response!=expected_response:
            raise Exception("Error returned, code = 0x%04x" % response)
    return result

#####################################################
# Ask Eye Mon fimware to collect the Eye Mon data
# Note: Eye Mon collection is destructive type.
#####################################################
def eye_mon_collect(lane=0, depth=7, option=None):
    log("")

    if option is None:
        option=0
    elif option == "destructive":
        option=2
    elif option == "bathtub":
        option=4

    eye_mon_collection_start_word = fw_eyemon_start_cmd + (depth<<4)  + option
    start_time=time.time()

    result=fw_cmd(eye_mon_collection_start_word, expected_response=0, lane=lane)
    eye_max_samples[lane] = 3 * (10**depth)
    cnt=0
    eye_mon_curr_progress=0
    while ((eye_mon_curr_progress & 0x00ff) < 100):
        result = fw_cmd(fw_eyemon_prog_cmd, expected_response=1, lane=lane)
        eye_mon_curr_progress = result & 0xff
        log_no_newline("\r....Eye Mon Collection In Progress...%3d%%" % (eye_mon_curr_progress))
        if(cnt>100000):
            log_no_newline("\n>>>>EYE_MON Collection Timed Out")
            break
        time.sleep(0.5)
        cnt+=1
    if(cnt<100000): log_no_newline("Done!")
    stop_time=time.time()
    test_time = stop_time - start_time

    global eye_data_type
    eye_data_type[lane] = 'vertical' if option == 4 else 'eye'

    log("Eye Mon Time: %2.3f sec"%(stop_time-start_time))

# multi-lane version of eye_mon_collect()
def eye_mon_collect_multi(lane_list, depth, is_vert_bathtub=False):
    log('Collecting data for %d lanes:' % len(lane_list))

    # option (low 4 bits): 0: normal, 2: destructive, 4: bathtub
    if is_vert_bathtub:
        eye_mon_collection_start_word = fw_eyemon_start_cmd + (depth<<4) + 4
    else:
        eye_mon_collection_start_word = fw_eyemon_start_cmd + (depth<<4)
    start_time=time.time()
    active_lanes = []
    for lane in lane_list:
        try:
            fw_cmd(eye_mon_collection_start_word, expected_response=0, lane=lane)
            active_lanes += [lane]
        except Exception as e:
            log('Could not start collection on %s: %s' % (mgmt.laneToIbPicLaneidx(lane), e))

    if len(active_lanes) == 0:
        return
    for lane in active_lanes:
        global eye_data_type, eye_max_samples
        eye_max_samples[lane] = 3 * (10**depth)
        eye_data_type[lane] = 'vertical' if is_vert_bathtub else 'eye'
    cnt=0
    progress = 0
    while (progress < 100):
        progress = 0
        for lane in active_lanes:
            result = fw_cmd(fw_eyemon_prog_cmd, expected_response=1, lane=lane)
            lane_progress = result & 0xff
            progress += lane_progress
        progress = progress / len(active_lanes)
        sys.stdout.write("\r....Eye Mon Collection In Progress...%3d%%" % (progress)); sys.stdout.flush()
        if(cnt>100000):
            log_no_newline("\n>>>>EYE_MON Collection Timed Out")
            break
        time.sleep(0.5)
        cnt+=1
    if(cnt<100000):
        sys.stdout.write("\r....Eye Mon Collection In Progress...Done!\n"); sys.stdout.flush()
    stop_time=time.time()
    test_time = stop_time - start_time
    log("Eye Mon Time: %2.3f sec" % test_time)

#####################################################
# Extract Eye Mon data from chip
#####################################################

def get_eye_data(lane):
    eye_mon_data_start_addr = 0x9f00
    eye_mon_phase_range = 16

    if get_mode(lane)=='pam4':
        vert_size_side = 63
    else:
        vert_size_side = 48
    vert_size_full = vert_size_side*2+1

    valid_data = False
    eye_mon_columns = []

    ############## Ask FW to pass eye mon data from chip
    for phase in range(-eye_mon_phase_range,eye_mon_phase_range+1):
        pindex = phase+eye_mon_phase_range
        eye_mon_column = []
        for margin in range(-vert_size_side, vert_size_side+1, 16):
            status=fw_cmd(fw_eyemon_read_cmd | (phase & 0xff),
                          detail=margin, lane=lane)

            if ((status>>8) & 0xF) != 2:
                for i in range(16):
                    m = margin + i + vert_size_side
                    if m<vert_size_full:
                        eye_mon_column += [0.0]
            else:
                for i in range(16):
                    m=margin+i+vert_size_side
                    if m<vert_size_full:
                        datapoint = rregLane(eye_mon_data_start_addr+i, lane=lane)
                        val = 10**(-datapoint/16.0)
                        eye_mon_column += [val]
                        valid_data = True
        eye_mon_columns += [eye_mon_column]

    if valid_data:
        return [list(line) for line in zip(*eye_mon_columns)]  # transpose columns to rows
    else:
        return None

def horiz_bathtub_data(lane, margin = 0, saveData = False):
    if not numpyAvailable:
        log('Numpy/Scipy not available: no extrapolation')
        return None, None, None

    eye_mon_data_start_addr = 0x9f00
    phase_scaling = 0.0232  # in units of UI
    phase_range = 16
    horiz_size_full = phase_range * 2 + 1
    bathtub_data=numpy.zeros((horiz_size_full, 1))
    is_valid = False

    if lane not in eye_data_type or eye_data_type[lane] == 'vertical':
        return None, None, None

    for phase in range(-phase_range, phase_range + 1):
        pindex = phase + phase_range
        status = fw_cmd(fw_eyemon_read_cmd | (phase & 0xff), detail=margin, lane=lane)
        if ((status>>8) & 0xF) != 2:
            bathtub_data[pindex] = 0
        else:
            bathtub_data[pindex] = rregLane(eye_mon_data_start_addr, lane=lane)
            is_valid = True

    if not is_valid:
        return None, None, None
    if saveData:
        with open("horiz_bathtub_data_lane_%d_margin_%d_txt.txt" % (lane, margin), "w") as tfile:
            with open("horiz_bathtub_data_lane_%d_margin_%d_bin.bin" % (lane, margin), "wb") as bfile:
                for p in range(horiz_size_full):
                    if bathtub_data[p] == 255:
                        tfile.write("    \n")
                    else:
                        tfile.write("%4d\n" % bathtub_data[p])
                    bfile.write(struct.pack("H", bathtub_data[p]))
    x_list = numpy.arange(-phase_range, phase_range + 1) * phase_scaling
    err_list, samples_list = [], []
    for raw_b in bathtub_data:
        ber = 10**(-raw_b/16.0)
        errs = int(ber * eye_max_samples[lane])
        if errs > 100:
            # FW stops at 100 errors, so adjust samples
            err_list += [100]
            samples_list += [int(100.0 / ber)]
        else:
            err_list += [errs]
            samples_list += [eye_max_samples[lane]]
    return x_list, err_list, samples_list


def vert_bathtub_data(lane, saveData=False):
    if not numpyAvailable:
        log('Numpy/Scipy not available: no extrapolation')
        return None, None, None
    if lane not in eye_data_type:
        return None, None, None
    if get_mode(lane) == 'nrz':
        vert_size_side = 48
    else:  # pam4
        vert_size_side = 63
    eye_mon_data_start_addr = 0x9f00
    vert_size_full = vert_size_side*2+1
    #print "\n...Bathtub Plot In Progress...",
    bathtub_data=numpy.zeros((vert_size_full, 1))
    is_valid = False
    for margin in range(-vert_size_side, vert_size_side, 16):
        status=fw_cmd(fw_eyemon_read_cmd, detail=margin, lane=lane)
        if ((status>>8)&0xf) != 2:
            for i in range(16):
                m=margin+i+vert_size_side
                if m<vert_size_full:
                    bathtub_data[m] = 0
        else:
            for i in range(16):
                m=margin+i+vert_size_side
                if m<vert_size_full:
                    bathtub_data[m] = rregLane(eye_mon_data_start_addr+i, lane=lane)
                    is_valid = True
    if not is_valid:
        return None, None, None

    if saveData:
        bathtub_data_text_file = open("bathtub_data_lane_%d_txt.txt" % lane, "w")
        bathtub_data_bin_file = open("bathtub_data_lane_%d_bin.bin" % lane, "wb")
        for m in range(vert_size_full):
            bathtub_data_text_file.write("\n")
            if bathtub_data[m] == 255:
                bathtub_data_text_file.write("    ")
            else:
                bathtub_data_text_file.write("%4d" % bathtub_data[m])
            bin_value = struct.pack("H", bathtub_data[m])
            bathtub_data_bin_file.write(bin_value)
        bathtub_data_bin_file.close()
        bathtub_data_text_file.close()
    extent = rregLane(0x9816, lane)

    x_list = numpy.arange(-vert_size_side, vert_size_side+1)*extent/vert_size_side     # margin
    err_list, samples_list = [], []
    for raw_b in bathtub_data:
        ber = 10**(-raw_b/16.0)
        errs = int(ber * eye_max_samples[lane])
        if errs > 100:
            # FW stops at 100 errors, so adjust samples
            err_list += [100]
            samples_list += [int(100.0 / ber)]
        else:
            err_list += [errs]
            samples_list += [eye_max_samples[lane]]
    return x_list, err_list, samples_list


#############################################
def get_tuning_done_status():
    tuning_done_all_lanes=1
    for lane in lane_list:
        ctle_done_this_lane = rregBits(fw_tuning_status_addr,fw_tuning_status_done_bit_loc, lane)
        tuning_done_all_lanes = tuning_done_all_lanes * ctle_done_this_lane
    return tuning_done_all_lanes

#############################################
def wait_tuning_done():
    if is_fw_loaded() == 0: # if FW is not loaded or loaded but not running, return
        return 1

    cnt=0
    time.sleep(.020)
    tuning_done = get_tuning_done_status()
    while tuning_done==0:
        cnt+=1
        if cnt>=20000: break
        tuning_done = get_tuning_done_status()

    return tuning_done

#############################################
def prbs_rst(lane=0):
    if get_mode(lane) == 'pam4':
        wregBits(pam4_prbs_cnt_rst_addr, pam4_prbs_cnt_rst_bit_loc, 1, lane)
        wregBits(pam4_prbs_cnt_rst_addr, pam4_prbs_cnt_rst_bit_loc, 0, lane)
    else:
        wregBits(nrz_prbs_cnt_rst_addr, nrz_prbs_cnt_rst_bit_loc, 1, lane)
        wregBits(nrz_prbs_cnt_rst_addr, nrz_prbs_cnt_rst_bit_loc, 0, lane)
    global saved_prbs_err_reset_time
    saved_prbs_err_reset_time[lane] = time.time()
    global saved_prbs_err_last_val
    saved_prbs_err_last_val[lane] = 0

def get_ber_valid(lane):
    if not get_phy_rdy(lane):
        return False

    # check to see if pattern checker is enabled
    if get_mode(lane) != 'pam4':
        return rregBits(0x161, [10], lane=lane)
    else:
        return rregBits(0x43, [4], lane=lane)

def calc_adjusted_ber(mode, err_cnt, total_bits):
    rate = 1.0 * err_cnt / total_bits
    # NRZ PRBS checker is implemented as an xor of three taps, so isolated bit errors trigger 3 counts
    # error rates of 1.0 and 0.5 are still 1.0 and 0.5 though.  So divide BER by 3 if errors are isolated
    if mode == "nrz" and rate < 0.1:
        rate /= 3.0
    return rate

def get_ber_since_reset(lane):
    global saved_prbs_err_last_val
    global saved_prbs_err_reset_time
    count_at_call = get_prbs_cnt_raw(lane)
    # check for rollover since the count was last reset
    if count_at_call < saved_prbs_err_last_val[lane] or saved_prbs_err_reset_time[lane] is None:
        prbs_rst(lane)
        return None, 0

    # sanity check that the counter isn't rolling over or spinning fast
    time.sleep(.01)
    cur_count = get_prbs_cnt_raw(lane)
    if cur_count < count_at_call or cur_count - count_at_call > 1000:
        return None, 0

    saved_prbs_err_last_val[lane] = cur_count

    elapsed = time.time() - saved_prbs_err_reset_time[lane]
    actual_data_rate, _, _, _, _, _, _ = get_pll(lane=lane)
    rate = calc_adjusted_ber(get_mode(lane), cur_count, (elapsed * actual_data_rate * 1e9))

    return rate, elapsed

###########################################
def get_ber(lane=0, rst=1, accum_time=5, max_ber=1e-4, print_status=False):
    data_rate_gbps, _, _, _, _, _, _ = get_pll(lane=lane)
    data_rate = data_rate_gbps * 1e9

    if (rst==1):
        prbs_rst(lane)

    if not get_ber_valid(lane):
        return 0, 0, 1, 0, LANE_NOT_RDY

    total_errors = 0
    last_count, lane_status = get_prbs_cnt(lane)
    if lane_status != LANE_RDY:
        return 0, last_count, 1, 0, lane_status

    if print_status:
        sys.stdout.write('Gathering for up to %d seconds:' % accum_time) ; sys.stdout.flush()
    start_time = time.time()
    last_print_time = start_time
    this_time = start_time
    while (this_time - start_time < accum_time):
        this_count, _ = get_prbs_cnt(lane)
        if this_count >= last_count:
            total_errors += this_count - last_count
        else:
            # HW counter wrapped
            total_errors += this_count + (1<<32) - last_count
        last_count = this_count
        this_time = time.time()
        elapsed_time = this_time - start_time
        if this_time - last_print_time > 1:
            ber = total_errors / (elapsed_time * data_rate)
            if ber > max_ber and elapsed_time > 1.0:
                # BER is big. No sense waiting longer, just return it
                break
            if print_status:
                sys.stdout.write('.') ; sys.stdout.flush()
            last_print_time = this_time
    if print_status:
        sys.stdout.write('\n') ; sys.stdout.flush()
    ber = calc_adjusted_ber(get_mode(lane), total_errors, (elapsed_time * data_rate))
    return elapsed_time, total_errors, ber, math.log10(ber+1e-20), LANE_RDY

###########################################
def get_ber_multi(lane_list, rst=1, accum_time=5, max_ber=1e-4, print_status=False):
    bad_lanes = []

    out, data_rate, last_count, total_errors, ber ={}, {}, {}, {}, {}

    for lane in lane_list:
        data_rate_gbps, _, _, _, _, _, _ = get_pll(lane=lane)
        data_rate[lane] = data_rate_gbps * 1e9

        if (rst==1):
            prbs_rst(lane)

        if not get_ber_valid(lane):
            out[lane] = [0, 0, 1, 0, LANE_NOT_RDY]
            bad_lanes += [lane]
            continue

        total_errors[lane] = 0
        last_count[lane], _ = get_prbs_cnt(lane)

    if print_status:
        sys.stdout.write('Gathering for up to %d seconds:' % accum_time) ; sys.stdout.flush()
    start_time = time.time()
    last_print_time = start_time
    this_time = start_time
    good_lanes = [lane for lane in lane_list if lane not in bad_lanes]
    while (this_time - start_time < accum_time):
        for lane in good_lanes:
            this_count, _ = get_prbs_cnt(lane)
            if this_count >= last_count[lane]:
                total_errors[lane] += this_count - last_count[lane]
            else:
                # HW counter wrapped
                total_errors[lane] += this_count + (1<<32) - last_count[lane]
            last_count[lane] = this_count
        this_time = time.time()
        elapsed_time = this_time - start_time
        if this_time - last_print_time > 1:
            for lane in good_lanes:
                ber[lane] = calc_adjusted_ber(get_mode(lane), total_errors[lane], (elapsed_time * data_rate[lane]))
                if ber[lane] > max_ber and elapsed_time > 1.0:
                    # BER is big. No sense waiting longer for this lane
                    out[lane] = [elapsed_time, total_errors[lane], ber[lane], math.log10(ber[lane]+1e-20), LANE_RDY]
                    bad_lanes += [lane]
            good_lanes = [lane for lane in lane_list if lane not in bad_lanes]
            if len(good_lanes) == 0:
                break
            if print_status:
                sys.stdout.write('.') ; sys.stdout.flush()
            last_print_time = this_time
    if print_status:
        sys.stdout.write('\n') ; sys.stdout.flush()
    for lane in good_lanes:
        out[lane] = [elapsed_time, total_errors[lane], ber[lane], math.log10(ber[lane]+1e-20), LANE_RDY]
    return out

###########################################
def ber (lane=0, rst=1, accum_time=5,accum_errors=1e5):
    if not get_ber_valid(lane):
        log('Rx Pattern Check disabled')
        return
    stat = ['RDY', '***NOT_RDY***','***NOT_GOOD***']
    data_rate, baud_rate, fvco, pll_n, pll_fracn, pll_cap, div4 = get_pll(lane=lane)
    ber_accum_time = accum_time

    if get_mode(lane) != 'pam4':
        if get_nrz_bb_mode(lane) == 1:
            mode='NRZ-BB'
        else:
            mode='NRZ-MM'
    else:
        mode = 'PAM4'

    # get a quick prbs_count to use it a reference as previous count...
    prev_prbs_accum_time, prev_prbs_error_cnt, ber_val, log_ber, lane_status = get_ber(lane, rst, 0.01)

    while True:
        try:
            eye_mV, DACQ = get_eye(lane)
            prbs_accum_time, prbs_error_cnt, ber_val, log_ber, lane_status = get_ber(lane, rst, 0.01)
            ctle_val, ctle1,ctle2 = ctle(lane=lane)
            log_no_newline(" Lane%d: %s, %s, %2.0fG, CTLE: %d, DAC: %d," %( lane, stat[lane_status], mode, math.floor(data_rate), ctle_val, DACQ ))
            prbs_accum_time, prbs_error_cnt, ber_val, log_ber, lane_status = get_ber(lane, 0, ber_accum_time)
            if rst==1:
                log("EYE: %-3.0f, BER: %3.1e %4.2f, %-5.1fs, %s: %-10d" %(eye_mV, ber_val, log_ber, prbs_accum_time, get_prbs_type(lane), prbs_error_cnt))
                break
            else:
                inst_prbs_error_cnt = prbs_error_cnt - prev_prbs_error_cnt
                inst_prbs_accum_time = prbs_accum_time - prev_prbs_accum_time

                log("EYE: %-3.0f, BER: %3.1e %4.2f, %5.3fs, %s: %-10d" %(eye_mV, ber_val, log_ber, inst_prbs_accum_time, get_prbs_type(lane), inst_prbs_error_cnt))
                prev_prbs_error_cnt = prbs_error_cnt
                prev_prbs_accum_time = prbs_accum_time
                ber_accum_time = 0.001
                time.sleep(accum_time)

        except KeyboardInterrupt:
            break

##########################################
def set_tx_test(enable, lane):
    wregBits(0xa0, [13], enable, lane)
    # disable PRBS Gen & CLK
    if not enable:
        wregBits(0xb0, [14], 0, lane=lane) # NRZ PRBS_CLK
        wregBits(0xb0, [11], 0, lane=lane) # NRZ PRBS_GEN
        wregBits(0xa0, [14], 0, lane=lane) # PAM4 PRBS_CLK
        wregBits(0xa0, [11], 0, lane=lane) # PAM4 PRBS_GEN


def get_tx_test(lane):
    return rregBits(0xa0, [13], lane=lane)

#                                  DATA_SRC MODE  CLK  GEN  TEST_PAT  GRAYCODE
pam4_tx_prbs_settings = {'PRBS9':     [1,     0,   1,   1,      0,       0],
                         'PRBS13':    [1,     1,   1,   1,      0,       0],
                         'PRBS13Q':   [1,     1,   1,   1,      0,       1],
                         'PRBS15':    [1,     2,   1,   1,      0,       0],
                         'PRBS31':    [1,     3,   1,   1,      0,       0],
                         'PRBS31Q':   [1,     3,   1,   1,      0,       1],
                         'PATTERN':   [0,     0,   0,   0,      0,       0],
                         'JP03A':     [0,     0,   0,   0,      0,       0],
                         'JP03B':     [0,     0,   0,   0,      1,       0],
                         'LINEARITY': [0,     0,   0,   0,      2,       0]}

nrz_tx_prbs_settings  = {'PRBS9':     [1,     0,   1,   1],
                         'PRBS15':    [1,     1,   1,   1],
                         'PRBS23':    [1,     2,   1,   1],
                         'PRBS31':    [1,     3,   1,   1],
                         'PATTERN':   [0,     0,   0,   0]}

def set_tx_prbs(sequence, lane):
    if get_mode(lane) == 'pam4':
        if sequence not in pam4_tx_prbs_settings:
            log('Tx Pattern %s not valid in PAM4' % (sequence))
            return
        data_src, prbs_mode, prbs_clk, prbs_gen, test_pat, graycode = pam4_tx_prbs_settings[sequence]
        wregBits(0xa0, [15], data_src, lane=lane)
        wregBits(0xa0, [9,8], prbs_mode, lane=lane)
        wregBits(0xa0, [14], prbs_clk, lane=lane)
        wregBits(0xa0, [11], prbs_gen, lane=lane)
        wregBits(0xa0, [3,2], test_pat, lane=lane)
        wregBits(0xaf, [9], graycode, lane=lane)
    else: # NRZ
        if sequence not in nrz_tx_prbs_settings:
            log('Tx Pattern %s not valid for NRZ' % (sequence))
            return
        data_src, prbs_mode, prbs_clk, prbs_gen = nrz_tx_prbs_settings[sequence]
        wregBits(0xa0, [15], data_src, lane=lane)
        wregBits(0xa0, [9,8], prbs_mode, lane=lane)
        wregBits(0xb0, [14], prbs_clk, lane=lane)
        wregBits(0xb0, [11], prbs_gen, lane=lane)

def set_tx_pattern(value, lane):
    wregLane(0xa1, (value >> 48) & 0xffff, lane=lane)
    wregLane(0xa2, (value >> 32) & 0xffff, lane=lane)
    wregLane(0xa3, (value >> 16) & 0xffff, lane=lane)
    wregLane(0xa4, (value >>  0) & 0xffff, lane=lane)

def get_tx_pattern(lane):
    return ((rregLane(0xa1, lane=lane) << 48) + (rregLane(0xa2, lane=lane) << 32) +
            (rregLane(0xa3, lane=lane) << 16) + (rregLane(0xa4, lane=lane)))

def get_tx_type(lane):
    if not get_tx_test(lane):
        if get_rx_tx_serial_loopback(lane):
            return 'LOOPBACK'
        else:
            return 'CORE'
    if get_mode(lane) == 'pam4':
        data_src = rregBits(0xa0, [15], lane=lane)
        prbs_mode = rregBits(0xa0, [9,8], lane=lane)
        prbs_clk = rregBits(0xa0, [14], lane=lane)
        prbs_gen = rregBits(0xa0, [11], lane=lane)
        test_pat = rregBits(0xa0, [3,2], lane=lane)
        graycode = rregBits(0xaf, [9], lane=lane)
        cur_settings = [data_src, prbs_mode, prbs_clk, prbs_gen, test_pat, graycode]
        # find the entry that has the specfied settings
        settings_name = next((name for name, settings in pam4_tx_prbs_settings.items() if settings == cur_settings), None)
    else: # NRZ
        data_src = rregBits(0xa0, [15], lane=lane)
        prbs_mode = rregBits(0xa0, [9,8], lane=lane)
        prbs_clk = rregBits(0xb0, [14], lane=lane)
        prbs_gen = rregBits(0xb0, [11], lane=lane)
        cur_settings = [data_src, prbs_mode, prbs_clk, prbs_gen]
        # find the entry that has the specfied settings
        settings_name = next((name for name, settings in nrz_tx_prbs_settings.items() if settings == cur_settings), None)
    if settings_name is None:
        return 'Unknown'
    if settings_name is 'PATTERN':
        return '%016x' % get_tx_pattern(lane)
    else:
        return settings_name

#                                PRBS_CHECK   PRBS_MODE  GRAYCODE
pam4_rx_prbs_settings = {'PRBS9':  [ 1,           0,        0 ],
                         'PRBS13': [ 1,           1,        0 ],
                         'PRBS13Q':[ 1,           1,        1 ],
                         'PRBS15': [ 1,           2,        0 ],
                         'PRBS31': [ 1,           3,        0 ],
                         'PRBS31Q':[ 1,           3,        1 ],
                         'OFF':    [ 0,           0,     None ]}

nrz_rx_prbs_settings =  {'PRBS9':  [ 1,           0 ],
                         'PRBS15': [ 1,           1 ],
                         'PRBS23': [ 1,           2 ],
                         'PRBS31': [ 1,           3 ],
                         'OFF':    [ 0,           0 ]}

def set_rx_prbs(sequence, lane):
    if get_mode(lane) == 'pam4':
        if sequence not in pam4_rx_prbs_settings:
            log('Tx Pattern %s not valid for PAM4' % (sequence))
            return
        prbs_check, prbs_mode, graycode = pam4_rx_prbs_settings[sequence]
        wregBits(0x43, [4], prbs_check, lane=lane)
        wregBits(0x43, [6,5], prbs_mode, lane=lane)
        if graycode is not None:
            wregBits(0x42, [0], graycode, lane=lane)
    else:
        if sequence not in nrz_rx_prbs_settings:
            log('Tx Pattern %s not valid for NRZ' % (sequence))
            return
        prbs_check, prbs_mode = nrz_rx_prbs_settings[sequence]
        wregBits(0x161, [10], prbs_check, lane=lane)
        wregBits(0x161, [13,12], prbs_mode, lane=lane)

def get_rx_pat_match(lane):
    if get_mode(lane) == 'pam4':
        prbs_check = rregBits(0x43, [4], lane=lane)
        if not prbs_check:
            return 'OFF'
        prbs_mode = rregBits(0x43, [6,5], lane=lane)
        graycode = rregBits(0x42, [0], lane=lane)
        cur_settings = [prbs_check, prbs_mode, graycode]
        settings_name = next((name for name, settings in pam4_rx_prbs_settings.items() if settings == cur_settings), None)
    else:
        prbs_check = rregBits(0x161, [10], lane=lane)
        if not prbs_check:
            return 'OFF'
        prbs_mode = rregBits(0x161, [13,12], lane=lane)
        cur_settings = [prbs_check, prbs_mode]
        settings_name = next((name for name, settings in nrz_rx_prbs_settings.items() if settings == cur_settings), None)

    if settings_name is None:
        return 'Unknown'
    else:
        return settings_name

###########################################
def get_prbs_cnt_raw(lane=0):
    if get_mode(lane)=='pam4':
        return rreg32Lane(pam4_prbs_cnt_addr, lane)
    else:
        return rreg32Lane(nrz_prbs_cnt_addr, lane)

###########################################
def get_phy_rdy (lane):
    return rregBits(params(lane).sd_rdy_addr, params(lane).rdy_bit_loc, lane)

def get_sig_detect (lane):
    return rregBits(params(lane).sd_rdy_addr, params(lane).sig_det_loc, lane)

def get_prbs_cnt (lane=0):
    if not get_phy_rdy(lane):
        return get_prbs_cnt_raw(lane), LANE_NOT_RDY

    return get_prbs_cnt_raw(lane), LANE_RDY
##############################


##########################################
#
# MR/LR mode emulation by Dis/En FFE
#
##########################################
def mr_mode (mr_en=None, lane=0):

    global gMrMode
    global gFfeTune1En

    if mr_en!=None:
        # MR Mode enabled, FFE Disabled, FFE_Gain1=8, FFE_Gain2=0
        if mr_en == 'en' or mr_en == 1:
            wregBits(ffe_en_addr, ffe_en_bit_loc, 0, lane)
            wregBits(fw_tuning_ctrl_addr, fw_tuning_ctrl_ffe_adapt_dis_bit_loc, 1, lane) # Set to 1 to disable FFE Adapt by FW
            ffe_taps(0x00,0x00, 0x00, 0x00, 0x00, 0x00, lane) # FFE taps at set to 0
            ffe_pol(0, 0, 0, 0, lane) # FFE taps polaroties set to 0
            dc_gain(ctle_gain1=None, ffe_gain1=8, ctle_gain2=None, ffe_gain2=0, lane=lane)
            dc_gain(0, 15,31*4, 0,lane=lane) # LR mode (FFE on) initial DC Gain for channel analyzer
            sel_ctle_map(IL='56G_Rev40_MR', lane=lane) # MR CTLE table: IL = 0 to 20dB
            for i in range (85,89): # in MR mode, FFE Gain in FW's DC_GAIN is always 8 (not 15 for higher chan Est)
                fw_reg(i,0x0808,lane=lane)
                ## ??? Is this right? TODO
            gFfeTune1En=False    # Do not run Python FFE Fine Search routine during Adaptation
            gMrMode = 'en'

        # LR Mode, FFE Enabled, leave FFE_Gain1/2 as is
        elif mr_en == 'dis' or mr_en == 0:
            wregBits(ffe_en_addr, ffe_en_bit_loc, 1, lane)
            wregBits(fw_tuning_ctrl_addr, fw_tuning_ctrl_ffe_adapt_dis_bit_loc, 0, lane) # Set to 0 to enable FFE Adapt by FW
            dc_gain(0, 15,31*1, 0,lane=lane) # LR mode (FFE on) initial DC Gain for channel analyzer
            sel_ctle_map(IL='56G_Rev40', lane=lane) # Standard CTLE table: IL = 0 to 30dB
            fw_reg(85,0x080F,lane=lane)
            fw_reg(86,0x0F0F,lane=lane)
            fw_reg(87,0x0F0F,lane=lane)
            fw_reg(88,0x0F00,lane=lane)
            ## ??? Is this right? TODO
            gFfeTune1En=True    # Run Python FFE Fine Search routine during Adaptation
            gMrMode = 'dis'
        else: #mr_en == '?':
            log_no_newline("\n    To Check SerDes for MR Mode:  mr_mode()      => Returns 1 if MR Mode, 0 if LR Mode")
            log_no_newline("\n    To Put SerDes in MR Mode   :  mr_mode('en')  => Returns 1")
            log("\n    To Put SerDes in LR Mode   :  mr_mode('dis') => Returns 0\n")

    ffe_en = rregBits(ffe_en_addr, ffe_en_bit_loc, lane)
    fw_ffe_adapt_skip = rregBits(fw_tuning_ctrl_addr, fw_tuning_ctrl_ffe_adapt_dis_bit_loc, lane) # Set to 1 to disable FFE Adapt by FW

    #  MR Mode = FFE Disabled, FFE_Gain1=8, FFE_Gain2=0
    if (ffe_en==0 and gMrMode=='en' and fw_ffe_adapt_skip==1):
        mr_mode_en = 1
    else:
        mr_mode_en = 0

    return mr_mode_en
##########################################
# Select NRZ timing mode to be
# Bang-Bang Mode or Muller-Mueller mode
# Options:
#          for 25G BB mode
#          for 25G MM mode
#          for 10G BB mode
#
##########################################
def set_nrz_bb_mode (en=1, rx_half_rate_mode=0, lane=0):

    if rx_half_rate_mode==0: # NRZ Full Rate
        if en == 1: # NRZ Full Rate BB Mode
            wregLane(0x0179,0x887c+rx_half_rate_mode, lane)  # 0x801E #Bit0=1 => 10G
            #wregBits(nrz_delta_adapt_en_addr, nrz_delta_adapt_en_bit_loc, 0, lane) # Disable Delta Adapt (clean up)
            #wregLane(0x013B,0xD000, lane) # bits[15] CDR OW en, and bits [14:1] CDR BW Kp = 5 for BB mode (FW clears this, do not use)
            wregLane(0x0182,0xb800, lane)  # bits[15:13] = CDR BW after Link-up = 5 for 25G BB mode (use this to program CDR BW Kp)

            wregBits(nrz_bb_mode_addr, nrz_bb_mode_bit_loc, 1, lane) # need to set BB bit only when in full rate mode
            wregLane(0x0101,0x0201, lane)  # 0xC201
            wregLane(0x0100,0x437D, lane)  #  6,-3
            wregLane(0x0107,0x4078, lane)  #  0,-8
            wregLane(0x0183,0x4902, lane)  # 18, 2
            wregLane(0x0184,0x81FB, lane)  #  3,-5
            wregLane(0x0185,0x477D, lane)  # 14,-3
            wregLane(0x0186,0xC97E, lane)  # 18,-2
            wregLane(0x0187,0x02FB, lane)  #  5,-5
            wregLane(0x0188,0x41FB, lane)  #  3,-5

        else: # NRZ Full Rate MM Mode
            wregBits(nrz_bb_mode_addr, nrz_bb_mode_bit_loc, 0, lane) # Disable BB mode
            #wregBits(nrz_delta_adapt_en_addr, nrz_delta_adapt_en_bit_loc, 1, lane) # enable Delta Adapt (clean up)
            wregLane(0x0179,0x883E+rx_half_rate_mode, lane)
            wregLane(0x0182,0xd800, lane)  # bits[15:13] = CDR BW after Link-up = 6 for 25G MM mode (use this to program CDR BW Kp)
            wregLane(0x0101,0x4201, lane)  # 0xC201
            wregLane(0x0100,0x4900, lane)  # 0x5185
            wregLane(0x0107,0x44FB, lane)  # 0x5185
            wregLane(0x0183,0x4B08, lane)  # 0x5185
            wregLane(0x0184,0x82FA, lane)  # 0x9185
            wregLane(0x0185,0x4B82, lane)  # 0x5185
            wregLane(0x0186,0xCB88, lane)  # 0xD185
            wregLane(0x0187,0x497A, lane)  # 0x5185
            wregLane(0x0188,0x417A, lane)  # 0x5185

    else: # NRZ 10G/12.5G Mode (NRZ half-rate mode), BB MODE ONLY
        wregLane(0x0179,0x887c+rx_half_rate_mode, lane)  # 0x801E #Bit0=1 => 10G
        #wregBits(nrz_delta_adapt_en_addr, nrz_delta_adapt_en_bit_loc, 0, lane) # Disable Delta Adapt (clean up)
        #wregLane(0x013B,0xD000, lane) # bits[15] CDR OW en, and bits [14:1] CDR BW Kp = 5 for BB mode (FW clears this, do not use)
        wregLane(0x0182,0xd800, lane)  # bits[15:13] = CDR BW after Link-up = 6 for 10G BB mode (use this to program CDR BW Kp)
        wregBits(nrz_bb_mode_addr, nrz_bb_mode_bit_loc, 0, lane) # clear 25G BB bit for half rate mode
        wregLane(0x0101,0x0201, lane)  # 0xC201
        wregLane(0x0100,0x4013, lane)  # 0x5185
        wregLane(0x0107,0x4010, lane)  # 0x5185
        wregLane(0x0183,0x4013, lane)  # 0x5185
        wregLane(0x0184,0x8007, lane)  # 0x9185
        wregLane(0x0185,0x4013, lane)  # 0x5185
        wregLane(0x0186,0xC014, lane)  # 0xD185
        wregLane(0x0187,0x4012, lane)  # 0x5185
        wregLane(0x0188,0x4006, lane)  # 0x5185


##########################################
def get_nrz_bb_mode(lane=0):

    bb_mode_en = rregBits(nrz_bb_mode_addr, nrz_bb_mode_bit_loc, lane) # check BB mode
    delta_adapt_en=rregBits(nrz_delta_adapt_en_addr, nrz_delta_adapt_en_bit_loc, lane) # check Delta Adapt

    if bb_mode_en == 1 and delta_adapt_en==0:
        bb_mode=1
    elif bb_mode_en == 1 and delta_adapt_en==1:
        #print "\n>>> get_nrz_bb_mode: Non-ideal combination of BB_Mode bit and Delta_Adapt_En bit"
        bb_mode=1
    else:
        bb_mode=0

    return bb_mode

############################################
def pol(tx_pol=None, rx_pol=None,lane=0):

    print_en=0

    if rx_pol is None:
        rx_pol = tx_pol
    if tx_pol is not None:
        wregBits(tx_pol_addr, tx_pol_bit_loc, tx_pol, lane)
        wregBits(rx_nrz_pol_addr, rx_nrz_pol_bit_loc, rx_pol, lane)
        wregBits(rx_pam4_pol_addr, rx_pam4_pol_bit_loc, rx_pol, lane)
    else:
        print_en=1

    tx_pol= rregBits(tx_pol_addr, tx_pol_bit_loc,lane)
    rx_pol= rregBits(rx_nrz_pol_addr, rx_nrz_pol_bit_loc,lane)
    #if(gDebugTuning or print_en): print("\n TX Polarity: %d -- RX Polarity: %d"%(tx_pol, rx_pol)),
    log_no_newline("\n TX Polarity: %d -- RX Polarity: %d"%(tx_pol, rx_pol))
    return (tx_pol,rx_pol)


#############################################
def pc (tx_pc=None, rx_pc=None,lane=0):
    print_en=0
    tx_pc_en_addr = 0xAF # TX Precoder En, |  0= PC Dis | 1 = PC En
    tx_pc_en_bit_loc = [8]
    rx_pc_en_addr = 0x42 # RX Precoder En, |  0= PC Dis | 1 = PC En
    rx_pc_en_bit_loc = [1]

    if tx_pc!=None and rx_pc==None:
        wregBits(tx_pc_en_addr, tx_pc_en_bit_loc, tx_pc, lane)
        wregBits(rx_pc_en_addr, rx_pc_en_bit_loc, tx_pc, lane)
    elif tx_pc!=None and rx_pc!=None:
        wregBits(tx_pc_en_addr, tx_pc_en_bit_loc, tx_pc, lane)
        wregBits(rx_pc_en_addr, rx_pc_en_bit_loc, rx_pc, lane)
    else:
        print_en=1


    tx_pc = rregBits(tx_pc_en_addr, tx_pc_en_bit_loc, lane)
    rx_pc = rregBits(rx_pc_en_addr, rx_pc_en_bit_loc, lane)
    if(gDebugTuning or print_en): log_no_newline("\n TX Precoder: %d -- RX Precoder: %d" %(tx_pc, rx_pc))
    log_no_newline(" TX Precoder: %d -- RX Precoder: %d" %(tx_pc, rx_pc))
    #return tx_pc,rx_pc

##
def get_rx_precode(lane):
    rx_pc_en_addr = 0x42 # RX Precoder En, |  0= PC Dis | 1 = PC En
    rx_pc_en_bit_loc = [1]
    return rregBits(rx_pc_en_addr, rx_pc_en_bit_loc, lane)

def set_rx_precode(val, lane):
    rx_pc_en_addr = 0x42 # RX Precoder En, |  0= PC Dis | 1 = PC En
    rx_pc_en_bit_loc = [1]
    wregBits(rx_pc_en_addr, rx_pc_en_bit_loc, val, lane)

def get_tx_precode(lane):
    tx_pc_en_addr = 0xAF # TX Precoder En, |  0= PC Dis | 1 = PC En
    tx_pc_en_bit_loc = [8]
    return rregBits(tx_pc_en_addr, tx_pc_en_bit_loc, lane)

def set_tx_precode(val, lane):
    tx_pc_en_addr = 0xAF # TX Precoder En, |  0= PC Dis | 1 = PC En
    tx_pc_en_bit_loc = [8]
    wregBits(tx_pc_en_addr, tx_pc_en_bit_loc, val, lane)

#############################################
def gc (tx_gc=None, rx_gc=None, lane=0):
    print_en=0
    tx_gc_en_addr = 0xAF # TX Gray Code En, |  0= GC Dis | 1 = GC En (PRBSQ)
    tx_gc_en_bit_loc = [9]
    rx_gc_en_addr = 0x42 # RX Gray Code En, |  0= GC Dis | 1 = GC En (PRBSQ)
    rx_gc_en_bit_loc = [0]

    if tx_gc!=None and rx_gc==None:
        wregBits(tx_gc_en_addr, tx_gc_en_bit_loc, tx_gc, lane)
        wregBits(rx_gc_en_addr, rx_gc_en_bit_loc, tx_gc, lane)
    elif tx_gc!=None and rx_gc!=None:
        wregBits(tx_gc_en_addr, tx_gc_en_bit_loc, tx_gc, lane)
        wregBits(rx_gc_en_addr, rx_gc_en_bit_loc, rx_gc, lane)
    else:
        print_en=1

    tx_gc = rregBits(tx_gc_en_addr, tx_gc_en_bit_loc, lane)
    rx_gc = rregBits(rx_gc_en_addr, rx_gc_en_bit_loc, lane)
    if(gDebugTuning or print_en): log_no_newline("\n TX GrayCode: %d -- RX GrayCode: %d" %(tx_gc, rx_gc))
    log("\n TX GrayCode: %d -- RX GrayCode: %d" %(tx_gc, rx_gc))

    #return tx_gc,rx_gc

##
def get_rx_graycode(lane):
    rx_gc_en_addr = 0x42 # RX Gray Code En, |  0= GC Dis | 1 = GC En (PRBSQ)
    rx_gc_en_bit_loc = [0]
    return rregBits(rx_gc_en_addr, rx_gc_en_bit_loc, lane)

def set_rx_graycode(val, lane):
    rx_gc_en_addr = 0x42 # RX Gray Code En, |  0= GC Dis | 1 = GC En (PRBSQ)
    rx_gc_en_bit_loc = [0]
    wregBits(rx_gc_en_addr, rx_gc_en_bit_loc, val, lane)

def get_tx_graycode(lane):
    tx_gc_en_addr = 0xAF # TX Gray Code En, |  0= GC Dis | 1 = GC En (PRBSQ)
    tx_gc_en_bit_loc = [9]
    return rregBits(tx_gc_en_addr, tx_gc_en_bit_loc, lane)

def set_tx_graycode(val, lane):
    tx_gc_en_addr = 0xAF # TX Gray Code En, |  0= GC Dis | 1 = GC En (PRBSQ)
    tx_gc_en_bit_loc = [9]
    wregBits(tx_gc_en_addr, tx_gc_en_bit_loc, val, lane)

#############################################
def msblsb (tx_msblsb=None, rx_msblsb=None,lane=0):
    print_en=0
    tx_msb_lsb_addr = 0xAF # TX MSB-LSB Swap, | 0=MSB first | 1 = LSB first
    tx_msb_lsb_bit_loc = [10]
    rx_msb_lsb_addr = 0x43 # RX MSB-LSB Swap, | 0=MSB first | 1 = LSB first
    rx_msb_lsb_bit_loc = [15]

    if tx_msblsb!=None and rx_msblsb==None:
        wregBits(tx_msb_lsb_addr, tx_msb_lsb_bit_loc, tx_msblsb, lane)
        wregBits(rx_msb_lsb_addr, rx_msb_lsb_bit_loc, tx_msblsb, lane)
    elif tx_msblsb!=None and rx_msblsb!=None:
        wregBits(tx_msb_lsb_addr, tx_msb_lsb_bit_loc, tx_msblsb, lane)
        wregBits(rx_msb_lsb_addr, rx_msb_lsb_bit_loc, rx_msblsb, lane)
    else:
        print_en=1

    tx_msb_lsb = rregBits(tx_msb_lsb_addr, tx_msb_lsb_bit_loc, lane)
    rx_msb_lsb = rregBits(rx_msb_lsb_addr, rx_msb_lsb_bit_loc, lane)
    if(gDebugTuning or print_en): log_no_newline("\n TX MSB-LSB : %d -- RX MSB-LSB : %d" %(tx_msb_lsb, rx_msb_lsb))
    log_no_newline("\n TX MSB-LSB : %d -- RX MSB-LSB : %d" %(tx_msb_lsb, rx_msb_lsb))
    #return tx_msb_lsb,rx_msb_lsb

def get_tx_msblsb(lane):
    return rregBits(tx_pam4_msblsb_addr, tx_pam4_msblsb_bit_loc, lane)

def set_tx_msblsb(val, lane):
    wregBits(tx_pam4_msblsb_addr, tx_pam4_msblsb_bit_loc, val, lane)

def get_rx_msblsb(lane):
    return rregBits(rx_pam4_msblsb_addr, rx_pam4_msblsb_bit_loc, lane)

def set_rx_msblsb(val, lane):
    wregBits(rx_pam4_msblsb_addr, rx_pam4_msblsb_bit_loc, val, lane)

###########################################
def set_pat (pat=None, lane=0):

    if pat==None:
        log_no_newline("\n Usage:")
        log_no_newline("\n set_pat(pat='1T', lane=0)")
        log_no_newline("\n options for pat:")
        log_no_newline("\n\t\t '00'")
        log_no_newline("\n\t\t '1T'")
        log_no_newline("\n\t\t '2T'")
        log_no_newline("\n\t\t '4T'")
        log_no_newline("\n\t\t '8T'")
        log_no_newline("\n\t\t '16T")
        log_no_newline("\n\t\t '32T'")
        log_no_newline("\n\t\t 'NRZ-PRBS9'")
        log_no_newline("\n\t\t 'NRZ-PRBS15'")
        log_no_newline("\n\t\t 'NRZ-PRBS23'")
        log_no_newline("\n\t\t 'NRZ-PRBS31'")
        log_no_newline("\n\t\t 'PAM4-PRBS9'")
        log_no_newline("\n\t\t 'PAM4-PRBS13'")
        log_no_newline("\n\t\t 'PAM4-PRBS15'")
        log_no_newline("\n\t\t 'PAM4-PRBS31'")
        log_no_newline("\n\t\t 'PAM4-PRBS9Q'")
        log_no_newline("\n\t\t 'PAM4-PRBS13Q'")
        log_no_newline("\n\t\t 'PAM4-PRBS15Q'")
        log_no_newline("\n\t\t 'PAM4-PRBS31Q'")
        log_no_newline("\n\t\t 'PAM4-PRBS9QP'")
        log_no_newline("\n\t\t 'PAM4-PRBS13QP'")
        log_no_newline("\n\t\t 'PAM4-PRBS15QP'")
        log_no_newline("\n\t\t 'PAM4-PRBS31QP'")
        return

    requested_pattern_found=0

    tx_nrz_en_addr = 0xB0         # TX NRZ Mode | 0=Dis (PAM4) | 1 = En (NRZ)
    tx_nrz_en_bit_loc = [1]
    tx_nrz_prbs_en_addr = 0xB0     # TX NRZ PRBS Mode | 0=Dis (NRZ Test Patt) | 1 = En (NRZ PRBS)
    tx_nrz_prbs_en_bit_loc = [11]
    tx_nrz_prbs_gen_en_addr = 0xB0  # TX NRZ PRBS Gen | 0=Dis | 1 = En  (Set this bit to en clock to NRZ PRBS generator)
    tx_nrz_prbs_gen_en_bit_loc = [14]
    tx_pam4_prbs_gen_en_addr = 0xA0 # TX PAM4 PRBS Gen | 0=Dis | 1 = En  (Set this bit to en clock to PAM4 PRBS generator)
    tx_pam4_prbs_gen_en_bit_loc = [14]

    rx_nrz_en_addr = 0x179 # RX NRZ Mode En | 0=Dis | 1 = En  (Set this bit to en clock to NRZ RX)
    rx_nrz_en_bit_loc = [5]
    rx_pam4_en_addr = 0x41 # RX PAM4 Mode En | 0=Dis | 1 = En  (Set this bit to en PAM4 RX)
    rx_pam4_en_bit_loc = [15]

    tx_msb_lsb_addr = 0xAF # TX MSB-LSB Swap, | 0=MSB first | 1 = LSB first
    tx_msb_lsb_bit_loc = [10]
    rx_msb_lsb_addr = 0x43 # RX MSB-LSB Swap, | 0=MSB first | 1 = LSB first
    rx_msb_lsb_bit_loc = [15]

    tx_gc_en_addr = 0xAF # TX Gray Code En, |  0= GC Dis | 1 = GC En (PRBSQ)
    tx_gc_en_bit_loc = [9]
    rx_gc_en_addr = 0x42 # RX Gray Code En, |  0= GC Dis | 1 = GC En (PRBSQ)
    rx_gc_en_bit_loc = [0]

    tx_pc_en_addr = 0xAF # TX Precoder En, |  0= PC Dis | 1 = PC En
    tx_pc_en_bit_loc = [8]
    rx_pc_en_addr = 0x42 # RX Precoder En, |  0= PC Dis | 1 = PC En
    rx_pc_en_bit_loc = [1]

    #             patt          patt4  patt3  patt2, patt1  prbs? prbstype, GrayCode, Precode, MSB-LSB
    pat_list=[ ['00',          0x0000,0x0000,0x0000,0x0000, 0,     0,      0,        0,       0 ],\
               ['1T',          0xAAAA,0xbAAA,0xcAAA,0xdAAA, 0,     0,      0,        0,       0 ],\
               ['2T',          0xCCCC,0xCCCC,0xCCCC,0xCCCC, 0,     0,      0,        0,       0 ],\
               ['4T',          0xF0F0,0xF0F0,0xF0F0,0xF0F0, 0,     0,      0,        0,       0 ],\
               ['8T',          0xFF00,0xFF00,0xFF00,0xFF00, 0,     0,      0,        0,       0 ],\
               ['16T',         0xFFFF,0x0000,0xFFFF,0x0000, 0,     0,      0,        0,       0 ],\
               ['32T',         0xFFFF,0xFFFF,0x0000,0x0000, 0,     0,      0,        0,       0 ],\
               ['NRZ-PRBS9',    0x9999,0x9999,0x9999,0x9999, 1,     0,      0,        0,       0 ],\
               ['NRZ-PRBS15',   0x1515,0x1515,0x1515,0x1515, 1,     1,      0,        0,       0 ],\
               ['NRZ-PRBS23',   0x2323,0x2323,0x2323,0x2323, 1,     2,      0,        0,       0 ],\
               ['NRZ-PRBS31',   0x3131,0x3131,0x3131,0x3131, 1,     3,      0,        0,       0 ],\
               ['PAM4-PRBS9',   0x9999,0x9999,0x9999,0x9999, 1,     0,      0,        0,       0 ],\
               ['PAM4-PRBS13',  0x1313,0x1313,0x1313,0x1313, 1,     1,      0,        0,       0 ],\
               ['PAM4-PRBS15',  0x1515,0x1515,0x1515,0x1515, 1,     2,      0,        0,       0 ],\
               ['PAM4-PRBS31',  0x3131,0x3131,0x3131,0x3131, 1,     3,      0,        0,       0 ],\
               ['PAM4-PRBS9Q',  0x9999,0x9999,0x9999,0x9999, 1,     0,      1,        0,       0 ],\
               ['PAM4-PRBS13Q', 0x1313,0x1313,0x1313,0x1313, 1,     1,      1,        0,       0 ],\
               ['PAM4-PRBS15Q', 0x1515,0x1515,0x1515,0x1515, 1,     2,      1,        0,       0 ],\
               ['PAM4-PRBS31Q', 0x3131,0x3131,0x3131,0x3131, 1,     3,      1,        0,       0 ],\
               ['PAM4-PRBS9QP', 0x9999,0x9999,0x9999,0x9999, 1,     0,      1,        1,       0 ],\
               ['PAM4-PRBS13QP',0x1313,0x1313,0x1313,0x1313, 1,     1,      1,        1,       0 ],\
               ['PAM4-PRBS15QP',0x1515,0x1515,0x1515,0x1515, 1,     2,      1,        1,       0 ],\
               ['PAM4-PRBS31QP',0x3131,0x3131,0x3131,0x3131, 1,     3,      1,        1,       0 ]]


    for i in range(len(pat_list)): # look for the requested pattern in the pat_list
        if pat.upper() in pat_list[i][0]: # FOUND requested pattern in the pat_list, program it
            requested_pattern_found=1
            log("\n....Programmed Serdes for %s Pattern"%pat_list[i][0])
            wregLane(tx_test_patt_addr_4, pat_list[i][1], lane)
            wregLane(tx_test_patt_addr_3, pat_list[i][2], lane)
            wregLane(tx_test_patt_addr_2, pat_list[i][3], lane)
            wregLane(tx_test_patt_addr_1, pat_list[i][4], lane)
            wregBits(tx_test_patt_ctrl_addr,tx_test_patt_ctrl_bit_loc, pat_list[i][5], lane) # 0: Test Pattern 1: PRBS

            wregBits(tx_test_patt_sel_addr, tx_test_patt_sel_bit_loc, pat_list[i][6], lane) # TX PRBS mode
            wregBits(params(lane).prbs_mode_sel_addr, params(lane).prbs_mode_sel_bit_loc, pat_list[i][6], lane) # RX PRBS Mode

            wregBits(tx_gc_en_addr,tx_gc_en_bit_loc, pat_list[i][7], lane) # TX Gray Code En,|  0= GC Dis | 1 = GC En (PRBSQ)
            wregBits(rx_gc_en_addr,rx_gc_en_bit_loc, pat_list[i][7], lane) # RX Gray Code En,|  0= GC Dis | 1 = GC En (PRBSQ)

            wregBits(tx_gc_en_addr,tx_pc_en_bit_loc, pat_list[i][8], lane) # TX Precoder En, |  0= PC Dis | 1 = PC En
            wregBits(rx_gc_en_addr,rx_pc_en_bit_loc, pat_list[i][8], lane) # RX Precoder En, |  0= PC Dis | 1 = PC En

            wregBits(tx_msb_lsb_addr,tx_msb_lsb_bit_loc, pat_list[i][9], lane) # TX MSB-LSB Swap, | 0= LSB first | 1 = MSB first
            wregBits(rx_msb_lsb_addr,rx_msb_lsb_bit_loc, pat_list[i][9], lane) # RX MSB-LSB Swap, | 0= MSB first | 1 = LSB first

            if 'PAM' in pat_list[i][0]: # PAM4 PRBS patterns
                wregBits(tx_nrz_en_addr,         tx_nrz_en_bit_loc,          0, lane)
                wregBits(rx_nrz_en_addr,         rx_nrz_en_bit_loc,          0, lane)
                wregBits(tx_nrz_prbs_en_addr,     tx_nrz_prbs_en_bit_loc,     0, lane)
                wregBits(tx_nrz_prbs_gen_en_addr, tx_nrz_prbs_gen_en_bit_loc,  0, lane)
                wregBits(tx_pam4_prbs_gen_en_addr,tx_pam4_prbs_gen_en_bit_loc, 1, lane)
                wregBits(rx_pam4_en_addr,        rx_pam4_en_bit_loc,         1, lane)
            elif 'NRZ' in pat_list[i][0]:# NRZ PRBS patterns
                wregBits(tx_pam4_prbs_gen_en_addr,tx_pam4_prbs_gen_en_bit_loc, 0, lane)
                wregBits(rx_pam4_en_addr,        rx_pam4_en_bit_loc,         0, lane)
                wregBits(tx_nrz_en_addr,         tx_nrz_en_bit_loc,          1, lane)
                wregBits(tx_nrz_prbs_en_addr,     tx_nrz_prbs_en_bit_loc,     1, lane)
                wregBits(tx_nrz_prbs_gen_en_addr, tx_nrz_prbs_gen_en_bit_loc,  1, lane)
                wregBits(rx_nrz_en_addr,         rx_nrz_en_bit_loc,          1, lane)
            else: # Repeating Test patterns
                wregBits(tx_pam4_prbs_gen_en_addr,tx_pam4_prbs_gen_en_bit_loc, 0, lane)
                wregBits(rx_pam4_en_addr,        rx_pam4_en_bit_loc,         0, lane)
                wregBits(tx_nrz_en_addr,         tx_nrz_en_bit_loc,          1, lane)
                wregBits(tx_nrz_prbs_en_addr,     tx_nrz_prbs_en_bit_loc,     0, lane)
                wregBits(tx_nrz_prbs_gen_en_addr, tx_nrz_prbs_gen_en_bit_loc,  0, lane)
                wregBits(rx_nrz_en_addr,         rx_nrz_en_bit_loc,          1, lane)


            return # requested pattern FOUND and done programming all relevant registers

    if (requested_pattern_found==0):
        log_no_newline("\n>>>> Requested Pattern '%s' not in the list"%pat)
        log("\n>>>> Enter 'set_pat()' to see the available list of patterns")
####################################################################
# When OWEN_TX_IDLE =1, IDLE mode will control by OW_TX_IDLE, not TX_IDLE pins.
# that is
# 9803[13] OWEN_TX_IDLE =1
# 9803[14] OW_TX_IDLE =1
# -----------regardless of TX_IDLE pins ,force all the TX output = 0
#
# 9803[13] OWEN_TX_IDLE =1
# 9803[14] OW_TX_IDLE =0
# ----------- regardless of TX_IDLE pins , output TX data.
#
####################################################################
def tx_idle_set(enable, lane):
    if enable:
        wregBits(0x9803, [13], 1, lane) # OWEN_TX_IDLE=1, TX_IDLE bit controls IDLE mode
        wregBits(0x9803, [14], 1, lane) # OW_TX_IDLE  =1, output 0
    else:
        wregBits(0x9803, [13], 0, lane) # OWEN_TX_IDLE=0, TX_IDLE pins controls IDLE mode
        wregBits(0x9803, [14], 0, lane) # OW_TX_IDLE, this bit is don't care when OWEN_TX_IDLE=0

def tx_idle_get(lane):
    mode          =rregBits(0x9803, [13], lane)
    tx_output_type=rregBits(0x9803, [14], lane)

    return mode and tx_output_type

###########################################
def tx_test_patt (en=1, lane=0,tx_test_patt_val_4=0x0000,tx_test_patt_val_3=0x0000,tx_test_patt_val_2=0x0000,tx_test_patt_val_1=0x0000):
    val=rregLane(tx_test_patt_ctrl_addr,lane)
    if(en == 1): # test pattern mode
        wregLane(tx_test_patt_addr_4, tx_test_patt_val_4, lane=lane)
        wregLane(tx_test_patt_addr_3, tx_test_patt_val_3, lane=lane)
        wregLane(tx_test_patt_addr_2, tx_test_patt_val_2, lane=lane)
        wregLane(tx_test_patt_addr_1, tx_test_patt_val_1, lane=lane)
        wregBits(tx_test_patt_ctrl_addr, tx_test_patt_ctrl_bit_loc, 0, lane) # clear bit 15 to do test pattern
    else: # PRBS mode
        wregBits(tx_test_patt_ctrl_addr, tx_test_patt_ctrl_bit_loc, 1, lane) # set bit 15 to do PRBS

####################################################################
def tx_taps_scale (scale=[None,None,None,None,None], lane=0):
    tap_scale_reg=[0,0,0,0,0] # start with all 1x (0 or 1)
    tap_scale=[1,1,1,1,1] # start with all 1x (1 or 2)

    if (scale[0]!=None): # if given an argument, write the setting
        #if 2 in scale: # if want to use 2X scale, set register bit to 1 for 2X, set to 0 for 1X (usually only main tap is 2X)
        tap_scale_reg[0] = 0 if (scale[0]==0.5) else 1 # TX Pre2 Tap scale
        tap_scale_reg[1] = 0 if (scale[1]==0.5) else 1 # TX Pre1 Tap scale
        tap_scale_reg[2] = 0 if (scale[2]==0.5) else 1 # TX Main Tap scale
        tap_scale_reg[3] = 0 if (scale[3]==0.5) else 1 # TX Post1 Tap scale
        tap_scale_reg[4] = 0 if (scale[4]==0.5) else 1 # TX Post2 Tap scale
        #else:
        #    tap_scale = scale # all tap scales are 1x

        wregBits(tx_taps_scale_addr, tx_pre2_scale_bit_loc, tap_scale_reg[0],lane)
        wregBits(tx_taps_scale_addr, tx_pre1_scale_bit_loc, tap_scale_reg[1],lane)
        wregBits(tx_taps_scale_addr, tx_main_scale_bit_loc, tap_scale_reg[2],lane)
        wregBits(tx_taps_scale_addr, tx_post1_scale_bit_loc,tap_scale_reg[3],lane)
        wregBits(tx_taps_scale_addr, tx_post2_scale_bit_loc,tap_scale_reg[4],lane)

    #if ( rregBits(tx_taps_scale_addr, [5,1],lane)!=0x1F): # Must be using 2x scale if any of the scales are 0
    tap_scale[0] = 0.5 if (rregBits(tx_taps_scale_addr, tx_pre2_scale_bit_loc, lane)==0) else 1
    tap_scale[1] = 0.5 if (rregBits(tx_taps_scale_addr, tx_pre1_scale_bit_loc, lane)==0) else 1
    tap_scale[2] = 0.5 if (rregBits(tx_taps_scale_addr, tx_main_scale_bit_loc, lane)==0) else 1
    tap_scale[3] = 0.5 if (rregBits(tx_taps_scale_addr, tx_post1_scale_bit_loc,lane)==0) else 1
    tap_scale[4] = 0.5 if (rregBits(tx_taps_scale_addr, tx_post2_scale_bit_loc,lane)==0) else 1

    return tap_scale

####################################################################
def get_tx_taps (lane=0):
    tap_scale= tx_taps_scale(lane=lane) # values are either 0.5 or 1

    tx_pre2 = tap_scale[0] * int_to_twos(rregBits(tx_pre2_addr, tx_pre2_bit_loc, lane), 8)
    tx_pre1 = tap_scale[1] * int_to_twos(rregBits(tx_pre1_addr, tx_pre1_bit_loc, lane), 8)
    tx_main = tap_scale[2] * int_to_twos(rregBits(tx_main_addr, tx_main_bit_loc, lane), 8)
    tx_post1= tap_scale[3] * int_to_twos(rregBits(tx_post1_addr,tx_post1_bit_loc,lane), 8)
    tx_post2= tap_scale[4] * int_to_twos(rregBits(tx_post2_addr,tx_post2_bit_loc,lane), 8)
    return tx_pre2,tx_pre1,tx_main,tx_post1,tx_post2

####################################################################
def set_tx_taps (tx_pre2=-2,tx_pre1=-1,tx_main=20, tx_post1=1, tx_post2=2, lane=0):
    tap_scale= tx_taps_scale(lane=lane) # values are either 0.5 or 1

    wregBits(tx_pre2_addr, tx_pre2_bit_loc, twos_to_int(int(float(tx_pre2 /tap_scale[0])),8), lane)
    wregBits(tx_pre1_addr, tx_pre1_bit_loc, twos_to_int(int(float(tx_pre1 /tap_scale[1])),8), lane)
    wregBits(tx_main_addr, tx_main_bit_loc, twos_to_int(int(float(tx_main /tap_scale[2])),8), lane)
    wregBits(tx_post1_addr,tx_post1_bit_loc,twos_to_int(int(float(tx_post1/tap_scale[3])),8), lane)
    wregBits(tx_post2_addr,tx_post2_bit_loc,twos_to_int(int(float(tx_post2/tap_scale[4])),8), lane)


####################################################################
def tx (tx_pre2=None,tx_pre1=None,tx_main=None, tx_post1=None, tx_post2=None, lane=0):

    tap_reg=[-2,-1,21,1,2]
    tap_val=[-2,-1,21,1,2]
    tap_scale=[1,1,1,1,1]

    if (tx_pre2!=None):
        #if ( tx_main > 30): # if user tries to write main tap larger than 30, double the scale
        #    wregBits(tx_taps_scale_addr, [5,1], 0x04, lane) # scale = '00100' => main tap is 2X, all others are 1X
        set_tx_taps (tx_pre2,tx_pre1,tx_main, tx_post1, tx_post2, lane=lane)


    #tap_reg[0],tap_reg[1],tap_reg[2],tap_reg[3],tap_reg[4] = get_tx_taps(with_scale=0, lane=lane)
    #tap_val[0],tap_val[1],tap_val[2],tap_val[3],tap_val[4] = get_tx_taps(with_scale=1, lane=lane)
    tap_reg[0],tap_reg[1],tap_reg[2],tap_reg[3],tap_reg[4] = get_tx_taps(lane=lane)
    tap_scale = tx_taps_scale(lane=lane)
    status, tx_taps_sum = tx_taps_rule_check(lane)

    log_no_newline("\nLane %d TX Tap Scales   : (" %lane)
    for i in range(0,5):
        log_no_newline("%4.1f" %(tap_scale[i]))
        if(i<4): log_no_newline(",")
    log_no_newline(")")


    log_no_newline("\nLane %d TX Tap Registers: (" %lane)
    for i in range(0,5):
        log_no_newline("%4.0f" %(tap_reg[i]))
        if(i<4): log_no_newline(",")

    log_no_newline(")")
    log_no_newline("\nLane %d TX Tap Values   : (" %lane)
    for i in range(0,5):
        log_no_newline("%4.1f" %(tap_reg[i]*tap_scale[i]))
        if(i<4): log_no_newline(",")

    log_no_newline(")")


    if( status == False):
        log("**** WARNING: (Sum:%2.1f > Max:%2.1f) *****" %(tx_taps_sum, tx_taps_sum_limit))
    else:
        log("  [Sum:%2.1f, Max:%2.1f]" %(tx_taps_sum, tx_taps_sum_limit))
####################################################################
def tx_taps_rule_check (lane=0):

    global tx_taps_sum_limit;
    tap_val=[-2,-1,21,1,2]
    tap_scale=[1,1,1,1,1]

    # if ( (rregBits(tx_taps_scale_addr, [5,1],lane)==0x00) ): # if all of the scales are 0, there is no 2x scale
        # tap_val[4],tap_val[3],tap_val[2],tap_val[1],tap_val[0] = get_tx_taps(with_scale=0, lane=lane)
        # tx_taps_sum_limit = 31
    # else:
        # tap_val[4],tap_val[3],tap_val[2],tap_val[1],tap_val[0] = get_tx_taps(with_scale=1, lane=lane)
        # tx_taps_sum_limit = 31.5

    #tap_val[4],tap_val[3],tap_val[2],tap_val[1],tap_val[0] = get_tx_taps(with_scale=1, lane=lane)
    tap_val[4],tap_val[3],tap_val[2],tap_val[1],tap_val[0] = get_tx_taps(lane=lane)
    tap_scale = tx_taps_scale(lane=lane)
    tx_taps_sum_limit = 31.5


    tx_taps_sum=0
    for i in range(5):
        tx_taps_sum += abs(tap_val[i]*tap_scale[i])

    if(tx_taps_sum > tx_taps_sum_limit):
        return False, tx_taps_sum # Constraint violated
    return True, tx_taps_sum # Constraints not violated

def set_tx_taps_safe(tx_pre2,tx_pre1,tx_main, tx_post1, tx_post2, lane):
    tx_taps_sum = sum(map(abs, [tx_pre2,tx_pre1,tx_main, tx_post1, tx_post2]))
    if tx_taps_sum > tx_taps_sum_limit:
        log("**** WARNING: Not setting taps (Sum:%2.1f > Max:%2.1f) *****" %(tx_taps_sum, tx_taps_sum_limit))
    else:
        set_tx_taps(tx_pre2,tx_pre1,tx_main, tx_post1, tx_post2, lane=lane)

####################################################################
# program TX Taps from a pre-selected list of tap combinations
#
####################################################################
def tx_taps_select(tx_idx, lane):
    if tx_idx==None:
        return

    # figure out if we're at 37G:
    actual_data_rate, _,_, _, _, _, _ = get_pll(lane)
    is37G = (actual_data_rate > 36 and actual_data_rate < 38)

    if is37G:
        if tx_idx==0:
            set_tx_taps( 0, -2, 21, 0, 0, lane) # for short reach or loopback
        elif tx_idx==1:
            set_tx_taps( 0, -3, 21, 0, 0, lane)
        elif tx_idx==2:
            set_tx_taps( 1, -5, 23, 0, 0, lane)
        elif tx_idx==3:
            set_tx_taps( 1, -6, 23, 0, 0, lane)
        elif tx_idx==4:
            set_tx_taps( 2, -8, 21, 0, 0, lane) # for very long reach
        elif tx_idx==5:
            set_tx_taps( 2, -7, 21, 0, 0, lane)
        elif tx_idx==6:
            set_tx_taps( 1, -7, 22, -1, 0, lane)
        elif tx_idx==7:
            set_tx_taps( 0, -4, 23, -3, 0, lane)
        else:
            set_tx_taps( 2, -8, 21, 0, 0, lane) # for very long reach

    else: # PAM4 53G, 56G, and All NRZ modes
        if tx_idx==0:
            set_tx_taps( 0, -3, 20, 0, 0, lane) # for short reach or loopback
        elif tx_idx==1:
            set_tx_taps( 0, -4, 24, 0, 0, lane)
        elif tx_idx==2:
            set_tx_taps( 1, -5, 23, 0, 0, lane)
        elif tx_idx==3:
            set_tx_taps( 1, -6, 23, 0, 0, lane)
        elif tx_idx==4:
            set_tx_taps( 1, -7, 23, 0, 0, lane) # for very long reach
        elif tx_idx==5:
            set_tx_taps( 2, -8, 21, 0, 0, lane)
        elif tx_idx==6:
            set_tx_taps( 2, -9, 20, 0, 0, lane)
        else:
            set_tx_taps( 2, -8, 21, 0, 0, lane) # for very long reach

############################################
def lane_los (los=1, los_time=5):
    if (los==1): #los ON
        for lane in lane_list:
            tx_test_patt(1, lane,0x0000,0x0000,0x0000,0x0000) # 00 pattern
        time.sleep(los_time)
        for lane in lane_list:
            tx_test_patt(0, lane) # back to PRBS pattern
    else: # LOS off (PRBS on)
        for lane in lane_list:
            tx_test_patt(0, lane) # back to PRBS pattern

####################################################################
def lane_reset_toggle (wait=0.01, lane=0):
    wregBits(params(lane).lane_reset_addr, params(lane).lane_reset_bit_loc, 1, lane)
    wregBits(params(lane).sm_ctrl_continue_addr, params(lane).sm_ctrl_continue_bit_loc, 0, lane)
    wregBits(params(lane).sm_ctrl_continue_addr, params(lane).sm_ctrl_continue_bit_loc, 1, lane)
    wregBits(params(lane).sm_ctrl_continue_addr, params(lane).sm_ctrl_continue_bit_loc, 0, lane)
    time.sleep(wait)
    wregBits(params(lane).lane_reset_addr, params(lane).lane_reset_bit_loc, 0, lane)

#############################################
def lane_reset (lane=0):

    if get_mode(lane)!='pam4': # NRZ Mode lane Reset is a simple lane-reset toggle
        params(lane).lane_reset_toggle(lane)
        tuning_done = wait_tuning_done()
        return tuning_done

    else: # PAM4 Mode Lane Reset
        wregLane(params(lane).sm_ctrl_addr, 0x0000, lane) # Clear Break points when running without FW
        #background_cal(enable=0,lane=lane)
        wregBits (ow_mu_offset_addr, ow_mu_offset_bit_loc, 0, lane) # typcially 3
        # if (rregBits(ow_mu_offset_addr, ow_mu_offset_bit_loc, lane)) != 0 :
            # background_cal_was_on = 1
            # background_cal(enable=0,lane=lane)
        # else:
            # background_cal_was_on = 0


        tgt_init  = 0x8000
        tgt_final = 0x4000

        # Save the original settigns for cntr targets before lane reset
        curr_tgt_init  = rregBits(params(lane).cntr_target_init_addr, params(lane).cntr_target_init_bit_loc, lane)
        curr_tgt_final = rregBits(params(lane).cntr_target_final_addr, params(lane).cntr_target_final_bit_loc, lane)
        #curr_iter_s6 = rregBits (iter_s6_addr, iter_s6_bit_loc,  lane)
        #curr_mu = rregBits(ow_mu_offset_addr, ow_mu_offset_bit_loc, lane)

        # rewrite cntr targets to the above values for lane reset
        wregBits(params(lane).cntr_target_init_addr,  params(lane).cntr_target_init_bit_loc,  tgt_init, lane)
        wregBits(params(lane).cntr_target_final_addr, params(lane).cntr_target_final_bit_loc, tgt_final, lane)
        # wregBits (iter_s6_addr, iter_s6_bit_loc,  1, lane) # typically 6
        # wregBits (ow_mu_offset_addr, ow_mu_offset_bit_loc, 0, lane) # typcially 3


        if lane > len(lane_list): # reset all lanes
            for ln in lane_list:
                # select_lane(lane=ln)
                wregBits(params(lane).lane_reset_addr, params(lane).lane_reset_bit_loc, 1, ln)
            time.sleep(0.01)
            for ln in lane_list:
                # select_lane(lane=ln)
                wregBits(params(lane).lane_reset_addr, params(lane).lane_reset_bit_loc, 0, ln)
            #select_lane(lane=lane)
        else: # reset only the requested lane
            lane_reset_toggle(lane=lane)
            time.sleep(0.4)

        # Restore the original settings for cntr targets before lane reset
        wregBits(params(lane).cntr_target_init_addr,  params(lane).cntr_target_init_bit_loc,  curr_tgt_init, lane)
        wregBits(params(lane).cntr_target_final_addr, params(lane).cntr_target_final_bit_loc, curr_tgt_final, lane)
        # wregBits (ow_mu_offset_addr, ow_mu_offset_bit_loc,   curr_mu, lane)
        # wregBits (iter_s6_addr, iter_s6_bit_loc,  curr_iter_s6, lane)

        #lane_reset_toggle(lane=lane)
        need_reset = check_for_reset(lane)


        # if background_cal_was_on == 1:
            # time.sleep(1)
            # background_cal(enable=1,lane=lane)

        return need_reset
############################################

def attenuator(val = None, lane = 0):
    if val != None:
        wregBits(0x01f4, [11,10], val, lane = lane)
    return rregBits(0x01f4, [11,10], lane = lane)

def pam4_freq_acc(lane = 0):
    return get_signed_val(rregBits(0x73, [10, 0], lane=lane), 11)

def pam4_vgavdsat(val=None, lane=0):
    if val != None:
        msb = (val >> 3) & 0x1
        lsb = (val & 0x7)

        wregBits(0x00CA, [5], msb, lane = lane)
        wregBits(0x00F6, [15, 13], lsb, lane = lane)

    msb = rregBits(0x00CA, [5], lane = lane)
    lsb = rregBits(0x00F6, [15, 13], lane = lane)

    readback = (msb << 3) + lsb
    return readback

def pam4_bias_mix_sel(val=None, lane=0):
    if val != None:
        wregBits(0x00CB, [13,11], val, lane = lane)

    return rregBits(0x00CB, [13,11], lane = lane)

def ctle (ctle_val_to_write=None,ctle1=None, ctle2=None, lane=0):

    wregBits(params(lane).ctle_en_addr, params(lane).ctle_en_bit_loc, 1, lane) # make sure CTLE OW is enabled

    if ctle_val_to_write!=None and ctle1 != None and ctle2 != None:
       wregBits(params(lane).ctle_val_addr, params(lane).ctle_val_bit_loc, ctle_val_to_write, lane)
       ctle_map(ctle_val_to_write, ctle1, ctle2,lane)
    elif ctle_val_to_write!=None:
        wregBits(params(lane).ctle_val_addr, params(lane).ctle_val_bit_loc, ctle_val_to_write, lane)

    curr_ctle_idx = rregBits(params(lane).ctle_val_addr, params(lane).ctle_val_bit_loc, lane)
    curr_ctle, ctle1_val, ctle2_val = get_ctle_map(curr_ctle_idx,lane=lane)

    return curr_ctle, ctle1_val, ctle2_val


####################################################################
def get_pll_vcocap_from_table (desired_fvco,lane=0):
    freq_index = len(pll_lvcocap_table) - 1 # start from bottom of table, lowest freqency, and move up
    while True:
        #print ("VCO CAP Table[%2d] = [%2.4fGHz, %2d]" %(freq_index, pll_lvcocap_table[freq_index][0],pll_lvcocap_table[freq_index][1] ) )
        if (desired_fvco <= pll_lvcocap_table[freq_index][0] and freq_index >=0): #<= len(pll_lvcocap_table) - 1:
            optimum_vco_cap = pll_lvcocap_table[freq_index][1]
            break
        else:
            freq_index -=1
            if (freq_index <0): # len(pll_lvcocap_table) - 1):
                freq_index = 0 # len(pll_lvcocap_table) - 1
                optimum_vco_cap = pll_lvcocap_table[freq_index][1]
                #print ("\n Out of VCOCAP Choice for Fvco=%2.5f GHz. Using [%2.4fGHz, %d]" %(desired_fvco, pll_lvcocap_table[freq_index][0],pll_lvcocap_table[freq_index][1] ) )
                break
    return optimum_vco_cap


###########################################################################
# sets PLL to desired setting
#
# Examples:
# >>> set_pll(56.25)
#     sets all PLL paramters to get data rate of 56.25Gbps, i.e. Fvco = 28.125 GHz.
#     PLL_N is computed based on current refclk and div4
#     refclk and div4 are unchanged
#     VCOCAP is selected according to Fvc0
#
# >>> set_pll(input=56.25, refclk=415.0)
#     sets all PLL paramters to get data rate of 56.25Gbps
#     based on refclk=415MHz, div4 is unchanged
#     VCOCAP is selected according to Fvco
#
# >>> set_pll(rate=56.25, refclk=415.0, div4=0, lane=0)
#     sets all PLL paramters to get data rate of 56.25Gbps, i.e. Fvco = 28.125 GHz.
#     PLL_N is computed based on refclk=415MHz and div4 set to 0,
#     and only lane0 PLL if applicable
#     VCOCAP is selected according to Fvco
############################################################################
def set_pll (rate=None, div4=None, lane=0, forceFractional=False):
    global gRefclkFreq
    global gDataRate

    cur_data_rate, cur_baud_rate, fvco, pll_n, pll_fracn, pll_cap, tmp_div4 = get_pll(lane=lane)

    if div4 == None:
        div4 = tmp_div4

    wregBits(pll_div4_addr, pll_div4_bit_loc, div4, lane)

    # rate is a float number and the desired_data_rate, calculate closest pll_n, and program PLL registers
    desired_data_rate = rate

    desired_fvco = desired_data_rate / params(lane).baud_rate_ratio
    #if desired_fvco >33.0: desired_fvco=33.0
    #if desired_fvco <15.0: desired_fvco=15.0

    if (get_mode(lane)!='pam4'):
        if desired_fvco < 16.0: # NRZ half-rate mode, i.e. 10G Mode, program Fvco at 2X
            wregBits(nrz_10g_mode_addr,nrz_10g_mode_bit_loc, 1, lane)
            desired_fvco *= 2.0
            #print desired_fvco
        else:  # NRZ full-rate mode, i.e. 25G Mode, program Fvco at 1X
            wregBits(nrz_10g_mode_addr,nrz_10g_mode_bit_loc, 0, lane)
    if desired_fvco >33.0: desired_fvco=33.0
    if desired_fvco <15.0: desired_fvco=15.0

    calc_pll_n = (1000.0 * desired_fvco * pow(4,div4)) / ( 4.0  *  gRefclkFreq)
    pll_n_val = int(calc_pll_n)
    pll_n_frac = calc_pll_n - pll_n_val
    pll_n_frac_val = int(pll_n_frac * (1<<20))

    #print "\n....PLL_N should be set to %2.5f (0x%02X[%d:%d]= 0x%02X)" % (pll_n_val, pll_n_addr, pll_n_bit_loc[0], pll_n_bit_loc[1],int(calc_pll_n))
    #delta_fvco_m1= abs(desired_fvco - ((gRefclkFreq * float(pll_n_val-1) * 4.0) / pow(4,div4) / 1000.0))
    #delta_fvco_0 = abs(desired_fvco - ((gRefclkFreq * float(pll_n_val)   * 4.0) / pow(4,div4) / 1000.0))
    #delta_fvco_p1= abs(desired_fvco - ((gRefclkFreq * float(pll_n_val+1) * 4.0) / pow(4,div4) / 1000.0))
    #if delta_fvco_p1 < delta_fvco_0:
    #    pll_n_val +=1
    #elif delta_fvco_m1 < delta_fvco_0:
    #    pll_n_val -=1
    wregBits(pll_n_addr, pll_n_bit_loc, (pll_n_val), lane)
    wregLane(pll_nfrac_addr, pll_n_frac_val >> 16, lane)
    wregLane(pll_nfrac_addr + 1, pll_n_frac_val & 0xffff, lane)
    if pll_n_frac_val == 0:
        wregBits(pll_sdm_addr, pll_sdm_en_bit_loc, 0, lane)
    else:
        wregBits(pll_sdm_addr, pll_sdm_order_bit_loc, 2, lane)
        wregBits(pll_sdm_addr, pll_sdm_en_bit_loc, 1, lane)

    programmed_n = pll_n_val + float(pll_n_frac_val) / (1<<20)
    #pll_n_val = rregBits(pll_n_addr, pll_n_bit_loc, lane)
    calc_fvco = ((gRefclkFreq * programmed_n) * 4.0 / pow(4,div4) / 1000.0)# in GHz

    pll_cap_val = get_pll_vcocap_from_table(calc_fvco) # get vco_cap from table
    wregBits(pll_lvcocap_addr,  pll_lvcocap_bit_loc,  pll_cap_val,  lane) # program vco_cap[5:0]

    # if gPllVcocapFromTable==False: # Get VCOCAP from fixed VCOCAP table or use the PLL Lock to pick best VCOCAP real-time?
        # actual_data_rate, actual_fvco, original_vcocap, pll_cap_val, final_list = get_pll_vcocap_from_pll_lock(desired_fvco=None, print_en=0) # get vco_cap dynamcially from PLL Lock Check
        # wregBits(pll_lvcocap_addr,  pll_lvcocap_bit_loc,  pll_cap_val,  lane) # program vco_cap[5:0]

    calc_baud_rate = calc_fvco
    calc_data_rate = params(lane).baud_rate_ratio * calc_baud_rate     # in Gbps
    if get_mode(lane)!='pam4' and is_halfrate(lane): # NRZ half-rate mode, i.e. 10G Mode, date rate = 0.5x Fvco
        calc_baud_rate /= 2.0
        calc_data_rate /= 2.0

    gDataRate[lane] = calc_data_rate # update this global variable

    return calc_data_rate

####################################################################
# reads all PLL related registers and computes PLL Frequency
####################################################################
def get_pll (lane=0):
    div4 = rregBits(pll_div4_addr, pll_div4_bit_loc, lane)
    pll_n = rregBits(pll_n_addr, pll_n_bit_loc, lane)
    pll_fracn = rreg32Lane(pll_nfrac_addr, lane)
    pll_cap = rregBits(pll_lvcocap_addr, pll_lvcocap_bit_loc, lane)
    full_pll_n = pll_n + float(pll_fracn) / float(1<<20)

    fvco = (gRefclkFreq * full_pll_n * 4.0 / pow(4, div4) / 1000.0)# in GHz
    baud_rate = fvco
    calc_data_rate = params(lane).baud_rate_ratio * baud_rate     # in Gbps
    data_rate = calc_data_rate # update this global variable

    if get_mode(lane)!='pam4' and is_halfrate(lane): # If NRZ Mode, check 10G mode bit
        data_rate = data_rate / 2.0
        baud_rate = baud_rate / 2.0

    return data_rate, baud_rate, fvco, pll_n, pll_fracn, pll_cap, div4

####################################################################
# pll()
# This is intended for python command line usage
# to get or set PLL
####################################################################
def pll(rate=None, div4=None, lane=0, verbose=False):

    if rate!=None: # check actual PLL settings and calculate the data rate as the chip is set now
        # input= desired_pll_n or desired_data_rate, then program PLL registers
        set_pll(rate, div4, lane)

    data_rate, baud_rate, fvco, pll_n, pll_fracn, pll_cap, div4 = get_pll(lane=lane)
    if fracn_enabled(lane):
        full_pll_n = pll_n + float(pll_fracn) / float(1<<20)
    else:
        full_pll_n = float(pll_n)

    if verbose:
        log("....PLL Reg 1 R%04X: %04X" %(pll_div4_addr,    rregLane(pll_div4_addr, lane)))
        log("....PLL Reg 2 R%04X: %04X" %(pll_n_addr,       rregLane(pll_n_addr, lane)))
        log("....PLL Reg 3 R%04X: %04X" %(pll_lvcocap_addr, rregLane(pll_lvcocap_addr, lane)))
        log("....PLL Reg 4 R%04X: %08X" %(pll_nfrac_addr,   rreg32Lane(pll_nfrac_addr, lane)))
        log("....PLL Reg 3 R%04X: %04X" %(0x1fc,            rregLane(0x1fc, lane)))
        log("....PLL Reg 3 R%04X: %04X" %(0x1fd,            rregLane(0x1fd, lane)))
        log("....PLL Reg 3 R%04X: %04X" %(0x1fe,            rregLane(0x1fe, lane)))
        log("....PLL Reg 3 R%04X: %04X" %(0x1ff,            rregLane(0x1ff, lane)))
        log("")
        log("PLL_Div4 : %-7d (0x%02X[%d]= 0x%02X)" % (div4, pll_div4_addr, pll_div4_bit_loc[0], rregBits(pll_div4_addr, pll_div4_bit_loc, lane) ))
        log("PLL_N    : %-7d (0x%02X[%d:%d]= 0x%02X)" % (pll_n, pll_n_addr, pll_n_bit_loc[0], pll_n_bit_loc[1], pll_n))
        log("PLL_Nfrac: %-7f (0x%02X-0x%02X= 0x%05X)" % (float(pll_fracn)/(1<<20), pll_n_addr, pll_n_addr+1, pll_fracn))
        log("PLL_Nfull: %-7f" % (full_pll_n))
        log("PLL_LCAP : %-7d (0x%02X[%d:%d]= 0x%02X)" % (pll_cap, pll_lvcocap_addr, pll_lvcocap_bit_loc[0], pll_lvcocap_bit_loc[1], rregBits(pll_lvcocap_addr, pll_lvcocap_bit_loc, lane) ))
        log("")
    else:
        log("%10s: %9.5f     %10s: %d" % ('PLL_Nfull', full_pll_n, 'PLL_Div4', div4))
    log("%10s: %9.5f MHz %10s: %9.5f GHz %10s: %9.5f GHz" % ('RefClk', gRefclkFreq, 'VCO Freq', fvco, '1T Freq', fvco/2.0))
    #print "RefClk: %9.5f MHz  VCO Freq: %9.5f GHz  1T: %9.5f GHz" % (gRefclkFreq, fvco, fvco/2.0)
    log("%10s: %9.5f Gbd %10s: %9.5f Gbps" % ('Baud Rate', baud_rate, 'Data Rate', data_rate))
    #print "Baud Rate: %9.5f GBaud   Data Rate: %9.5f Gbps" % (baud_rate, data_rate)
    log("")

####################################################################
def ffe (en=None, lane=0):
    if en==None:
        if (rregBits(ffe_en_addr, ffe_en_bit_loc, lane))==1:
            log(" Lane %d FFE Status: Enabled" %lane)
        else:
            log(" Lane %d FFE Status: Disabled" %lane)
    else:
        if en!=1:
            wregBits(ffe_en_addr, ffe_en_bit_loc, 0, lane)
            #print " Lane %d FFE Disabled" %lane
        else:
            wregBits(ffe_en_addr, ffe_en_bit_loc, 1, lane)
            #print " Lane %d FFE Enabled " %lane
####################################################################

def SetCtlePeaking(peaking,lane=0):   #set ctle map to N

    curr_ctle = rregBits(params(lane).ctle_val_addr, params(lane).ctle_val_bit_loc, lane)
    if (peaking==8):
        wregBits(params(lane).ctle_map0_addr, [5,0], 0x3F, lane) # overwrite CTLE7 = 7,7
        #wregLane(0x004a,0x1c7f, lane) #<<<<<< todo
        peaking = 7
    if (peaking==0):
        wregBits(params(lane).ctle_map2_addr,[9,4],0x09,lane) # overwrite CTLE1 = 1,1
        peaking = 1
    wregBits(params(lane).ctle_en_addr, params(lane).ctle_en_bit_loc, 1, lane) # make sure CTLE OW is enabled
    wregBits(params(lane).ctle_val_addr, params(lane).ctle_val_bit_loc, peaking, lane)
    new_ctle = rregBits(params(lane).ctle_val_addr, params(lane).ctle_val_bit_loc, lane)
    if(gDebugTuning):
        log_no_newline("\nSetCtlePeaking: Prev=%d, New=%d"%(curr_ctle, new_ctle) )

def fw_config(params, tx_idx=None, LT=None, print_header=True, simulation = False, optical_mode='dis', lane=0):
    tx_taps=get_tx_taps(lane=lane)

    soft_reset(lane=lane)
    set_tx_taps(tx_taps[0],tx_taps[1],tx_taps[2],tx_taps[3],tx_taps[4],lane=lane)

    # find the key in fw_data_rate_map closest to the target data rate
    int_rate = min(compat_listkeys(fw_data_rate_map), key=lambda x:abs(x-params.data_rate))
    fw_data_rate = fw_data_rate_map[int_rate]

    if int_rate <=28:
        half_rate = 1 if int_rate <= 16 else 0
        value = fw_config_speed_nrz(params, fw_data_rate, LT=LT, tx_idx=tx_idx, half_rate=half_rate, print_header=print_header, optical_mode=optical_mode, lane=lane)
    else:
        value = fw_config_speed_pam4(params, fw_data_rate, LT=LT, tx_idx=tx_idx, print_header=print_header, optical_mode=optical_mode, lane=lane)

    return value


#############################################
def dfe (lane=0):

    #### PAM4 DFE ####
    if get_mode(lane) == 'pam4':
        f0,f1 = get_pam4_dfe(lane)
        return f0,f1

    #### NRZ DFE ####
    else:
        delta, f1, f2, f3 = get_nrz_dfe (lane)
        return delta, f1, f2, f3

####################################################################
def nrz_dfe_init(index=None, init_f1=None, init_f2=None, lane=0):

    dfe_init_index_addr = [0x100,0x107,0x183,0x184,0x185,0x186,0x87,0x188]
    dfe_init_f1_val = [0,0,0,0,0,0,0,0]
    dfe_init_f2_val = [0,0,0,0,0,0,0,0]
    dfe_init_f1_bit_loc = [13,7]
    dfe_init_f2_bit_loc = [6,0]


    if index=='?':
        log_no_newline("\n     Get DFE F1/F2 Init Information:")
        log_no_newline("\n     nrz_dfe_init() => Returns (Initial DFE Index 0 to 7 and initial F1/F2 for each")
        log_no_newline("\n     nrz_dfe_init(index=0 to 7) => Returns (Index_Initial F1, Index_Initial F2)")
        log("\n     nrz_dfe_init(index=0 to 7, init_F1_value_in_twos, initial_F2_value_in_twos) => Returns (Index_Initial F1, Index_Initial F2)")

    # Write the requested Init F1/F2 Values to the DFE init Index location
    elif index!=None and init_f1!=None and init_f2!=None:
            wregBits(dfe_init_index_addr[index], dfe_init_f1_bit_loc, twos_to_int(init_f1,7), lane)
            wregBits(dfe_init_index_addr[index], dfe_init_f2_bit_loc, twos_to_int(init_f2,7), lane)

    # Read all 8 DFE Init F1/F2 values
    else:
        curr_index_pointer = rregBits(nrz_restart_counter_addr,nrz_restart_counter_bit_loc,lane)
        log_no_newline("\n   Register    => Index, InitF1/F2")
        for idx in range(8):
            dfe_init_index_val = rregLane(dfe_init_index_addr[idx],lane)
            dfe_init_f1_val[idx] = int_to_twos(rregBits(dfe_init_index_addr[idx], dfe_init_f1_bit_loc, lane),7)
            dfe_init_f2_val[idx] = int_to_twos(rregBits(dfe_init_index_addr[idx], dfe_init_f2_bit_loc, lane),7)
            log_no_newline("\n 0x%04X=0x%04X => %5d, (%2d,%2d)"   %(dfe_init_index_addr[idx], dfe_init_index_val, idx, dfe_init_f1_val[idx],dfe_init_f2_val[idx]))
            if( idx == curr_index_pointer):
                log_no_newline("   <<< Currently Selected")

#############################################
def get_nrz_dfe (lane=0):
  delta = rregBits(nrz_dfe_delta_addr, nrz_dfe_delta_bit_loc, lane)
  f1 = int_to_twos(rregBits(nrz_dfe_f1_addr, nrz_dfe_f1_bit_loc, lane), 7)
  f2 = int_to_twos(rregBits(nrz_dfe_f2_addr, nrz_dfe_f2_bit_loc, lane), 7)
  f3 = int_to_twos(rregBits(nrz_dfe_f3_addr, nrz_dfe_f3_bit_loc, lane), 7)

  return delta, f1, f2, f3

####################################################################
def get_pam4_dfe(lane=0):
    if is_fw_loaded(lane=lane):
        ths_list = []
        ths_list_temp = Get_Ths_fw(lane=lane)
        for ths in ths_list_temp:
            ths = ths/64.0
            ths_list.append(ths)
    else:
        ths_sel_list = [x for x in range(12)]
        ths_list = []

        for val in ths_sel_list:
          wregBits (pam4_dfe_sel_addr, pam4_dfe_sel_bit_loc, val, lane)
          time.sleep(0.01)
          readout = rregBits(pam4_dfe_read_addr, pam4_dfe_read_bit_loc, lane)
          readout2 = rregBits(pam4_dfe_read_addr, pam4_dfe_read_bit_loc, lane)
          if readout == readout2:
            result = ((float(readout)/2048.0)+1.0) % 2.0 - 1.0
            #print("\n%2d 0x%04X %6.3f"%(val,readout,result)),
          else:
            readout = rregBits(pam4_dfe_read_addr, pam4_dfe_read_bit_loc, lane)
            result = ((float(readout)/2048.0)+1.0) % 2.0 - 1.0
            #print("\n*%2d 0x%04X %6.3f"%(val,readout,result)),
          ths_list.append(result)

    f0 = (-3.0/16)*((ths_list[0]-ths_list[2])+(ths_list[3]-ths_list[5])+(ths_list[6]-ths_list[8])+(ths_list[9]-ths_list[11]))
    f1 = (-3.0/20)*((ths_list[0]+ths_list[1]+ths_list[2]-ths_list[9]-ths_list[10]-ths_list[11])+(1.0/3)*(ths_list[3]+ths_list[4]+ths_list[5]-ths_list[6]-ths_list[7]-ths_list[8]))

    return f0,f1
####################################################################
#
####################################################################
def ffe_adapt (enable=None,lane=0):

    if is_fw_loaded(lane=lane): # PAM4 FW Loaded and Running? Use FFE Adaptatoin in FW
        if(gDebugTuning): log_no_newline("\n...FW FFE Adaptation:")
        if enable!=None:
            wregBits(fw_tuning_ctrl_addr, fw_tuning_ctrl_ffe_adapt_en_bit_loc, enable, lane)
        ffe_adapt_en_bits = rregBits(fw_tuning_ctrl_addr, fw_tuning_ctrl_ffe_adapt_en_bit_loc, lane)
        if ffe_adapt_en_bits == 0:
            if(gDebugTuning): log("OFF")
        else:
            if(gDebugTuning): log("ON")
        return ffe_adapt_en_bits
    else:
        log("\n...FW FFE Adaptation: OFF (No FW Running)\n")
        return 0

####################################################################
#
####################################################################
def background_cal (enable=None,lane=0):

    if is_fw_loaded(lane=lane): # PAM4 FW Loaded and Running? Use background_cal in FW instead of python routine
        if(gDebugTuning): log_no_newline("\n...FW Background Cal:")
        if enable!=None:
            wregBits(fw_tuning_ctrl_addr, fw_tuning_ctrl_background_cal_bit_loc, enable, lane)
        background_cal_bits = rregBits(fw_tuning_ctrl_addr, fw_tuning_ctrl_background_cal_bit_loc, lane)
        if background_cal_bits == 0:
            if(gDebugTuning): log("OFF")
        else:
            if(gDebugTuning): log("ON")
        return background_cal_bits


    if(gDebugTuning): log_no_newline("\n...Background Cal:")
    if enable==None: # resturn current status of background cal
        background_cal_bits = rregBits (ow_mu_offset_addr, ow_mu_offset_bit_loc, lane) & 0x1
        if background_cal_bits == 0:
            if(gDebugTuning): log("Already OFF")
        else:
            if(gDebugTuning): log("Already ON")
        return background_cal_bits

    # elif enable==0: # Do the simple turn-off of background cal
        # wregBits (ow_mu_offset_addr, ow_mu_offset_bit_loc,0, lane)
        # if(gDebugTuning):print ("Turned OFF")
        # background_cal_bits = rregBits (ow_mu_offset_addr, ow_mu_offset_bit_loc, lane)
        # return background_cal_bits

    else: # enable=1
        bp1_ori = rregBits(bp_addr, bp1_bit_loc, lane)
        bp1_en_ori = rregBits(bp_addr, bp1_en_bit_loc, lane)
        bp2_en_ori = rregBits(bp_addr, bp2_en_bit_loc, lane)

        wregBits(bp_addr, bp1_bit_loc, 0x12, lane)
        wregBits(bp_addr, bp2_en_bit_loc, 0, lane)
        wregBits(bp_addr, bp1_en_bit_loc, 1, lane)
        wait_for_bp1_timeout=0
        while True:
            if rregBits(params(lane).sm_status_addr, params(lane).sm_status_bp1_bit_loc, lane):
                break
            else:
                wait_for_bp1_timeout+=1
                if wait_for_bp1_timeout>1000:
                    if(gDebugTuning): log("\n Background Cal: >>>>> Timed out waiting for BP1")
                    break


        if enable:
            wregBits (0x4, [0],  1, lane)
            wregLane (0x77, 0x4e5c, lane)
            wregLane (0x78, 0xe080, lane)
            wregBits (iter_s6_addr, iter_s6_bit_loc,   6, lane)
            wregBits (ow_mu_offset_addr, ow_mu_offset_bit_loc,   3, lane)
            if(gDebugTuning): log("Turned ON")
        else:
            wregBits (iter_s6_addr, iter_s6_bit_loc,   1, lane)
            wregBits (ow_mu_offset_addr, ow_mu_offset_bit_loc,   0, lane)
            wregBits (iter_s6_addr, iter_s6_bit_loc,   1, lane)
            wregBits (ow_mu_offset_addr, ow_mu_offset_bit_loc,   0, lane)
            if(gDebugTuning): log("Turned OFF")


        wregBits(bp_addr, bp1_en_bit_loc, 0, lane)
        wregBits(bp_addr, bp1_bit_loc, bp1_ori, lane)
        wregBits(bp_addr, bp1_en_bit_loc, bp1_en_ori, lane)
        wregBits(bp_addr, bp2_en_bit_loc, bp2_en_ori, lane)
        background_cal_bits = rregBits (ow_mu_offset_addr, ow_mu_offset_bit_loc, lane) & 0x1
        sm_cont(lane)
        return background_cal_bits

####################################################################
def ffe_taps(ffe_tap1=None, ffe_tap234=None, ffe_tap2=None, ffe_tap34=None, ffe_tap3=None, ffe_tap4=None, lane=0):

    #Write FFE taps to register
    if ffe_tap1!=None:
        ffe_tap1_gray_LSB = Bin_Gray(ffe_tap1&0xf)
        ffe_tap1_gray_MSB = Bin_Gray(ffe_tap1 >> 4)
        ffe_tap1_gray = ((ffe_tap1_gray_MSB << 4) + ffe_tap1_gray_LSB)&0xFF
        wregBits(ffe_tap1_addr, ffe_tap1_bit_loc, ffe_tap1_gray, lane)
    if ffe_tap234!=None:
        ffe_tap234_gray_LSB = Bin_Gray(ffe_tap234&0x0f)
        ffe_tap234_gray_MSB = Bin_Gray((ffe_tap234 >> 4)&0x0f)
        ffe_tap234_gray = ((ffe_tap234_gray_MSB << 4) + ffe_tap234_gray_LSB)&0xFF
        wregBits(ffe_tap234_addr, ffe_tap234_bit_loc, ffe_tap234_gray, lane)
    if ffe_tap2!=None:
        ffe_tap2_gray_LSB = Bin_Gray(ffe_tap2&0xf)
        ffe_tap2_gray_MSB = Bin_Gray(ffe_tap2 >> 4)
        ffe_tap2_gray = ((ffe_tap2_gray_MSB << 4) + ffe_tap2_gray_LSB)&0xFF
        wregBits(ffe_tap2_addr, ffe_tap2_bit_loc, ffe_tap2_gray, lane)
    if ffe_tap34!=None:
        ffe_tap34_gray_LSB = Bin_Gray(ffe_tap34&0x0f)
        ffe_tap34_gray_MSB = Bin_Gray((ffe_tap34 >> 4)&0x0f)
        ffe_tap34_gray = ((ffe_tap34_gray_MSB << 4) + ffe_tap34_gray_LSB)&0xFF
        wregBits(ffe_tap34_addr, ffe_tap34_bit_loc, ffe_tap34_gray, lane)
    if ffe_tap3!=None:
        ffe_tap3_gray_LSB = Bin_Gray(ffe_tap3&0xf)
        ffe_tap3_gray_MSB = Bin_Gray(ffe_tap3 >> 4)
        ffe_tap3_gray = ((ffe_tap3_gray_MSB << 4) + ffe_tap3_gray_LSB)&0xFF
        wregBits(ffe_tap3_addr, ffe_tap3_bit_loc, ffe_tap3_gray, lane)
    if ffe_tap4!=None:
        ffe_tap4_gray_LSB = Bin_Gray(ffe_tap4&0xf)
        ffe_tap4_gray_MSB = Bin_Gray(ffe_tap4 >> 4)
        ffe_tap4_gray = ((ffe_tap4_gray_MSB << 4) + ffe_tap4_gray_LSB)&0xFF
        wregBits(ffe_tap4_addr, ffe_tap4_bit_loc, ffe_tap4_gray, lane)

    ffe_tap1_main1 = Gray_Bin(rregBits(ffe_tap1_addr, [15,12], lane))
    ffe_tap1_main0 = Gray_Bin(rregBits(ffe_tap1_addr, [11,8], lane))
    ffe_tap1_bin = (((ffe_tap1_main1) << 4) + ffe_tap1_main0)&0xFF

    ffe_tap234_main1 = Gray_Bin(rregBits(ffe_tap234_addr, [7,4], lane))
    ffe_tap234_main0 = Gray_Bin(rregBits(ffe_tap234_addr, [3,0], lane))
    ffe_tap234_bin = (((ffe_tap234_main1) << 4) + ffe_tap234_main0)&0xFF

    ffe_tap2_main1 = Gray_Bin(rregBits(ffe_tap2_addr, [15,12], lane))
    ffe_tap2_main0 = Gray_Bin(rregBits(ffe_tap2_addr, [11,8], lane))
    ffe_tap2_bin = (((ffe_tap2_main1) << 4) + ffe_tap2_main0)&0xFF

    ffe_tap34_main1 = Gray_Bin(rregBits(ffe_tap34_addr, [7,4], lane))
    ffe_tap34_main0 = Gray_Bin(rregBits(ffe_tap34_addr, [3,0], lane))
    ffe_tap34_bin = (((ffe_tap34_main1) << 4) + ffe_tap34_main0)&0xFF

    ffe_tap3_main1 = Gray_Bin(rregBits(ffe_tap3_addr, [15,12], lane))
    ffe_tap3_main0 = Gray_Bin(rregBits(ffe_tap3_addr, [11,8], lane))
    ffe_tap3_bin = (((ffe_tap3_main1) << 4) + ffe_tap3_main0)&0xFF

    ffe_tap4_main1 = Gray_Bin(rregBits(ffe_tap4_addr, [7,4], lane))
    ffe_tap4_main0 = Gray_Bin(rregBits(ffe_tap4_addr, [3,0], lane))
    ffe_tap4_bin = (((ffe_tap4_main1) << 4) + ffe_tap4_main0)&0xFF

    return ffe_tap1_bin, ffe_tap234_bin, ffe_tap2_bin, ffe_tap34_bin, ffe_tap3_bin, ffe_tap4_bin
########################################################################################
def ffe_delay(ffe_delay1=None,ffe_delay2=None,ffe_delay3=None,ffe_delay4=None,ffe_delay5=None,ffe_delay6=None,ffe_delay7=None,ffe_delay8=None,ffe_delay9=None,lane=0):
    if ffe_delay1!=None:
        ffe_delay1_gray = Bin_Gray(ffe_delay1)
        wregBits(ffe_delay1234_ctrl_addr, ffe_delay1_bit_loc, ffe_delay1_gray, lane)
    if ffe_delay2!=None:
        ffe_delay2_gray = Bin_Gray(ffe_delay2)
        wregBits(ffe_delay1234_ctrl_addr, ffe_delay2_bit_loc, ffe_delay2_gray, lane)
    if ffe_delay3!=None:
        ffe_delay3_gray = Bin_Gray(ffe_delay3)
        wregBits(ffe_delay1234_ctrl_addr, ffe_delay3_bit_loc, ffe_delay3_gray, lane)
    if ffe_delay4!=None:
        ffe_delay4_gray = Bin_Gray(ffe_delay4)
        wregBits(ffe_delay1234_ctrl_addr, ffe_delay4_bit_loc, ffe_delay4_gray, lane)
    if ffe_delay5!=None:
        ffe_delay5_gray = Bin_Gray(ffe_delay5)
        wregBits(ffe_delay5678_ctrl_addr, ffe_delay5_bit_loc, ffe_delay5_gray, lane)
    if ffe_delay6!=None:
        ffe_delay6_gray = Bin_Gray(ffe_delay6)
        wregBits(ffe_delay5678_ctrl_addr, ffe_delay6_bit_loc, ffe_delay6_gray, lane)
    if ffe_delay7!=None:
        ffe_delay7_gray = Bin_Gray(ffe_delay7)
        wregBits(ffe_delay5678_ctrl_addr, ffe_delay7_bit_loc, ffe_delay7_gray, lane)
    if ffe_delay8!=None:
        ffe_delay8_gray = Bin_Gray(ffe_delay8)
        wregBits(ffe_delay5678_ctrl_addr, ffe_delay8_bit_loc, ffe_delay8_gray, lane)
    if ffe_delay9!=None:
        ffe_delay9_gray = Bin_Gray(ffe_delay9)
        wregBits(ffe_delay9_ctrl_addr, ffe_delay9_bit_loc, ffe_delay9_gray, lane)

    ffe_delay1_bin = Gray_Bin(rregBits(ffe_delay1234_ctrl_addr, ffe_delay1_bit_loc, lane))
    ffe_delay2_bin = Gray_Bin(rregBits(ffe_delay1234_ctrl_addr, ffe_delay2_bit_loc, lane))
    ffe_delay3_bin = Gray_Bin(rregBits(ffe_delay1234_ctrl_addr, ffe_delay3_bit_loc, lane))
    ffe_delay4_bin = Gray_Bin(rregBits(ffe_delay1234_ctrl_addr, ffe_delay4_bit_loc, lane))

    ffe_delay5_bin = Gray_Bin(rregBits(ffe_delay5678_ctrl_addr, ffe_delay5_bit_loc, lane))
    ffe_delay6_bin = Gray_Bin(rregBits(ffe_delay5678_ctrl_addr, ffe_delay6_bit_loc, lane))
    ffe_delay7_bin = Gray_Bin(rregBits(ffe_delay5678_ctrl_addr, ffe_delay7_bit_loc, lane))
    ffe_delay8_bin = Gray_Bin(rregBits(ffe_delay5678_ctrl_addr, ffe_delay8_bit_loc, lane))

    ffe_delay9_bin = Gray_Bin(rregBits(ffe_delay9_ctrl_addr, ffe_delay9_bit_loc, lane))
    return ffe_delay1_bin, ffe_delay2_bin, ffe_delay3_bin, ffe_delay4_bin, ffe_delay5_bin, ffe_delay6_bin, ffe_delay7_bin, ffe_delay8_bin, ffe_delay9_bin
####################################################################
def ffe_pol(ffe_pol1=None, ffe_pol2=None, ffe_pol3=None, ffe_pol4=None, lane=0):

    if ffe_pol1!=None and ffe_pol2!=None and ffe_pol3!=None and ffe_pol4!=None:
        wregBits(ffe_pol_addr,ffe_po11_bit_loc,ffe_pol1,lane)
        wregBits(ffe_pol_addr,ffe_po12_bit_loc,ffe_pol2,lane)
        wregBits(ffe_pol_addr,ffe_po13_bit_loc,ffe_pol3,lane)
        wregBits(ffe_pol_addr,ffe_po14_bit_loc,ffe_pol4,lane)

    ffe_pol1 = rregBits(ffe_pol_addr,ffe_po11_bit_loc,lane)
    ffe_pol2 = rregBits(ffe_pol_addr,ffe_po12_bit_loc,lane)
    ffe_pol3 = rregBits(ffe_pol_addr,ffe_po13_bit_loc,lane)
    ffe_pol4 = rregBits(ffe_pol_addr,ffe_po14_bit_loc,lane)

    return ffe_pol1, ffe_pol2, ffe_pol3, ffe_pol4
######################################################################################
def dc_gain(ctle_gain1=None, ffe_gain1=None, ctle_gain2=None, ffe_gain2=None, lane=0):

    if ctle_gain1=='?':
        log_no_newline("\n >>>> Usage: dc_gain(ctle_gain1, ffe_gain1, ctle_gain2, ffe_gain2, lane#)")
        ctle_gain1=None; ffe_gain1=None; ctle_gain2=None; ffe_gain2=None; lane=lane
        log("\n >>>> Current settings shown below:")


    ctle_gain1_bin, ffe_gain1_bin, ctle_gain2_bin, ffe_gain2_bin = dc_gain_Rev70(ctle_gain1, ffe_gain1, ctle_gain2, ffe_gain2, lane)
    return ctle_gain1_bin, ffe_gain1_bin, ctle_gain2_bin, ffe_gain2_bin

######################################################################################



def dc_gain_Rev70(ctle_gain1=None, ffe_gain1=None, ctle_gain2=None, ffe_gain2=None, lane=0):
    ## Write dc gain to register
    if ctle_gain1=='?':
        log_no_newline("\n >>>> Usage: dc_gain(ctle_gain1, ffe_gain1, ctle_gain2, ffe_gain2, lane#)")
        ctle_gain1=None; ffe_gain1=None; ctle_gain2=None; ffe_gain2=None; lane=lane
        log("\n >>>> Current settings shown below:")


    if ctle_gain1 !=None:
        ctle_gain1_gray = Bin_Gray(ctle_gain1)
        wregBits(ctle_gain1_addr,ctle_gain1_bit_loc, ctle_gain1_gray, lane)

    if ffe_gain1 !=None:
        ffe_gain1_gray = Bin_Gray(ffe_gain1)
        wregBits(ffe_gain1_addr, ffe_gain1_bit_loc, ffe_gain1_gray, lane)

    if ctle_gain2 !=None:
        ctle_gain2_gray = Bin_Gray(ctle_gain2)
        wregBits(ctle_gain2_addr,ctle_gain2_bit_loc, ctle_gain2_gray, lane)

    if ffe_gain2 !=None:
        ffe_gain2_gray = Bin_Gray(ffe_gain2)
        wregBits(ffe_gain2_addr,ffe_gain2_bit_loc, ffe_gain2, lane)

    ##read DC gain from register

    ctle_gain1_bin = Gray_Bin(rregBits(ctle_gain1_addr,ctle_gain1_bit_loc, lane))
    ctle_gain2_bin = Gray_Bin(rregBits(ctle_gain2_addr,ctle_gain2_bit_loc, lane))

    ffe_gain1_bin = Gray_Bin(rregBits(ffe_gain1_addr, ffe_gain1_bit_loc,  lane))
    ffe_gain2_bin = Gray_Bin(rregBits(ffe_gain2_addr, ffe_gain2_bit_loc,  lane))

    return ctle_gain1_bin, ffe_gain1_bin, ctle_gain2_bin, ffe_gain2_bin
####################################################################
def f1over3(f1over3_val_to_write=None, lane=0):
    if f1over3_val_to_write==None: # read f1over3 value
        f1= rregBits(f1over3_addr, f1over3_bit_loc, lane)
        f1 = (f1>0x40) and (f1-0x80) or f1
        return f1
    else: # write f1over3
        f1 = (f1over3_val_to_write<0) and (f1over3_val_to_write+0x80) or f1over3_val_to_write
        wregBits(f1over3_addr, f1over3_bit_loc, f1, lane)
        #if(gDebugTuning):print ('\nF1over3 write %d, read back %d' % (f1over3_val_to_write, f1over3())),
####################################################################
def delta_ph(delta_val_to_write=None, lane=0):

    ######### PAM4 Mode
    if get_mode(lane) == 'pam4':
        if delta_val_to_write==None:
            delta= rregBits(delta_ph_ow_addr, delta_ph_ow_val_bit_loc, lane)
            delta = (delta>0x40) and (delta-0x80) or delta
            #print("\n ************************ DELTA Value= %d" %delta)
            return delta
        else:
            delta= (delta_val_to_write<0) and (delta_val_to_write+0x80) or delta_val_to_write
            wregBits(delta_ph_ow_addr, delta_ph_ow_val_bit_loc, delta, lane)
            #print("\n >>>>>>>>>>>>>>>>>>>>> DELTA Written= %d (%02X)" %(delta_val_to_write,delta))

    ######### NRZ Mode
    else:
        if delta_val_to_write==None:
            delta = rregBits(nrz_dfe_delta_addr, nrz_dfe_delta_bit_loc, lane)
            return delta
        else:
            wregBits(nrz_dfe_delta_addr, nrz_dfe_delta_bit_loc, delta_val_to_write, lane)

####################################################################
def ctle_fine(ctle_fine_val_to_write=None, lane=0):
    if ctle_fine_val_to_write==None:
        ctle= rregBits(ctle_fine_addr, ctle_fine_bit_loc, lane)
        return ctle
    else:
        wregBits(ctle_fine_addr, ctle_fine_bit_loc, ctle_fine_val_to_write, lane)

####################################################################
def ext_rch(mode='en', val1_to_write=None, val2_to_write=None, lane=0):

    if mode=='?':
        log_no_newline("\n     Manage Extended Reach Feature:")
        log_no_newline("\n     1.  Enable and ExtRch1=2 ExtRch2=0: ext_rch('en',2,0), Returns (ext_rch_en=1,ext_rch1=2,ext_rch2=0)")
        log_no_newline("\n     2.  Disable Extended Reach        : ext_rch('dis'),    Returns (ext_rch_en=0,ext_rch1=0,ext_rch2=0)")
        log("\n     3.  Check Current Setting         : ext_rch(),         Returns (ext_rch_en=0/1,ext_rch1=0-7,ext_rch2=0-7)")
    elif mode=='dis' or mode==0:
        wregBits(ext_rch_en_addr, ext_rch_en_bit_loc, 0, lane)
        wregBits(ext_rch_en_addr, ext_rch_param1_bit_loc, 0, lane)
        wregBits(ext_rch_en_addr, ext_rch_param2_bit_loc, 0, lane)
    else: #mode=='en' or mode==1
        if val1_to_write!=None:
            wregBits(ext_rch_en_addr, ext_rch_en_bit_loc, 1, lane)
            wregBits(ext_rch_en_addr, ext_rch_param1_bit_loc, val1_to_write, lane)
        if val2_to_write!=None:
            wregBits(ext_rch_en_addr, ext_rch_en_bit_loc, 1, lane)
            wregBits(ext_rch_en_addr, ext_rch_param2_bit_loc, val2_to_write, lane)

    ext_rch_en = rregBits(ext_rch_en_addr, ext_rch_en_bit_loc, lane)
    ext_rch1 = rregBits(ext_rch_en_addr, ext_rch_param1_bit_loc, lane)
    ext_rch2 = rregBits(ext_rch_en_addr, ext_rch_param2_bit_loc, lane)
    return ext_rch_en, ext_rch1,ext_rch2
####################################################################
def sel_ctle_map(IL='ALL', lane=0):
    if IL == 'SR':
        wregLane(params(lane).ctle_map2_addr, 0x2518, lane) # CTLE 0 = ((1,1)(2,1)(4,1)
        wregLane(params(lane).ctle_map1_addr, 0x79eb, lane) # CTLE 3 = ((7,1)(7,2)
        wregLane(params(lane).ctle_map0_addr, 0xbf3f, lane) # CTLE 5 = ((7,3)(7,4)(7,7)
    elif IL == 'MR':
        wregLane(params(lane).ctle_map2_addr, 0x64c3, lane)
        wregLane(params(lane).ctle_map1_addr, 0x533a, lane)
        wregLane(params(lane).ctle_map0_addr, 0x951c, lane)
    elif IL == 'VSR':
        wregLane(params(lane).ctle_map2_addr, 0x7249, lane)
        wregLane(params(lane).ctle_map1_addr, 0x6dbb, lane)
        wregLane(params(lane).ctle_map0_addr, 0x6dff, lane)
    # elif IL == 'NRZ_Rev40':
        # wregLane(ctle_map2_addr, 0x2514, lane) # CTLE 0 = ((1,1)(2,1)(2,2)
        # wregLane(ctle_map1_addr, 0xa9e7, lane) # CTLE 3 = ((5,1)(7,1)
        # wregLane(ctle_map0_addr, 0xaefd, lane) # CTLE 5 = ((7,2)(7,3)(7,5)
    elif IL == 'NRZ_Rev40':
        wregLane(params(lane).ctle_map2_addr, 0x2514, lane) # CTLE 0 = ((1,1)(2,1)(2,2)
        wregLane(params(lane).ctle_map1_addr, 0x8d53, lane) # CTLE 3 = ((1,5)(2,4)
        wregLane(params(lane).ctle_map0_addr, 0xaefd, lane) # CTLE 5 = ((7,2)(7,3)(7,5)
    elif IL == '56G_Rev40'or IL=='ALL':
        #wregLane(ctle_map2_addr, 0x259a, lane) # CTLE 0 = ((1,1)(3,1)(5,1)
        #wregLane(ctle_map2_addr, 0x452a, lane) # CTLE 0 = ((2,1)(2,2)(5,1)
        wregLane(params(lane).ctle_map2_addr, 0x28b3, lane) # CTLE 0 = ((1,2)(1,3)(1,4)
        wregLane(params(lane).ctle_map1_addr, 0x31eb, lane) # CTLE 3 = ((6,1)(7,2)
        wregLane(params(lane).ctle_map0_addr, 0xbf3e, lane) # CTLE 5 = ((7,3)(7,4)(7,6)
    elif IL == '56G_Rev40_MR': ####### Standard MR Mode (FFE Off) CTLE table
        #wregLane(ctle_map2_addr, 0x259a, lane) # CTLE 0 = ((1,1)(3,1)(5,1)
        wregLane(params(lane).ctle_map2_addr, 0xc79a, lane) # CTLE 0 = ((6,1)(7,1)(5,2)
        wregLane(params(lane).ctle_map1_addr, 0xbacf, lane) # CTLE 3 = ((7,2)(6,3)
        wregLane(params(lane).ctle_map0_addr, 0xbf3e, lane) # CTLE 5 = ((7,3)(7,4)(7,6)
    elif IL == '37G_Rev40':
        wregLane(params(lane).ctle_map2_addr, 0x2516, lane) # CTLE 0 = (1,1) (2,1) (3,1)
        wregLane(params(lane).ctle_map1_addr, 0x61a7, lane) # CTLE 3 = (4,1) (5,1)
        wregLane(params(lane).ctle_map0_addr, 0x1e7a, lane) # CTLE 5 = (6,1) (7,1) (7,3)

####################################################################
def get_ctle_map(index=None, lane=0):

    map=[]
    for idx in range(0,8):
        map.append([])

    map[0].append(rregBits(params(lane).ctle_map2_addr, [15,13], lane))
    map[0].append(rregBits(params(lane).ctle_map2_addr, [12,10], lane))
    map[1].append(rregBits(params(lane).ctle_map2_addr, [ 9, 7], lane))
    map[1].append(rregBits(params(lane).ctle_map2_addr, [ 6, 4], lane))
    map[2].append(rregBits(params(lane).ctle_map2_addr, [ 3, 1], lane))
    map[2].append((rregBits(params(lane).ctle_map2_addr,[0],     lane)<<2) + rregBits(params(lane).ctle_map1_addr, [15,14], lane) )
    map[3].append(rregBits(params(lane).ctle_map1_addr, [13,11], lane))
    map[3].append(rregBits(params(lane).ctle_map1_addr, [10, 8], lane))
    map[4].append(rregBits(params(lane).ctle_map1_addr, [ 7, 5], lane))
    map[4].append(rregBits(params(lane).ctle_map1_addr, [ 4, 2], lane))
    map[5].append((rregBits(params(lane).ctle_map1_addr,[ 1, 0], lane)<<1) + rregBits(params(lane).ctle_map0_addr, [15], lane))
    map[5].append(rregBits(params(lane).ctle_map0_addr, [14,12], lane))
    map[6].append(rregBits(params(lane).ctle_map0_addr, [11, 9], lane))
    map[6].append(rregBits(params(lane).ctle_map0_addr, [ 8, 6], lane))
    map[7].append(rregBits(params(lane).ctle_map0_addr, [ 5, 3], lane))
    map[7].append(rregBits(params(lane).ctle_map0_addr, [ 2, 0], lane))

    if index==None:
        index = rregBits(params(lane).ctle_val_addr, params(lane).ctle_val_bit_loc, lane) # CTLE currently used

    return index, map[index][0],map[index][1]
####################################################################
def ctle_map(index=None, c1=None, c2=None, lane=0):

    if(index!=None and c1!=None and c2!=None):
        if(index==0):
            wregBits(params(lane).ctle_map2_addr, [15,13], c1, lane)
            wregBits(params(lane).ctle_map2_addr, [12,10], c2, lane)
        elif(index==1):
            wregBits(params(lane).ctle_map2_addr, [ 9, 7], c1, lane)
            wregBits(params(lane).ctle_map2_addr, [ 6, 4], c2, lane)
        elif(index==2):
            wregBits(params(lane).ctle_map2_addr, [ 3, 1], c1,   lane)
            wregBits(params(lane).ctle_map2_addr,     [0], c2>>2, lane)
            wregBits(params(lane).ctle_map1_addr,  [15,14], c2&3, lane)
        elif(index==3):
            wregBits(params(lane).ctle_map1_addr, [ 13,11], c1, lane)
            wregBits(params(lane).ctle_map1_addr, [ 10, 8], c2, lane)
        elif(index==4):
            wregBits(params(lane).ctle_map1_addr, [ 7, 5], c1, lane)
            wregBits(params(lane).ctle_map1_addr, [ 4, 2], c2, lane)
        elif(index==5):
            wregBits(params(lane).ctle_map1_addr, [ 1, 0], c1>>1,lane)
            wregBits(params(lane).ctle_map0_addr, [15],    c1&1, lane)
            wregBits(params(lane).ctle_map0_addr,  [14,12], c2,  lane)
        elif(index==6):
            wregBits(params(lane).ctle_map0_addr, [11, 9], c1, lane)
            wregBits(params(lane).ctle_map0_addr, [ 8, 6], c2, lane)
        elif(index==7):
            wregBits(params(lane).ctle_map0_addr, [ 5, 3], c1, lane)
            wregBits(params(lane).ctle_map0_addr, [ 2, 0], c2, lane)
    else:
        map=[]
        for idx in range(0,8):
            map.append([])

        map[0].append(rregBits(params(lane).ctle_map2_addr, [15,13], lane))
        map[0].append(rregBits(params(lane).ctle_map2_addr, [12,10], lane))
        map[1].append(rregBits(params(lane).ctle_map2_addr, [ 9, 7], lane))
        map[1].append(rregBits(params(lane).ctle_map2_addr, [ 6, 4], lane))
        map[2].append(rregBits(params(lane).ctle_map2_addr, [ 3, 1], lane))
        map[2].append((rregBits(params(lane).ctle_map2_addr,[0],     lane)<<2) + rregBits(params(lane).ctle_map1_addr, [15,14], lane) )
        map[3].append(rregBits(params(lane).ctle_map1_addr, [13,11], lane))
        map[3].append(rregBits(params(lane).ctle_map1_addr, [10, 8], lane))
        map[4].append(rregBits(params(lane).ctle_map1_addr, [ 7, 5], lane))
        map[4].append(rregBits(params(lane).ctle_map1_addr, [ 4, 2], lane))
        map[5].append((rregBits(params(lane).ctle_map1_addr,[ 1, 0], lane)<<1) + rregBits(params(lane).ctle_map0_addr, [15], lane))
        map[5].append(rregBits(params(lane).ctle_map0_addr, [14,12], lane))
        map[6].append(rregBits(params(lane).ctle_map0_addr, [11, 9], lane))
        map[6].append(rregBits(params(lane).ctle_map0_addr, [ 8, 6], lane))
        map[7].append(rregBits(params(lane).ctle_map0_addr, [ 5, 3], lane))
        map[7].append(rregBits(params(lane).ctle_map0_addr, [ 2, 0], lane))

        log("\n L%d CTLE_MAP 2 R%04X: %04X"   %(lane, params(lane).ctle_map2_addr, rregLane(params(lane).ctle_map2_addr, lane)))
        log(" L%d CTLE_MAP 1 R%04X: %04X"   %(lane,params(lane).ctle_map1_addr, rregLane(params(lane).ctle_map1_addr, lane)))
        log(" L%d CTLE_MAP 0 R%04X: %04X\n" %(lane, params(lane).ctle_map0_addr, rregLane(params(lane).ctle_map0_addr, lane)))
        curr_ctle = rregBits(params(lane).ctle_val_addr, params(lane).ctle_val_bit_loc, lane) # CTLE
        for idx in range(0,8):
            log_no_newline(" L%d CTLE %d = (%d,%d)" % (lane, idx, map[idx][0],map[idx][1]))
            if( idx == curr_ctle):
                log("<<< Currently Selected")
            else:
                log('')
        #print (map)

####################################################################
def get_pll_vcocap_from_pll_lock(mode='tx_en', lane=0, print_en=0):
    # force NRZ Full Rate mode for simplicity (i.e. data_rate=fvco)
    # global gPam4NrzMode
    #global gNrzSubRateMode
    saved_mode = gPam4NrzMode[lane]
    saved_subratemode = gNrzSubRateMode[lane]
    gPam4NrzMode[lane] = 'nrz'
    gNrzSubRateMode[lane]=False

    # if requested to check vcocap range for a particular fvco frequency, program PLL to it first
    # if desired_fvco !=None and (type(desired_fvco)==float or type(desired_fvco)==int):
        # if desired_fvco>34.0: desired_fvco/=2.0
        # set_pll(rate=float(desired_fvco), lane=lane)
    # elif type(desired_fvco)==str:
        # mode = desired_fvco # if desired_fvco not a number, take it as mode

    # get the current PLL frequency so we can get its center value from "pll_lvcocap_table", as defined in set_serdes_globals()
    actual_data_rate, actual_baud_rate, actual_fvco, pll_n, pll_fracn, pll_cap, div4 = get_pll(lane=lane)
    original_vcocap = get_pll_vcocap_from_table (actual_fvco)
    lock_list = []

    # First, Start vcocap sweep from CENTER and to LEFT: until lock condition goes away
    # Next, sweep vcocap from CENTER+1 to RIGHT: until lock condition goes away
    dir=0
    total_caps_each_dir = 10
    total_caps_tested = 0
    step_size=1
    testcap = original_vcocap # include center vcocap
    while (1):# (total_caps_tested != total_caps_each_dir) and (0<=testcap<=63):
        total_caps_tested += 1 # increment counter fail-safe
        wregBits(pll_lvcocap_addr,  pll_lvcocap_bit_loc,  testcap,  lane) # update vcocap value
        set_pll_lock(mode) # turn on PLL Lock Detection:
        lock_status = get_pll_lock()[1] # check if part actually locks
        set_pll_lock('dis') # turn off pll_lock detection feature
        if print_en: log("VCOCAP (Lock Status):", step_size, total_caps_tested, testcap, lock_status)
        if lock_status ==3:
            lock_list.append(testcap) # record test cap if locks to up list
        if dir==0 and (total_caps_tested>=total_caps_each_dir or testcap<=0 or testcap>=63):
            dir=1
            total_caps_tested=0
            testcap = original_vcocap # start with center vcocap +1
            step_size=-1
        if dir==1 and (total_caps_tested>=total_caps_each_dir or testcap<=0 or testcap>=63):
            break

        testcap -= step_size # next testcap
        if testcap<0: testcap=0
        if testcap>63: testcap=63

    lock_list.sort() # ensure lock list is in sequential order
    if len(lock_list)>0: new_vcocap = lock_list[int(len(lock_list)/2)] # get middle value
    else: new_vcocap = original_vcocap
    wregBits(pll_lvcocap_addr,  pll_lvcocap_bit_loc,  new_vcocap,  lane)
    if print_en: log("Num Good VCOCAPs    :", len(lock_list))
    if print_en: log("Original VCOCAP     :", original_vcocap)
    if print_en: log("New VCOCAP          :", new_vcocap)
    if print_en: log("Good VCOCAP List    :", mode, lock_list)

    gPam4NrzMode[lane]=saved_mode
    gNrzSubRateMode[lane]=saved_subratemode

    return actual_data_rate, actual_fvco, mode, original_vcocap, new_vcocap, lock_list
####################################################################
def pll_lock(mode=None,lane=0):

    ################# help mode
    if mode=='?':
        log_no_newline("\n     Check PLL Lock Detection Status:")
        log("\n     1.  pll_lock()")
        log_no_newline("\n     Enable PLL Lock Detection:")
        log_no_newline("\n     1.  pll_lock('tx_en')")
        log("\n     2.  pll_lock('rx_en')")
        log_no_newline("\n     Disable PLL Lock Detection:")
        log("\n     1.  pll_lock('dis')\n")
        return

    ################# en/dis PLL lock detection
    elif mode!=None:
        set_pll_lock(mode,lane)

    ################# get PLL lock Status
    pll_lock_en,pll_lock_status,pll_lock_done,error_cnt,actual_cnt,target_cnt = get_pll_lock(lane)
    if pll_lock_en == 0:
        log("\n     PLL Lock Detection Disabled!\n")
    else: # PLL Lock Detection is enabled, report the status
        if pll_lock_en==1:
            log_no_newline("\n PLL Lock Detection Enabled for TX")
        elif pll_lock_en==2:
            log_no_newline("\n PLL Lock Detection Enabled for RX")
        log_no_newline("\n PLL Lock Detection Target Count: 0x%08X"%target_cnt)
        log_no_newline("\n PLL Lock Detection Actual Count: 0x%08X"%actual_cnt)
        log_no_newline("\n PLL Lock Detection Delta  Count: %d"%(error_cnt))

        log_no_newline("\n PLL Lock Detection Progress    :")
        if pll_lock_done==1:
            log_no_newline("Done!")
        else:
            log_no_newline("Not Done Yet!")

        log_no_newline("\n PLL Lock Status                :")
        if pll_lock_status==3:
            log("LOCKED!\n")
        else:
            log("Not Locked!\n")

####################################################################
def set_pll_lock(mode='tx_en',lane=0):
    if mode=='en' or mode=='tx' or mode=='tx_en' or mode=='rx' or mode=='rx_en': # enable TX or RX PLL checking
        if mode=='en' or mode=='tx' or mode=='tx_en':
            wregBits(0x9825, [15], 0, lane) # To enable TX PLL lock-detection feature
        else: # enable RX PLL checking
            wregBits(0x9825, [15], 1, lane) # To enable RX PLL lock-detection feature

        actual_data_rate, actual_baud_rate, fvco, pll_n, pll_fracn, pll_cap, div4 = get_pll(lane=lane)

        target_cnt = rregBits(0x9826, [15,0], lane) #1/ref_clk * (9826[15:0]) = Target * 32 / BaudRate
        target_cnt = int(target_cnt/(gRefclkFreq * 1e6) / (32.0 / fvco / 1.0e9))
        #print ("\n PLL Lock Detection Target Count: 0x%06X\n"%target_cnt)
        wregBits(0x9822, [15,0], (target_cnt >> 16)& 0xFFFF, lane) #Set the Target value MSB (32bits)
        wregBits(0x9823, [15,0],        target_cnt & 0xFFFF, lane) #Set the Target value LSB (32bits)
        wregBits(0x9824, [15,0], 0x20, lane) #Set the target margin reg 9824[15:0] to  small number like 0x20
        wregBits(0x9825, [8], 0, lane) # To start the detection: toggle 9825[8]: 0 -> 1
        wregBits(0x9825, [8], 1, lane) # To start the detection: toggle 9825[8]: 0 -> 1

####################################################################
def get_pll_lock(lane=0):

    pll_lock_en=0;pll_lock_status=0;pll_lock_done=0;error_cnt=0;actual_cnt=0;target_cnt=0


    rx_lock_det= rregBits(0x9825, [15], lane) #0: TX PLL lock-detection enabled 1: RX PLL lock-detection enabled

    pll_lock_en= 1 # TX lock detect is enabled
    if rx_lock_det==1: pll_lock_en=2 # RX lock detect is enabled

    #Use the following registers to monitor the lock detection function
    target_msb = rregBits(0x9822, [15,0], lane) #get the Target value MSB (32bits)
    target_lsb = rregBits(0x9823, [15,0], lane) #get the Target value LSB (32bits)
    target_cnt = (target_msb << 16) + target_lsb

    count_msb = rregBits(0x9827, [15,0], lane) #get the actual count value MSB (32bits)
    count_lsb = rregBits(0x9828, [15,0], lane) #get the actual count value LSB (32bits)
    actual_cnt = (count_msb << 16) + count_lsb
    error_cnt = actual_cnt-target_cnt

    pll_lock_done  = rregBits(0x9829, [14], lane) # 1:  lock detection process done
    pll_lock_status= rregBits(0x9829, [15,14], lane) # 1: pll locked successfully ,  0: pll is unlocked

    return pll_lock_en,pll_lock_status,pll_lock_done,error_cnt,actual_cnt,target_cnt
####################################################################
def pll_pi(mode=None,lane=0):

    if mode!=None:
        if mode >=0 and mode <= 15: # 4-bit control to set phase interpolator reference voltage range
            wregBits(0xCA, [4](mode>>3)&0x01, lane) # phase interpolator reference voltage MSB bit [3]
            wregBits(0xEA, [12,10], mode&0x7, lane) # phase interpolator reference voltage LSB bits[2:0]
        elif mode == '?':
            log_no_newline("\n    To Check the value of PLL PI:  pll_pi()")
            log("\n    To  Set  the value of PLL PI:  pll_pi(value) , Valid range: 0 to 15\n")


    val = (rregBits(0xCA, [4], lane) <<3) + (rregBits(0xEA, [12,10], lane))# phase interpolator reference voltage bits [2:0]
    log("\n....PLL PI Value set to %d\n"%val)
    return val
####################################################################
def pll_top_pi(mode=None,lane=0):

    if mode!=None:
        if mode=='dn' or mode=='dwn' or mode=='down' or mode=='dis':
            wregBits(0xE2, [3], 0, lane)
        elif mode=='up' or mode=='en' or mode=='enable':
            wregBits(0xE2, [3], 1, lane)
        elif mode == '?':
            log_no_newline("\n    To Check State of PLL TOP's PI:  pll_top_pi()")
            log_no_newline("\n    To Power  Up  TOP PLL PI      :  pll_top_pi('up')")
            log("\n    To Power Down TOP PLL PI      :  pll_top_pi('dn')\n")


    mode=rregBits(0xE2, [3], lane)
    if mode==0:
        log("\n....PLL TOP PI Powered Down!\n")
        return 0
    else: # up
        log("\n....PLL TOP PI Powered Up\n")
        return 1
####################################################################
# Here is the setting to put the Serdes in Rx-to-TX loopback mode (TX locks to the incoming RX frequency)
# 1.  0x00ce: 0x0000
# 2.  0x00cd: 0x0060
# 3.  0x004b: 0xf002
#
# Here are the descriptions for the bits related to RX-to-TX Loopback mode
#
# 0x00CD...0x0000...0x0060...Bit [6]:  Phase Rotator Polarity flip, Bit [5]: TX Rotator disabled
# 0x00CE...0x0000...0x0000...Bit [13]: Set to 0 to make sure frequency accumulator overwrite is disabled
#                            Bits[12:1]: frequency accumulator overwrite value if bit 13 is set to 1
# 0x004B...0xE802...0xF002...Bit [12]: set to 1 to enable PLL Intp, Bit [11]: set to 0 to disable RX DTL Intp
#
# For this loopback mode, only if the external link partner uses a
# asynchronized reference clock then Credos TX clock has to lock
# to the RX clock. Since the RX-TX clocks share one PLL in device
# we need to enable the PLL Intp and not the RX DTL Intp for this loopback mode
####################################################################
def rx_tx_serial_loopback(enable, lane=0):
    if enable:
       wregBits(0xCD,  [6], 1, lane)# Phase Rotator Polarity flip
       wregBits(0xCD,  [5], 1, lane)# TX Rotator disabled
       wregBits(0xCE, [13], 0, lane)# make sure frequency accumulator overwrite is disabled
       wregBits(0xCE,[12,1],0, lane)# frequency accumulator overwrite value if bit 13 is set to 1
       wregBits(0x4B, [12], 1, lane)# Enable PLL Intp
       wregBits(0x4B, [11], 1, lane)# disable RX DTL Intp
       wregBits(0xA0,[15,8],0, lane)# enable functional mode
       wregBits(0x9803,[15],1, lane)# enable loopback fifo
    else: # loopback disabled, normal mode
       wregBits(0xCD,  [6], 0, lane)# Phase Rotator Polarity flip
       wregBits(0xCD,  [5], 0, lane)# TX Rotator disabled
       wregBits(0xCE, [13], 0, lane)# make sure frequency accumulator overwrite is disabled
       wregBits(0xCE,[12,1],0, lane)# frequency accumulator overwrite value if bit 13 is set to 1
       wregBits(0x4B, [12], 0, lane)# Enable PLL Intp
       wregBits(0x4B, [11], 0, lane)# disable RX DTL Intp
       wregBits(0xA0,[15,8],0xef, lane)# enable PRBS mode, disable functional mode
       wregBits(0x9803,[15],0, lane)# disable loopback fifo

def get_rx_tx_serial_loopback(lane):
    return rregBits(0x9803, [15], lane)
    #w1=rregBits(0xCD,  [6], lane)# Phase Rotator Polarity flip
    #w2=rregBits(0xCD,  [5], lane)# TX Rotator disabled
    #w3=rregBits(0x4B, [12], lane)# Enable PLL Intp
    #w4=rregBits(0x4B, [11], lane)# disable RX DTL Intp
    #if w1==1 and w2==1 and w3==1 and w4==1:
    #    #print "\n....RX-to-TX internal Loopback ENABLED!\n"
    #    return True
    #elif w1==0 and w2==0 and w3==0 and w4==0:
    #    #print "\n....RX-to-TX internal Loopback Disabled!\n"
    #    return False
    #else:
    #    print "RX-to-TX internal Loopback Setup is UNKNOWN!\n"
    #    print w1, w2, w3, w4
    #    return False

####################################################################
def tx_rx_serial_loopback(mode=None,lane=0):

    rate = 'half_rate'  # or 'quarter_rate'

    if mode == 'pam4': # only works in NRZ Mode, not PAM4
        log("\n>>>> TX-to-RX Serial Loopback feature is available in NRZ mode Only!\n")
        return -1

    if mode=='?':
        log_no_newline("\n     To En/Disable TX-to-RX Serial Loopback:")
        log_no_newline("\n     1.  tx_rx_serial_loopback('en')")
        log("\n     2.  tx_rx_serial_loopback('dis')\n")
        log("\n     Note:  Requires a 100-ohm Termination between TX pins\n")
        return -1
    elif mode!=None:
        if mode=='en' or mode=='enable':
            #set_serdes_globals(chip_rev='4.0b', mode='nrz', rx_input_mode='dc', target_data_rate=14.1, ref_clk_freq=156.250, div4=1,lane=lane)
            serdes_set_params(lane=lane, mode='nrz', rx_input_mode='dc', target_data_rate=14.1, div4=1)
            serdes_setup_pll(lane)

            load_setup_nrz_half_rate(lane) # load the default nrz half-rate mode first

            ctle(7,5,6,lane=lane) # minimum peaking
            dc_gain(24,15,24,0,lane=lane) # mid to high DC Gain

            wregBits(0xCA,  [1], 1, lane)# en_loopback_rx
            wregBits(0xC5, [15], 1, lane)# en_loopback_tx
            wregBits(0xF7, [13], 0, lane)# disable pu_pmos
            wregBits(0x179, [6], 0, lane)# NRZ BB mode disabled
            wregBits(0x101,[14], 0, lane)# NRZ delta adaptation disabled
            #wregBits(0xA0,[15,8],0xeb, lane)# enable PRBS mode

            set_tx_taps(   0 ,   0 ,  27 ,   -4 ,   0, lane ) # this is good TX for half-rate NRZ loopback
            wregBits(0xB0,  [0], 1, lane)# tx NRZ sub rate
            wregBits(0x179, [0], 1, lane)# rx NRZ sub rate

            if rate == 'quarter_rate':
                set_tx_taps(   0 ,   0 ,  30 ,   0 ,   0, lane ) # this is good TX for 1/4-rate NRZ loopback
                wregBits(0x0A0,[1,0], 1, lane) # tx NRZ 1/4 rate
                wregBits(0x179,[8,7], 1, lane) # rx NRZ 1/4 rate


        else: # loopback disabled, normal mode
           load_setup_nrz_full_rate(lane)
           wregBits(0xCA,  [1], 0, lane)# dis_loopback_rx
           wregBits(0xC5, [15], 0, lane)# dis_loopback_tx
           wregBits(0xF7, [13], 1, lane)# enable pu_pmos
           wregBits(0xB0,  [0], 0, lane)# tx NRZ half rate disabled
           wregBits(0x179, [0], 0, lane)# rx NRZ half rate disabled
           wregBits(0x179, [6], 0, lane)# NRZ BB mode disabled
           wregBits(0x101,[14], 1, lane)# NRZ delta adaptation enabled

    lane_reset(lane)

    rx_mode=rregBits(0xCA,  [1], lane) # en_loopback_rx ?
    tx_mode=rregBits(0xC5, [15], lane) # en_loopback_tx ?
    if rx_mode==1 and tx_mode==1:
        log("\n....TX-to-RX Serial Loopback ENABLED!\n")
        log("\n....Note:  Requires a 100-ohm Termination between TX pins (or connect TX to another lane's RX)\n")
    else:
        log("\n....TX-to-RX Serial Loopback Disabled!\n")

    return rx_mode and tx_mode

####################################################################
def serdes_params(print_header=True, lane=0):
    if get_mode(lane) != 'pam4':
        return nrz_params(print_header=print_header, lane=lane)
    else:
        return pam4_params2(print_header=print_header, lane=lane)

#####################################################################################################
def pam4_params2(print_header=True,lane=0):
    global gAdaptationCount
    global gChannelEstimate
    global gChannelOf
    global gChannelHf

    if get_mode(lane) != 'pam4':
        log("\n\n>>> PAM4_PARAMS: Serdes Not in PAM4 Mode !\n\n")
        return

    if print_header==True:
        log_no_newline("\n--------------------------------------------------------------------------------------------------------------------------------------------------------------------")
        log_no_newline("\n|DataRate,AdpCnt/Time |      TX       |DAC,EYE1,EYE2,EYE3 |CTLE,1,2,F |  DCGain/Att |ChEst,Of,Hf |  F0,   F1,  Fm1 |F13,Del,Edges |FFEPol,Tap1,2,3,4,34,234| BER / Frq_acc")
        log_no_newline("\n--------------------------------------------------------------------------------------------------------------------------------------------------------------------")


    actual_data_rate, actual_baud_rate, fvco, pll_n, pll_fracn, pll_cap, div4 = get_pll(lane=lane)
    [eye1,eye2,eye3, dac]  = get_eye3(lane)
    [tx_pre2,tx_pre1,tx_main,tx_post1,tx_post2] = get_tx_taps(lane=lane)
    ctle_val,ctel1,ctle2 = ctle(lane=lane)
    ctle_f = ctle_fine(lane=lane)
    f0, f1     = get_pam4_dfe(lane=lane)
    fm1 = ((rregBits(pam4_tap_addr,pam4_tap_bit_loc,lane))+64)%128 - 64
    #f0, f1, fm1, ths_list = get_pam4_dfe_ng(lane=lane)
    #f0, f1 = get_pam4_dfe(lane)
    ffe_pol1 = rregBits(ffe_pol_addr,ffe_po11_bit_loc,lane)
    ffe_pol2 = rregBits(ffe_pol_addr,ffe_po12_bit_loc,lane)
    ffe_pol3 = rregBits(ffe_pol_addr,ffe_po13_bit_loc,lane)
    ffe_pol4 = rregBits(ffe_pol_addr,ffe_po14_bit_loc,lane)
    ffe_pol    = rregLane(ffe_pol_addr,    lane)
    delta1 = delta_ph(lane = lane)
    edge1      = rregLane(edge1_addr,       lane)
    #ctle_gain1 = rregLane(ctle_gain1_addr,  lane)
    #ffe_gain1  = rregLane(ffe_gain1_addr,   lane)
    [ctle_gain1_bin,ffe_gain1_bin,ctle_gain2_bin,ffe_gain2_bin] = dc_gain(lane=lane)
    att = attenuator(lane=lane)

    ext_rch    = rregLane(ext_rch_en_addr,  lane)
    #ffe_tap1   = rregLane(ffe_tap1_addr,    lane)
    #ffe_tap2   = rregLane(ffe_tap2_addr,    lane)
    #ffe_tap34  = rregLane(ffe_tap4_addr,    lane)
    [ffe_tap1_bin,ffe_tap234,ffe_tap2_bin,ffe_tap34,ffe_tap3_bin,ffe_tap4_bin] = ffe_taps(lane=lane)

    #ctle_fine  = rregLane(ctle_fine_addr,   lane)

    freq_acc = pam4_freq_acc(lane=lane)

    time.sleep(2)
    prbs_accum_time, prbs_error_cnt, ber_val3, log_ber3, lane_status = get_ber(lane=lane, rst=1, accum_time=5)
    #print("%4d," %lane),
    log_no_newline("\n|%7.4fG,%4d,%6.3f" % (actual_data_rate,gAdaptationCount, gAdaptationTime))
    log_no_newline("|%2d,%2d,%2d,%2d,%2d" %(tx_pre2,tx_pre1,tx_main,tx_post1,tx_post2))
    log_no_newline("|%3d,%4.0f,%4.0f,%4.0f" %(dac,eye1,eye2,eye3))
    log_no_newline("|%4d,%d,%d,%d" %(ctle_val,ctel1,ctle2,ctle_f))
    log_no_newline("|%2d,%2d,%2d,%d/%d" %(ctle_gain1_bin,ffe_gain1_bin,ctle_gain2_bin,ffe_gain2_bin,att))
    log_no_newline("|%5.3f,%2d,%2d" %(gChannelEstimate[lane],gChannelOf[lane], gChannelHf[lane]))
    log_no_newline("|%4.2f,%5.2f,%5.2f" %(f0, f1, fm1/64.0))
    #print("|%5d, %04X" %(delta1,edge1)),
    #print("|%6.3f" %gChannelEstimate[lane]),
    log_no_newline("|%3d,%3d, %04X" %(f1over3(lane=lane),delta_ph(lane=lane),edge1))
    log_no_newline("|%d%d%d%d" %(ffe_pol1,ffe_pol2,ffe_pol3,ffe_pol4))
    log_no_newline(",%02X,%02X,%02X,%02X,%02X,%02X" %(ffe_tap1_bin,ffe_tap2_bin,ffe_tap3_bin,ffe_tap4_bin,ffe_tap34,ffe_tap234))
    log("| %7.1e / %d" %(ber_val3, freq_acc))
    return [actual_data_rate,gAdaptationCount, gAdaptationTime,tx_pre2,tx_pre1,tx_main,tx_post1,tx_post2,dac,eye1,eye2,eye3,ctle_val,ctel1,ctle2,ctle_f,ctle_gain1_bin,ffe_gain1_bin,ctle_gain2_bin,ffe_gain2_bin,gChannelEstimate[lane],gChannelOf[lane], gChannelHf[lane],f0, f1, fm1/64.0,f1over3(lane=lane),delta_ph(lane=lane),edge1,ffe_pol1,ffe_pol2,ffe_pol3,ffe_pol4,ffe_tap1_bin,ffe_tap2_bin,ffe_tap3_bin,ffe_tap4_bin,ffe_tap34,ffe_tap234,ber_val3]
    #return ber_val3

#####################################################################################################
def nrz_params(print_header=True,lane=0):
    global gAdaptationCount
    global gChannelEstimate
    global gChannelOf
    global gChannelHf
    global gDfeInitPointer

    if get_mode(lane) == 'pam4':
        log("\n\n>>> NRZ_PARAMS: Serdes Not in NRZ Mode!\n\n")
        return

    if print_header==True:
        log_no_newline("\n----------------------------------------------------------------------------------------------------------------------------------")
        log_no_newline("\n|DataRate,AdpCnt,AdpTime |      TX       |DAC, EYE |CTLE,1,2,F |  DCGain   |ChEst,Of,Hf |Init, F1, F2, F3 |Delta,Edges |   BER   |")
        log_no_newline("\n----------------------------------------------------------------------------------------------------------------------------------")

    actual_data_rate, actual_baud_rate, fvco, pll_n, pll_fracn, pll_cap, div4 = get_pll(lane=lane)
    [eye_mV, dac]  = get_eye(lane)
    [tx_pre2,tx_pre1,tx_main,tx_post1,tx_post2] = get_tx_taps(lane)
    ctle_val,ctel1,ctle2 = ctle(lane=lane)
    ctle_f = ctle_fine(lane=lane)
    delta1, f1, f2, f3 = get_nrz_dfe(lane)
    [ctle_gain1_bin,ffe_gain1_bin,ctle_gain2_bin,ffe_gain2_bin] = dc_gain(lane=lane)
    edge1 = rregLane(edge1_addr, lane)
    ext_rch    = rregLane(ext_rch_en_addr,  lane)

    #print("%4d," %lane),
    log_no_newline("\n|%7.4fG,%6d,%7.3f" % (actual_data_rate,gAdaptationCount, gAdaptationTime))
    log_no_newline("|%2d,%2d,%2d,%2d,%2d" %(tx_pre2,tx_pre1,tx_main,tx_post1,tx_post2))
    log_no_newline("|%3d,%4.0f" %(dac,eye_mV))
    log_no_newline("|%4d,%d,%d,%d" %(ctle_val,ctel1,ctle2,ctle_f))
    log_no_newline("|%2d,%2d,%2d,%d" %(ctle_gain1_bin,ffe_gain1_bin,ctle_gain2_bin,ffe_gain2_bin))
    log_no_newline("|%5.3f,%2d,%2d" %(gChannelEstimate[lane],gChannelOf[lane], gChannelHf[lane]))
    log_no_newline("|%4d,%3d,%3d,%3d" %(gDfeInitPointer,f1, f2, f3))
    log_no_newline("|%5d, %04X" %(delta1,edge1))
    #time.sleep(2)
    prbs_accum_time, prbs_error_cnt, ber_val3, log_ber3, lane_status = get_ber(lane=lane, rst=1, accum_time=5)
    log("| %7.1e |" %ber_val3)
    return [actual_data_rate,gAdaptationCount, gAdaptationTime,tx_pre2,tx_pre1,tx_main,tx_post1,tx_post2,dac,eye_mV,ctle_val,ctel1,ctle2,ctle_f,ctle_gain1_bin,ffe_gain1_bin,ctle_gain2_bin,ffe_gain2_bin,gChannelEstimate[lane],gChannelOf[lane], gChannelHf[lane],gDfeInitPointer,f1, f2, f3,delta1,edge1,ber_val3]
    #return ber_val3

####################################################################
def lane_reset_fast (lane=0):
    # define
    lane_reset_addr=0x00
    lane_reset_bit_loc=[15]
    acal_start_addr = 0x1f
    acal_start_owen_bit_loc = [1]
    acal_start_ow_bit_loc = [0]
    acal_done_addr = 0x23
    acal_done_owen_bit_loc = [3]
    acal_done_ow_bit_loc = [2]

    wregBits(lane_reset_addr, lane_reset_bit_loc, 1,lane)

    wregBits(acal_start_addr, acal_start_owen_bit_loc,1,lane)
    wregBits(acal_start_addr, acal_start_ow_bit_loc,  0,lane)
    time.sleep(.008)
    wregBits(acal_done_addr,  acal_done_owen_bit_loc, 1,lane)
    wregBits(acal_done_addr,  acal_done_ow_bit_loc,   0,lane)

    wregBits(lane_reset_addr, lane_reset_bit_loc, 0,lane)

    wregBits(acal_done_addr,  acal_done_owen_bit_loc,  0,lane)
    wregBits(acal_start_addr, acal_start_owen_bit_loc, 0,lane)

####################################################################
def get_pam4_dfe_ng(lane=0):
    #record current setting
    bp1_ori = rregBits(bp_addr, bp1_bit_loc, lane)
    bp1_en_ori = rregBits(bp_addr, bp1_en_bit_loc, lane)
    reg_addr1 = 0x07
    wregBits (reg_addr1, [2,0], 2, lane)
    wregBits (pam4_tap_sel_addr, pam4_tap_sel_bit_loc, 1, lane)
    time.sleep(0.2)

    ths_sel_list = [x for x in range(12)]
    ths_list = []
    wregBits(bp_addr, bp1_bit_loc, 0x12, lane)
    wregBits(bp_addr, bp1_en_bit_loc, 1, lane)
    sm_cont(lane)
    wait_for_bp1_timeout=0
    while True:
        if rregBits(params(lane).sm_status_addr, params(lane).sm_status_bp1_bit_loc,lane):
            ma = rregBits(0x30,[7,4],lane)
            if ma==0xc:
                break
            else:
                wregBits(bp_addr, bp1_en_bit_loc, 0, lane)
                sm_cont(lane)
                wregBits(bp_addr, bp1_en_bit_loc, 1, lane)
        else:
            wait_for_bp1_timeout+=1
            if wait_for_bp1_timeout>10000:
                if(gDebugTuning): log("Get PAM4 DFE NG: >>>>> Timed out waiting for BP1")
                break


    for val in ths_sel_list:
        wregBits (pam4_dfe_sel_addr, pam4_dfe_sel_bit_loc, val, lane)
        readout = rregBits(pam4_dfe_read_addr, pam4_dfe_read_bit_loc, lane)
        result = ((float(readout)/2048)+1) % 2 - 1
        ths_list.append(result)
    f0 = int((-3)*((ths_list[0]-ths_list[2])+(ths_list[3]-ths_list[5])+(ths_list[6]-ths_list[8])+(ths_list[9]-ths_list[11]))*4)
    f1 = int(((-48)*(ths_list[0]+ths_list[1]+ths_list[2]-ths_list[9]-ths_list[10]-ths_list[11])+(-16)*(ths_list[3]+ths_list[4]+ths_list[5]-ths_list[6]-ths_list[7]-ths_list[8]))/5)
    fm1 = ((rregBits(pam4_tap_addr,pam4_tap_bit_loc,lane))+64)%128 - 64
    #print("\n F0= %d F1= %d Fm1= %d" % (f0, f1, fm1)),

    wregBits(bp_addr, bp1_en_bit_loc, 0, lane)
    sm_cont(lane)
    #wregBits(bp_addr, bp1_bit_loc, bp1_ori, lane)
    #wregBits(bp_addr, bp1_en_bit_loc, bp1_en_ori, lane)
    return f0, f1, fm1, ths_list

####################################################################
#
####################################################################
def check_for_reset(lane=0):
    #record current setting
    bp1_ori = rregBits(bp_addr, bp1_bit_loc, lane)
    bp1_en_ori = rregBits(bp_addr, bp1_en_bit_loc, lane)

    ths_sel_list = [x for x in range(12)]
    ths = []
    wregBits(bp_addr, bp1_bit_loc, 0x12, lane)
    wregBits(bp_addr, bp1_en_bit_loc, 1, lane)
    sm_cont(lane)
    wait_for_bp1_timeout=0
    #do_reset = 0
    while True:
        if rregBits(params(lane).sm_status_addr, params(lane).sm_status_bp1_bit_loc,lane):
            ma = rregBits(0x30,[7,4],lane)
            if ma==0xc:
                break
            else:
                wregBits(bp_addr, bp1_en_bit_loc, 0, lane)
                sm_cont(lane)
                wregBits(bp_addr, bp1_en_bit_loc, 1, lane)
        else:
            wait_for_bp1_timeout+=1
            if wait_for_bp1_timeout>1000:
                break



    for val in ths_sel_list:
        wregBits (pam4_dfe_sel_addr, pam4_dfe_sel_bit_loc, val, lane)
        readout = rregBits(pam4_dfe_read_addr, pam4_dfe_read_bit_loc, lane)
        result = int((((float(readout)/2048)+1) % 2 - 1)*64)
        ths.append(result)

    wregBits(bp_addr, bp1_en_bit_loc, 0, lane)
    sm_cont(lane)
    wregBits(bp_addr, bp1_bit_loc, bp1_ori, lane)
    wregBits(bp_addr, bp1_en_bit_loc, bp1_en_ori, lane)

    margin = 4
    margin2 = 2
    do_reset = 0
    if (ths[0]>ths[1])|(ths[1]>ths[2])|(ths[3]>ths[4])|(ths[4]>ths[5])|(ths[6]>ths[7])|(ths[7]>ths[8])|(ths[9]>ths[10])|(ths[10]>ths[11]):
        #if(gDebugTuning):print '\nDetected Smart Reset case1!\n',
        do_reset += 1

    if (abs((ths[0]+ths[2])/2-ths[1])>margin)|(abs((ths[3]+ths[5])/2-ths[4])>margin)|(abs((ths[6]+ths[8])/2-ths[7])>margin)|(abs((ths[9]+ths[11])/2-ths[10])>margin):
        #if(gDebugTuning):print '\nDetected Smart Reset case2!\n',
        do_reset += 2

    if (abs(ths[1]+ths[10])>6*margin2)|(abs(ths[4]+ths[7])>2*margin2):
        #if(gDebugTuning):print '\nDetected Smart Reset case3!\n',
        do_reset += 4
    log(ths)
    return do_reset

####################################################################################################
# New function:
# State Machine Continue,  toggle
####################################################################################################
def sm_cont(lane=0):
    wregBits(bp_addr, bp_ctu_bit_loc, 0, lane) # Alex, 20171206
    time.sleep(0.001)
    wregBits(bp_addr, bp_ctu_bit_loc, 1, lane) # Alex, 20171206
    #time.sleep(0.001)
    #wregBits(bp_addr, bp_ctu_bit_loc, 0, lane) # Alex, 20171206


####################################################################
def Gettapvalue_full (b0=None, dir=0, num=compat_listrange(0,15), lane=0):
    global gDebugPrint
    if b0==None:
        gDebugPrint=1
        b0=1
    else:
        gDebugPrint=0

    md_addr = 0x21
    md_ow_bit_loc = [3,2]
    reg_addr1 = 0x07


    #record current setting
    bp1_ori = rregBits(bp_addr, bp1_bit_loc, lane)
    bp1_en_ori = rregBits(bp_addr, bp1_en_bit_loc, lane)
    iters6_ori = rregBits (iter_s6_addr, iter_s6_bit_loc, lane)
    mu_ori = rregBits(ow_mu_offset_addr, ow_mu_offset_bit_loc, lane)
    # program registers for , b0, dir, pattern_p and pattern_n
    tap_list = []
    tap_index_list = ['f-2','f-1','f2','f3','f4','f5','f6','f7','f8','f9','f10','f11','f12','f13','f14','f15','f16','f17','f18','f19','f20']
    wregBits (reg_addr1, [2,0],   (b0<<1)  + dir, lane)
    wregBits (reg_addr1, [6,3],   8, lane)


    wregBits(bp_addr, bp1_bit_loc, 0x12, lane)
    wregBits(bp_addr, bp1_en_bit_loc, 1, lane)
    sm_cont(lane)

    wait_for_bp1_timeout=0
    while True:
        if rregBits(params(lane).sm_status_addr, params(lane).sm_status_bp1_bit_loc,lane):
            ma = rregBits(0x2e,[1,0],lane)
            if ma==0:
                break
            else:
                wregBits(bp_addr, bp1_en_bit_loc, 0, lane)
                sm_cont(lane)
                wregBits(bp_addr, bp1_en_bit_loc, 1, lane)
        else:
            wait_for_bp1_timeout+=1
            if wait_for_bp1_timeout>1000:
                if(gDebugTuning): log(" Get Tap Value >>>>> Timed out 1 waiting for BP1")
                break

    wregBits(md_addr, md_ow_bit_loc, 0x2,lane)
    wregBits (ow_mu_offset_addr, ow_mu_offset_bit_loc,   0, lane)
    wregBits (iter_s6_addr, iter_s6_bit_loc,   1, lane)
    wregBits(bp_addr, bp1_en_bit_loc, 0, lane)
    sm_cont(lane)


    for i in num:
        wregBits (pam4_tap_sel_addr, pam4_tap_sel_bit_loc, i, lane)
        time.sleep(0.2)
        wregBits(bp_addr, bp1_en_bit_loc, 1, lane)
        wait_for_bp1_timeout=0
        while True:
            if rregBits(params(lane).sm_status_addr, params(lane).sm_status_bp1_bit_loc,lane):
                break
            else:
                wait_for_bp1_timeout+=1
                if wait_for_bp1_timeout>1000:
                    if(gDebugTuning): log(" Get Tap Value >>>>> Timed out 2 waiting for BP1")
                    break


        # read back fixed pattern margins (plus margin and minus margin)reg_addr1 = 0x36
        reg_addr1 = 0x36
        reg_addr2 = 0x37
        plus = (rregBits(reg_addr1, [7,0], lane) <<4) +  rregBits(reg_addr2, [15,12], lane)
        minus = rregBits(reg_addr2, [11,0], lane)

        if (plus>2047): plus = plus - 4096
        if (minus>2047): minus = minus - 4096
        diff_margin = plus - minus
        diff_margin_f = ((float(diff_margin & 0x0fff)/2048)+1)%2-1
        if(gDebugTuning and gDebugEngineering): log_no_newline("\n%8d, %2d, %3d, %8d, %8d, %11d, %11.4f "  % (i, b0, dir, plus, minus, diff_margin, diff_margin_f))
        if abs(plus) == 2048 or abs(minus) == 2048: # saturated?
            diff_margin = 2222
        tap_list.append(diff_margin)

        wregBits(bp_addr, bp1_en_bit_loc, 0, lane)
        sm_cont(lane)

    wregBits(bp_addr, bp1_en_bit_loc, 1, lane)
    wait_for_bp1_timeout=0
    while True:
        if rregBits(params(lane).sm_status_addr, params(lane).sm_status_bp1_bit_loc,lane):
            break
        else:
            wait_for_bp1_timeout+=1
            if wait_for_bp1_timeout>1000:
                #if(gDebugTuning):
                log(" Get Tap Value >>>>> Timed out 3 waiting for BP1")
                break

    wregBits(md_addr, md_ow_bit_loc, 0x0,lane)
    wregBits (ow_mu_offset_addr, ow_mu_offset_bit_loc,   mu_ori, lane)
    wregBits (iter_s6_addr, iter_s6_bit_loc,  iters6_ori, lane)
    wregBits(bp_addr, bp1_en_bit_loc, 0, lane)
    #sm_cont(lane)
    #wregBits(bp_addr, bp1_bit_loc, bp1_ori, lane)
    #wregBits(bp_addr, bp1_en_bit_loc, bp1_en_ori, lane)
    sm_cont(lane)
    if gDebugPrint:
        log_no_newline("\n  Residual ISI Taps:\n\n|")
        for i in num:
            log_no_newline("%4s |"%tap_index_list[i])
        log_no_newline("\n|")
        for i in range(len(tap_list)):
            log_no_newline("%4s |"%tap_list[i])
        log("\n")
    else:
        return tap_list

####################################################################
#    channel_tap_analyzer(0xf,ctle_val,0,16,lane=lane)
def channel_tap_analyzer (ow_dac=0xf,ctle_val=7,gain_clear=1,ftap=16,lane=0):
    #define
    hf_cnt_owen_addr = 0x16
    hf_cnt_owen_bit_loc = [7]
    hf_cnt_ow_addr = 0x26
    sd_thre_addr = 0x3
    sd_owen_addr = 0x23
    sd_owen_bit_loc = [1]
    sd_ow_addr = 0x18
    sd_ow_bit_loc = [15]
    ow_dac_addr = 0x21
    ow_dac_bit_loc = [12,8]
    cnt_3_addr = 0x6f
    cnt_0_addr = 0x70
    cnt_hf_addr = 0x72
    lane_reset_addr=0x00
    lane_reset_bit_loc=[15]
    acal_start_addr = 0x1f
    acal_start_owen_bit_loc = [1]
    acal_start_ow_bit_loc = [0]
    acal_done_addr = 0x23
    acal_done_owen_bit_loc = [3]
    acal_done_ow_bit_loc = [2]
    ffe_pol_addr = 0xf0
    fast_rotater_addr = 0x22
    fast_rotater_bit_loc = [15,14]
    dir_bit_loc = [13,12]
    cth_gray_addr = 0x17
    cth_gray_bit_loc = [7,0]
    b1_addr = 0x18
    b1_bit_loc = [6,4]
    b_addr = 0x22
    b_bit_loc = [11,9]
    bn_bit_loc = [8,6]
    ths_owen_addr = 0x12
    ths_owen_bit_loc = [15]
    ths_ow_addr = 0x13
    ths_ow_bit_loc = [15,4]
    mcounter_addr = 0x31
    timer_addr = 0xa
    dac_timer_bit_loc = [9,5]
    dac_timer = 14
    ctle_timer_bit_loc = [4,0]
    ctle_timer = 14
    md_addr = 0x21
    md_ow_bit_loc = [3,2]
    mu_mg_ow_addr = 0x20
    mu_mg_ow_bit_loc = [15,13]
    post_dis_addr = 0x41
    post_dis_bit_loc = [14]

    global gF1over3Min  # <<<< ALEX
    #record current setting
    bp1_ori = rregBits(bp_addr, bp1_bit_loc,lane)
    bp1_en_ori = rregBits(bp_addr, bp1_en_bit_loc,lane)
    bp2_en_ori = rregBits(bp_addr, bp2_en_bit_loc,lane)
    ctle_map_ori = rregBits(params(lane).ctle_map0_addr, [5,0],lane)
    ctle_ori = rregBits(params(lane).ctle_val_addr, params(lane).ctle_val_bit_loc,lane)
    ts5_ori = rregBits(timer_s_addr, timer_s5_bit_loc,lane)
    iter4_ori = rregBits(iter_s4_addr, iter_s4_bit_loc,lane)
    ts1_ori = rregBits(timer_s1_addr, timer_s1_bit_loc,lane)
    ts3_ori = rregBits(timer_s3_addr, timer_s3_bit_loc,lane)
    mu_ori = rregBits(mu_mg_ow_addr, mu_mg_ow_bit_loc,lane)
    f1_ori = f1over3(lane=lane)
    #initial setting
    start_time=time.time()
    wregBits (pam4_tap_sel_addr, pam4_tap_sel_bit_loc, ftap,lane)
    wregBits(fast_rotater_addr, fast_rotater_bit_loc, 3,lane)
    wregBits(fast_rotater_addr, dir_bit_loc, 2,lane)
    wregBits(cth_gray_addr, cth_gray_bit_loc, 0x80,lane)

    wregBits(timer_s_addr, timer_s5_bit_loc, 0x9,lane)
    wregBits(timer_s1_addr, timer_s1_bit_loc, 0x1,lane)
    wregBits(timer_s3_addr, timer_s3_bit_loc, 0x1,lane)
    wregBits(iter_s4_addr, iter_s4_bit_loc, 0x1,lane)
    wregBits(mu_mg_ow_addr, mu_mg_ow_bit_loc, 0x4,lane)
    wregBits(timer_addr, dac_timer_bit_loc, 1,lane)
    wregBits(timer_addr, ctle_timer_bit_loc, 1,lane)
    wregLane(hf_cnt_ow_addr, 0x8000,lane)
    wregBits(hf_cnt_owen_addr, hf_cnt_owen_bit_loc, 1,lane)
    wregBits(ow_dac_addr, ow_dac_bit_loc, (0x10+ow_dac),lane)
    if (ctle_val==8):
        wregBits(params(lane).ctle_map0_addr,[5,0],0x3f,lane)
        ctle_val = 7
    wregBits(params(lane).ctle_val_addr, params(lane).ctle_val_bit_loc, ctle_val,lane)
    if(gDebugTuning): log_no_newline("\n\nChannel Tap Analyzer: DAC: %2d" % (rregBits(ow_dac_addr, ow_dac_bit_loc,lane)&0xF))
    if(gDebugTuning): log_no_newline("CTLE: %2d" % rregBits(params(lane).ctle_val_addr, params(lane).ctle_val_bit_loc,lane))

    if ftap<16:
        wregBits(md_addr, md_ow_bit_loc, 0x2,lane)
        wregBits(post_dis_addr, post_dis_bit_loc, 0x1,lane)
    else:
        f1over3(0,lane=lane)
        #f1over3(gF1over3Min)

    #main loop
    hfList = []
    for i in [0,1]:
        wregBits(b_addr, b_bit_loc, 0x7,lane)

        if i==1:
            wregBits(b1_addr, b1_bit_loc, 0x7,lane)
            wregBits(b_addr, bn_bit_loc, 0x6,lane)
        else:
            wregBits(b1_addr, b1_bit_loc, 0x4,lane) #FC: I think it should be 0x7, it used to be 0x4, Alex, can you take a try?
            wregBits(b_addr, bn_bit_loc, 0x5,lane)


        if gain_clear:
            #wregBits(ctle_gain1_addr, ctle_gain1_bit_loc, 0, lane)
            dc_gain(ctle_gain1=0,lane=lane)
        if(gDebugTuning):
            ctle_gain1_val, ffe_gain1_val, ctle_gain2_val, ffe_gain2_val = dc_gain(lane=lane)
            log_no_newline("\nChannel Tap Analyzer: CTLE_Gain1:%2d,FFE_Gain1:%2d,CTLE_Gain2:%2d,FFE_Gain2:%2d" % (ctle_gain1_val, ffe_gain1_val, ctle_gain2_val, ffe_gain2_val))
        #if(gDebugTuning):print "CTLE_Gain1: %2d" % rregBits(ctle_gain1_addr, ctle_gain1_bit_loc, lane),


        hf_thre = 0x1f
        final_cnt = 0
        final_hf = 0x0
        wregBits(sd_owen_addr, sd_owen_bit_loc, 1,lane)
        wregBits(sd_ow_addr, sd_ow_bit_loc, 1,lane)
        for t in range(1,9):
            wregBits(lane_reset_addr, lane_reset_bit_loc, 1,lane)
            wregBits(acal_start_addr, acal_start_owen_bit_loc, 1,lane)
            wregBits(acal_start_addr, acal_start_ow_bit_loc, 0,lane)
            wregBits(acal_done_addr, acal_done_owen_bit_loc, 1,lane)
            wregBits(acal_done_addr, acal_done_ow_bit_loc, 0,lane)
            wregBits(bp_addr, bp1_en_bit_loc, 0,lane)
            wregBits(bp_addr, bp2_en_bit_loc, 0,lane)
            wregBits(bp_addr, bp1_bit_loc, 0x11,lane)
            sm_cont(lane)
            wregBits(bp_addr, bp1_en_bit_loc, 1,lane)
            wregBits(lane_reset_addr, lane_reset_bit_loc, 0,lane)
            wregBits(timer_s1_addr, th_ini_bit_loc, hf_thre,lane)
            wregBits(acal_done_addr, acal_done_owen_bit_loc, 0,lane)
            wregBits(acal_start_addr, acal_start_owen_bit_loc, 0,lane)
            wait_for_bp1_timeout=0
            while True:
                bp1=rregBits(params(lane).sm_status_addr, params(lane).sm_status_bp1_bit_loc,lane)
                if bp1:
                        #print hex(rregBits(pam4_dfe_read_addr, pam4_dfe_read_bit_loc, lane))
                    step =  (t<7) and (0x40>>(t+1)) or 1

                    if rregLane(mcounter_addr,lane)>0x10:
                        #if(gDebugTuning):print ("\n Channel Tap Analyzer: Hit: hf_thre: %2d, st: %2d, cnt_hf: %2d" % (hf_thre, rregBits(sm_addr, sm_bit_loc, lane), rregLane(mcounter_addr, lane)))
                        final_hf = hf_thre
                        if hf_thre<0x3f:
                            final_cnt = rregLane(mcounter_addr,lane)
                            hf_thre =min(hf_thre+step, 0x3f)
                    else:
                        #if(gDebugTuning):print ("\n Channel Tap Analyzer:Miss: hf_thre: %2d, st: %2d, cnt_hf: %2d" % (hf_thre, rregBits(sm_addr, sm_bit_loc, lane), rregLane(mcounter_addr, lane)))
                        hf_thre = hf_thre - step
                    break
                else:
                    wait_for_bp1_timeout+=1
                    if wait_for_bp1_timeout>1000:
                        if(gDebugTuning): log("\n Channel Tap Analyzer: >>>>> Timed out waiting for BP1")
                        break

        hfList.append(final_hf)
    f0 = (hfList[1]+hfList[0])/2
    f1 = (hfList[1]-hfList[0])/3
    if f0 ==0:
        f0=0.0000001
    tap_value = int(round(f1*50/f0))
    if(gDebugTuning): log_no_newline("\nChannel Tap Analyzer: f1/f0: %1.3f/%1.3f = %2.3f,  tap iter1: %2d,  tap iter0: %2d" % (f1,f0,tap_value, hfList[1], hfList[0]))
    if(gDebugTuning): log_no_newline("\nChannel Tap Analyzer: f1o3 Tap: %2.0f" % tap_value)



    f1over3(f1_ori,lane=lane)
    wregBits(post_dis_addr, post_dis_bit_loc, 0x0,lane)
    wregBits(md_addr, md_ow_bit_loc, 0x0,lane)
    wregBits(sd_owen_addr, sd_owen_bit_loc, 0,lane)
    wregBits(fast_rotater_addr, fast_rotater_bit_loc, 0,lane)
    wregBits(fast_rotater_addr, dir_bit_loc, 0,lane)
    wregBits(cth_gray_addr, cth_gray_bit_loc, 0x0,lane)
    wregBits(ths_owen_addr, ths_owen_bit_loc, 0,lane)
    wregBits(b1_addr, b1_bit_loc, 0,lane)
    wregBits(b_addr, b_bit_loc, 0,lane)
    wregBits(b_addr, bn_bit_loc, 0,lane)
    wregBits(hf_cnt_owen_addr, hf_cnt_owen_bit_loc, 0,lane)
    #wregBits(params(lane).ctle_val_addr, params(lane).ctle_val_bit_loc, ctle_ori)
    wregBits(timer_s_addr, timer_s5_bit_loc, ts5_ori,lane)
    wregBits(timer_s1_addr, timer_s1_bit_loc, ts1_ori,lane)
    wregBits(timer_s3_addr, timer_s3_bit_loc, ts3_ori,lane)
    wregBits(mu_mg_ow_addr, mu_mg_ow_bit_loc, mu_ori,lane)
    wregBits(params(lane).ctle_map0_addr,[5,0],ctle_map_ori,lane)
    wregBits(ow_dac_addr, ow_dac_bit_loc, 0,lane)
    wregBits(timer_addr, dac_timer_bit_loc, 10,lane)
    wregBits(timer_addr, ctle_timer_bit_loc, 10,lane)
    wregBits(iter_s4_addr, iter_s4_bit_loc, iter4_ori,lane)
    wregBits(bp_addr, bp1_en_bit_loc, 0,lane)
    wregBits(bp_addr, bp2_en_bit_loc, 0,lane)
    wregBits(bp_addr, bp1_bit_loc, bp1_ori,lane)
    wregBits(bp_addr, bp1_en_bit_loc, bp1_en_ori,lane)
    wregBits(bp_addr, bp2_en_bit_loc, bp2_en_ori,lane)
    sm_cont(lane)
    if(gDebugTuning): log('\nChannel Tap Analyzer: OptTime: %2.2f, '%(time.time()-start_time))

    return tap_value

####################################################################
def ffe_fine_search(iter=20,lane=0): # 2017-05-09
    start_time = time.time()
    tap_range = compat_listrange(2,6)
    tap_value = [0]*len(tap_range)

    for i in range(iter):
        tap_list = Gettapvalue_full (1, 0, tap_range,lane=lane)
        tap_value = compat_listmap(lambda x,y:x+(y/iter), tap_value, tap_list)
        #if(gDebugTuning):print('\nFFE Fine Search:'),
        #if(gDebugTuning):print(["%6.1f"%x for x in tap_list]),
    if(gDebugTuning): log_no_newline('\nFFE Fine Search:')
    if(gDebugTuning): log_no_newline(["%6.1f"%x for x in tap_value])
    k31_pol = rregBits(ffe_pol_addr,ffe_po11_bit_loc,lane)
    k21_pol = rregBits(ffe_pol_addr,ffe_po12_bit_loc,lane)
    k11_pol = rregBits(ffe_pol_addr,ffe_po13_bit_loc,lane)
    k12_pol = rregBits(ffe_pol_addr,ffe_po14_bit_loc,lane)
    k31_step = 30
    k21_step = 20
    k11_step = 20
    k12_step = 20
    k21_k31_step = 0
    ffe_tap4_main1 = Gray_Bin(rregBits(ffe_tap4_addr, [7,4],lane))
    ffe_tap4_main0 = Gray_Bin(rregBits(ffe_tap4_addr, [3,0],lane))
    step_old = ((ffe_tap4_main1 << 4) + ffe_tap4_main0)&0xFF
    step = int(abs(tap_value[3])/(k12_step*2))
    if k12_pol==0:
        if tap_value[3]<-k12_step:
            if (step*17+step_old)<0xff: step_new = step*17+step_old
            else: step_new = 0xff
            #wregBits(ffe_tap4_addr, ffe_tap4_bit_loc, step_new, lane)
            ffe_taps(ffe_tap4 = step_new,lane=lane)
            if(gDebugTuning): log_no_newline('\nFFE Fine Search: tap4 Pol:%d, val:%4d, Step:%02X' %(k12_pol,tap_value[3],step_new))
        elif tap_value[3]>k12_step:
            if step_old>step*17: step_new = step_old-step*17
            else: step_new = step_old
            #wregBits(ffe_tap4_addr, ffe_tap4_bit_loc, step_new, lane)
            ffe_taps(ffe_tap4 = step_new,lane=lane)
            if(gDebugTuning): log_no_newline('\nFFE Fine Search: tap4 Pol:%d, val:%4d, Step:%02X' %(k12_pol,tap_value[3],step_new))
    else:
        if tap_value[3]>k12_step:
            if (step*17+step_old)<0xff: step_new = step*17+step_old
            else: step_new = 0xff
            #wregBits(ffe_tap4_addr, ffe_tap4_bit_loc, step_new, lane)
            ffe_taps(ffe_tap4 = step_new,lane=lane)
            if(gDebugTuning): log_no_newline('\nFFE Fine Search: tap4 Pol:%d, val:%4d, Step:%02X' %(k12_pol,tap_value[3],step_new))
        elif tap_value[3]<-k12_step:
            if step_old>step*17: step_new = step_old-step*17
            else: step_new = step_old
            #wregBits(ffe_tap4_addr, ffe_tap4_bit_loc, step_new, lane)
            ffe_taps(ffe_tap4 = step_new,lane=lane)
            if(gDebugTuning): log_no_newline('\nFFE Fine Search: tap4 Pol:%d, val:%4d, Step:%02X' %(k12_pol,tap_value[3],step_new))

    ffe_tap3_main1 = Gray_Bin(rregBits(ffe_tap3_addr, [15,12],lane))
    ffe_tap3_main0 = Gray_Bin(rregBits(ffe_tap3_addr, [11,8],lane))
    step_old = ((ffe_tap3_main1 << 4) + ffe_tap3_main0)&0xFF
    step = int(abs(tap_value[2])/(k11_step*2))
    if k11_pol==0:
        if tap_value[2]<-k11_step:
            if (step*17+step_old)<0xff: step_new = step*17+step_old
            else: step_new = 0xff
            #wregBits(ffe_tap3_addr, ffe_tap3_bit_loc, step_new, lane)
            ffe_taps(ffe_tap3 = step_new,lane=lane)
            if(gDebugTuning): log_no_newline('\nFFE Fine Search: tap3 Pol:%d, val:%4d, Step:%02X' %(k11_pol,tap_value[2],step_new))
        elif tap_value[2]>k11_step:
            if step_old>step*17: step_new = step_old-step*17
            else: step_new = step_old
            #wregBits(ffe_tap3_addr, ffe_tap3_bit_loc, step_new, lane)
            ffe_taps(ffe_tap3 = step_new,lane=lane)
            if(gDebugTuning): log_no_newline('\nFFE Fine Search: tap3 Pol:%d, val:%4d, Step:%02X' %(k11_pol,tap_value[2],step_new))
    else:
        if tap_value[2]>k11_step:
            if (step*17+step_old)<0xff: step_new = step*17+step_old
            else: step_new = 0xff
            #wregBits(ffe_tap3_addr, ffe_tap3_bit_loc, step_new, lane)
            ffe_taps(ffe_tap3 = step_new,lane=lane)
            if(gDebugTuning): log_no_newline('\nFFE Fine Search: tap3 Pol:%d, val:%4d, Step:%02X' %(k11_pol,tap_value[2],step_new))
        elif tap_value[2]<-k11_step:
            if step_old>step*17: step_new = step_old-step*17
            else: step_new = step_old
            #wregBits(ffe_tap3_addr, ffe_tap3_bit_loc, step_new, lane)
            ffe_taps(ffe_tap3 = step_new,lane=lane)
            if(gDebugTuning): log_no_newline('\nFFE Fine Search: tap3 Pol:%d, val:%4d, Step:%02X' %(k11_pol,tap_value[2],step_new))

    ffe_tap2_main1 = Gray_Bin(rregBits(ffe_tap2_addr, [15,12],lane))
    ffe_tap2_main0 = Gray_Bin(rregBits(ffe_tap2_addr, [11,8],lane))
    step_old = ((ffe_tap2_main1 << 4) + ffe_tap2_main0)&0xFF
    step = int(abs(tap_value[1])/(k21_step*2))
    if k21_pol==0:
        if tap_value[1]<-k21_step:
            if (step*17+step_old)<0xff: step_new = step*17+step_old
            else: step_new = 0xff
            #wregBits(ffe_tap2_addr, ffe_tap2_bit_loc, step_new, lane)
            ffe_taps(ffe_tap2 = step_new,lane=lane)
            if(gDebugTuning): log_no_newline('\nFFE Fine Search: tap2 Pol:%d, val:%4d, Step:%02X' %(k21_pol,tap_value[1],step_new))
        elif tap_value[1]>k21_step:
            if step_old>step*17: step_new = step_old-step*17
            else: step_new = step_old
            #wregBits(ffe_tap2_addr, ffe_tap2_bit_loc, step_new, lane)
            ffe_taps(ffe_tap2 = step_new,lane=lane)
            if(gDebugTuning): log_no_newline('\nFFE Fine Search: tap2 Pol:%d, val:%4d, Step:%02X' %(k21_pol,tap_value[1],step_new))
    else:
        if tap_value[1]>k21_step:
            if (step*17+step_old)<0xff: step_new = step*17+step_old
            else: step_new = 0xff
            #wregBits(ffe_tap2_addr, ffe_tap2_bit_loc, step_new, lane)
            ffe_taps(ffe_tap2 = step_new,lane=lane)
            if(gDebugTuning): log_no_newline('\nFFE Fine Search: tap2 Pol:%d, val:%4d, Step:%02X' %(k21_pol,tap_value[1],step_new))
        elif tap_value[1]<-k21_step:
            if step_old>step*17: step_new = step_old-step*17
            else: step_new = step_old
            #wregBits(ffe_tap2_addr, ffe_tap2_bit_loc, step_new, lane)
            ffe_taps(ffe_tap2 = step_new,lane=lane)
            if(gDebugTuning): log_no_newline('\nFFE Fine Search: tap2 Pol:%d, val:%4d, Step:%02X' %(k21_pol,tap_value[1],step_new))

    ffe_tap1_main1 = Gray_Bin(rregBits(ffe_tap1_addr, [15,12],lane))
    ffe_tap1_main0 = Gray_Bin(rregBits(ffe_tap1_addr, [11,8],lane))
    step_old = ((ffe_tap1_main1 << 4) + ffe_tap1_main0)&0xFF
    step = int(abs(tap_value[0])/(k31_step*2))
    if k31_pol==0:
        if tap_value[0]<-k31_step:
            if (step*17+step_old)<0xff: step_new = step*17+step_old
            else: step_new = 0xff
            #wregBits(ffe_tap1_addr, ffe_tap1_bit_loc, step_new, lane)
            ffe_taps(ffe_tap1 = step_new,lane=lane)
            if(gDebugTuning): log_no_newline('\nFFE Fine Search: tap1 Pol:%d, val:%4d, Step:%02X' %(k31_pol,tap_value[0],step_new))
        elif tap_value[0]>k31_step:
            if step_old>step*17: step_new = step_old-step*17
            else: step_new = step_old
            #wregBits(ffe_tap1_addr, ffe_tap1_bit_loc, step_new, lane)
            ffe_taps(ffe_tap1 = step_new,lane=lane)
            if(gDebugTuning): log_no_newline('\nFFE Fine Search: tap1 Pol:%d, val:%4d, Step:%02X' %(k31_pol,tap_value[0],step_new))
    else:
        if tap_value[0]>k31_step:
            if (step*17+step_old)<0xff: step_new = step*17+step_old
            else: step_new = 0xff
            #wregBits(ffe_tap1_addr, ffe_tap1_bit_loc, step_new, lane)
            ffe_taps(ffe_tap1 = step_new,lane=lane)
            if(gDebugTuning): log_no_newline('\nFFE Fine Search: tap1 Pol:%d, val:%4d, Step:%02X' %(k31_pol,tap_value[0],step_new))
        elif tap_value[0]<-k31_step:
            if step_old>step*17: step_new = step_old-step*17
            else: step_new = step_old
            #wregBits(ffe_tap1_addr, ffe_tap1_bit_loc, step_new, lane)
            ffe_taps(ffe_tap1 = step_new,lane=lane)
            if(gDebugTuning): log_no_newline('\nFFE Fine Search: tap1 Pol:%d, val:%4d, Step:%02X' %(k31_pol,tap_value[0],step_new))

    [ffe_tap1_bin,ffe_tap234,ffe_tap2_bin,ffe_tap34,ffe_tap3_bin,ffe_tap4_bin] = ffe_taps(lane=lane)
    if(gDebugTuning): log("\nFFE Fine Search: Taps:(%02X,%02X,%02X,%02X,%02X,%02X)" %(ffe_tap1_bin,ffe_tap2_bin,ffe_tap3_bin,ffe_tap4_bin,ffe_tap34,ffe_tap234))

    #if(gDebugTuning):print ('\nFFE Fine Search: OptTime: %2.2f, '%(time.time()-start_time))

def Get_Ths_fw(lane=0):
    fw_dump_cmd(1, lane=lane)
    ths_list=[rregLane(0x9f00+i, lane=lane) for i in range(12)]
    ths_list=[x-0x10000 if x&0x8000 else x for x in ths_list]
    ths_list=[int(x/32) for x in ths_list]
    return ths_list

def PT_debug(mode, index, lane=0):
    cmd = fw_debug_cmd + ((mode&0xf)<<4)
    result = fw_cmd(cmd, detail=index, expected_response=0xb, lane=lane)
    return rregLane(fw_cmd_detail_addr, lane=lane)

def PT_debugs(mode, index, lane=0):
    return [PT_debug(mode, i, lane=lane) for i in index]

def PT_debugs_signed(mode, index, lane=0):
    return [PT_debug_signed(mode, i, lane=lane) for i in index]

def PT_debug1(mode, index, length, lane=0):
    return PT_debugs(mode, compat_listrange(index, index+length), lane=lane)

def PT_debug1_signed(mode, index, length, lane=0):
    return PT_debugs_signed(mode, compat_listrange(index, index+length), lane=lane)

def PT_debug2(mode, index, l1, l2, lane=0):
    return [PT_debugs(mode, compat_listrange(index+i*l2, index+(i+1)*l2), lane=lane)
        for i in range(l1)]

def PT_debug2_signed(mode, index, l1, l2, lane=0):
    return [PT_debugs_signed(mode, compat_listrange(index+i*l2, index+(i+1)*l2), lane=lane)
        for i in range(l1)]

def PT_debug32(mode, index, lane=0):
    h = PT_debug(mode, index, lane=lane)
    l = PT_debug(mode, index+1, lane=lane)
    return (h<<16)+l

def PT_debug_signed(mode, index, lane=0):
    value = PT_debug(mode, index, lane=lane)
    return value if value<0x8000 else value-0x10000

def PT_debug32_signed(mode, index, lane=0):
    value = PT_debug32(mode, index, lane=lane)
    return value if value<0x80000000 else value-0x100000000

def PD_transform(data, filter):
    if filter is None:
        return data
    if isinstance(data, list):
        return [PD_transform(x, filter) for x in data]
    return filter(data)
def PD(index, l1=None, l2=None, signed=False, sect=0, filter=None, lane=0):
    if l2 is not None:
        if signed:
            raw = PT_debug2_signed(sect, index, l1, l2, lane=lane)
        else:
            raw = PT_debug2(sect, index, l1, l2, lane=lane)
    elif l1 is not None:
        if signed:
            raw = PT_debug1_signed(sect, index, l1, lane=lane)
        else:
            raw = PT_debug1(sect, index, l1, lane=lane)
    else:
        if signed:
            raw = PT_debug_signed(sect, index, lane=lane)
        else:
            raw = PT_debug(sect, index, lane=lane)
    return PD_transform(raw, filter)

def PD32(index, signed=False, filter=None, lane=0):
    if signed:
        raw = PT_debug32_signed(sect, index, lane=lane)
    else:
        raw = PT_debug32(sect, index, lane=lane)
    return PD_transform(raw, filter)

def fec_init(lane=0,err_type=0,T=15,M=10,N=5440):
    lane = 0
    if get_mode(lane) != 'pam4':
        if T > 7: T = 7 # locks T to max 7 if in nrz mode


    FEC_BASE_ADDR = 0xf000
    wregLane(FEC_BASE_ADDR+0x00bf,0x6202, lane)
    #wregLane(FEC_BASE_ADDR+0x00df, rregLane(FEC_BASE_ADDR+0x00df, lane) | 0x0018, lane) #set PRBS mode:PRBS31
    wregBits(FEC_BASE_ADDR+0x00df, [4,3], 0x3, lane) #set PRBS mode:PRBS31
    #wregLane(FEC_BASE_ADDR+0x00f0, rregLane(FEC_BASE_ADDR+0x00f0, lane) & 0xFFF0 | M), lane)  #set M = 10
    wregBits(FEC_BASE_ADDR+0x00f0, [3,0], M, lane)  #set M = 10
    wregLane(FEC_BASE_ADDR+0x00ef, N, lane) #set N = 5440
    #wregLane(FEC_BASE_ADDR+0x00ee, rregLane(FEC_BASE_ADDR+0x00ee, lane) & 0xf007 | ((T<<7)+(T<<3)), lane) #set T = 2
    wregBits(FEC_BASE_ADDR+0x00ee, [11,3], (T<<4) + T, lane) #set T = 2
    fec_rst(lane)
    wregLane(FEC_BASE_ADDR+0x00ba, err_type, lane)#set TEO error type
    wregLane(FEC_BASE_ADDR+0x00bb, err_type, lane)#set TEI error type

def fec_rst(lane):
    wregLane(0xf0f1,11, lane)
    time.sleep(0.1)
    fec_analyzer_tei()
    fec_analyzer_teo()
    wregLane(0xf0f1,3, lane)


def fec_analyzer_tei():
    # pre-fec counter
    FEC_BASE_ADDR = 0xf000
    lane = 0

    #wregLane(FEC_BASE_ADDR+0x00fb,4,lane) #set reading data of TEi low 16 bit
    tei_l = rregLane(FEC_BASE_ADDR+0x00fb, lane)#read data
    #wregLane(FEC_BASE_ADDR+0x00fa,5,lane) #set reading data of TEi high 16 bit
    tei_h = rregLane(FEC_BASE_ADDR+0x00fa, lane)#read data
    tei = tei_h*65536+tei_l #combinate the data
    #print '\n....Lane %s: TEi counter: %d' %(lane_name_list[lane],tei),
    return tei

def fec_analyzer_teo():
    #post-fec counter
    FEC_BASE_ADDR = 0xf000
    lane = 0
    #wregLane(FEC_BASE_ADDR+0x00f9,6,lane ) #set reading data of TEo low 16 bit
    teo_l = rregLane(FEC_BASE_ADDR+0x00f9, lane)#read data
    #wregLane(FEC_BASE_ADDR+0x00fa,7,lane) #set reading data of TEo high 16 bit
    teo_h = rregLane(FEC_BASE_ADDR+0x00f8, lane)#read data
    teo = teo_h*65536+teo_l#combinate the data
    #print '\n....Lane %s: TEo counter: %d' %(lane_name_list[lane],teo),
    return teo

def fec_analyzer(rst=0,lane=0):

    global gDataRate
    global fec_timer
    last_lane = rregBits(0xf0f0,[5,4])
    if last_lane != lane:
        rst=1
        wregBits(0xf0f0,[5,4],lane)

    if rst ==1 or fec_timer=='dis':
        fec_init()
        fec_timer = time.time()
        time.sleep(0.5)

    current_time = time.time() - fec_timer

    postfecprbs_error_cnt = fec_analyzer_teo()
    prefecprbs_error_cnt = fec_analyzer_tei()

    postfec_ber_val=float(postfecprbs_error_cnt)/(current_time*gDataRate[lane]*pow(10,9))
    postfec_log_ber=math.log10(float(postfec_ber_val)+1.0e-20)

    prefec_ber_val=float(prefecprbs_error_cnt)/(current_time*gDataRate[lane]*pow(10,9))
    prefec_log_ber=math.log10(float(prefec_ber_val)+1.0e-20)


    return prefecprbs_error_cnt, postfecprbs_error_cnt, prefec_ber_val, postfec_ber_val
    #return (duration,prefecprbs_error_cnt,prefec_ber_val ,prefec_log_ber,postfecprbs_error_cnt, postfec_ber_val, postfec_log_ber)

def rx_monitor_capture(lane=0,rst=0):
    global gMrMode
    gMrMode = 'dis'

    global rx_mon_time_keeper
    global rx_mon_time_elapsed
    global rx_mon_status
    global rx_mon_eye0
    global rx_mon_eye1
    global rx_mon_eye2
    global rx_mon_daq
    global rx_mon_prbs_cnt
    global rx_mon_prbs_ber
    global rx_mon_prefec_cnt
    global rx_mon_prefec_ber
    global rx_mon_postfec_cnt
    global rx_mon_postfec_ber

    if rst == 1 :
        rx_mon_time_keeper[lane] = time.time()
        prbs_rst(lane)
        #select_lane(lane=lane)
        time.sleep(0.5)
    if get_mode(lane) == 'pam4':
        rx_mon_eye0[lane],rx_mon_eye1[lane],rx_mon_eye2[lane], rx_mon_daq[lane] = get_eye3(lane)
    else:
        rx_mon_eye0[lane], rx_mon_daq[lane] = get_eye(lane)
        rx_mon_eye1[lane] = -1
        rx_mon_eye2[lane] = -1

    prbs_error_cnt, lane_status = get_prbs_cnt(lane)
    if lane_status == 0: lane_status = 'RDY'
    else: lane_status = 'OFF'


    prbs_accum_time = time.time() - rx_mon_time_keeper[lane]
    ber_val=float(prbs_error_cnt)/(prbs_accum_time*gDataRate[lane]*pow(10,9))
    if get_mode(lane) == 'pam4':
        rx_mon_prefec_cnt[lane],rx_mon_postfec_cnt[lane],rx_mon_prefec_ber[lane],rx_mon_postfec_ber[lane] =fec_analyzer(rst=rst,lane=lane)
    else:
        rx_mon_prefec_cnt[lane] = '-'
        rx_mon_postfec_cnt[lane] = '-'
        rx_mon_prefec_ber[lane] = '-'
        rx_mon_postfec_ber[lane] = '-'


    rx_mon_status[lane] = lane_status
    rx_mon_time_elapsed[lane] = prbs_accum_time
    rx_mon_prbs_cnt[lane] = prbs_error_cnt
    rx_mon_prbs_ber[lane] = ber_val

def rx_monitor_print(lane=0):
    log('--'*12)
    log('Lane:            %s'%lane)
    log('Encoding         %s'%gPam4NrzMode[lane])
    log('Data Rate(Gpbs)  %s'%gDataRate[lane])
    log('--'*12)
    log('Status:          %s'%rx_mon_status[lane])
    log('Eye0:            %.0f'%rx_mon_eye0[lane])
    if gPam4NrzMode[lane] == 'pam4':
        log('Eye1:            %.0f'%rx_mon_eye1[lane])
        log('Eye2:            %.0f'%rx_mon_eye2[lane])
    log('DAQ:             %.0f'%rx_mon_eye0[lane])
    log('--'*12)
    log('Time:            %.1f'%rx_mon_time_elapsed[lane])
    log('Prbs Cnt:        %s'%rx_mon_prbs_cnt[lane])
    log('Prbs BER:        %.1e'%rx_mon_prbs_ber[lane])
    if gPam4NrzMode[lane] == 'pam4':
        log('--'*12)
        log('PreFEC Cnt:      %s'%rx_mon_prefec_cnt[lane])
        log('PostFEC Cnt:     %s'%rx_mon_postfec_cnt[lane])
        log('PreFEC BER:      %.1e'%rx_mon_prefec_ber[lane])
        log('PostFEC BER:     %.1e'%rx_mon_postfec_ber[lane])
    log('--'*12)

def rx_monitor(lane=0,rst=0):
    rx_monitor_capture(lane=lane,rst=rst)
    rx_monitor_print(lane=lane)

reg_fw_data0=0x9f00

def dump_isi(lane=0):
   isi=[None]*16
   fw_dump_cmd(0, lane=lane)
   for i in range(16):
       isi[i]=fw_read_s16(i,lane=lane)
   return isi

def dump_nrz_isi(lane=0):
   isi=[None]*16
   fw_dump_nrz_cmd(0, lane=lane)
   for i in range(16):
       isi[i]=fw_read_s16(i,lane=lane)
   return isi

def dump_ths(lane=0):
   ths=[None]*12
   fw_dump_cmd(1, lane=lane)
   for i in range(12):
       ths[i]=fw_read_s16(i,lane=lane)/32
   return ths

def dump_ffe(lane=0):
    fw_dump_cmd(3, lane=lane)
    ths = [fw_read_s16(i, lane=lane) for i in range(6)]
    return ths

def dump_ffe_wt(lane=0):
    weight_table=[None]*28
    weight_table_debug=[None]*28
    fw_dump_cmd(8, lane=lane)
    for i in range(14):
       weight_table[i]= fw_read_s16(i, lane=lane)/8
    fw_dump_cmd(9, lane=lane)
    for i in range(14):
       weight_table[i+14]= fw_read_s16(i, lane=lane)/8
    log(" ****************")
    log(" * WEIGHT TABLE *")
    log(" ****************")
    for i in range(4):
       log(" ROW%d   : [%+07.2f] [%+07.2f] [%+07.2f] [%+07.2f] [%+07.2f] [%+07.2f] [%+07.2f]" % (i,weight_table[i*7], weight_table[i*7+1], weight_table[i*7+2],
        weight_table[i*7+3], weight_table[i*7+4], weight_table[i*7+5], weight_table[i*7+6]))

def dump_eye(lane=0):
    eye=[None]*3
    fw_dump_cmd(4, lane=lane)
    for i in range(3):
        eye[i]=fw_read_s16(i,lane=lane)
    return eye

def dump_nrz_eye(lane=0):
    fw_dump_nrz_cmd(4, lane=lane)
    return fw_read_s16(0, lane=lane)

def fw_dump_cmd(x, lane=0):
    PT_debug(0xA, index=x, lane=lane)

def fw_dump_nrz_cmd(x, lane=0):
    PT_debug(0x9, index=x, lane=lane)

def dump_exit_code(lane=0):
    PT_debug(0x8, index=100, lane=lane)
    codes = []
    for i in range(16):
        codes.append(rregLane(reg_fw_data0+i, lane=lane))
    log("Exit codes (starts from earliest):")
    for c in codes:
        log("  0x%04x" % c)

def fw_read_s32(offset,lane=0):
    t = fw_read_u32(offset,lane=lane)
    t = t - 0x100000000 if t&0x80000000 else t
    return t

def fw_read_s16(offset,lane=0):
    t = rregLane(reg_fw_data0+offset,lane=lane)
    t = t - 0x10000 if t&0x8000 else t
    return t

def fw_read_u32(offset,lane=0):
    t = (rregLane(reg_fw_data0+offset,lane=lane)<<16) | rregLane(reg_fw_data0+offset+1,lane=lane)
    return t

# All the external connection that is not firmware-related
def config_connection(params, lane):
    if params.rx_input == 'dc':
        wregBits(0xF7, [12], 0, lane)
    else:
        wregBits(0xF7, [12], 1, lane)
    pol(params.pol_tx, params.pol_rx, lane=lane)
    msblsb(params.msblsb_tx, params.msblsb_rx, lane=lane)
    gc(params.gc_tx, params.gc_rx, lane=lane)
    pc(params.pc_tx, params.pc_rx, lane=lane)
    prbs=params.prbs_pattern.upper()
    if prbs == "PRBS9":
        set_prbs_type (pat='PRBS9', lane=lane)
    elif prbs == "PRBS13" or prbs == "PRBS23":
        set_prbs_type (pat='PRBS13', lane=lane)
    elif prbs== "PRBS15":
        set_prbs_type (pat='PRBS15', lane=lane)
    else:
        set_prbs_type (pat='PRBS31', lane=lane)

def config_pam4_tx(tx_idx=None, lane=0):
    if tx_idx is None:
        tx_pre2,tx_pre1,tx_main,tx_post1,tx_post2 = get_tx_taps(lane=lane)
        tap_scale = tx_taps_scale(lane=lane)
    wregLane(0xAF, 0xF83E, lane)
    wregLane(0xB0, 0, lane)
    wregLane(0xB0, 0x800, lane)
    wregLane(0xB0, 0, lane)
    wregLane(0xA0, 0xef00, lane)
    tx_taps_select(tx_idx, lane)

def config_nrz_tx(tx_idx=None, half_rate=False, lane=0):
    if tx_idx is None:
        tx_pre2,tx_pre1,tx_main,tx_post1,tx_post2 = get_tx_taps(lane=lane)
        tap_scale = tx_taps_scale(lane=lane)
    wregLane(0xAF, 0xF83E, lane)
    wregLane(0xB0, 0x4802, lane)
    wregBits(0xB0, [0], 1 if half_rate else 0,lane)
    wregBits(0xB0, [11], 0, lane)
    wregBits(0xB0, [11], 1, lane)
    wregLane(0xA0, 0xE300, lane)
    tx_taps_select(tx_idx, lane)

def config_pam4_fw_rx(optical_mode=False, lane=0):
    wregBits(0x980f, [12], 1, lane=lane)        # gain search
    wregBits(0x980f, [10], 1, lane=lane)        # supercal enable
    wregBits(0x980f, [11], 1, lane=lane)        # Gain tracking
    wregBits(0x980f, [9],  1, lane=lane)        # FFE background adaptation enable
    wregBits(0x980f, [8], int(optical_mode), lane=lane)   # Set optical mode
    # PRBS config
    wregLane(0x0043, 0x8cfa, lane=lane)
    wregLane(0x0044, 0x1035, lane=lane)
    wregLane(0x0045, 0x1008, lane=lane)
    #fw_reg(172, 70, lane=lane)

def config_nrz_fw_rx(optical_mode=False, lane=0):
    wregBits(0x980f, [11], 1, lane=lane)        # Gain tracking
    wregBits(0x980f, [8], int(optical_mode), lane=lane)   # Set optical mode

    wregBits(0x0161, [15, 10], 0x1d,lane=lane)

def optical_status(lane):
    return rregBits(0x980f, [8], lane=lane) == 1

def optical_set(enable, lane):
    wregBits(0x980f, [8], enable, lane=lane)

def los_holdoff_status(lane):
    if rregBits(0x980f, [13], lane=lane) == 0:
        return 'Off'
    if rregBits(0x9811, [5], lane=lane):
        return 'Armed'
    return 'Enabled'

def los_holdoff_set(enable, lane):
    wregBits(0x980f, [13], enable, lane=lane)

def fw_config_speed_pam4(params, fw_speed, LT=None, tx_idx=None, print_header = True, simulation = False, optical_mode = False, lane=0):
    # Clear go bit
    wregBits(fw_tuning_ctrl_addr, fw_tuning_ctrl_go_bit_loc, 0, lane=lane)

    wregBits(0x8440, [15], 0, lane=lane)     # Disables AN/LT lane swapping
    detail = fw_speed
    if LT:
        detail |= (1<<8)

    # Set LT option firmware register
    LT_option = get_fw_reg(0, section=4, lane=lane)
    if isinstance(LT, str) and LT == "prbs":
        LT_option |= (1<<0)
    else:
        LT_option &= ~(1<<0)
        if lane_swapping_en:
            LT_option |= (1<<3)
        else:
            LT_option &= ~(1<<3)
    set_fw_reg(0, LT_option, section=4, lane=lane)    # Set LT option firmware register

    config_pam4_tx(tx_idx, lane=lane)                       # This enables PRBS so we need to put this first
    if LT:
        wregBits(0xA0, [13], 0, lane=tx_lane)               # Send data
    config_pam4_fw_rx(optical_mode, lane=lane)                            # This clears polarity, so before connection
    config_connection(params, lane)                         # This enables Gray/precoding so we need to put this first
    # if LT:
        # tx_taps_scale([0.5, 0.5, 1, 0.5, 0.5], lane=lane)
        # msblsb(tx_msblsb=0, rx_msblsb=1,lane=lane)
    fw_cmd(0x80D0, detail=detail, expected_response=8, lane=lane)
    pll(params.data_rate, lane=lane)
    #YYY serdes_set_global_rates_from_pll(lane)
    # Set go bit
    wregBits(fw_tuning_ctrl_addr, fw_tuning_ctrl_go_bit_loc, 1, lane=lane)
    if simulation == False:
        return fw_show_tuning(print_header, lane=lane)
    else:
        return 1

def fw_config_speed_nrz(params, fw_speed, LT=None, tx_idx=None, half_rate=False, print_header = True, simulation = False, optical_mode = False, lane=0):
    # Clear go bit
    wregBits(fw_tuning_ctrl_addr, fw_tuning_ctrl_go_bit_loc, 0, lane=lane)
    #config_test_chip(lane=lane)
    wregBits(0x8440, [15], 0, lane=lane)                    # Disables AN/LT lane swapping
    detail = fw_speed
    if LT: detail |= (1<<8)
    if isinstance(LT, str) and LT == "prbs":
        LT_option = get_fw_reg(0, section=4, lane=lane)
        LT_option |= 1
        set_fw_reg(0, LT_option, section=4, lane=lane)

    config_nrz_tx(tx_idx, half_rate=half_rate, lane=lane)           # This enables PRBS so we need to put this first
    fw_cmd(0x80C0, detail=detail, expected_response=8, lane=lane)
    config_nrz_fw_rx(optical_mode=optical_mode, lane=lane)
    config_connection(lane)
    pll(gDataRate[lane], lane=lane)
    serdes_set_global_rates_from_pll(lane)
    # Set go bit
    wregBits(fw_tuning_ctrl_addr, fw_tuning_ctrl_go_bit_loc, 1, lane=lane)
    if simulation == False:
        return fw_show_tuning(print_header, lane=lane)
    else:
        return 1



def AN_dump_fw(lane=0):
    p1=pprint.PrettyPrinter(indent=4)
    pp=p1.pprint
    pd=functools.partial(PD, sect=3, lane=lane)
    pd32=functools.partial(PD32, sect=3, lane=lane)
    state = pd(0, filter=h4)
    arb_sm = pd(3)
    HCD_IEEE = pd(10)
    HCD_consort = pd(11)
    log("AN State =", state)
    log("Arbitration SM =", arb_sm)
    log("HCD IEEE = %04x" % HCD_IEEE)
    log("HCD consort = %04x" % HCD_consort)

def fw_deconfig(lane=0):
    fw_cmd(0x9000, expected_response=9, lane=lane)

def fw_lane_reset(lane=0):
    wregBits(0x980f, [0], 1, lane=lane)
    return fw_show_tuning(lane=lane)

def fw_show_tuning(print_header=True, show_param=True, lane=0):
    # print 'fw_show_tuning: lane %d,  mode %s' % (lane, get_mode(lane))
    global gChannelEstimate
    global gChannelOf
    global gChannelHf
    global gAdaptationCount
    start_time=time.time()
    # Monitor progress Status of FW Tuning
    timeout=1e2
    time.sleep(.05)
    while True:
        if gShowTuningSteps: log_no_newline(".")
        timeout-=1
        if(timeout==1): break
        regval = rregLane(fw_tuning_status_addr,lane)
        status = regval & 0x7

        if gShowTuningSteps:
            sys.stdout.write("(%d,%d,%d)" % (fw_tuning_counter(lane=lane), regval, fw_reset_counter(lane=lane)))
            sys.stdout.flush()
        #if ((status==0) and (status_last==3)) or (status==4):  # if 3, tuning is in final stages
        if (status==4):  # if 4, done
            break # FW Tuning ended, exit
        status_last = status
        time.sleep(0.5)

    stop_time=time.time()

    if rregBits(fw_tuning_status_addr, fw_tuning_status_done_link_not_rdy_bit_loc, lane):   # status = 8?
        if gShowTuningSteps: log("\n>>>> ERROR: FW Tuning failed\n")
    elif rregBits(fw_tuning_status_addr, fw_tuning_status_done_bit_loc,lane)==1:            # status = 4?
        if gShowTuningSteps: log("Done!")
    else:# (timeout<=2):
        if gShowTuningSteps: log("\n>>>> ERROR: FW Tuning Timed Out\n")


    gAdaptationTime=stop_time-start_time
    if gDebugTuning: log('\n%2.4fG FW Adaptation Time: %2.2f sec '%(gDataRate[lane], gAdaptationTime))
    if show_param:
        time.sleep(1)
        gPostAdaptationFullRegList = reg_capture(lane=lane)
        gChannelEstimate[lane] = fw_channel_estimate(lane=lane)
        gChannelOf[lane], gChannelHf[lane] = fw_channel_of_hf(lane)
        gAdaptationCount = fw_tuning_counter(lane=lane)
        return serdes_params(print_header,lane)
    else:
        return None

def h4(x):
    return "0x%04x" % x

def em_separator(lane):
    status = fw_cmd(fw_eyemon_read_cmd, detail=0x7fff, lane=lane)
    return [fw_read_s16(i, lane=lane) for i in range(5)]

def eye_regions(lane):
    if get_mode(lane) == 'pam4':
        separator = em_separator(lane)
        p1   = separator[0] + 62
        sep1 = separator[1] + 62
        p2   = separator[2] + 62
        sep2 = separator[3] + 62
        p3   = separator[4] + 62
        return [(0, p1), (p1, sep1), (sep1, p2), (p2, sep2), (sep2, p3), (p3, 125)]
    else:
        # NRZ, just the two halves
        return [(0, 47), (47,94)]

def serdes_check_custom_fw_loaded(lane, verbose=False):
    # Get hash code for the lane
    hash_code = fw_hash(lane)
    code_str = str(hex(hash_code))
    fw_crc_str = str(hex(fw_crc(lane)))
    if code_str in fw_hash_date_dict:
        return (code_str, fw_hash_date_dict.get(code_str), fw_crc_str)
    else:
        return None

def serdes_fw_load(fw_file_name, lane, verbose=False):
    global fw_hash_date_dict
    if not os.path.exists(fw_file_name):
        log("\n...Device %d FW LOAD ERROR: Error Opening FW File: %s\n" % (lane, fw_file_name))
        return

    fw_unload(lane=lane)
    log_no_newline("\n...Device %d Downloading FW: %s..." % (lane, fw_file_name))

    FW0 =0x9F00#+lane*0x2000 #0x9F00
    FW1 =0x980D#+lane*0x2000 #0x9802
    FW2 =0x9814#+lane*0x2000 #0x9805

    fw_file_ptr = open(fw_file_name, 'rb')
    fw_file_ptr.seek(0x1000)
    header = fw_file_ptr.read(20)
    hash_code, crc, date, entryPoint, length, ramAddr = struct.unpack(">IHHIII", header)
    d = datetime.date(1970, 1, 1) + datetime.timedelta(date)
    date_str = "%04d%02d%02d" % (d.year, d.month, d.day)
    fw_hash_date_dict.update({str(hex(hash_code)) : (date, date_str)})

    if verbose:
        log("")
        log("fw_load Hash Code : 0x%06x" % hash_code)
        log("fw_load Date Code : 0x%02x (%04d-%02d-%02d)" % (date, d.year, d.month, d.day))
        log("fw_load  CRC Code : 0x%04x" % crc)
        log("fw_load    Length : %d" % length)
        log("fw_load     Entry : 0x%08x" % entryPoint)
        log("fw_load       RAM : 0x%08x" % ramAddr)

    data = fw_file_ptr.read()
    dataPtr = 0
    sections = (length + 23) // 24

    wregLane(FW2, 0xFFF0, lane)
    wregLane(FW1, 0x0AAA, lane)
    wregLane(FW1, 0x0000, lane)

    start_time = time.time()
    checkTime = 0
    status = rregLane(FW2,lane)
    while status != 0:
        status = rregLane(FW2, lane)
        checkTime += 1
        if checkTime > 100000:
            log('\n...FW LOAD ERROR: : Wait for FW2=0 Timed Out! FW2 = 0x%X' % status)  # Wait for FW2=0: 0.000432 sec
            return
    stop_time = time.time()
    if verbose:
        log('\n Iterations: %d  Time:' % checkTime, stop_time - start_time)

    wregLane(FW2, 0x0000, lane)

    i = 0
    while i < sections:
        checkSum = 0x800c
        wregLane(FW0 + 12, ramAddr >> 16, lane)
        wregLane(FW0 + 13, (ramAddr & 0xFFFF), lane)
        checkSum += (ramAddr >> 16) + (ramAddr & 0xFFFF)
        for j in range(12):
            if (dataPtr >= length):
                mdioData = 0x0000
            else:
                mdioData = struct.unpack_from('>H', data[dataPtr:dataPtr + 2])[0]
            wregLane(FW0 + j, mdioData, lane)
            checkSum += mdioData
            dataPtr += 2
            ramAddr += 2

        wregLane(FW0 + 14, (~checkSum + 1) & 0xFFFF,lane)
        wregLane(FW0 + 15, 0x800C, lane)
        # print '\nfw_load: section %d, Checksum %X' % (i, checkSum),

        checkTime = 0
        print_en=1
        status = rregLane(FW0 + 15, lane)
        while status == 0x800c:
            status = rregLane(FW0 + 15, lane)
            checkTime += 1
            if checkTime > 50000:
                log_no_newline('\n...FW LOAD ERROR: Write to Ram Timed Out! FW0 = %x' % status)
                break

        if checkTime > 0:
            if print_en: log_no_newline('\nfw_load: section %d, CheckTime= %d' % (i, checkTime))

        if status != 0:
            log("...FW LOAD ERROR: Invalid Write to RAM, section %d" % i)
            return
        i += 1

    wregLane(FW0 + 12, entryPoint >> 16 ,lane)
    wregLane(FW0 + 13, (entryPoint & 0xFFFF),lane)
    checkSum = (entryPoint >> 16) + (entryPoint & 0xFFFF) + 0x4000
    wregLane(FW0 + 14, (~checkSum + 1) & 0xFFFF,lane)
    wregLane(FW0 + 15, 0x4000,lane)
    fw_file_ptr.close()
    log("Done!")
    time.sleep(.5)
    log("crc=%x" % fw_crc(lane))
    #fw_info()
    # pll_cap()
    fw_hash(lane)
    return 1


def serdes_fw_load14(fw_data, lane, verbose=False):
    fw_unload(lane=lane)

    FW0 =0x9F00
    FW1 =0x980D
    FW2 =0x9814

    fw_data = fw_data[0x1000:]  # discard the first 4KB
    header, fw_data = fw_data[:20], fw_data[20:]

    hash_code, crc, date, entryPoint, length, ramAddr = struct.unpack(">IHHIII", header)
    d = datetime.date(1970, 1, 1) + datetime.timedelta(date)

    if verbose:
        log("")
        log("fw_load Hash Code : 0x%06x" % hash_code)
        log("fw_load Date Code : 0x%02x (%04d-%02d-%02d)" % (date, d.year, d.month, d.day))
        log("fw_load  CRC Code : 0x%04x" % crc)
        log("fw_load    Length : %d" % length)
        log("fw_load     Entry : 0x%08x" % entryPoint)
        log("fw_load       RAM : 0x%08x" % ramAddr)

    sections = (length + 27) / 28

    wregLane(FW2, 0xFFF0, lane)
    wregLane(FW1, 0x0AAA, lane)
    wregLane(FW1, 0x0000, lane)

    start_time = time.time()
    checkTime = 0
    status = rregLane(FW2,lane)
    while status != 0:
        status = rregLane(FW2, lane)
        checkTime += 1
        if checkTime > 100000:
            log('FW LOAD ERROR: : Wait for FW2=0 Timed Out! FW2 = 0x%X' % status)  # Wait for FW2=0: 0.000432 sec
            return
    stop_time = time.time()
    if verbose:
        log('Iterations: %d  Time:' % checkTime, stop_time - start_time)

    wregLane(FW2, 0x0000, lane)

    for i in range((length + 27) // 28):
        if i & 0xff == 0:
            sys.stdout.write('.')
            sys.stdout.flush()
        checkSum = 0x100e
        hunk, fw_data = fw_data[:28], fw_data[28:]
        hunkWords = struct.unpack_from('>' + 'H'*14, hunk + ' '*28)

        for idx, w in enumerate(hunkWords):
            wregLane(FW0 + idx, w, lane)
            checkSum += w

        wregLane(FW0 + 14, (~checkSum + 1) & 0xFFFF,lane)
        wregLane(FW0 + 15, 0x100e, lane)  # control word:  write 14 bytes to FW RAM

        checkTime = 0
        print_en=1
        status = rregLane(FW0 + 15, lane)
        while status == 0x800c:
            status = rregLane(FW0 + 15, lane)
            checkTime += 1
            if checkTime > 500:
                log('...FW LOAD ERROR: Write to Ram Timed Out! FW0 = %x' % status)
                return

        if checkTime > 0:
            if print_en:
                log('fw_load: offset %d, CheckTime= %d' % (length-len(fw_data), checkTime))

        if status != 0:
            log("...FW LOAD ERROR: Invalid Write to RAM")
            return

    sys.stdout.write('\n')
    sys.stdout.flush()

    if print_en:
        log('Starting FW')

    wregLane(FW0 + 12, entryPoint >> 16 ,lane)
    wregLane(FW0 + 13, (entryPoint & 0xFFFF),lane)
    checkSum = (entryPoint >> 16) + (entryPoint & 0xFFFF) + 0x4000
    wregLane(FW0 + 14, (~checkSum + 1) & 0xFFFF,lane)
    wregLane(FW0 + 15, 0x4000,lane)
    log("Done!")
    time.sleep(.5)
    log("crc=%x" % fw_crc(lane))

    fw_hash(lane)
    return 1
