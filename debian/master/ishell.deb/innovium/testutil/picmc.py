#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2017
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

# Utility functions for loading/running code on PIC MCU
import threading
import time
import sys
import datetime
import struct

from testutil import pen
from testutil import bincopy
from utils.compat_util import *
from ifcs_ctypes import *

# mc_clint_space_addr_offset = 0x02000000
# mc_clic_space_addr_offset  = 0x02800000
# mc_tim0_space_addr_offset  = 0x80000000

TIM0_OFFSET = 0x80000000

num_ports = 8
num_lanes = 8
mbox_base = 0x80000300

port_cmd_base = mbox_base + 16
port_cmd_size = 4  # 4 bytes per cmd
port_cfg_base = port_cmd_base + num_ports * port_cmd_size
port_cfg_size = 16 # 16 bytes per config
port_state_base = port_cfg_base + num_ports * port_cfg_size
port_state_size = 1
port_error_base = port_state_base + num_ports * port_state_size
port_error_size = 1

mbox_len = (port_error_base + num_ports * port_error_size) - mbox_base

logdata_base = mbox_base + mbox_len
logdata_len = 0x300
lanedata_base = logdata_base + logdata_len
lanedata_context_len = 16
lanedata_numconfig = 32
lanedata_numoutput = 4
lanedata_config_len = lanedata_numconfig * 2
lanedata_out_len = lanedata_numoutput * 2
lanedata_each_len = lanedata_context_len + lanedata_config_len + lanedata_out_len
lanedata_len = 8 * lanedata_each_len

verbose = False
beVerbose = False

FW_CMD_RESET_PORTS = 2    # resets, then runs any outstanding port cmds
FW_CMD_UPDATE_PORTS = 3   # updates config, then runs any outstanding port cmds
FW_CMD_DO_PORT_CMDS = 4   # runs any outstanding port cmds

PORT_CMD_AN_LT = 1
PORT_CMD_AN_ONLY = 2
PORT_CMD_LT_ONLY = 3
PORT_CMD_DOWN = 4

def status_as_string(val):
    s = ['Not Started',
         'Init Start',
         'Init Done',
         'Running'
    ]
    if val < len(s):
        return s[val]
    if val == 0xf000ba7d:
        return 'Fault'
    return 'Invalid: %08x' % val

class HexContainer(object):
    def __str__(self):
        ret = type(self).__name__ + " [ "
        for k, v in self.__dict__.items():
            if type(v) == int:
                ret += "%s:%x " % (k, v)
            else:
                ret += "%s:%s " % (k, str(v))
        return ret + "]"

class LaneOpcode(HexContainer):
    pass

class LaneState(HexContainer):
    pass

class MboxState(HexContainer):
    pass

class PortConfig(HexContainer):
    def __repr__(self):
        ret = "[ "
        for k, v in self.__dict__.items():
            if type(v) == int:
                ret += "%s:%x " % (k, v)
            else:
                ret += "%s:%s " % (k, str(v))
        return ret + "]"
    def __str__(self):
        return "%s (%d lanes)" % (mode_list[self.lane_mode].name, self.num_lanes)

class PortMode(object):
    def __init__(self, name, modename=None):
        self.name = name
        if modename is None:
            modename = name
        # Pick apart the name (e.g. I100G_R2_KRFEC) to get speed and num of SERDES lanes
        m = re.match(r'I(?P<speed>\d*)G_R(?P<lanes>\d)_.*', modename)
        self.speed = int(m.group('speed'))
        self.lanes = int(m.group('lanes'))
    def __str__(self):
        return "%s (%G, %d lanes)" % (self.name, self.speed, self.lanes)

# See PIC PEN field pcs_fec_mux_f
mode_list = {
    0:  PortMode('DISABLED', 'I0G_R1_DISABLED'),
    1:  PortMode('I10G_R1_NOFEC'),
    2:  PortMode('I40G_R4_NOFEC'),
    3:  PortMode('I25G_R1_KRFEC'),
    4:  PortMode('I25G_R1_FCFEC'),
    5:  PortMode('I25G_R1_NOFEC'),
    6:  PortMode('I100G_R4_KRFEC'),
    7:  PortMode('I100G_R2_KRFEC'),
    8:  PortMode('I100G_R2_KPFEC'),
    9:  PortMode('I100G_R4_KPFEC'),
    12: PortMode('I100G_R4_NOFEC'),
    14: PortMode('I50G_R2_KRFEC'),
    15: PortMode('I50G_R1_KRFEC'),
    16: PortMode('I50G_R2_NOFEC'),
    17: PortMode('I50G_R2_FCFEC'),
    19: PortMode('I50G_R2_KPFEC'),
    20: PortMode('I50G_R1_KPFEC'),
    23: PortMode('I200G_R8_FPFEC'),
    29: PortMode('I400G_R8_FPFEC')
}

mode_to_idx = {}
for k,v in compat_iteritems(mode_list):
    mode_to_idx[v.name] = k

class LogEntry(object):
    def __init__(self, raw_bytes):
        entry_type = (raw_bytes[0] & 0xf0) >> 4
        if entry_type == 0:
            self.entry_type = 'Empty'
            self.idx = 0
        elif entry_type == 1:
            self.entry_type = 'Lane'
            (self.idx, self.action, self.pc_idx, self.apb_busy_count,
             self.run_state, self.stage, self.verify_try_count, self.debug_mem) = struct.unpack_from("<BBHHBBHH", buffer(raw_bytes))
            self.idx = self.idx & 0xf
        elif entry_type == 2:
            self.entry_type = 'Port'
            self.idx, action, empty1, data, empty2 = struct.unpack_from("<BBHII", buffer(raw_bytes))
            self.idx = self.idx & 0xf
            self.action = ['N/A', 'State', 'Config', 'Error'][action]
            if self.action == 'State':
                self.event = ['N/A', 'Reset', 'Cmd', 'Error', 'Lanes Done'][(data >> 16)]
                self.state = ['Down', 'AN', 'Training', 'Up'][data & 0xffff]
            elif self.action == 'Config':
                self.config = data
            elif self.action == 'Error':
                self.error_mask = data
        elif entry_type == 0xf:
            self.entry_type = 'Debug'
            rfu, self.val1, self.val2 = struct.unpack_from("<III", buffer(raw_bytes))
        elif entry_type == 0xe:
            self.entry_type = 'Trace'
            rfu, self.cmd, self.stage, rfu2, rfu3, self.debug = struct.unpack_from("<IBBBBI", buffer(raw_bytes))
        else:
            self.entry_type = 'Invalid'
            self.idx = 0
            self.raw = [("%02x" % b) for b in raw_bytes]

    def __repr__(self):
        if self.entry_type == 'Lane' or self.entry_type == 'Port':
            ret = "%s %d: " % (self.entry_type, self.idx)
        else:
            ret = '%s: ' % self.entry_type
        for k, v in self.__dict__.items():
            if k == 'entry_type' or k == 'idx':
                continue
            if type(v) == int:
                ret += "%s:%x " % (k, v)
            else:
                ret += "%s:%s " % (k, str(v))
        return ret

class picmc:
    def __init__(self, ib=0, pic=0):
        self.ib = ib
        self.pic = pic

    def set_resets(self, core, uncore):
        pen.write_pen(MC_RESET, 0, [(CORE_RESET_F, int(core)), (UNCORE_RESET_F, int(uncore))], ib=self.ib, pic=self.pic)

    def reset_full(self):
        self.set_resets(1, 1)

    def reset_coreonly(self):
        self.set_resets(1, 0)

    def go(self):
        self.set_resets(0, 0)

    def reset_status(self):
        fldlist = pen.read_pen(MC_RESET, 0, ib=self.ib, pic=self.pic)
        return (fldlist[0][1], fldlist[1][1])

    def write(self, addr, val):
        global verbose
        if verbose:
            log('Write %08x: %08x' % (addr, val))
        pen.write_pen(MC_TIM0, (addr - TIM0_OFFSET)/4, [(DATA_F, val)], ib=self.ib, pic=self.pic)

    def read(self, addr):
        fldlist = pen.read_pen(MC_TIM0, (addr - TIM0_OFFSET)/4, ib=self.ib, pic=self.pic)
        if fldlist[0][1] < 0:
            fldlist[0][1] += (1<<32)

        global verbose
        if verbose:
            log('Read %08x: %08x' % (addr, fldlist[0][1]))

        return fldlist[0][1]

    def write32(self, addr, datalist):
        for data in datalist:
            self.write(addr, data)
            addr += 4

    def write8(self, addr, data):
        while len(data) % 4 > 0:
            data.append(0)
        # little-endian packing into 32-bit words:
        b0 = [b << 0 for b in data[::4]]
        b1 = [b << 8 for b in data[1::4]]
        b2 = [b << 16 for b in data[2::4]]
        b3 = [b << 24 for b in data[3::4]]
        data32 = compat_listmap(sum, zip(b3, b2, b1, b0))

        self.write32(addr, data32)

    def read32(self, addr, count):
        out = []
        for i in range(count):
            out.append(self.read(addr + i * 4))
        return out

    def read_bytes(self, addr, count):
        out = bytearray()
        word = self.read(addr & 0xfffffffc)
        while (count):
            if ((addr & 0x3) == 0x00): out.append((word & 0x000000ff))
            if ((addr & 0x3) == 0x01): out.append((word & 0x0000ff00) >> 8)
            if ((addr & 0x3) == 0x02): out.append((word & 0x00ff0000) >> 16)
            if ((addr & 0x3) == 0x03): out.append((word & 0xff000000) >> 24)
            count -= 1
            addr += 1
            if (count > 0 and ((addr & 0x3) == 0)):
                word = self.read(addr)
        return out

    def load(self, filename):
        global verbose
        global beVerbose
        verbose = False
        binfile = bincopy.BinFile()
        if filename.lower().endswith('ihex'):
            binfile.add_ihex_file(filename)
        else:
            binfile.add_srec_file(filename)

        for seg_base, seg_top, seg_data in binfile.iter_segments():
            self.write8(seg_base, seg_data)
        verbose = beVerbose

    def read_mbox(self):
        mbox_hdr = struct.Struct("<IIBBBBI")
        port_cmd = struct.Struct("<IIIIIIII")
        single_port_cfg = struct.Struct("<BBHIII")
        port_state = struct.Struct("<BBBBBBBB")
        port_error = struct.Struct("<BBBBBBBB")

        mbox_buffer = buffer(self.read_bytes(mbox_base, mbox_len))
        curs = 0
        ret = MboxState()

        status_num, ret.cmd, ret.lane_steps, lane_log_mask, port_log_mask, ret.log_head_idx, rfu = mbox_hdr.unpack_from(mbox_buffer, curs)
        curs += mbox_hdr.size
        ret.status = status_as_string(status_num)

        ret.port_cmd = list(port_cmd.unpack_from(mbox_buffer, curs))
        curs += port_cmd.size

        ret.port_cfg = []
        for i in range(0, 8):
            cfg = PortConfig()
            cfg.num_lanes, cfg.lane_mode, cfg.link_fail_timer_period, cfg.serdes_ctrl, cfg.bp_lo, cfg.bp_hi = single_port_cfg.unpack_from(mbox_buffer, curs)
            curs += single_port_cfg.size
            ret.port_cfg.append(cfg)

        ret.port_state = list(port_state.unpack_from(mbox_buffer, curs))
        curs += port_state.size

        ret.port_error = list(port_error.unpack_from(mbox_buffer, curs))
        curs += port_error.size

        return ret

    def read_lanes(self):
        parsed_lanes = []
        lane_data = self.read32(lanedata_base, lanedata_len / 4)
        for i in range(0, num_lanes):
            this_lane = LaneState()
            this_lane.pc = 0x80000000 + (lane_data[0] >> 16)
            this_lane.startpc = 0x80000000 + (lane_data[0] & 0xffff)
            this_lane.apb_busy_count = lane_data[1] & 0xffff
            this_lane.run_state = (lane_data[1] >> 16) & 0xff
            this_lane.stage = (lane_data[1] >> 24)
            this_lane.verify_try_count = lane_data[2] & 0xffff
            this_lane.debug_mem = lane_data[2] >> 16
            this_lane.config = []
            for ci in range(0, lanedata_numconfig/2):
                this_lane.config.append(lane_data[4 + ci] & 0xffff)
                this_lane.config.append(lane_data[4 + ci] >> 16)

            if this_lane.pc == 0:
                this_lane.op = None
            else:
                this_lane.op = self.read_opcode(this_lane.pc)

            parsed_lanes = parsed_lanes + [this_lane]
            lane_data = lane_data[(lanedata_each_len/4):]
        return parsed_lanes

    def lane_config_set(self, laneidx, cfg):
        offset = lanedata_base + (laneidx * lanedata_each)/4
        self.write32(offset, cfg)

    def lane_config_get(self, laneidx):
        offset = lanedata_base + (laneidx * lanedata_each)/4
        cfgvals = self.read32(offset, lanedata_numconfig/2)
        out = []
        for c2 in cfgvals:
            out.append(c2 & 0xffff)
            out.append(c2 >> 16)
        return out

    # On the device, multi-lane ports occupy more than a single port index
    # this sets the mode for all port indices for the specified port,
    # but only the first has numlanes != 0
    def port_config_set(self, portidx, numlanes, mode, link_fail_timer_period, serdes_ctrl, bp):
        offset = port_cfg_base + portidx * port_cfg_size
        word0 = (mode << 8) + (link_fail_timer_period << 16)
        word1 = serdes_ctrl
        word2 = bp & 0xffffffff
        word3 = bp >> 32
        vals = [word0 + numlanes, word1, word2, word3]
        vals += (numlanes-1) * [word0, word1, word2, word3]
        self.write32(offset, vals)

    # returns tuple: (is_primary, mode), where is_primary is only True for the first index of the port
    def port_config_get(self, portidx):
        offset = port_cfg_base + portidx * port_cfg_size
        cfg = self.read32(offset, 1)[0]
        mode = (cfg >> 8)
        is_primary = ((cfg & 0xff) != 0)
        return (is_primary, mode)

    def port_cmd(self, portidx, cmd):
        offset = port_cmd_base + portidx * port_cmd_size
        self.write32(offset, [cmd])

        #picmc write 0x330 0x01 0x01 0x01 0x01 0x01 0x01 0x01 0x01
        #picmc write 0x310 0x01
        #picmc write 0x304 2

    def fw_cmd(self, cmd):
        cmd_offset = mbox_base + 4
        log('Writing %08x to %08x' % (cmd, cmd_offset))
        self.write32(cmd_offset, [cmd])

    def read_log(self):
        log = []
        log_data = self.read_bytes(logdata_base, logdata_len)
        # step through, 12 bytes (one entry) at a time
        for i in range(0, logdata_len, 12):
            entry = LogEntry(log_data[i:i+12])
            if entry.entry_type != 'Empty':
                log.append(entry)
        last_idx = self.read_mbox().log_head_idx
        return log[:last_idx] + log[last_idx:]

    def log_mask_set(self, ports, lanes):
        portmask, lanemask = (0,0)
        for p in ports:
            portmask |= (1<<p)
        for ln in lanes:
            lanemask |= (1<<ln)
        mbox_val = self.read32(mbox_base + 8, 1)[0]
        mbox_val &= 0xff0000ff
        mbox_val |= (portmask << 16) | (lanemask << 8)
        self.write32(mbox_base + 8, [mbox_val])

    def log_mask_get(self):
        mbox_val = self.read32(mbox_base + 8, 1)[0]
        ports, lanes = ([], [])
        for i in range(0, 8):
            if (mbox_val & (1 << (8+i))):
                lanes += [i]
            if (mbox_val & (1 << (16+i))):
                ports += [i]
        return (ports, lanes)

    def read_opcode(self, addr):
        values = self.read32(addr, 2)
        ret = LaneOpcode()
        cmd = (values[0] >> 24)
        ret.count = ((values[0] & 0x00ff0000) >> 16)
        ret.addr = values[0] & 0xffff
        ret.value = values[1] >> 16
        ret.mask = values[1] & 0xffff
        if cmd == 0:
            ret.cmd = 'Read'
        elif cmd == 1:
            if ret.mask == 0xffff:
                ret.cmd = 'Write'
            else:
                ret.cmd = 'RMW'
        elif cmd == 2:
            ret.cmd = 'Done'
        else:
            ret.cmd = 'Invalid'
        return ret

    def read_fault(self):
        fault_base = 0x80000224
        fault_len = 36
        cause_str = ['Instruction address misaligned', 'Instruction access fault', 'Illegal instruction',
                     'Breakpoint', 'Load address misaligned', 'Load access fault',
                     'Store (or atomic op) address misaligned', 'Store (or atomic op) access fault',
                     'Env call from U-mode', 'Env call from S-mode',
                     'Env call from H-mode', 'Env call from M-mode']

        ret = lambda: None    # something that we can add attributes/fields to
        fault_data = self.read32(fault_base, fault_len)
        ret.reg = [0] + fault_data[:31]
        ret.status = fault_data[31]
        ret.cause = cause_str[fault_data[32]]
        ret.badaddr = fault_data[33]
        ret.epc = fault_data[34]
        marker = fault_data[35]
        if marker != 0xfeedf00d:
            log('Invalid Fault Data')
            # could fault or return Null, but we'll assume the caller knows what they're doing

        return ret
