#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

from ifcs_ctypes import *

import struct

# HOST_PORT = 33
HOST_PORT = 65

def get_dtm_discard_count():
    drop_count = 0

    return drop_count

def ldh_vf2(ib, ib_port, queue):
    dlp = (ib << 6) | ib_port
    return struct.pack("!6BLH", 1 << 1, 2,
                dlp >> 6, (dlp & 0x3f) << 2, (queue << 4), 0, 0, 0)

def ldh_vf2_full(ib, ib_port, dlp, queue_offset, priority_set, qos_dp, do_not_cut_through, dtm_ctrl_signals, viz_eligible, ect, cr):
    dlp = (ib << 6) | ib_port
    return struct.pack("!6BHL", 1<<1, 2,
                       dlp >> 6,
                       (dlp & 0x3f) << 2,
                       (queue_offset << 4) | (priority_set << 2) | qos_dp,
                       do_not_cut_through << 7 | (dtm_ctrl_signals << 3) | (viz_eligible << 2) | (ect << 1) | cr,
                       0, 0) # lower 48

def ldh_vf1_full(system_qos, proc_sibp, ssp):
    if proc_sibp is None:
        proc_sibp_valid = 0
        proc_sibp = 0
    else:
        proc_sibp_valid = 1
    return struct.pack("!6BHL",
                       0, 1,
                       ssp >> 7,
                       ((ssp & 0x7f) << 1) | proc_sibp_valid,
                       proc_sibp << 1,
                       system_qos << 2,
                       0, 0)

def ldh_vf1(sibp):
    return ldh_vf1_full(0, sibp, 0)

def ldh_vf0(ib, ib_port, ssp, queue):
    slp = (ib << 6) | ib_port
    return struct.pack("!8BL", 1 << 1, 0, slp >> 6, (slp & 0x3f) << 2,
                       (ssp >> 3), (ssp & 0x07) << 5, 0, queue << 1,
                       0)

def ether_hdr_no_vlan(dmac, smac, ethertype = 0x0800):
    return dmac + smac + struct.pack("!H", ethertype)

def ether_hdr(dmac, smac, vlan=0, pcp=0, dei=0, ethertype=0x0800):
    return dmac + smac + struct.pack("!HHH", 0x8100, (pcp << 13) | (dei << 12) | vlan, ethertype)

def ip_hdr(saddr, daddr, len, ttl=100, proto=17):
    return struct.pack("!BBHHHBBHLL", (5 << 4) | 4, 0,
                       len, 0, 0, ttl, proto, 0, saddr, daddr)
