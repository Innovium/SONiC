#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2017
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

# Utility functions for loading/running code on MCU
import threading
import time
import sys
import datetime

from testutil import pci
from testutil import mid
from testutil import bincopy
from utils.compat_util import *

MSN_OFFSETS = [ [ 0x08000000, 0x08800000 ],     # MCU0 TCMA, TCMB
                [ 0x09000000, 0x09800000 ] ]    # MCU1 TCMA, TCMB

TCMA_OFFSET = 0x00000000  # Address of TCMA in MCU space
TCMB_OFFSET = 0x00800000  # Address of TCMB in MCU space

TCMA_SIZE = 0x00040000
TCMB_SIZE = 0x00080000

class FirmwareTimeoutExeception(Exception):
    pass

def reset_is_active(mcu_num):
    reg_name = 'MCU%d_CNFG' % (mcu_num)
    return (pci.read_fields(reg_name)['reset_f'] == 0)  # active low

def reset_clear(mcu_num):
    reg_name = 'MCU%d_CNFG' % (mcu_num)
    pci.write_fields(reg_name, reset_f=1)

def reset_set(mcu_num):
    reg_name = 'MCU%d_CNFG' % (mcu_num)
    pci.write_fields(reg_name, reset_f=0)

def sysreset_is_active(mcu_num):
    reg_name = 'MCU%d_CNFG1' % (mcu_num)
    return (pci.read_fields(reg_name)['sysporeset_f'] == 0)  # active low

def sysreset_clear(mcu_num):
    reg_name = 'MCU%d_CNFG1' % (mcu_num)
    pci.write_fields(reg_name, sysporeset_f=1)

def sysreset_set(mcu_num):
    reg_name = 'MCU%d_CNFG1' % (mcu_num)
    pci.write_fields(reg_name, sysporeset_f=0)

def dbgreset_is_active(mcu_num):
    reg_name = 'MCU%d_CNFG1' % (mcu_num)
    return (pci.read_fields(reg_name)['presetdbg_f'] == 0)

def dbgreset_clear(mcu_num):
    reg_name = 'MCU%d_CNFG1' % (mcu_num)
    pci.write_fields(reg_name, presetdbg_f=1)

def dbgreset_set(mcu_num):
    reg_name = 'MCU%d_CNFG1' % (mcu_num)
    pci.write_fields(reg_name, presetdbg_f=0)

def halt_is_active(mcu_num):
    reg_name = 'MCU%d_CNFG' % (mcu_num)
    return (pci.read_fields(reg_name)['halt_f'] == 1)  # active high

def halt_set(mcu_num):
    reg_name = 'MCU%d_CNFG' % (mcu_num)
    pci.write_fields(reg_name, halt_f=1)

def halt_clear(mcu_num):
    reg_name = 'MCU%d_CNFG' % (mcu_num)
    pci.write_fields(reg_name, halt_f=0)

def is_unsafe(mcu_num):
    # check to see if the block is in reset
    #return not(sysreset_is_active() && reset_is_active())
    return (sysreset_is_active(mcu_num) or reset_is_active(mcu_num))

def mem_init(mcu_num):
    # hardware init of memory, wait 32usec (x2 for safety)
    if (mcu_num == 0):
        pci.write_fields('MCU_MEM_INIT', mcu1_f=1)
    elif (mcu_num == 1):
        pci.write_fields('MCU_MEM_INIT', mcu2_f=1)
    else:
        log("Invalid MCU");
    #time.sleep(0.32) # XXX 1/5000 speed in EMULATION
    time.sleep(1) # XXX 1/5000 speed in EMULATION


def stop(mcu_num):
    sysreset_clear(mcu_num)
    halt_set(mcu_num)
    reset_set(mcu_num)
    reset_clear(mcu_num)

def map_mcu_to_msn(mcu_num, addr):
    if addr >= TCMA_OFFSET and addr < TCMA_OFFSET + TCMA_SIZE:
        return addr - TCMA_OFFSET + MSN_OFFSETS[mcu_num][0]
    if addr >= TCMB_OFFSET and addr < TCMB_OFFSET + TCMB_SIZE:
        return addr - TCMB_OFFSET + MSN_OFFSETS[mcu_num][1]
    raise ValueError('MCU Address 0x{:08x} not mapped to a TCM'.format(addr))

def read8(mcu_num, addr, count):
    return mid.read8(map_mcu_to_msn(mcu_num, addr), count)

def write8(mcu_num, addr, val_list):
    mid.write8(map_mcu_to_msn(mcu_num, addr), val_list)

def read32(mcu_num, addr, count):
    return mid.read32(map_mcu_to_msn(mcu_num, addr), count)

def write32(mcu_num, addr, val_list):
    mid.write32(map_mcu_to_msn(mcu_num, addr), val_list)

def read64(mcu_num, addr, count):
    return mid.read64(map_mcu_to_msn(mcu_num, addr), count)

def write64(mcu_num, addr, val_list):
    mid.write64(map_mcu_to_msn(mcu_num, addr), val_list)

def load(mcu_num, filename):
    mem_init(mcu_num)

    binfile = bincopy.BinFile()
    if filename.lower().endswith('ihex'):
        binfile.add_ihex_file(filename)
    else:
        binfile.add_srec_file(filename)

    if is_unsafe(mcu_num):
        # core not running, go to reset/halted state to avoid bus fault/hang
        stop(mcu_num)

    for seg_base, seg_top, seg_data in binfile.iter_segments():
        mid.write8(map_mcu_to_msn(mcu_num, seg_base), seg_data)

exitFlag = False
threads = []

class logThread (threading.Thread):
    def __init__(self, threadID, name, sleepTime):
        threading.Thread.__init__(self)
        self.threadID = threadID
        self.name = name
        self.sleepTime = sleepTime
        self.exitFlag = False
        self.old_head = 0

    def run(self):
        log(":Start MCU Logging: %s" % ("/tmp/ii-root-0/log/mculog.%d" % self.threadID))
        with open("/tmp/ii-root-0/log/mculog.%d" % self.threadID, "w") as logfile:
            log_size = read32(self.threadID, 0x800404, 1)[0]
            write32(self.threadID, 0x800404, [0x0])
            self.old_head = read32(self.threadID, 0x00800400, 1)[0]
            logfile.write("MCULOG: ThreadID: %d, Log Size: %d, head: %d\n" % (self.threadID, log_size, self.old_head))

            while not self.exitFlag:
                # check for program reloads
                check_size = read32(self.threadID, 0x800404, 1)[0]
                if check_size:
                    #print("MCULOG: New Run, check_size:%u" % (check_size))
                    write32(self.threadID, 0x800404, [0x0])
                    log_size = check_size
                    self.old_head = 0
                #check for new log text
                cur_head = read32(self.threadID, 0x800400, 1)[0]
                #print("head:%u old:%u" % (cur_head, self.old_head))
                if (cur_head != self.old_head):
                    count = cur_head - self.old_head
                    if (count < 0):
                        count += log_size
                    #print("log:%u" % (count))
                    if ((self.old_head + count) > log_size):
                        #print("wrap:%u" % (log_size - self.old_head))
                        buf = read8(self.threadID, 0x00800408 + self.old_head, log_size - self.old_head)
                        outstr = "".join(map(chr, buf))
                        self.old_head = 0
                        count = cur_head - self.old_head
                    else:
                        outstr = ""
                    buf = read8(self.threadID, 0x00800408 + self.old_head, count)
                    outstr += "".join(map(chr, buf))
                    outstr = sub_in_timestamps(outstr)
                    logfile.write(outstr)
                    logfile.flush()
                    self.old_head = cur_head

                time.sleep(self.sleepTime)
        log(":Ending MCU Logging:")

def log_start(mcu_num):
    global print_timestamp_start
    global threads
    print_timestamp_start = datetime.datetime.now()

    exists = False
    for t in threads:
        if t.threadID == mcu_num:
            exists = True

    if not exists:
        thread = logThread(mcu_num, "MCU Logging Thread", 0.25)
        thread.start()
        threads.append(thread)

def log_stop(mcu_num):
    global threads

    log("log_stop %d" % (mcu_num))

    tempThreads = threads
    for t in tempThreads:
        if t.threadID == mcu_num:
            t.exitFlag = True
            t.join()
            threads.remove(t)
    log("log stopped")

def log_stop_all():
    global threads

    tempThreads = threads
    for t in tempThreads:
        t.exitFlag = True
        t.join()
        threads.remove(t)

def sub_in_timestamps(s):
    SOH = '\001'  # prints timestamp
    STX = '\002'  # sets "start" timestamp value
    ETX = '\003'  # prints current time - "start" timestamp value

    curtime = datetime.datetime.now()
    a = s.replace(SOH, str(curtime))
    # deal with the fact that we might get <STX>xxx<ETX> or <ETX><STX> in one blob

    global print_timestamp_start
    b_list = []
    for x in a.split(ETX):
        if STX in x:
            print_timestamp_start = curtime
            b_list.append(x.replace(STX,''))
        else:
            b_list.append(x)
        b_list.append(str(curtime - print_timestamp_start))

    # we'll have an extra 'timediff' on the end of the list, so trim it:
    return "".join(b_list[:-1])

def get_existing_log(mcu_num):
    log_size = read32(mcu_num, 0x00800404, 1)[0]
    cur_head = read32(mcu_num, 0x00800400, 1)[0]
    buf = read8(mcu_num, 0x00800408, cur_head)
    outstr = "".join(map(chr,buf))
    return outstr
