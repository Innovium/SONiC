/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_neighbor_util.h
 * @brief ISAI Util Include file for NEIGHBOR module
 */


#ifndef __IFCS_SAI_NEIGHBOR_UTIL_H__
#define __IFCS_SAI_NEIGHBOR_UTIL_H__

#include "util/ifcs_sai_neighbor_util_dep.h"
#include "ifcs_isai_ds_nbr.h"

/*
 * @brief Initializes Neighbor module
 *
 * @param [in]  sai_switch_init_info_p   - Pointer to switch init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_neighbor_init(
    sai_switch_init_info_t *sai_switch_init_info_p);

/*
 * @brief Un-initializes Neighbor module
 *
 * @param [in]  switch_deinit_info_p   - Pointer to switch deinit information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_neighbor_deinit(
    sai_switch_deinit_info_t *switch_deinit_info_p);

/*
 * @brief Forms IFCS neighbor database key
 *
 * @param [out] ifcs_key_p        - IFCS neighbor database key
 * @param [in]  neighbor_entry_p  - Pointer to neighbor entry
 * @return sai_status_t
 */
extern sai_status_t
isai_im_neighbor_form_ifcs_key(
    ifcs_isai_ds_nbr_t                *ifcs_key_p,
    const sai_neighbor_entry_t *const neighbor_entry_p);


/**
 * @brief Get neighbor NH handle
 *
 * @param [in]  neighbor_entry_p   - Pointer to neighbor entry
 * @param [in]  nbr_handle_p       - Pointer for handle
 * @param [out] nbr_found_p        - state of nbr existance
 * @return sai_status_t
 */
extern sai_status_t
isai_im_neighbor_get_nh(
    const sai_neighbor_entry_t *neighbor_entry_p,
          ifcs_handle_t        *nbr_handle_p,
          bool                 *nbr_found_p);


/**
 * @brief Increment neighbor reference count
 *
 * @param [in]  neighbor_entry_p   - Pointer to neighbor entry
 * @param [in]  nh_handle          - IFCS NH handle
 * @return sai_status_t
 */
extern sai_status_t
isai_im_neighbor_ref_count_inc(
    const sai_neighbor_entry_t *neighbor_entry_p,
    const ifcs_handle_t        nh_handle);


/**
 * @brief Decrement neighbor reference count
 *
 * @param [in]  neighbor_entry_p   - Pointer to neighbor entry
 * @param [in]  nh_handle          - IFCS NH handle
 * @return sai_status_t
 */
extern sai_status_t
isai_im_neighbor_ref_count_dec(
    const sai_neighbor_entry_t *neighbor_entry_p,
    const ifcs_handle_t        nh_handle);

/**
 * @brief Fdb event notification for neighbor module (only for static fdb events)
 *
 * @param [in] node_id       - IFCS node id
 * @param [in] count         - Number of entries
 * @param [in] data_p        - Pointer to notification data
 */
extern sai_status_t isai_im_neighbor_fdb_event_notify(ifcs_node_id_t node_id, uint32_t       count,
                                sai_shim_fdb_event_notification_data_t *data_p);


/*
 * @brief Get Neighbor object type resource availability.
 *
 * @param[in] switch_id   SAI Switch object id
 * @param[in] attr_count  Number of attributes
 * @param[in] attr_list_p List of attributes that to distinguish resource
 * @param[out] count_p    Available objects left
 *
 * @return #SAI_STATUS_NOT_SUPPORTED if the given object type does not support resource accou
 * Otherwise, return #SAI_STATUS_SUCCESS.
 */
sai_status_t
isai_im_neighbor_object_type_get_availability(sai_object_id_t       switch_id,
                                              uint32_t              attr_count,
                                              const sai_attribute_t *attr_list_p,
                                              uint64_t              *count_p);

/**
 * @brief Get neighbor No host route
 *
 * @param [in]  neighbor_entry_p   - Pointer to neighbor entry
 * @param [out] no_host_route_p    - Pointer for no host route
 * @return sai_status_t
 */
sai_status_t
isai_im_neighbor_get_no_host_route(
    const sai_neighbor_entry_t *neighbor_entry_p,
          bool                 *no_host_route_p);


/**
 * @brief Restore neighbor No host route
 *
 * @param [in]  neighbor_entry_p   - Pointer to neighbor entry
 * @param [out] host_route_info_p  - Pointer for host route
 * @return sai_status_t
 */
sai_status_t
isai_im_neighbor_add_host_route(
    const sai_neighbor_entry_t *neighbor_entry_p,
          isai_host_route_t    *host_route_info_p);

/**
 * @brief Get neighbor No host route based on VRF
 *
 * @param [in]  route_entry_p      - Pointer to route entry
 * @param [out] nbr_data_p         - Pointer for nbr data
 * @return sai_status_t
 */
extern sai_status_t
isai_im_neighbor_get_no_host_route_from_vrf(
    const sai_route_entry_t *route_entry_p,
    isai_host_rt_nbr_t      *nbr_data_p);
    
/**
 * @brief Set neighbor NH Bind info
 *
 * @param [in]  neighbor_entry_p   - Pointer to neighbor entry
 * @param [in]  nbrhdl_bind_to_nh   - Pointer for return state
 * @return sai_status_t
 */
extern sai_status_t
isai_im_neighbor_nhhdl_bind_info_set(
          sai_neighbor_entry_t *neighbor_entry_p,
          bool                 nbrhdl_bind_to_nh);


/**
 * @brief Add Nhop to  neighbor ds
 *
 * @param [in]  neighbor_entry_p   - Pointer to neighbor entry
 * @param [in]  nh_hdl             - Nexthop hdl
 * @return sai_status_t
 */
extern sai_status_t
isai_im_neighbor_add_nh_hdl(
          sai_neighbor_entry_t *neighbor_entry_p,
          ifcs_handle_t        nh_hdl);


/**
 * @brief Del Nhop from neighbor ds
 *
 * @param [in]  neighbor_entry_p   - Pointer to neighbor entry
 * @param [in]  nh_hdl             - Nexthop hdl
 * @return sai_status_t
 */
extern sai_status_t
isai_im_neighbor_del_nh_hdl(
          sai_neighbor_entry_t *neighbor_entry_p,
          ifcs_handle_t        nh_hdl);

/**
 * @brief Add Nhop to  neighbor unresolv info
 *
 * @param [in]  neighbor_entry_p   - Pointer to neighbor entry
 * @param [in]  nh_hdl             - Nexthop hdl
 * @return sai_status_t
 */
extern sai_status_t
isai_im_neighbor_add_nexthop_to_unresolv_info(
          sai_neighbor_entry_t *neighbor_entry_p,
          ifcs_handle_t        nh_hdl);


/**
 * @brief Del Nhop from neighbor unresolv info
 *
 * @param [in]  neighbor_entry_p   - Pointer to neighbor entry
 * @param [in]  nh_hdl             - Nexthop hdl
 * @return sai_status_t
 */
extern sai_status_t
isai_im_neighbor_del_nexthop_from_unresolv_info(
          sai_neighbor_entry_t *neighbor_entry_p,
          ifcs_handle_t        nh_hdl);


/**
 * @brief Update neighbor miss trap info
 *
 * @param [in]  node_id         - Node Id
 * @param [in]  trap_hdl        - Trap handle
 * @param [in]  pkt_action      - Sai pkt action
 * @return sai_status_t
 */
extern sai_status_t
isai_im_neighbor_update_neighbor_miss_trap_info
(
    ifcs_node_id_t        node_id,
    ifcs_handle_t         trap_hdl,
    sai_packet_action_t   pkt_action
);

#endif /* __IFCS_SAI_NEIGHBOR_UTIL_H__ */
