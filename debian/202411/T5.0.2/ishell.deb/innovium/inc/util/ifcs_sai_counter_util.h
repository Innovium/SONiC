/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_counter_util.h
 * @brief ISAI Util Include file for Counter module
 */


#ifndef __IFCS_SAI_COUNTER_UTIL_H__
#define __IFCS_SAI_COUNTER_UTIL_H__

#include "util/ifcs_sai_counter_util_dep.h"
#include "ifcs_sysport.h"

sai_status_t
isai_im_counter_init(sai_switch_init_info_t * sai_switch_init_info_p);

sai_status_t
isai_im_counter_get_flex_pool_counter(ifcs_node_id_t        node_id,
                                      sai_object_id_t       counter_oid,
                                      bool                  alloc,
                                      ifcs_handle_t         *flex_pool_counter);
sai_status_t
isai_im_counter_free_flex_pool_counter(ifcs_node_id_t    node_id,
                                       sai_object_id_t   counter_oid);
/*
 * Routine Description:
 *   Attach/Detach Bindpoint Oid to Counter Oid
 *
 * Arguments:
 *    [in] node_id            - IFCS node_id
 *    [in] counter_oid        - Object Id of Counter
 *    [in] bindpoint_obj_id   - Object Id of bindpoint
 *    [in] counter_ids        - specifies the array of counter ids
 *    [in] is_attach          - 1-Attach , 0-Detach
 *
 * Return Values:
 *    SAI_STATUS_SUCCESS on success
 *    Failure status code on error
 */
sai_status_t
isai_im_counter_attach_sai_object(ifcs_node_id_t    node_id,
                                  sai_object_id_t   counter_oid,
                                  sai_object_id_t   bindpoint_obj_id,
                                  bool              is_attach);
/*
 * Routine Description:
 *   Get Counter type of the Counter Oid
 *
 * Arguments:
 *    [in]  node_id            - IFCS node_id
 *    [in]  counter_oid        - Object Id of Counter
 *    [out] counter_type       - counter type (IPMC/Hostif)
 *
 * Return Values:
 *    SAI_STATUS_SUCCESS on success
 *    Failure status code on error
 */

sai_status_t
isai_im_counter_get_counter_type(ifcs_node_id_t    node_id,
                                 sai_object_id_t   counter_oid,
                                 uint32_t *counter_type);

/*
 * Routine Description:
 *   Set Counter type of the Counter Oid
 *
 * Arguments:
 *    [in]  node_id            - IFCS node_id
 *    [in]  counter_oid        - Object Id of Counter
 *    [in]  object_type        - type of Object to be checked
 *    [out] is_valid           - 0-Not Valid, 1-Valid
 *
 * Return Values:
 *    SAI_STATUS_SUCCESS on success
 *    Failure status code on error
 */
sai_status_t
isai_im_counter_is_valid_for_object_type(ifcs_node_id_t    node_id,
                                    sai_object_id_t   counter_oid,
                                    sai_object_type_t object_type,
                                    bool *is_valid);
/*
 * Routine Description:
 *   Set Counter type of the Counter Oid
 *
 * Arguments:
 *    [in]  node_id            - IFCS node_id
 *    [in]  obj_id             - Object Id of bind point
 *    [in]  counter_oid        - Object Id of Counter
 *
 * Return Values:
 *    SAI_STATUS_SUCCESS on success
 *    Failure status code on error
 */
sai_status_t
isai_im_counter_set_counter_type(ifcs_node_id_t    node_id,
                                 sai_object_id_t   obj_id,
                                 sai_object_id_t   counter_oid);


#endif /* __IFCS_SAI_COUNTER_UTIL_H__ */

