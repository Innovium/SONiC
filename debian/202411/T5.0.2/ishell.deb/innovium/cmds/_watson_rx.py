#-------------------------------------------------------------------------------
# Copyright (c) (2025) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------
from abc import ABC, abstractmethod
import argparse
import json
import os
#import pcapkit
import socket
import struct
import threading
import time

from datetime import datetime, timezone, timedelta
from enum import Enum
from verbosity import *
from _watson_i2c import WatsonDevice, WatsonI2C

NODE_ID = 0

class DevportMap:
    def __init__(self, devports: str):
        self.devport_map = None
        self.assign(devports)

    def assign(self, devports: str):
        self.devport_map = {}
        for map in devports.split(":"):
            parts = map.split("=")
            if len(parts) != 2:
                raise ValueError("Invalid devport map: {}".format(map))

            devport = int(parts[0])
            ib_port = parts[1].split(".")
            if len(parts) != 2:
                raise ValueError("Invalid devport map entry: {}".format(parts[1]))
                continue

            ib = int(ib_port[0])
            port = int(ib_port[1])
            index = self._get_index(ib, port)
            if index in self.devport_map:
                raise ValueError("Duplicate devport map entry: {}".format(map))
                continue
            self.devport_map[index] = devport

    def get(self, ib, ibport):
        index = self._get_index(ib, ibport)
        return self.devport_map.get(index)

    @staticmethod
    def _get_index(ib: int, ibport: int):
        return (ib << 8) | ibport

class WatsonSku:
    def __init__(self, ib_count = 8, port_count = 64, queue_count = 8, partition_count = 4):
        self.ib_count = ib_count
        self.port_count = port_count
        self.queue_count = queue_count
        self.partition_count = partition_count

    def assign(self, sku: str):
        parts = sku.split(",")
        for part in parts:
            key, value = part.split("=")
            if key == "ib":
                self.ib_count = int(value)
            elif key == "port":
                self.port_count = int(value)
            elif key == "queue":
                self.queue_count = int(value)
            elif key == "partition":
                self.partition_count = int(value)

class WatsonFilter:
    def __init__(self, sku):
        self.ibs = [[True for _ in range(sku.ib_count)],]
        self.ports = [[True for _ in range(sku.port_count)] for _ in range(sku.ib_count)]
        self.queues = [[True for _ in  range(sku.queue_count)] for _ in range(sku.ib_count)]
        self.partitions = [[True for _ in range(sku.partition_count)] for _ in range(sku.ib_count)]

    def assign(self, enable):
        parts = enable.split(",")
        for part in parts:
            key, value = part.split("=")
            if key == "ib":
                self._clear_mask(self.ibs)
                self._parse_mask(value, self.ibs)
            elif key == "ports":
                self._clear_mask(self.ports)
                self._parse_mask(value, self.ports)
            elif key == "queues":
                self._clear_mask(self.queues)
                self._parse_mask(value, self.queues)
            elif key == "partitions":
                self._clear_mask(self.partitions)
                self._parse_mask(value, self.partitions)

    @staticmethod
    def _parse_mask(mask: str, filter: list):
        values = mask.split(":")
        for i, value in enumerate(values):
            v = int(value, base=0)
            for j in range(len(filter[i])):
                filter[i][j] = (v & (1 << j)) != 0

    @staticmethod
    def _clear_mask(filter: list):
        for i in range(len(filter)):
            for j in range(len(filter[i])):
                filter[i][j] = False

class WatsonReader(ABC):
    @abstractmethod
    def read(self):
        pass

    @abstractmethod
    def is_eof(self):
        pass

class WatsonSocketReader(WatsonReader):
    BUFFER_SIZE = (16 * 1024)

    def __init__(self, port: int, timeout: int = 1):
        if port is None:
            port = 4300
        elif isinstance(port, str):
            port = int(port)
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(("", port))
        self.sock.settimeout(timeout)

    def read(self):
        data = None
        try:
            data, addr = self.sock.recvfrom(self.BUFFER_SIZE)
        except socket.timeout:
            pass
        return data

    def is_eof(self):
        return False
class WatsonI2CReader(WatsonReader):

    def __init__(self, watson: WatsonI2C):
        self.watson = watson

    def read(self):
        data = self.watson.read()
        return data

    def is_eof(self):
        return self.watson.is_eof()

class WatsonI2CFileReader(WatsonReader):

    def __init__(self, i2cfile: str):
        with open(i2cfile, "rb") as file:
            self.pkt_buf = file.read()
            self.offset = 0

    def read(self):
        if self.offset >= len(self.pkt_buf):
            return None
        msg_hdr = struct.unpack(">H", self.pkt_buf[self.offset:self.offset + 2])[0]
        msg_size = msg_hdr & 0x7fff
        msg_type = msg_hdr & 0x8000
        msg_id = self.pkt_buf[self.offset + 2]
        log_dbg(1, "msg: id=%d offset=%d type=%#x size=%d" % (msg_id, self.offset, msg_type, msg_size))
        msg_data = struct.pack(">H", msg_type)
        msg_data += struct.pack(">H", msg_size)
        msg_data += self.pkt_buf[self.offset + 2:self.offset + msg_size]
        self.offset += msg_size
        if self.offset & 1:
            self.offset += 1
        return msg_data

    def is_eof(self):
        return self.offset >= len(self.pkt_buf)

class WatsonPcapFileReader(WatsonReader):
    def __init__(self, pcap_file: str):
        self.cap = pcapkit.extract(fin=pcap_file, nofile=True)
        self.frame_idx = 0

    def read(self):
        if self.frame_idx >= len(self.cap.frame):
            return None
        frame = self.cap.frame[self.frame_idx]
        self.frame_idx += 1
        if pcapkit.UDP not in frame:
            return None
        udp = frame[pcapkit.UDP]
        return udp.packet.payload

    def is_eof(self):
        return self.frame_idx >= len(self.cap.frame)

class WatsonMessage:
    def __init__(self, type: str):
        self.is_valid = False
        self.type = type
        self.id = None
        self.ts = None
        self.ibs = None

    def __str__(self):
        if self.id is None:
            id_str = "None"
        else:
            id_str = "id: {} ({})".format(self.id.value, self.id.name)
        ts = None if self.ts is None else self.ts_to_datetime(self.ts).isoformat()
        return "type: {}, {}, ts: {}, ibs: {}".format(self.type, id_str, ts, self.ibs)

    def to_json(self, ts_mode: str = None):
        obj = {}
        obj["id"] = self.id.value
        obj["ts"] = self.ts_to_datetime(self.ts).isoformat() if ts_mode == "iso" else self.ts
        obj["mod"] = self.id.type.name.lower()
        if self.ibs:
            obj[self.type] = self.ibs
        elif self.devports:
            obj[self.type] = self.devports
        else:
            obj[self.type] = {}
        return json.dumps(obj, separators=(',', ':'))

    @staticmethod
    def ts_to_datetime(ts: int):
        secs  = ts >> 32
        nsecs = ts & 0xffffffff
        dt    = datetime.fromtimestamp(secs, tz=timezone.utc)
        dt   += timedelta(microseconds=nsecs/1000)
        return dt

    @staticmethod
    def parse(reader: WatsonReader, filter: WatsonFilter, devport_map: DevportMap):
        msg_seq = 0
        msg_length = 0
        msg_payload = None
        while True:
            msg_buf = reader.read()
            if msg_buf is None:
                return None
            if len(msg_buf) == 0:
                return WatsonMessage()
            msg_hdr = struct.unpack(">H", msg_buf[0:2])[0]
            seq = (msg_hdr & 0x7f00) >> 8
            if seq == 0:
                msg_length = struct.unpack(">H", msg_buf[2:4])[0] - 2
                msg_payload = msg_buf[4:]
                msg_seq += 1
            else:
                if seq != msg_seq:
                    raise ValueError("Invalid sequence number: {} (expected {})".format(seq, msg_seq))
                msg_payload += msg_buf[2:]
                msg_seq += 1
            curr_length = len(msg_payload)
            if curr_length == msg_length:
                break

        if msg_hdr & 0x8000:
            return WatsonEvent(msg_payload, filter, devport_map)

        return WatsonStats(msg_payload, filter, devport_map)

class WatsonType(Enum):
    PORT = 0
    QUEUE = 1
    PARTITION = 2

class WatsonEventId(Enum):
    PORT_PACKET_DROPPED = (0, 64, WatsonType.PORT, "Port packet dropped")
    QUEUE_PACKET_DROPPED = (1, 512, WatsonType.QUEUE, "Queue packet dropped")
    PORT_UTILIZATION_EXCESSIVE = (2, 64, WatsonType.PORT, "Port utilization excessive")
    RESERVED = (3, 0, WatsonType.PORT, "Reserved")
    QUEUE_LENGTH_EXCESSIVE = (4, 512, WatsonType.QUEUE, "Queue length excessive")
    QUEUE_DELAY_EXCESSIVE = (5, 512, WatsonType.QUEUE, "Queue delay excessive")
    PARTITION_USAGE_EXCESSIVE = (6, 8, WatsonType.PARTITION, "Partition usage excessive")

    def __new__(cls, value, width, type, description):
        obj = object.__new__(cls)
        obj._value_ = value
        obj.width = width
        obj.type = type
        obj.description = description
        return obj

class WatsonEvent(WatsonMessage):
    def __init__(self, payload: bytes, filter: WatsonFilter, devport_map: DevportMap):
        super().__init__("events")

        self.id = WatsonEventId(payload[0])
        self.ibs = None
        self.devports = None

        if self.id == WatsonEventId.RESERVED:
            return
        self.ts = struct.unpack("<Q", payload[1:9])[0]

        if self.id.type == WatsonType.PORT:
            events = self.ibs = self._parse_port_events(filter, payload[9:], devport_map)
        elif self.id.type == WatsonType.QUEUE:
            events = self._parse_queue_events(filter, payload[9:], devport_map)
        elif self.id.type == WatsonType.PARTITION:
            events = self._parse_partition_events(filter, payload[9:])
            devport_map = None
        else:
            events = None

        if devport_map is None:
            self.ibs = events
        else:
            self.devports = events

        self.is_valid = True

    @staticmethod
    def _parse_port_events(filter: WatsonFilter, payload: bytes, devport_map: DevportMap):
        events = {}
        offset = 0
        for ib, ib_enabled in enumerate(filter.ibs[NODE_ID]):
            if not ib_enabled:
                continue
            port_events = {}
            event = 0
            bit = 0
            for port, _ in enumerate(filter.ports[ib]):
                if bit == 0:
                    event = payload[offset]
                    offset += 1
                    bit = 1
                value = (event & bit) != 0
                bit <<= 1
                bit &= 0xff
                if value:
                    if devport_map is None:
                        port_events[port] = 1
                    else:
                        devport = devport_map.get(ib, port)
                        if devport is not None:
                            events[devport] = 1
            if devport_map is None:
                events[ib] = port_events
        return events

    @staticmethod
    def _parse_queue_events(filter: WatsonFilter, payload: bytes, devport_map: DevportMap):
        events = {}
        offset = 0
        for ib, ib_enabled in enumerate(filter.ibs[NODE_ID]):
            if not ib_enabled:
                continue
            port_events = {}
            for port, _ in enumerate(filter.ports[ib]):
                queue_events = {}
                event = 0
                bit = 0
                for queue, _ in enumerate(filter.queues[ib]):
                    if bit == 0:
                        event = payload[offset]
                        offset += 1
                        bit = 1
                    value = (event & bit) != 0
                    bit <<= 1
                    bit &= 0xff
                    if value:
                        queue_events[queue] = 1
                if not queue_events:
                    continue
                if devport_map is None:
                    port_events[port] = queue_events
                else:
                    devport = devport_map.get(ib, port)
                    if devport is not None:
                        events[devport] = queue_events
            if port_events and devport_map is None:
                events[ib] = port_events
        return events

    @staticmethod
    def _parse_partition_events(filter: WatsonFilter, payload: bytes):
        ibs_events = {}
        offset = 0
        for ib, ib_enabled in enumerate(filter.ibs[NODE_ID]):
            if not ib_enabled:
                continue
            partition_events = {}
            event = 0
            bit = 0
            for partition, _ in enumerate(filter.partitions[ib]):
                if bit == 0:
                    event = payload[offset]
                    offset += 1
                    bit = 1
                value = (event & bit) != 0
                bit <<= 1
                bit &= 0xff
                if value:
                    partition_events[partition] = 1
            if partition_events:
                ibs_events[ib] = partition_events
        return ibs_events

class WatsonStatsId(Enum):
    QUEUE_DROPPED_PACKETS = (0, 32, WatsonType.QUEUE, "Queue dropped packets")
    QUEUE_CONGESTION_RATIO = (1, 16, WatsonType.QUEUE, "Queue congestion ratio")
    QUEUE_LENGTH = (2, 24, WatsonType.QUEUE, "Queue length")
    QUEUE_LENGTH_AVG = (3, 24, WatsonType.QUEUE, "Queue length average")
    QUEUE_DELAY = (4, 32, WatsonType.QUEUE, "Queue delay")
    QUEUE_DELAY_AVG = (5, 32, WatsonType.QUEUE, "Queue delay average")
    PORT_TX_PACKETS = (6, 32, WatsonType.PORT, "Port transmitted packets")
    PORT_TX_BYTES = (7, 32, WatsonType.PORT, "Port transmitted bytes")
    PORT_TX_DROPPED = (8, 32, WatsonType.PORT, "Port transmitted dropped")
    PORT_UTILIZATION = (9, 8, WatsonType.PORT, "Port utilization")
    PORT_UTILIZATION_AVG = (10, 8, WatsonType.PORT, "Port utilization average")
    PARTITION_USAGE = (11, 32, WatsonType.PARTITION, "Partition usage")
    QUEUE_LENGTH_MIN = (12, 24, WatsonType.QUEUE, "Queue length min")
    QUEUE_LENGTH_MAX = (13, 24, WatsonType.QUEUE, "Queue length max")
    QUEUE_DELAY_MIN = (14, 32, WatsonType.QUEUE, "Queue delay min")
    QUEUE_DELAY_MAX = (15, 32, WatsonType.QUEUE, "Queue delay max")
    PARTITION_USAGE_MIN = (16, 32, WatsonType.PARTITION, "Partition usage min")
    PARTITION_USAGE_MAX = (17, 32, WatsonType.PARTITION, "Partition usage max")

    def __new__(cls, value, bits, type, description):
        obj = object.__new__(cls)
        obj._value_ = value
        obj.bits = bits
        obj.type = type
        obj.description = description
        return obj

    def byte_length(self):
        return (self.bits + 7) // 8

class WatsonStats(WatsonMessage):
    def __init__(self, payload: bytes, filter: WatsonFilter, devport_map: DevportMap):
        super().__init__("stats")

        self.id = WatsonStatsId(payload[0])
        self.ts = struct.unpack("<Q", payload[1:1+8])[0]

        if self.id.type == WatsonType.PORT:
            stats = self.devports = self._parse_port_stats(filter, payload[9:], self.id.byte_length(), devport_map)
        elif self.id.type == WatsonType.QUEUE:
            stats = self._parse_queue_stats(filter, payload[9:], self.id.byte_length(), devport_map)
        elif self.id.type == WatsonType.PARTITION:
            stats = self._parse_partition_stats(filter, payload[9:], self.id.byte_length())
        else:
            stats = None

        if devport_map is None:
            self.ibs = stats
        else:
            self.devports = stats

        self.is_valid = True

    @staticmethod
    def _parse_port_stats(filter: WatsonFilter, payload: bytes, width: int, devport_map: DevportMap):
        stats = {}
        offset = 0
        pad = b"\x00" * (4 - width)
        for ib, ib_enabled in enumerate(filter.ibs[NODE_ID]):
            if not ib_enabled:
                continue
            port_stats = {}
            for port, port_enabled in enumerate(filter.ports[ib]):
                if not port_enabled:
                    continue
                value = payload[offset:offset+width] + pad
                offset += width
                counter = struct.unpack("<I", value)[0]
                if devport_map is None:
                    port_stats[port] = counter
                else:
                    devport = devport_map.get(ib, port)
                    if devport is not None:
                        stats[devport] = counter
            if devport_map is None:
                stats[ib] = port_stats
        if (offset + 2) != len(payload):
            log_err("Watson message length mismatch, expected %d, got %d" % (len(payload), offset + 2))
            raise ValueError("Message length mismatch")
        return stats

    @staticmethod
    def _parse_queue_stats(filter: WatsonFilter, payload: bytes, width: int, devport_map: DevportMap):
        stats = {}
        offset = 0
        pad = b"\x00" * (4 - width)
        for ib, ib_enabled in enumerate(filter.ibs[NODE_ID]):
            if not ib_enabled:
                continue
            port_stats = {}
            for port, port_enabled in enumerate(filter.ports[ib]):
                if not port_enabled:
                    continue
                queue_stats = {}
                for queue, queue_enabled in enumerate(filter.queues[ib]):
                    if not queue_enabled:
                        continue
                    value = payload[offset:offset+width] + pad
                    offset += width
                    counter = struct.unpack("<I", value)[0]
                    queue_stats[queue] = counter
                if devport_map is None:
                    port_stats[port] = queue_stats
                else:
                    devport = devport_map.get(ib, port)
                    if devport is not None:
                        stats[devport] = queue_stats
            if devport_map is None:
                stats[ib] = port_stats
        if (offset + 2) != len(payload):
            log_err("Watson message length mismatch, expected %d, got %d" % (len(payload), offset + 2))
            raise ValueError("Message length mismatch")
        return stats

    @staticmethod
    def _parse_partition_stats(filter: WatsonFilter, payload: bytes, width: int):
        ibs_stats = {}
        offset = 0
        pad = b"\x00" * (4 - width)
        for ib, ib_enabled in enumerate(filter.ibs[NODE_ID]):
            if not ib_enabled:
                continue
            partition_stats = {}
            for partition, partition_enabled in enumerate(filter.partitions[ib]):
                if not partition_enabled:
                    continue
                value = payload[offset:offset+width] + pad
                offset += width
                counter = struct.unpack("<I", value)[0]
                partition_stats[partition] = counter
            ibs_stats[ib] = partition_stats
        if (offset + 2) != len(payload):
            log_err("Watson message length mismatch, expected %d, got %d" % (len(payload), offset + 2))
            raise ValueError("Message length mismatch")
        return ibs_stats

class WatsonSim(WatsonDevice):
    def get_dev_id(self):
        return 128

    def get_rev_id(self):
        return 16

    def enable(self):
        pass

    def disable(self):
        pass

    def reset(self):
        pass

    def set_verbose(self, verbose):
        pass

    def eth_enable(self):
        pass

    def eth_disable(self):
        pass

class WatsonCapture:
    SYSTEM_I2C_BUS = 1
    SYSTEM_I2C_ADDR = 0x32

    WATSON_I2C_BUS = 1
    WATSON_I2C_ADDR = 0x34

    def __init__(self, cmd_args = None):
        self.args = None
        self.thread = None
        self.thread_stop = False
        self.running = False

        parser = argparse.ArgumentParser(description="Watson Receiver")
        parser.add_argument("--sku", type=str, help="Set the SKU numbers ib=<n>,port=<n>,queue=<n>,partition=<n>")
        parser.add_argument("--enable", type=str, help="Set enabled resources ib=<mask>:ports=<mask:...>,queues=<mask:...>,partitions=<mask,...>")
        parser.add_argument("--devports", type=str, help="Set devport mapping devport0=ib.port:devport1=ib.port:...")
        parser.add_argument("--reset", type=str, help="soft/hard reset Watson FPGA")
        parser.add_argument("--source", type=str, default="i2c", help="i2c/mgmt0/mgmt1/file")
        parser.add_argument("--ts", type=str, default="epoch", help="Timestamp format (iso/epoch)")
        parser.add_argument("--output", type=str, default="watson", help="Output file")
        parser.add_argument("--background", action="store_true", help="Run in background")

        if cmd_args is not None:
            self.args = parser.parse_args(cmd_args)
        else:
            self.args = parser.parse_args()

        if "." in self.args.output:
            self.output_filename = self.args.output
        else:
            output_num = 0
            output_filename = "{}-{}.json".format(self.args.output, output_num)
            while os.path.exists(output_filename):
                output_num += 1
                output_filename = "{}-{}.json".format(self.args.output, output_num)
            self.output_filename = output_filename

        self.sku = WatsonSku()
        if self.args.sku is not None:
            self.sku.assign(self.args.sku)

        self.filter = WatsonFilter(self.sku)
        if self.args.enable is not None:
            self.filter.assign(self.args.enable)

        self.devport_map = None
        if self.args.devports is not None:
            self.devport_map = DevportMap(self.args.devports)

        self.smbus2 = None
        if self.args.reset == "hard":
            try:
                self.smbus2 = importlib.import_module("smbus2")
            except ImportError:
                raise ImportError("smbus2 module not found. Please install it using 'pip install smbus2'")
            sys_i2c = self.smbus2.SMBus(self.SYSTEM_I2C_BUS)
            sys_i2c.write_byte_data(self.SYSTEM_I2C_ADDR, 0x0d, 0x01)
            sys_i2c.write_byte_data(self.SYSTEM_I2C_ADDR, 0x0d, 0x00)
            time.sleep(1)

        source_args = self.args.source.split(":")
        if source_args[0] == "i2c":
            filename = source_args[1] if len(source_args) >= 2 else None
            self.watson = WatsonI2C(self.WATSON_I2C_BUS, self.WATSON_I2C_ADDR, filename)
        elif source_args[0] == "mgmt0" or source_args[0] == "mgmt1":
            self.watson = WatsonI2C(self.WATSON_I2C_BUS, self.WATSON_I2C_ADDR)
        else:
            self.watson = WatsonSim()

        log("Watson FPGA: DevId=0x{:04x}, RevId=0x{:04x}".format(self.watson.get_dev_id(), self.watson.get_rev_id()))

        if source_args[0] == "i2c":
            self.reader = WatsonI2CReader(self.watson)
        elif source_args[0] == "mgmt0" or source_args[0] == "mgmt1":
            self.watson.eth_enable()
            self.reader = WatsonSocketReader(source_args[1] if len(source_args) >= 2 else None)
        elif source_args[0] == "file":
            if len(source_args) < 2:
                raise Exception("Specify the input file=<file>")
            file_ext = source_args[1].split(".")[-1]
            if file_ext == "i2c":
                self.reader = WatsonI2CFileReader(source_args[1])
            elif file_ext == "pcap":
                self.reader = WatsonPcapFileReader(source_args[1])
            else:
                raise ValueError("Invalid file extension")
        else:
            raise Exception("Specify the input source i2c/mgmt0/mgmt1/pcap")

        if self.args.reset == "soft":
            self.watson.reset()

        self.watson.set_verbose(not self.args.background)
        log("Output file: {}".format(self.output_filename))

    def start(self):
        self.watson.enable()
        if self.args.background:
            self.thread_stop = False
            self.thread = threading.Thread(target=self.run)
            self.thread.daemon = True
            self.thread.start()
            log("Watson background thread started")
            return

    def wait(self):
        if self.thread is not None and self.running:
            log("Waiting for Watson background thread to finish...")
            self.thread.join()

    def stop(self):
        if self.thread is not None:
            if self.running:
                log("Stopping Watson background thread...")
                self.thread_stop = True
                self.thread.join()
            self.thread = None

        self.watson.disable()
        self.watson.eth_disable()

    def run(self):
        self.running = True
        with open(self.output_filename, "w") as output:
            output.write("{\n")
            output.write("\"watson\": {\"dev_id\": %d, \"rev_id\": %d},\n" % (self.watson.get_dev_id(), self.watson.get_rev_id()))
            output.write("\"sku\": {\"ib\": %d, \"port\": %d, \"queue\": %d, \"partition\": %d},\n" % (self.sku.ib_count, self.sku.port_count, self.sku.queue_count, self.sku.partition_count))
            output.write("\"messages\": [\n")

            first = True
            while not self.thread_stop:
                msg = WatsonMessage.parse(self.reader, self.filter, self.devport_map)
                if msg is None:
                    if self.reader.is_eof():
                        break
                    time.sleep(1/1000)
                    continue
                if msg.is_valid:
                    if not first:
                        output.write(",\n")
                    first = False
                    output.write(msg.to_json(self.args.ts))

            output.write("\n]\n")
            output.write("}\n")
            output.close()
        if self.thread:
            log("Watson background thread finished")
        self.running = False

    def is_running(self):
        return self.running

if __name__ == "__main__":
    watson_capture = WatsonCapture()
    watson_capture.start()
    if watson_capture.args.background:
        watson_capture.wait()
    else:
        watson_capture.run()
    watson_capture.stop()
