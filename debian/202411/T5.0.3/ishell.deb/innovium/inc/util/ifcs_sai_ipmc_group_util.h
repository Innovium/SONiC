/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_ipmc_group_util.h
 * @brief ISAI Util Include file for IPMC_GROUP module
 */

#ifndef __IFCS_SAI_IPMC_GROUP_UTIL_H__
#define __IFCS_SAI_IPMC_GROUP_UTIL_H__

#include "util/ifcs_sai_ipmc_group_util_dep.h"
#include "ifcs_sysport.h"
#include "ifcs_l2vni.h"
#include "ifcs_intf.h"
#include "ifcs_mdg.h"

/*
 * @brief Get member count from IPMC group data store entry
 *
 * @param [in]  node_id         - IFCS node id
 * @param [in]  ds_handle       - Data store handle
 * @param [in]  mem_count_p     - Pointer to member count
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_group_ds_get_mem_count(
    ifcs_node_id_t    node_id,
    ifcs_handle_t     ds_hdl,
    uint32_t           *mem_count_p);

/**
 * @brief Increment member count in the IPMC group DS
 *
 * @param [in]  node_id       - IFCS Node id
 * @param [in]  ds_hdl        - Data store handle
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_group_ds_mem_count_inc(
    ifcs_node_id_t    node_id,
    ifcs_handle_t     ds_hdl);

/**
 * @brief Decrement member count in the IPMC group DS
 *
 * @param [in]  node_id       - IFCS Node id
 * @param [in]  ds_hdl        - Data store handle
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_group_ds_mem_count_dec(
    ifcs_node_id_t    node_id,
    ifcs_handle_t     ds_hdl);

/**
 * @brief Get Ref count in the IPMC group DS
 *
 * @param [in]  node_id       - IFCS Node id
 * @param [in]  ds_hdl        - Data store handle
 * @param [out] count_p       - Pointer to count
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_group_ds_get_ref_count(
    ifcs_node_id_t    node_id,
    ifcs_handle_t     ds_hdl,
    uint32_t           *count_p);

/**
 * @brief Increment Ref count in the IPMC group DS
 *
 * @param [in]  node_id       - IFCS Node id
 * @param [in]  ds_hdl        - Data store handle
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_group_ds_ref_count_inc(
    ifcs_node_id_t    node_id,
    ifcs_handle_t     ds_hdl);

/**
 * @brief Decrement Ref count in the IPMC group DS
 *
 * @param [in]  node_id       - IFCS Node id
 * @param [in]  ds_hdl        - Data store handle
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_group_ds_ref_count_dec(
    ifcs_node_id_t    node_id,
    ifcs_handle_t     ds_hdl);

/**
 * @brief Set IPMC group OID in the IPMC Group  DS
 *
 * @param [in]  node_id          - IFCS Node id
 * @param [in]  ds_hdl           - Data store handle
 * @param [in]  oid              - IPMC group OID
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_group_ds_set_oid(
    const ifcs_node_id_t  node_id,
    const ifcs_handle_t   ds_hdl,
    const sai_object_id_t oid);

/**
 * @brief Set IPMC group MDG handle in the IPMC Group DS
 *
 * @param [in]  node_id          - IFCS Node id
 * @param [in]  ds_hdl           - Data store handle
 * @param [in]  mdg_hdl          - MDG handle
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_group_ds_set_mdg_hdl(
    const ifcs_node_id_t  node_id,
    const ifcs_handle_t   ds_hdl,
    const ifcs_handle_t   mdg_hdl);

/*
 * @brief Get OID from IPMC group ds entry
 *
 * @param [in]  node_id    - IFCS node id
 * @param [in]  ds_hdl     - Data store handle
 * @param [in]  oid_p      - Pointer to OID
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_group_ds_get_oid(
    ifcs_node_id_t                  node_id,
    ifcs_handle_t                   ds_hdl,
    sai_object_id_t                 *oid_p);

/*
 * @brief Get MDG handle from IPMC group ds entry
 *
 * @param [in]  node_id    - IFCS node id
 * @param [in]  ds_hdl     - Data store handle
 * @param [in]  mdg_hdl_p  - Pointer to MDG handle
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_group_ds_get_mdg_hdl(
    ifcs_node_id_t   node_id,
    ifcs_handle_t    ds_hdl,
    ifcs_handle_t    *mdg_hdl_p);

/**
 * @brief Gets IPMC group members
 *
 * @param [in] node_id          - IFCS node ID
 * @param [in] ipmc_group_oid   - IPMC Group Object ID
 * @param [in] obj_list_p       - Pointer to object list
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_group_get_mem_list(
    ifcs_node_id_t    node_id,
    sai_object_id_t   ipmc_group_oid,
    sai_object_list_t *obj_list_p);

/*
 * @brief Creates RIF Multicast Nexthop DS entry
 *
 * @param [in]  node_id                         - IFCS node id
 * @param [in] rif_mcast_nexthop_entry_p        - Pointer to rif_mcast_nexthop db entry
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_group_rif_nh_ds_entry_create(
    ifcs_node_id_t                       node_id,
    isai_shim_rif_mcast_nexthop_db_entry *rif_mcast_nexthop_entry_p);

/**
 * @brief Get RIF Multicast Nexthop Data Store Entry
 *
 * @param [in]  node_id                       - IFCS node id
 * @param [in]  rif_oid                       - RIF object ID
 * @param [out] rif_mcast_nexthop_entry_p     - Pointer to RIF Multicast Nexthop entry
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_group_rif_nh_ds_entry_get(
    ifcs_node_id_t                       node_id,
    sai_object_id_t                      rif_oid,
    isai_shim_rif_mcast_nexthop_db_entry *rif_mcast_nexthop_entry_p);

/**
 * @brief Get Ref count from RIF Multicast Nexthop Data Store
 *
 * @param [in]  node_id                       - IFCS node id
 * @param [in]  rif_oid                       - RIF object ID
 * @param [out] ref_count_p                   - Pointer to Ref count
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_group_rif_nh_ds_ref_count_get(
    ifcs_node_id_t  node_id,
    sai_object_id_t rif_oid,
    ifcs_handle_t   *ref_count_p);

/**
 * @brief Increment RIF Multicast Nexthop Ref Count
 *
 * @param [in]  node_id                - IFCS node_id
 * @param [in]  rif_oid                - RIF object ID
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_group_rif_nh_ds_ref_count_inc(
    ifcs_node_id_t  node_id,
    sai_object_id_t rif_oid);

/**
 * @brief Increment RIF Multicast Nexthop Ref Count
 *
 * @param [in]  node_id                - IFCS node_id
 * @param [in]  rif_oid                - RIF object ID
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_group_rif_nh_ds_ref_count_dec(
    ifcs_node_id_t  node_id,
    sai_object_id_t rif_oid);

/**
 * @brief Delete a given RIF Multicast Nexthop Data Store entry
 *
 * Caller provides a rif oid for the entry to be deleted
 * If object_id exists, then it is deleted from the database.
 *
 * @param [in]  node_id            - IFCS node_id
 * @param [in] rif_oid             - RIF OID
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_group_rif_nh_ds_entry_remove(
    ifcs_node_id_t  node_id,
    sai_object_id_t rif_oid);

/*
 * @brief Creates VLAN Multicast Nexthop DS entry
 *
 * @param [in] node_id                         - IFCS node id
 * @param [in] vlan_mcast_nexthop_entry_p      - Pointer to vlan_mcast_nexthop db entry
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_group_vlan_nh_ds_entry_create(
    ifcs_node_id_t                        node_id,
    isai_shim_vlan_mcast_nexthop_db_entry *vlan_mcast_nexthop_entry_p);

/**
 * @brief Get VLAN Multicast Nexthop Data Store Entry
 *
 * @param [in]  node_id                       - IFCS node id
 * @param [in]  vlan_oid                      - VLAN object ID
 * @param [out] vlan_mcast_nexthop_entry_p    - Pointer to VLAN Multicast Nexthop entry
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_group_vlan_nh_ds_entry_get(
    ifcs_node_id_t                        node_id,
    sai_object_id_t                       vlan_oid,
    isai_shim_vlan_mcast_nexthop_db_entry *vlan_mcast_nexthop_entry_p);

/**
 * @brief Get Ref count From Vlan Multicast Nexthop Data Store
 *
 * @param [in]  node_id         - IFCS node id
 * @param [in]  vlan_oid        - VLAN object ID
 * @param [out] ref_count_p     - Pointer to Ref count
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_group_vlan_nh_ds_ref_count_get(
    ifcs_node_id_t  node_id,
    sai_object_id_t vlan_oid,
    ifcs_handle_t   *ref_count_p);

/**
 * @brief Increment VLAN Multicast Nexthop Ref Count
 *
 * @param [in]  node_id                - IFCS node_id
 * @param [in]  vlan_oid                - VLAN object ID
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_group_vlan_nh_ds_ref_count_inc(
    ifcs_node_id_t  node_id,
    sai_object_id_t vlan_oid);

/**
 * @brief Decrement VLAN Multicast Nexthop Ref Count
 *
 * @param [in]  node_id                - IFCS node_id
 * @param [in]  vlan_oid                - VLAN object ID
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_group_vlan_nh_ds_ref_count_dec(
    ifcs_node_id_t  node_id,
    sai_object_id_t vlan_oid);

/**
 * @brief Delete a given VLAN Multicast Nexthop Data Store entry
 *
 * Caller provides a vlan oid for the entry to be deleted
 * If object_id exists, then it is deleted from the database.
 *
 * @param [in] node_id     - IFCS node_id
 * @param [in] vlan_oid    - VLAN OID
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_group_vlan_nh_ds_entry_remove(
    ifcs_node_id_t  node_id,
    sai_object_id_t vlan_oid);

/*
 * @brief Get ipmc_group_member DB entry from SAI ipmc group member attributes
 *     Used by internal shim function
 *     It store the entry into a internal shim structure format
 *
 * @param [in]  node_id       - IFCS node id
 * @param [in]  ds_handle     - Data store handle
 * @param [in]  ds_entry_p    - Pointer to shim ds entry structure
 * @return sai_status_t
 */

sai_status_t
isai_im_ipmc_group_member_ds_entry_get(
    ifcs_node_id_t                         node_id,
    ifcs_handle_t                          ds_handle,
    isai_shim_ipmc_group_member_ds_entry_t *ds_entry_p);

/*
 * @brief Get IPMC Group Member Count
 * @param [in]  node_id                -  node_id
 * @param [in]  ipmc_group_oid         -  IPMC Group Id
 * @param [out] mem_count_p            -  Member count pointer
 * @return sai_status_t
 */
sai_status_t
isai_im_ipmc_group_get_mem_cnt(
    ifcs_node_id_t  node_id,
    sai_object_id_t ipmc_group_oid,
    uint32_t        *mem_count_p);

/**
 * @brief Initializes IPMC group module
 *
 * @param [in]  sai_switch_init_info_p   - Pointer to swith init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_ipmc_group_init(sai_switch_init_info_t *sai_switch_init_info_p);


/**
 * @brief Un-initializes IPMC group module
 *
 * @param [in]  switch_deinit_info_p   - Pointer to switch de-init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_ipmc_group_deinit(sai_switch_deinit_info_t *switch_deinit_info_p);

#endif /* __IFCS_SAI_IPMC_GROUP_UTIL_H__ */
