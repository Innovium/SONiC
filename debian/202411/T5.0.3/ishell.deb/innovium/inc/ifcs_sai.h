/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License
 *Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */
/**
 * @file  ifcs_sai.h
 * @brief Definition for IFCS SAI Interface
 */

#ifndef __IFCS_IFCS_SAI_H__
#define __IFCS_IFCS_SAI_H__

#include "ifcs_init.h"
#include "ifcs_status.h"
#include "ifcs_types.h"
#include <assert.h>
#include <sai.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <unistd.h>

extern sai_service_method_table_t g_services;
extern bool g_initialized;
#define UNUSED(expr)                                                           \
  do {                                                                         \
    (void)(expr);                                                              \
  } while (0)

typedef uint32_t ifcs_sai_bitvec_t[32];   // do this dynammically
typedef uint32_t ifcs_sai_attr_info[128]; // max number of attributes.

/* Should be the same size as sai_object_id_t */
/* Should fix for big endian vs little endian */
typedef struct ifcs_sai_oid_base_s {
  uint8_t reserved[sizeof(sai_object_id_t) - 1];
  uint8_t type;
} ifcs_sai_oid_base_t;

sai_status_t ifcs_sai_set_bit(ifcs_sai_bitvec_t vec, uint32_t bit);

sai_status_t ifcs_sai_clear_bit(ifcs_sai_bitvec_t vec, uint32_t bit);

bool ifcs_sai_test_bit(ifcs_sai_bitvec_t vec, uint32_t bit);

sai_status_t ifcs_sai_parse_attr(ifcs_sai_bitvec_t attrs,
                                 ifcs_sai_attr_info attr_info,
                                 sai_attr_id_t max_attr_id, uint32_t attr_count,
                                 const sai_attribute_t *attr_list_p);

ifcs_status_t ifcs_sai_get_sysport_from_devport(ifcs_node_id_t node_id,
                                                uint32_t devport,
                                                uint32_t *sysport);

typedef sai_status_t (*sai_to_ifcs_translate_key_fn)(

    const void *sai_key, void *ifcs_key);
typedef sai_status_t (*sai_to_ifcs_translate_attr_fn)(
    sai_common_api_t api_type, uint32_t attr_count,
    const sai_attribute_t *attr_list_p,

    uint32_t *ifcs_attr_count, ifcs_attr_t **ifcs_attr_list_p);
typedef sai_status_t (*sai_to_ifcs_translate_object_id_fn)(
    sai_object_id_t sai_object_id, ifcs_handle_t *ifcs_handle);
typedef sai_status_t (*ifcs_to_sai_translate_attr_fn)(
    uint32_t ifcs_attr_count,

    ifcs_attr_t *ifcs_attr_list_p, uint32_t attr_count,
    sai_attribute_t *attr_list_p);
typedef sai_status_t (*ifcs_to_sai_translate_object_id_fn)(
    ifcs_handle_t ifcs_handle, sai_object_id_t *sai_object_id);

/**
 * @brief Next Hop methods table retrieved with sai_api_query()
 */
typedef struct _sai_ifcs_shim_t {

  sai_to_ifcs_translate_key_fn sai_to_ifcs_translate_key;
  sai_to_ifcs_translate_attr_fn sai_to_ifcs_translate_attr;
  sai_to_ifcs_translate_object_id_fn sai_to_ifcs_translate_object_id;
  ifcs_to_sai_translate_attr_fn ifcs_to_sai_translate_attr;
  ifcs_to_sai_translate_object_id_fn ifcs_to_sai_translate_object_id;

} sai_ifcs_shim_t;

extern sai_status_t sai_api_shim_initialize(sai_api_t sai_api_id,
                                            sai_ifcs_shim_t *shim_ptr);
extern sai_ifcs_shim_t g_sai_api_shims[SAI_API_MAX];
typedef pthread_mutex_t ifcs_sai_shim_mlock_t;
extern ifcs_sai_shim_mlock_t
    g_switch_creation_lock; /// < Mutex to protect switch creation

extern const sai_acl_api_t acl_api;
extern const sai_ars_api_t ars_api;
extern const sai_ars_profile_api_t ars_profile_api;
extern const sai_bridge_api_t bridge_api;
extern const sai_buffer_api_t buffer_api;
extern const sai_counter_api_t counter_api;
extern const sai_debug_counter_api_t debug_counter_api;
extern const sai_fdb_api_t fdb_api;
extern const sai_hash_api_t hash_api;
extern const sai_hostif_api_t hostif_api;
extern const sai_ipmc_api_t ipmc_api;
extern const sai_ipmc_group_api_t ipmc_group_api;
extern const sai_isolation_group_api_t isolation_group_api;
extern const sai_l2mc_api_t l2mc_api;
extern const sai_l2mc_group_api_t l2mc_group_api;
extern const sai_lag_api_t lag_api;
extern const sai_mirror_api_t mirror_api;
extern const sai_my_mac_api_t my_mac_api;
extern const sai_neighbor_api_t neighbor_api;
extern const sai_next_hop_api_t next_hop_api;
extern const sai_next_hop_group_api_t next_hop_group_api;
extern const sai_policer_api_t policer_api;
extern const sai_port_api_t port_api;
extern const sai_qos_map_api_t qos_map_api;
extern const sai_queue_api_t queue_api;
extern const sai_route_api_t route_api;
extern const sai_virtual_router_api_t virtual_router_api;
extern const sai_router_interface_api_t router_interface_api;
extern const sai_rpf_group_api_t rpf_group_api;
extern const sai_samplepacket_api_t samplepacket_api;
extern const sai_scheduler_api_t scheduler_api;
extern const sai_scheduler_group_api_t scheduler_group_api;
extern const sai_stp_api_t stp_api;
extern const sai_switch_api_t switch_api;
extern const sai_synce_api_t synce_api;
extern const sai_tam_api_t tam_api;
extern const sai_tunnel_api_t tunnel_api;
extern const sai_udf_api_t udf_api;
extern const sai_vlan_api_t vlan_api;
extern const sai_wred_api_t wred_api;
/*
 * @brief Converts SAI key to IFCS key
 *
 * @param [in]  sai_api_id - SAI api ID
 * @param [in]  sai_key    - SAI Key
 * @param [out] ifcs_key   - IFCS key
 * @return sai_status_t
 */

sai_status_t sai_to_ifcs_translate_key(sai_api_t sai_api_id,
                                       const void *sai_key, void *ifcs_key);

/*
 * @brief Converts SAI attr to IFCS attr
 *
 * @param [in]  sai_api_id       - SAI api ID
 * @param [in]  attr_count       - SAI Attr count
 * @param [in]  attr_list_p      - SAI Attr pointer
 * @param [out] ifcs_attr_count  - IFCS attr count
 * @param [out] ifcs_attr_list_p - IFCS attr list
 * @return sai_status_t
 */

sai_status_t sai_to_ifcs_translate_attr(sai_api_t sai_api_id,
                                        sai_common_api_t api_type,
                                        uint32_t attr_count,
                                        const sai_attribute_t *attr_list_p,
                                        uint32_t *ifcs_attr_count,
                                        ifcs_attr_t **ifcs_attr_list_p);

/*
 * @brief Converts SAI object_id to ifcs handle
 *
 * @param [in]  sai_api_id    - SAI api ID
 * @param [in]  sai_object_id - SAI Object_id
 * @param [out] ifcs_handle   - ifcs handle
 * @return sai_status_t
 */

sai_status_t sai_to_ifcs_translate_object_id(sai_api_t sai_api_id,
                                             sai_object_id_t sai_object_id,
                                             ifcs_handle_t *ifcs_handle);

/*
 * @brief Converts SAI attr to IFCS attr
 *
 * @param [in]  sai_api_id        - SAI api ID
 * @param [in]  ifcs_attr_count   - IFCS Attr count
 * @param [in]  ifcs_attr_list_p  - IFCS Attr pointer
 * @param [out] attr_count        - SAI attr count
 * @param [out] attr_list_p       - SAI attr list
 * @return sai_status_t
 */

sai_status_t ifcs_to_sai_translate_attr(sai_api_t sai_api_id,
                                        uint32_t ifcs_attr_count,
                                        ifcs_attr_t *ifcs_attr_list_p,
                                        uint32_t attr_count,
                                        sai_attribute_t *attr_list_p);

/*
 * @brief Converts SAI object_id to ifcs handle
 *
 * @param [in] sai_api_id  - SAI api ID
 * @param [in] ifcs_handle - Ifcs Handle
 * @param [out] object_id  - SAI object_id
 * @return sai_status_t
 */

sai_status_t ifcs_to_sai_translate_object_id(sai_api_t sai_api_id,
                                             ifcs_handle_t ifcs_handle,
                                             sai_object_id_t *object_id);

/*
 * @brief Converts IFCS status to SAI status
 *
 * @param [in] ifcs_status - Ifcs status
 * @param [out] sai_status - SAI status
 * return sai_status_t
 */
sai_status_t ifcs_to_sai_translate_status(ifcs_status_t ifcs_status);
sai_status_t sai_api_shim_init(void);
#endif /* __IFCS_IFCS_SAI_H__ */
