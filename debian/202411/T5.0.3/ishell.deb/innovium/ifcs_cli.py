#-------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------

import cmd
import cli
import sys
import os

from cmdmgr import CmdMgr
from utils.compat_util import compat_bytesToStr
from verbosity import *
from ctypes import *

class IFCS_CLI(cli.CLI):
    def __init__(self, intro=''):
        cli.CLI.__init__(self)
        self.supported_env  = ['board', 'emulator', 'switch']
        self.intro          = intro
        self.node_id        = None
        self.cmdmgr         = CmdMgr()
        self.num_nodes      = 0
        self.remote_mode    = False
        self.server_mode    = False
        self.server_object  = None
        self.debug_mode     = 0
        self.privilege_mode = 0
        self.standalone     = False
        self.ifcs_ctypes    = sys.modules['ifcs_ctypes']
        """
            For every new environment we intend to run the cli on, add
            a name for the environment here if we wish import a module
            specific to that environment
        """
        self.rt_env         = ''
        """
            Board is used for internal board development environment
            emulator is used for internal emulator environment
            switch is used in external environments.
        """
        self.set_prompt()

    def set_standalone(self, flag):
        self.standalone = flag

    def set_prompt(self):
        if not self.remote_mode:
            if self.node_id is None:
                self.prompt = 'IVM>'
            else:
                self.prompt = 'IVM:' + str(self.node_id) + '>'
        else:
            if self.node_id is None:
                self.prompt = 'IVM-R>'
            else:
                self.prompt = 'IVM-R:' + str(self.node_id) + '>'

    def set_server_mode(self, flag):
        self.server_mode = flag

    def set_server_object(self, obj):
        self.server_object = obj

    def set_remote(self, flag):
        self.remote_mode = flag
        self.set_prompt()

    def set_remote_port(self, port):
        self.remote_port = port

    def set_node_id(self, node_id):
        if node_id is None:
            self.node_id = None
            return
        elif (node_id < 0 or node_id > 16):
            log_err("Invalid node id {0}".format(node_id))
            return
        else:
            self.node_id = node_id
            log_dbg(1, "Node {0} set successfully".format(node_id))
            return

    def set_rt_env(self, env):
        if env in self.supported_env:
            self.rt_env = env
            log_dbg(1, "Setting CLI runtime environment to " + env)
        else:
            log_err("Environment " + env + " not supported")
            raise LookupError

    def config(self, configfile):
        nodes = c_uint32(0)
        boot = self.ifcs_ctypes.IFCS_BOOT_COLD
        try:
            if int(os.environ['WBRESTART']) == 1:
                boot = self.ifcs_ctypes.IFCS_BOOT_WARM
                log("Starting with WB restart IFCS_WB_FILE="+ os.environ['IFCS_WB_FILE'])
        except:
            pass
        rc = self.ifcs_ctypes.ifcs_init(
            configfile.encode('utf-8') if configfile else None,
            b"cli_sh",
            boot,
            pointer(nodes))
        if (rc == self.ifcs_ctypes.IFCS_SUCCESS):
            log_dbg(1, 'ifcs_init success')
        else:
            rc = compat_bytesToStr(
                self.ifcs_ctypes.ifcs_status_to_string(rc)).split('.')
            rc = rc[len(rc) - 1]
            log_err('ifcs_init fail - rc = ' + rc)
            return
        log_dbg(1, str(self.num_nodes) + " Innovium nodes detected")
        self.num_nodes = nodes.value

    def init_cmds(self):
        if not self.remote_mode and not self.standalone:
            return

        import pencmd
        import node
        import config
        import diagtest
        import pcicmd
        import port
        import pktcmd
         
        import verbosity
        import reloadcmd
        import errorcmd
        import privilege_mode
        import l2learn
        import blkpencmd
        import ifcscmd
        import showcmd
        #import credo_serdes
        try:
            import isaicmd
        except Exception as e:
            log_dbg(1, "{}".format(e))
            pass
        try:
            import debug
            import service
            import vendor_debug
        except:
            pass

        self.cmdmgr.add_cmd("verbosity", verbosity.Verbosity(self))
        self.node = node.Node(self)
        self.cmdmgr.add_cmd("node", self.node)
        self.cmdmgr.add_cmd("pen", pencmd.Pen(self))
        self.cmdmgr.add_cmd("config", config.Config(self))
        self.cmdmgr.add_cmd("diagtest", diagtest.Diagtest(self))
        self.cmdmgr.add_cmd("port", port.Port(self))
        self.cmdmgr.add_cmd("pci", pcicmd.Pci(self))
        self.cmdmgr.add_cmd("pkt", pktcmd.Pkt(self))
 
        self.cmdmgr.add_cmd("privilege", privilege_mode.Privilege_mode(self))
        self.cmdmgr.add_cmd("reload", reloadcmd.ReloadCmd(self))
        self.cmdmgr.add_cmd("l2learn", l2learn.L2learn(self))

        self.cmdmgr.add_cmd("blkpen", blkpencmd.Blkpen(self))

        self.cmdmgr.add_cmd("errors", errorcmd.Errors(self))
        #self.cmdmgr.add_cmd("serdes", credo_serdes.Credo(self))
 
        # Import environment specific modules and commands
        if self.rt_env == 'switch' or self.rt_env == 'emulator' or self.rt_env == 'board':
            self.cmdmgr.add_cmd("ifcs", ifcscmd.Ifcs(self))
            self.cmdmgr.add_cmd("im", ifcscmd.Im(self))
            self.cmdmgr.add_cmd("debug", debug.Debug(self))
            self.cmdmgr.add_cmd("service", service.Service(self))
            self.cmdmgr.add_cmd("show", showcmd.Show(self))
            try:
                self.cmdmgr.add_cmd("isai", isaicmd.Isai(self))
            except Exception as e:
                log_dbg(1, "{}".format(e))
                pass

            self.cmdmgr.add_cmd("debugparser", vendor_debug.DebugParser(self))

        if self.rt_env == 'board':
            try:
                import board1
                self.cmdmgr.add_cmd("board1", board1.Board1(self))
            except BaseException:
                pass
