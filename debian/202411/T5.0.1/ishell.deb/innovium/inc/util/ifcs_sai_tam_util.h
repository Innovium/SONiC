/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_tam_util.h
 * @brief ISAI Util Include file for TAM_INT module
 */


#ifndef __IFCS_SAI_TAM_UTIL_H__
#define __IFCS_SAI_TAM_UTIL_H__

#include "util/ifcs_sai_tam_util_dep.h"

/*
 * @brief  Initializes tam module
 *
 * @param [in]  sai_switch_init_info_p - Pointer to switch init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_tam_init(
    sai_switch_init_info_t *sai_switch_init_info_p);
/*
 * @brief Get the IFCS tam_int handle for a given target OID.
 * @param [in] node_id        - Node ID
 * @param [in] tam_int_oid    - TAM_INT OID.
 * @param [out] tam_int_handle_p - Return pointer to tam_int handle.
 *
 * @return sai_status_t
 */
extern sai_status_t
isai_im_tam_get_tam_int_handle(ifcs_node_id_t node_id,
                               sai_object_id_t tam_int_oid,
                               ifcs_handle_t   *tam_int_handle_p);

/*
 * @brief Get the IFCS tam_int handle for a given target OID.
 * @param [in] node_id        - Node ID
 * @param [in] tam_int_oid    - TAM_INT OID.
 * @param [out] tam_int_handle_p - Return pointer to tam_int handle.
 *
 * @return sai_status_t
 */
extern sai_status_t
isai_im_tam_create_tam_int_acl_user(ifcs_node_id_t node_id,
                               sai_object_id_t tam_int_oid,
                               ifcs_handle_t   *tam_int_handle_p);

/*
 * @brief Update ref count for a given tam int OID.
 * @param [in] node_id        - Node ID
 * @param [in] tam_int_oid    - TAM_INT OID.
 * @param [in] increment      - increment ref count
 * @param [in] delete_on_zero - delete if ref count reaches zero 
 *
 * @return sai_status_t
 */
sai_status_t
isai_im_tam_int_update_ref_count(ifcs_node_id_t  node_id,
                                 sai_object_id_t tam_int_oid,
                                 bool            increment,
                                 bool            delete_on_zero);

 /** @brief Update ref count for a given tam OID.
 * @param [in] node_id        - Node ID
 * @param [in] tam_oid        - TAM OID.
 * @param [in] increment      - increment ref count
 * @param [in] delete_on_zero - delete if ref count reaches zero 
 *
 * @return sai_status_t
 */
sai_status_t
isai_im_tam_update_ref_count(ifcs_node_id_t node_id,
                             sai_object_id_t tam_oid,
                             bool increment,
                             bool delete_on_zero);

/*
 * @brief Get the HDC policy for a given tam OID.
 * @param [in] node_id        - Node ID
 * @param [in] tam_oid        - TAM OID.
 * @param [out] tam_hdc_policy - Return pointer to tam_hdc_policy.
 *
 * @return sai_status_t
 */
sai_status_t
isai_im_tam_hdc_policy_get(ifcs_node_id_t node_id, sai_object_id_t tam_oid,
                           ifcs_hdc_policy_t *hdc_policy);
/*
 * @brief Get the BDC policy for a given tam OID.
 * @param [in] node_id        - Node ID
 * @param [in] tam_oid        - TAM OID.
 * @param [out] tam_bdc_policy - Return pointer to tam_bdc_policy.
 *
 * @return sai_status_t
 */
sai_status_t
isai_im_tam_bdc_policy_get(ifcs_node_id_t node_id, sai_object_id_t tam_oid,
                           ifcs_bdc_policy_t *bdc_policy);

/*
 * @brief Get the tam event type for a given tam OID.
 * @param [in] switch_oid     - Switch OID
 * @param [in] tam_oid        - TAM OID.
 * @param [out] is_event_type_mod_p - Return pointer to is_event_type_mod.
 * @param [out] event_type_p  - Return pointer to event_type.
 *
 * @return sai_status_t
 */
sai_status_t
isai_im_tam_tam_event_type_get(sai_object_id_t switch_oid, sai_object_id_t tam_oid,
                               bool *is_event_type_mod_p, uint32_t *event_type_p);
#endif /* __IFCS_SAI_TAM_UTIL_H__ */
