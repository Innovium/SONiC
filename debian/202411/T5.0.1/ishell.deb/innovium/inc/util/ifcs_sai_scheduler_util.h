/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_scheduler_util.h
 * @brief ISAI Util Include file for SCHEDULER module
 */


#ifndef __IFCS_SAI_SCHEDULER_UTIL_H__
#define __IFCS_SAI_SCHEDULER_UTIL_H__

#include "util/ifcs_sai_scheduler_util_dep.h"

/*
 * @brief  Initializes scheduler module
 *
 * @param [in]  sai_switch_init_info_p - Pointer to switch init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_scheduler_init(
    sai_switch_init_info_t *sai_switch_init_info_p);

/*
 * @brief Initialize defaults SAI attr for scheduler obj
 *
 * @param [in,out] obj_p        - Scheduler DSO object
 * @param [in] id        - Scheduler OID
 * @return sai_status_t
 */
sai_status_t
isai_im_scheduler_default_attr(
    isai_shim_qos_info_t *obj_p,
    sai_object_id_t      id);

/*
 * @brief Fill defaults SAI attr for scheduler obj if user has not provided
 * those values.
 *
 * @param [in] id        -     node_Id
 * @param [in,out] obj_p        - Scheduler DSO object
 * @return sai_status_t
 */
sai_status_t
isai_im_scheduler_default_attr_fill(ifcs_node_id_t       node_id,
                                    isai_shim_qos_info_t *obj_p);


/*
 * @brief Converts SAI attr to IFCS attr
 *
 * @param [in] switch_id        - Switch OID
 * @param [in] api_type        - CRUD operation type
 * @param [in] attr_count        - SAI Attr count
 * @param [in] attr_list_p       - SAI Attr pointer
 * @param [out] ifcs_attr_count  - IFCS attr count
 * @param [out] ifcs_attr_list_pp - IFCS attr list
 * @return sai_status_t
 */
sai_status_t
isai_im_scheduler_attr_stoi(
    sai_object_id_t       switch_id,
    sai_common_api_t      api_type,
    uint32_t              attr_count,
    const sai_attribute_t *attr_list_p,
    uint32_t              *ifcs_attr_count,
    ifcs_attr_t           **ifcs_attr_list_pp,
    bool                  is_data_rate_mode_changed);

/*
 * @brief Converts SAI attr to IFCS attr for scheduler obj for CPU queue
 *
 * @param [in] cpu_queue_id        - cpu_queue OID
 * @param [in] api_type        - CRUD operation type
 * @param [in] attr_count        - SAI Attr count
 * @param [in] attr_list_p       - SAI Attr pointer
 * @param [out] ifcs_attr_count  - IFCS attr count
 * @param [out] ifcs_attr_list_pp - IFCS attr list
 * @return sai_status_t
 */
sai_status_t
isai_im_scheduler_cpu_q_attr_stoi(
    sai_object_id_t       cpu_queue_id,
    sai_common_api_t      api_type,
    uint32_t              attr_count,
    const sai_attribute_t *attr_list_p,
    uint32_t              *ifcs_attr_count,
    ifcs_attr_t           **ifcs_attr_list_pp);

/*
 * @brief Converts SAI attr to IFCS attr for scheduler obj for CPU port
 *
 * @param [in] port_id        - port OID
 * @param [in] api_type        - CRUD operation type
 * @param [in] attr_count        - SAI Attr count
 * @param [in] attr_list_p       - SAI Attr pointer
 * @param [out] ifcs_attr_count  - IFCS attr count
 * @param [out] ifcs_attr_list_pp - IFCS attr list
 * @return sai_status_t
 */
sai_status_t
isai_im_scheduler_cpu_port_attr_stoi(
    sai_object_id_t       port_id,
    sai_common_api_t      api_type,
    uint32_t              attr_count,
    const sai_attribute_t *attr_list_p,
    uint32_t              *ifcs_attr_count,
    ifcs_attr_t           **ifcs_attr_list_pp);

/*
 * @brief Converts SAI attr to IFCS attr for scheduler obj for front panel port
 *
 * @param [in] port_id        - port OID
 * @param [in] api_type        - CRUD operation type
 * @param [in] attr_count        - SAI Attr count
 * @param [in] attr_list_p       - SAI Attr pointer
 * @param [out] ifcs_attr_count  - IFCS attr count
 * @param [out] ifcs_attr_list_pp - IFCS attr list
 * @return sai_status_t
 */
sai_status_t
isai_im_scheduler_fp_port_attr_stoi(
    sai_object_id_t       port_id,
    sai_common_api_t      api_type,
    uint32_t              attr_count,
    const sai_attribute_t *attr_list_p,
    uint32_t              *ifcs_attr_count,
    ifcs_attr_t           **ifcs_attr_list_pp,
    bool                  is_data_rate_mode_changed);

/**
 * @brief Fill log params for a given scheduler
 *
 * @param [in]  attr_list_p        - Attribute list
 * @param [in]  attr_count         - Number of attributes
 * @param [out] scheduler_params   - Scheduler params
 * @return sai_status_t
 */
sai_status_t
isai_im_scheduler_fill_log_params(sai_object_id_t switch_id,
                                  const sai_attribute_t *attr_list_p,
                                  uint32_t attr_count,
                                  scheduler_sai_params_t *scheduler_params);


sai_status_t
isai_im_scheduler_obj_validate(sai_object_id_t object_id);

/**
 * @brief Attach/detach a SAI object to another SAI object.
 * Eg: attach a scheduler to a queue
 * Type information is encoded in the object-ids.
 * @param[in] scheduler_object_id - object that is being attached
 * @param[in] bindpoint_obj_id - object to which we are attaching
 * @param[in] is_attach - if true attach else detach
 * @return sai_status_t
 */
sai_status_t
isai_im_scheduler_sai_object_attach(sai_object_id_t scheduler_object_id,
                                    sai_object_id_t bindpoint_obj_id,
                                    bool is_attach);

/**
 * @brief set scheduler for a given port
 *
 * @param [in] node_id           - node_id
 * @param [in] port_oid          - port object_id
 * @param [in] attr_list_p       - Attribute list
 * @param [in] prev_sched_id     - previous scheduler if attached
 * @return sai_status_t
 */
sai_status_t
isai_im_scheduler_port_scheduler_set(ifcs_node_id_t        node_id,
                                     sai_object_id_t       port_oid,
                                     const sai_attribute_t *attr_list_p,
                                     sai_object_id_t       prev_sched_id);

/**
 * @brief Program hardware on attach of a SAI object to another SAI object.
 * Eg: attach a scheduler to a queue, update the queue' scheduling related
 * attributes.
 * @param[in] action_obj_id   -  object that is being attached;
 *                               pass SAI_NULL_OBJECT_ID to signify unprogram.
 * @param[in] action_obj_type -  isai action object type when
 *                               action_obj_type is SAI_NULL_OBJECT_ID
 * @param[in] target_obj_id   -  object to which we are attaching
 * @return sai_status_t
 */
sai_status_t
isai_im_scheduler_hw_update(ifcs_node_id_t  node_id,
                            sai_object_id_t action_obj_id,
                            sai_object_type_t  action_obj_type,
                            sai_object_id_t target_obj_id);

#endif /* __IFCS_SAI_SCHEDULER_UTIL_H__ */
