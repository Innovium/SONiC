#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import cmd
import shlex
import sys
import os
import code
import string
from ctypes import *
from ifcs_ctypes import *
from utils.compat_util import *
from verbosity import *
from cmdmgr import CmdMgr
from print_table import PrintTable

def run_script(arg):
    try:
        args = arg.split(" ")
        module_ = args[0]
        module_args = " ".join(args[1:])
        module = __import__(module_)
        compat_reload(module)
        module.main(module_args)
    except Exception as e:
        log("{} : {}".format("Error", sys.exc_info()))
    del module

class IvmShell():
    def __init__(self):
        self.invocation_count =  0
        self.ivm_shell_help   =  " This is an interactive python interpreter console. \n", \
                                 " You can import your custom python modules or scripts from here. \n"
        self.ivm_banner_help  =  " Type \"help()\" for more information, \"exit() \" or \"quit() \" to return to Innovium command shell."
        self.ivm_banner       =  " Innovium Interactive Python Console, %s on %s\n %s" % (sys.version, sys.platform, self.ivm_banner_help)
        self.ivm_shell_locals =  {
                                        "exit"      : self.raise_sys_exit,
                                        "quit"      : self.raise_sys_exit,
                                        "help"      : self.print_cli_help,
                                        "count"     : self.print_cli_count,
                                        "countadd"  : self.set_cli_count,
                                        "rshell"    : self.start_rshell
                                 }

    def raise_sys_exit(self):
        raise SystemExit

    def print_cli_help(self):
        log(self.ivm_shell_help)

    def print_cli_count(self):
        log(self.invocation_count)

    def set_cli_count(self):
        self.invocation_count = self.invocation_count + 1
        return self.invocation_count

    def do_interact(self):
        try:
            code.interact(local=self.ivm_shell_locals,banner=self.ivm_banner)
        except SystemExit:
            self.invocation_count = self.invocation_count + 1
            return
    def start_rshell(self,
                     port=7105,
                     host='localhost',
                     log_file_name=None,
                     flush_interval_sec=60):
        # For safety, recommended to use localhost for host.
        from ifcscshell import main
        from threading import Thread
        import os; os.environ['IFCS_INNO_CLI_PORT'] = str(port)
        os.environ['IFCS_INNO_CLI_HOST'] = host
        cli_thread = Thread(target=main,
                            args=(log_file_name, flush_interval_sec))
        cli_thread.daemon = True
        cli_thread.start()

class CLI(cmd.Cmd):
    def __init__(self):
        global ifcs_error
        cmd.Cmd.__init__(self, completekey='tab')
        self.ivmshell = None
        self.cmdqueue = []
        self.sourceobjects = []
        self.sourcenames = []
        self.history = []
        self.cmdcount = 0
        self.MAX_HISTORY_COUNT = 1000
        self.redirect_fd = None
        self.stdout = sys.stdout
        ifcs_error = 0

    def error(self):
        global ifcs_error
        ifcs_error = 1

    def do_history(self, arg):
        for line,num in zip(self.history,range(len(self.history))):
            if line:
                log(str(num) + "  " + line)
        log(" Type the # next to the command you wish to re-run\n")

    def do_quit(self, arg):
        # quit gracefully
        return True

    def do_console(self, arg):
        self.ivmshell = IvmShell()
        self.ivmshell.do_interact()

    def do_source(self, arg):
        if arg in self.sourcenames:
            log("Recursive source command to file %s from file %s" % (arg, self.sourcenames[-1]))
            log("   Trace of source files:")
            for i in self.sourcenames:
                log("      {}".format(i))
            self.sourcenames = []
            self.sourceobjects = []
            return 0

        try:
            f = open(arg, 'r')
            self.sourceobjects.append(f)
            self.sourcenames.append(arg)
        except:
            log_dbg(
                1, "Exception opening source file {}: {}".format(
                    arg, sys.exc_info()))
            log("Invalid source filename - {}".format(arg))
            self.sourcenames = []
            self.sourceobjects = []
            return -1

        if self.remote_mode is True:
            if not self.cmdqueue:
                try:
                    while True:
                        if not self.sourceobjects:
                            break

                        line = self.sourceobjects[-1].readline()
                        if line:
                            self.onecmd(line)
                        else:
                            self.sourceobjects.pop().close()
                except BaseException as e:
                    log_dbg(
                        1, "Exception in source {} command : {}".format(
                            arg, sys.exc_info()))
                    log_err("Unexpected error: {}".format(e))
                    return -1

        return 0

    def do_redirect(self, arg):

        # help strings
        usage_help = " Usage: \n \tredirect /path-to-file/file"
        stop_help  = " (type \"redirect stop\" to stop redirecting)."

        # Check for a valid file name
        if arg == '':
            log(usage_help)
            return

        # check if that file already exists.
        if os.path.exists(arg):
            log(" File " + arg + " exists!")
            return

        if "stop" not in arg and self.redirect_fd:
            # /* Not supporting multiple redirect sessions at the moment. */
            log(" Already redirecting. " + stop_help)
            return
        elif "stop" in arg and self.redirect_fd:
            """
                stop redirecting case
                we check for stop ahead of time because open will succeed
                even if the file was already opened before.
                So, in the try block: redirect stop will end up opening a file 'stop'
             """
            self.redirect_fd.close()
            self.redirect_fd = None
            log(" Stopped redirecting.")
            return
        elif "stop" in arg and self.redirect_fd is None:
            # /* trying to stop redirecting when it wasn't started. */
            log(" Redirect not started.")
            log(usage_help)
            return

        # Try to open the file in arg
        try:
            f = open(arg,'w')
            self.redirect_fd = f
            log(" Redirecting to {} {}".format(arg, stop_help))
        except Exception as e:
            log_dbg(
                1, "Exception in redirect {} command : {}".format(
                    arg, sys.exc_info()))
            log(" Failed to start redirecting: {}".format(e))
            return

    def do_exit(self, arg):
        return True



    def do_deinit(self, arg):
        if self.remote_mode is True:
            log("Not supported in remote shell")
            return
        log("De-initializing IFCS...")
        ifcs_deinit(IFCS_SHUTDOWN_TYPE_COLD)
        return True

    def do_replay(self, arg):
        if self.remote_mode is True:
            log("Not supported in remote shell")
            return
        im_log_rec_params_restore(arg, ifcs_api_replay_cb_t(im_api_replay), 1)
        return

    def do_run(self, arg):
        if self.remote_mode is True:
            line = "run " + arg
            return self.run_remote_shell_command(line)
        else:
            try:
                log("Executing {}".format(arg))
                run_script(arg)
            except Exception as e:
                log_dbg(
                    1, "Exception in run {} command : {}".format(
                        arg, sys.exc_info()))
                log("Unexpected error: {}".format(e))

    def do_shell(self, arg):
        try:
            os.system(arg)
        except Exception as e:
            log_dbg(
                1, "Exception in shell {} command : {}".format(
                    arg, sys.exc_info()))
            log("Unexpected error: {}".format(e))

    def do_clear(self, arg):
        os.system("clear")

    def do_setup_modules(self, arg):

        import pencmd
        import node
        import config
        import diagtest
        import pcicmd
        import port
        import pktcmd
        import verbosity
        import reloadcmd
        import errorcmd
        import l2learn

        import ifcscmd
        try:
            import isaicmd
        except Exception as e:
            log_dbg(1, "Ignored exception {}".format(e))
            pass

        import vendor_debug
        import debug
        import service
        import showcmd

        self.cmdmgr.add_cmd("verbosity", verbosity.Verbosity(self))
        self.node = node.Node(self)
        self.cmdmgr.add_cmd("node", self.node)
        self.cmdmgr.add_cmd("pen", pencmd.Pen(self))
        self.cmdmgr.add_cmd("config", config.Config(self))
        self.cmdmgr.add_cmd("diagtest", diagtest.Diagtest(self))
        self.cmdmgr.add_cmd("port", port.Port(self))
        self.cmdmgr.add_cmd("pci", pcicmd.Pci(self))
        self.cmdmgr.add_cmd("pkt", pktcmd.Pkt(self))
        self.cmdmgr.add_cmd("reload", reloadcmd.ReloadCmd(self))
        self.cmdmgr.add_cmd("l2learn", l2learn.L2learn(self))
        self.cmdmgr.add_cmd("errors", errorcmd.Errors(self))
        self.cmdmgr.add_cmd("ifcs", ifcscmd.Ifcs(self))
        self.cmdmgr.add_cmd("im", ifcscmd.Im(self))
        try:
            self.cmdmgr.add_cmd("isai", isaicmd.Isai(self))
        except Exception as e:
            log_dbg(1, "Ignored exception {}".format(e))
            pass

        self.cmdmgr.add_cmd("debug", debug.Debug(self))
        self.cmdmgr.add_cmd("service", service.Service(self))
        self.cmdmgr.add_cmd("show", showcmd.Show(self))
        self.cmdmgr.add_cmd("debugparser", vendor_debug.DebugParser(self))

    def handle_debug_cli_show_summary(self):
        table = PrintTable()
        table.set_justification("left")
        table.add_row(["CLI shell server debug field", "Value"])
        table.add_row(["Python version", sys.version.split()[0]])
        table.add_row(["Total number of commands executed", self.cmdcount])
        table.add_row(["Maximum command history count", self.MAX_HISTORY_COUNT])
        table.add_row(["Current command history count", len(self.history)])
        try:
            if self.server_object:
                stats = self.server_object.get_server_stats()
                for k, v in stats.items():
                    table.add_row([k, v])
        except BaseException:
            table.add_row(["Server object exception", str(sys.exc_info())])
        table.print_table()
        table.reset_table()

    def handle_debug_cli_clear_counters(self):
        self.cmdcount = 0
        self.history = []
        try:
            if self.server_object:
                self.server_object.clear_server_stats()
        except BaseException:
            log("Server object exception: {}".format(str(sys.exc_info())))

    def emptyline(self):
        im_log_flush()  # flush log buffer (for testing/debug)
        pass

    def precmd(self, line):
        return line

    def filecompletions(self, line, text):
        self.completions = []
        try:
            prev = re.sub(r'%s$' % text, '', line)
            dir = os.path.dirname(prev)
            pfn = os.path.basename(prev)
        except:
            return

        if dir == "":
            dir = "./"

        for j in os.listdir(dir):
            if j.startswith(pfn + text):
                match = re.sub(r'^%s' % pfn, '', j)
                if os.path.isdir(dir + "/" + j):
                    match = match + '/'
                self.completions.append(match)

    def check_and_paginate(self, line):
        paginate        = False
        per_print_lines = 0
        if not 'filter' in line:
            return line, per_print_lines, paginate

        if not 'more' in line:
            return line, per_print_lines, paginate

        self.rows, self.columns = os.popen('stty size', 'r').read().split()
        self.rows       = int(self.rows)
        self.columns    = int(self.columns)

        args            = line.split()
        paginate        = True
        per_print_lines  = self.rows - 10
        if per_print_lines <= 0:
            paginate = False
        args = args[:-2]
        line = " ".join(args)
        return line, per_print_lines, paginate

    def receive_response(self):
        # /* recieve the response */
        return_buf = ''
        recv_size = 102400
        current_size = 0
        actual_size = 0
        total_size = 0
        while True:
            # /* recv data upto a maximum of recv_size */
            recv_data = compat_bytesToStr(self.remote_port.recv(recv_size))

            # /* retrieve the data buffer */
            try:
                return_buf += recv_data.split(':::')[1]
                total_size = int(recv_data.split(':::')[0])
                current_size = len(recv_data.split(':::')[1])
            except:
                # /* this could be the second or more iteration of recv */
                return_buf += recv_data
                current_size = len(recv_data)

            # /* decide whether to continue the loop or exit */
            actual_size += current_size
            if actual_size < total_size:
                continue
            else:
                break

        return return_buf

    def check_and_display(self, return_buf, per_print_lines, paginate):
        if self.redirect_fd:
            self.redirect_fd.write(return_buf)

        if paginate:
            return_buf_lines = return_buf.split('\n')
            if len(return_buf_lines) < per_print_lines:
                log(return_buf)
            else:
                i = 0
                while i < len(return_buf_lines):
                    log('\n'.join(return_buf_lines[i:i + per_print_lines]))
                    compat_raw_input()
                    i += per_print_lines
        else:
            log(return_buf)

    def run_remote_shell_command(self, line):
        # /* check for pagination */
        line, per_print_lines, paginate = self.check_and_paginate(line)

        # /* run the command */
        self.remote_port.send(compat_strToBytes(line))

        # /* receive reponse from server */
        return_buf = self.receive_response()

        # /* check and display output */
        self.check_and_display(return_buf, per_print_lines, paginate)


    def default(self, wholeline):
        global ifcs_error
        rc = None
        lines = wholeline.split(';')
        for line in lines:
            try:
                arg_list = shlex.split(line)
            except Exception as e:
                log_dbg(
                    1,
                    "Exception processing in default handler for command argument [{}] : {}".format(
                        line, sys.exc_info()))
                log_err("Error processing command arguments : {}".format(e))
                return line

            #find command
            if self.check_for_help_in_args(line):
                try:
                    self.cmdmgr.find_cmd(arg_list[0]).help(line)
                except BaseException:
                    log_dbg(
                        1,
                        "Ignored expected exception in default help handler for command [{}] : {}".format(
                            line, sys.exc_info()))
                    pass
            else:
                if self.remote_mode is True:
                    return self.run_remote_shell_command(line)
                else:
                    cmd_class = self.cmdmgr.find_cmd(arg_list[0])
                    try:
                        ifcs_error = 0;
                        self.stdout.write("\n")
                        self.stdout.flush()
                        rc = cmd_class.run_cmd(line)
                        self.stdout.flush()
                        self.cmdcount += 1
                        self.history.append(line)
                        if len(self.history) > self.MAX_HISTORY_COUNT:
                            self.history.pop(0)

                        assert ifcs_error == 0, "Command failed and ifcs_error is set, asserting"
                    except SystemExit as se:
                        # argparse can raise SystemExit, so trap it.  But allow
                        # commands to cause the CLI to exit with SystemExit(99)
                        if len(se.args) == 1 and se.args[0] == 99:
                            raise
                    except:
                        log_dbg(
                            1, "Exception in default handler for command [{}] : {}".format(
                                line, sys.exc_info()))
                        # See if we're trying to run something from history
                        try:
                            run_id = int(line)
                            self.onecmd(self.history[run_id])
                            self.cmdcount += 1
                        except:
                            try:
                                # display debug log only if we are running from history
                                if int(line) >= 0 and len(self.history) > 0 and int(line) < len(self.history):
                                    log_dbg(
                                        1,
                                        "Exception in default handler when trying from history for command [{}] : {}".format(
                                            line, sys.exc_info()))
                            except:
                                pass
                            log_err("Command error : type help for commands list and help")
                            if self.sourceobjects:
                                # Stop processing sourcefiles
                                log("Error in line: " + line)
                                log("Source file processing aborted due to command error")
                                self.sourceobjects = []
                                self.sourcenames = []
            return rc

    def postcmd(self, stop, line):
        # stop will be True on graceful exit
        if stop is True:
            return stop

        if not self.cmdqueue:
            while True:
                if not self.sourceobjects:
                    break

                line = self.sourceobjects[-1].readline()
                if line:
                    self.cmdqueue.append(line)
                    break
                else:
                    self.sourceobjects.pop().close()
                    self.sourcenames.pop()

    def complete(self, text, state):
        if state == 0:
            import readline
            origline = readline.get_line_buffer()

            cmd, remline, line = self.parseline(origline.lstrip())
            if cmd is None:
                self.completions = compat_listkeys(self.cmdmgr.cmds)

            elif cmd == text:
                self.completions = [j for j in self.cmdmgr.cmds.keys() if j.startswith(text)]
            elif cmd == 'source' or cmd == 'redirect':
                self.filecompletions(remline, text)

            else:
                try:
                    cmd_class = self.cmdmgr.find_cmd(cmd)
                    self.completions = cmd_class.subcomplete(text, remline)
                except IndexError:
                    self.completions = []

        self.completions.sort()

        try:
            return self.completions[state]
        except IndexError:
            return None

    ''' Parses the arguments to look for ? or help
        after cmd and subcmd
    '''
    def check_for_help_in_args(self, args):
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        if '?' in self.arg_list or 'help' in self.arg_list:
            return True
        else:
            return False

    def do_help(self, arg):
        table = PrintTable()
        table.set_justification('left')
        table.add_row(['Innovium CLI Shell Help Menu', 'Description'])
        table.add_row(['exit', 'Quit the Innovium shell '])
        table.add_row(['source', 'Source a command file with shell commands'])
        table.add_row(['redirect', 'Redirect outputs from a shell to a file'])
        table.add_row(['pen', 'Pen Access Commands'])
        table.add_row(['ifcs', 'IFCS Api Debug Commands'])
        table.add_row(['diagtest', 'Diagtest commands'])
        table.add_row(['console', 'Start an interactive Python Interpreter from within the shell'])
        table.add_row(['clear', 'Clear screen'])
        table.add_row(['run', 'Execute module'])
 
        log("")
        table.print_table()
        table.reset_table()
        self.stdout.write("\n")
        self.stdout.flush()
