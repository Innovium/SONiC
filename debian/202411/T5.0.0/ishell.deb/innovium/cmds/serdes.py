
#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import shlex
import argparse
import itertools
import time
import json
import sys
from utils.compat_util import *
from verbosity import *
from ctypes import *
from cmdmgr import Command
from collections import OrderedDict
from ifcs_cmds.sysport import Sysport as sysport
from ifcs_cmds.devport import Devport as Devport
from ifcs_cmds.node import Node as node
from print_table import PrintTable
import serdes_pcie_sierra
import serdes_eth_tl10
import serdes_mgmt_tl10
import serdes_comphy

ifcs_ctypes = sys.modules['ifcs_ctypes']

# Class implements Ifcs related commands
class Serdes(Command):
    def __init__(self, cli):
        self.sub_cmds = {
                         'help'        : self.help,
                         '?'           : self.help
                        }

        tl_sub_cmds = {
                         'prbs'        : self.prbs,
                         'aapl'        : self.aapl,
                         'aapl-full'   : self.aapl_full,
                         'mapping'     : self.mapping,
                         'intr'        : self.intr,
                         'test'        : self.test,
                         'tx-eq'       : self.tx_eq,
                         'gainshape1'   : self.gainshape,
                         'gainshape2'   : self.gainshape,
                         'laneswap'    : self.laneswap,

                         'pcie'        : self.pcie,
                         'sbm'         : self.sbm,
                         'eth'         : self.eth,
                         'help'        : self.tl_help,
                         '?'           : self.tl_help
                        }

        tl10_sub_cmds = {
                         'prbs'        : self.prbs,
                         'eth'         : self.eth,
                         'mgmt'        : self.mgmt,
                         'pcie'        : self.pcie,
                         'help'        : self.tl10_help,
                         '?'           : self.tl10_help
                        }

        self.cli = cli
        self.serdes_mgmt = None
        device_type = ifcs_ctypes.im_nmgr_node_device_type_get(self.cli.node_id)

        if device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
            self.sub_cmds.update(tl_sub_cmds)
        elif device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TL10:
            self.sub_cmds.update(tl10_sub_cmds)

        self.arg_list = []
        super(Serdes, self).__init__()

        self.list_polynomials = ['prbs7', 'prbs9', 'prbs11', 'prbs13', 'prbs15', 'prbs23', 'prbs31']
        self.list_rates       = ['10g', '25g', '26g', '27g', '28g', '51g', '53g', '54g', '56g']

        self.ringenummap = {}
        self.ringenummap['Ring'] = ['A', 'B']

    def __del__(self):
        return

    def run_cmd(self, args):
        self.arg_list = shlex.split(args)
        try:
            rc = self.sub_cmds[self.arg_list[2]](args)
            if rc == None:
                rc = ifcs_ctypes.IFCS_SUCCESS
            return rc
        except (KeyError):
            log("ERR: Invalid command, list of valid commands...")
            self.sub_cmds['help'](args)
        except Exception as ex:
            self.cli.error()
            self.sub_cmds['help'](args)
        return ifcs_ctypes.IFCS_PARAM

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def getIfcsType(self, ifcs_obj_name):
        '''Get IFCS Type Object'''
        log_dbg(1, "In getIfcsType ifcs_obj_name " + ifcs_obj_name)

        if ifcs_obj_name == 'sysport':
            return sysport(self.cli)
        if ifcs_obj_name == 'devport':
            return devport(self.cli)
        if ifcs_obj_name == 'node':
            return node(self.cli)

        return None

    def debug_info(self, args):
        """
        Method to print serdes debug commands
        """
        log("\n Serdes debug info: ")
        pass

    def eth(self, args):
        device_type = ifcs_ctypes.im_nmgr_node_device_type_get(self.cli.node_id)

        if device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
            return self.aapl(args)
        elif device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TL10:
            arglist = shlex.split(args)
            return serdes_eth_tl10.run_cmd(arglist[3:])
        else:
            log("Command not valid for chip type!")
            return ifcs_ctypes.IFCS_INVAL

    def mgmt(self, args):
        device_type = ifcs_ctypes.im_nmgr_node_device_type_get(self.cli.node_id)
        if device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TL10:
            arglist = shlex.split(args)
            return serdes_mgmt_tl10.run_cmd(self.cli.node_id, arglist[3:])
        else:
            log("Command not valid for chip type!")
            return ifcs_ctypes.IFCS_INVAL

    def pcie(self, args):
        device_type = ifcs_ctypes.im_nmgr_node_device_type_get(self.cli.node_id)
        if device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
            return self.tl_pcie(args)
        elif device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TL10:
            arglist = shlex.split(args)
            return serdes_pcie_sierra.run_cmd(arglist[3:])
        else:
            log("Command not valid for chip type!")
            return ifcs_ctypes.IFCS_INVAL

    def aapl_full(self, args):
        """
        Method to execute full aapl commands - not limited to front panel ports
        """
        def remote_shell_callback(node_id, buff):
            log("%s" % compat_bytesToStr(buff))

        callback_type = CFUNCTYPE(
            ifcs_ctypes.UNCHECKED(None),
            ifcs_ctypes.ifcs_node_id_t,
            c_char_p)
        callback = callback_type(remote_shell_callback)

        node_id = self.cli.node_id
        if ifcs_ctypes.im_nmgr_node_device_type_get(node_id) != ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
            log("Command not valid for chip type!")
            return ifcs_ctypes.IFCS_INVAL

        arg_list = shlex.split(args)
        num_args = len(self.arg_list)
        devport = 1 # dummy
        lane = 0 # dummy
        if num_args < 4:
            log_err("Incorrect params passed to the test\n")
            self.help_aapl_full(args)
            return ifcs_ctypes.IFCS_PARAM

        # Append -addr <#> to the command
        argv = arg_list[3]
        argc = (len(shlex.split(argv)))
        argv = (c_char_p * argc)()
        arg_idx = 0
        for x in arg_list[3].split():
            argv[arg_idx] = compat_strToBytes(x)
            arg_idx += 1

        rc = ifcs_ctypes.im_devport_serdes_aapl_cmd(node_id,
                                        devport, lane,
                                        argc, compat_pointer(argv, POINTER(c_char)), compat_funcPointer(callback, ifcs_ctypes.im_depvort_aapl_user_cb_t))

        if rc != ifcs_ctypes.IFCS_SUCCESS:
            err_msg = "ERR executing AAPL command, rc %d" % rc
            log_err(err_msg)

        return rc

    def serdes_temp_bcast(self, sbm, enable):
        """
        Enable or disable the temp broadcast on a given ring
        """

        node_id = self.cli.node_id
        if enable:
            data = 0x1
        else:
            data = 0x0

        # Prep the aapl command
        args = "diagtest serdes sbm %s \'aapl sbm -int 0x2C %s\'" % (sbm, data)
        self.sbm(args)
        return self.sbm(args)

    def aapl(self, args):
        """
        Method to execute aapl commands
        """
        def remote_shell_callback(node_id, buff):
            log("%s" % compat_bytesToStr(buff))

        callback_type = CFUNCTYPE(
            ifcs_ctypes.UNCHECKED(None),
            ifcs_ctypes.ifcs_node_id_t,
            c_char_p)
        callback = callback_type(remote_shell_callback)

        node_id = self.cli.node_id
        if ifcs_ctypes.im_nmgr_node_device_type_get(node_id) != ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
            log("Command not valid for chip type!")
            return ifcs_ctypes.IFCS_INVAL

        arg_list = shlex.split(args)
        num_args = len(self.arg_list)

        if num_args < 6:
            log_err("Incorrect params passed to the test\n")
            self.help_aapl(args)
            return ifcs_ctypes.IFCS_INVAL

        devport = int(arg_list[3])
        lane = int(arg_list[4])

        serdes_info = ifcs_ctypes.im_serdes_info_t()
        rc = ifcs_ctypes.im_devport_get_serdes_info(self.cli.node_id, devport,
                                        lane, pointer(serdes_info))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("Failed to get serdes info\n");
            return rc

        # Disable the temp bcast before aapl command
        ringA = "0xfd"
        ringB = "1:0xfd"
        aapl_cmd = arg_list[5]
        if 'eye' in aapl_cmd:
            self.serdes_temp_bcast(ringA, False)
            self.serdes_temp_bcast(ringB, False)
        # Extract the aapl command to pass
        # to Aapl lib
        argv = arg_list[5]
        # Append -addr <#> to the command
        addr_opt = " -addr %d:0x%x" % (serdes_info.ring, serdes_info.sbus_addr)
        argv = argv + addr_opt
        arg_list[5] = argv
        argc = (len(shlex.split(argv)))
        argv = (c_char_p * argc)()
        arg_idx = 0
        for x in arg_list[5].split():
            argv[arg_idx] = compat_strToBytes(x)
            arg_idx += 1

        rc = ifcs_ctypes.im_devport_serdes_aapl_cmd(node_id,
                                        devport, lane,
                                        argc, compat_pointer(argv, POINTER(c_char)), compat_funcPointer(callback, ifcs_ctypes.im_depvort_aapl_user_cb_t))

        # Enable the temp bcast after aapl command
        if 'eye' in aapl_cmd:
            self.serdes_temp_bcast(ringA, True)
            self.serdes_temp_bcast(ringB, True)
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            err_msg = "ERR executing AAPL command, rc %d" % rc
            log_err(err_msg)

        return rc

    def display(self, devport_info, brief=False):
        '''display ifcs object attributes'''

        table = PrintTable()

        table.add_row(['devport', 'lane', 'isg', 'isg lane', 'ring', 'sbus_addr'])
        for devport in range(len(devport_info)):
            if len(devport_info[devport]) == 6:
                table.add_row([devport_info[devport][0], devport_info[devport][1], devport_info[devport][2],
                               devport_info[devport][3], devport_info[devport][4], devport_info[devport][5]])


        table.print_table(brief)
        table.reset_table()


    def enum_to_str(self, attr_name, attr_val):
        return (self.attrenummap[attr_name][attr_val])

    def mapping(self, args):

        # Get the Devport object/instance
        devport_obj = Devport(self.cli)

        # Parse devport arg
        args_list = args.split()
        devport_arg = args_list.pop(3)

        # To store the lane map info
        devport_info = []
        lane_info = []

        if devport_arg == 'all':
            try:
                rc, all_devport = devport_obj.bulk_get_all_devport_keys()
            except BaseException:
                log_err(" Failed to get all devport")
                return ifcs_ctypes.IFCS_NOTFOUND

            all_devport = sorted(all_devport)
            for devport, count in zip(all_devport, range(len(all_devport))):
                # Get num lanes and start lane for each devport
                num_lanes = devport_obj.getNumLanes(devport)
                start_lane = devport_obj.getStartLane(devport)

                # For each lane, get serdes info
                for lane_num in range(num_lanes):
                    serdes_info = ifcs_ctypes.im_serdes_info_t()

                    rc = ifcs_ctypes.im_devport_get_serdes_info(self.cli.node_id, devport,
                                              lane_num, pointer(serdes_info))
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        err_msg = "Error getting serdes info for devport %d, rc %d" %(devport, rc)
                        log_err(err_msg)
                        return rc
                    # Fill the serdes info
                    lane_info = []
                    lane_info.append(devport)
                    lane_info.append(lane_num)
                    lane_info.append(devport_obj.enum_to_str('serdes_group', serdes_info.isg))
                    lane_info.append(serdes_info.serdes_num)
                    lane_info.append(self.ringenummap['Ring'][serdes_info.ring])
                    sbus_addr = "%d (0x%x)" % (serdes_info.sbus_addr, serdes_info.sbus_addr)
                    lane_info.append(sbus_addr)

                    # Add the lane_info in to devport list
                    devport_info.append(lane_info)


            # Print the data
            self.display(devport_info, brief=True)

            return

        try:
            # For a specific devport
            devport = int(devport_arg)
        except ValueError:
            err_msg = "Invalid arg for devport: %s" % devport_arg
            log_err(err_msg)
            self.help_mapping()
            return ifcs_ctypes.IFCS_INVAL

        # Get num lanes and start lane for each devport
        num_lanes = devport_obj.getNumLanes(devport)
        start_lane = devport_obj.getStartLane(devport)

        # For each lane, get serdes info
        for lane_num in range(num_lanes):
            serdes_info = ifcs_ctypes.im_serdes_info_t()
            rc = ifcs_ctypes.im_devport_get_serdes_info(self.cli.node_id, devport,
                                            lane_num, pointer(serdes_info))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                err_msg = "Error getting serdes info for devport %d, rc %d" %(devport, rc)
                log_err(err_msg)
                return rc
            # Fill the serdes info
            lane_info = []
            lane_info.append(devport)
            lane_info.append(lane_num)
            lane_info.append(devport_obj.enum_to_str('serdes_group', serdes_info.isg))
            lane_info.append(serdes_info.serdes_num)
            lane_info.append(self.ringenummap['Ring'][serdes_info.ring])
            sbus_addr = "%d (0x%x)" % (serdes_info.sbus_addr, serdes_info.sbus_addr)
            lane_info.append(sbus_addr)

            # Add the lane_info in to devport list
            devport_info.append(lane_info)

        # Print the data
        self.display(devport_info, brief=True)

        return

    def _devport_serdes_intr(self, devport, lane, intr_code,
                             intr_data):
        """
        Issue an interrupt to the serdes

        """
        node_id = self.cli.node_id
        serdes_info = ifcs_ctypes.im_serdes_info_t()
        rc = ifcs_ctypes.im_devport_get_serdes_info(self.cli.node_id, devport,
                                        lane, pointer(serdes_info))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            err_msg = "Error getting serdes info for devport %d lane %d, rc %d" %(devport, lane, rc)
            log_err(err_msg)
            return rc

        rsp_data = c_uint32()
        rc = ifcs_ctypes.im_devport_serdes_intr(node_id, devport, lane,
                                    intr_code, intr_data,
                                    pointer(rsp_data))
        """
        log("ring: %s sbus_addr: %d intr_code 0x%x intr_data 0x%x rsp_data: 0x%x\n"
                 % (self.ringenummap['Ring'][serdes_info.ring],
                    serdes_info.sbus_addr,
                    intr_code,
                    intr_data,
                    rsp_data.value))
        """

        return rsp_data.value




    def intr(self, args):
        """
        Method to issue generic interrupts to the serdes
        """
        node_id = self.cli.node_id
        arg_list = shlex.split(args)
        num_args = len(self.arg_list)

        if num_args < 7:
            log_err("Incorrect params passed to the test\n")
            self.help_intr(args)
            return ifcs_ctypes.IFCS_PARAM

        try:
            devport = int(arg_list[3])
            lane = int(arg_list[4])
            intr_code = int(arg_list[5], 16)
            intr_data = int(arg_list[6], 16)
        except Exception as ex:
            log_err("Error parsing params")
            self.help_intr(args)
            return ifcs_ctypes.IFCS_PARAM

        rsp_data = self._devport_serdes_intr(devport, lane, intr_code,
                                             intr_data)

        log("Devport %d lane %d intr_code %d intr_data %d rsp_data: 0x%x\n"
                 % ( devport, lane,
                    intr_code,
                    intr_data,
                    rsp_data))

        return

    def aapl_test(self, args):
        '''
        AAPL test hook
        '''

        node_id = self.cli.node_id
        if ifcs_ctypes.im_nmgr_node_device_type_get(node_id) != ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
            log("Command not valid for chip type!")
            return ifcs_ctypes.IFCS_INVAL

        arg_list = shlex.split(args)

        # Read -1 , write - 2
        cmd = int(arg_list[4])
        reg = int(arg_list[5], 16)

        data = c_uint32(0)
        if cmd == 2:
            data.value = int(arg_list[6])

        rc = ifcs_ctypes.im_devport_serdes_aapl_test(self.cli.node_id, cmd,
                                         reg, pointer(data))

        if rc != ifcs_ctypes.IFCS_SUCCESS:
            err_msg = "PCIe reg access error, cmd %d reg 0x%x data 0x%x rc %d" % (cmd, reg, data, rc)
            log_err(err_msg)

        return rc


    # ------------
    # test command
    # ------------
    def test(self, args):

        sub_cmds = {
                     'aapl'        : self.aapl_test,
                     'help'        : self.help,
                     '?'           : self.help
                   }

        arg_list = shlex.split(args)


        try:
            rc = sub_cmds[arg_list[3]](args)
            if rc == None:
                rc = ifcs_ctypes.IFCS_SUCCESS
            return rc
        except (KeyError):
            log_dbg(1, "IfcsKeyError")
            self.help(args)
            return ifcs_ctypes.IFCS_PARAM
        except (ValueError):
            log_dbg(1, "IfcsValueError")
            self.help(args)
            return ifcs_ctypes.IFCS_INVAL


    def tx_eq(self, args):
        '''
        Print the Tx EQ settings for a given lane
        '''
        num_args = len(self.arg_list)

        if num_args < 5:
            log_err("Incorrect params passed to the test\n")
            self.help_tx_eq(args)
            return ifcs_ctypes.IFCS_PARAM

        try:
            devport = int(self.arg_list[3])
            lane = int(self.arg_list[4], 16)
        except Exception as ex:
            log_err("Error parsing params")
            self.help_tx_eq(args)
            return ifcs_ctypes.IFCS_PARAM

        # Get the serdes info
        serdes_info = ifcs_ctypes.im_serdes_info_t()
        rc = ifcs_ctypes.im_devport_get_serdes_info(self.cli.node_id, devport,
                                        lane, pointer(serdes_info))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("Failed to get serdes info\n");
            return rc

        tx_pre1 = c_int8()
        tx_pre2 = c_int8()
        tx_pre3 = c_int8()
        tx_attn = c_int8()
        tx_post = c_int8()

        lane_mask = 0x1 << lane

        # Get the tx settings from h/w
        rc = ifcs_ctypes.im_devport_get_tx_eq(self.cli.node_id,
                                  devport,
                                  lane_mask,
                                  pointer(tx_pre1),
                                  pointer(tx_pre2),
                                  pointer(tx_pre3),
                                  pointer(tx_attn),
                                  pointer(tx_post))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("Failed to get Tx EQ\n");
            return rc
        table = PrintTable()
        table.add_row(['Ring', 'Sbus', 'Pre1', 'Pre2', 'Pre3', 'Attn', 'Post'])
        table.add_row([self.ringenummap['Ring'][serdes_info.ring], serdes_info.sbus_addr,
                       tx_pre1.value, tx_pre2.value, tx_pre3.value,
                       tx_attn.value, tx_post.value])


        table.print_table()
        table.reset_table()

        return

    def gainshape(self, args):
        '''
        Get/Set the CTLE gainshape settings
        '''
        # Get the Devport object/instance
        devport_obj = Devport(self.cli)

        num_args = len(self.arg_list)

        if num_args < 4:
            log_err("Incorrect params! \n")
            self.help_gainshape(args)
            return ifcs_ctypes.IFCS_PARAM

        # Get the current CTLE settings
        devport = int(self.arg_list[3])
        num_lanes = devport_obj.getNumLanes(devport)
        cur_gainshape1 = devport_obj.getRxGainshape1(devport)
        cur_gainshape2 = devport_obj.getRxGainshape2(devport)

        if num_args == 4:
            # display the values returned
            table = PrintTable()
            table.add_row(['Devport', 'Lane', 'Gainshape1', 'Gainshape2'])
            for lane in range(num_lanes):
                table.add_row([devport, lane, cur_gainshape1[lane], cur_gainshape2[lane]])

            table.print_table()
            table.reset_table()

            return

        elif num_args < 5:
            log_err("Incorrect params! \n")
            self.help_gainshape(args)
            return ifcs_ctypes.IFCS_PARAM

        lane_mask = self.arg_list[4]
        devport_obj.setLaneMask(devport, lane_mask)
        gainshape = int(self.arg_list[5])

        new_gs = []

        for i in range(num_lanes):
            if ((0x1 << i) & int(lane_mask, 16)):
                new_gs.append(gainshape)
            else:
                if self.arg_list[2] == 'gainshape1':
                    new_gs.append(cur_gainshape1[i])
                elif self.arg_list[2] == 'gainshape2':
                    new_gs.append(cur_gainshape2[i])

        if self.arg_list[2] == 'gainshape1':
            devport_obj.setRxGainshape1(devport, str(new_gs))
        elif self.arg_list[2] == 'gainshape2':
            devport_obj.setRxGainshape2(devport, str(new_gs))

        return

    def laneswap(self, args):
        '''
        Set the laneswap for a given ISG
        '''
        num_args = len(self.arg_list)

        if num_args < 5:
            log_err("Incorrect params passed to the test\n")
            self.help_laneswap(args)
            return ifcs_ctypes.IFCS_PARAM

        try:
            isg_num = int(self.arg_list[3])
            laneswap = self.arg_list[4]
        except Exception as ex:
            log_err("Error parsing params")
            self.help_laneswap(args)
            return ifcs_ctypes.IFCS_PARAM

        rc = ifcs_ctypes.im_devport_serdes_set_laneswap(self.cli.node_id, isg_num, int(laneswap, 16))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("Failed to set laneswap\n")
            self.help_laneswap(args)

        return

    # ------------
    # test command
    # ------------
    def show(self, args):

        sub_cmds = {
                     'debug-info'  : self.debug_info,
                     'help'        : self.help,
                     '?'           : self.help
                   }

        arg_list = shlex.split(args)
        try:
            rc = sub_cmds[arg_list[3]](args)
            if rc == None:
                rc = ifcs_ctypes.IFCS_SUCCESS
            return rc
        except (KeyError):
            log_dbg(1, "IfcsKeyError")
            self.help(args)
            return ifcs_ctypes.IFCS_PARAM
        except (ValueError):
            log_dbg(1, "IfcsValueError")
            self.help(args)
            return ifcs_ctypes.IFCS_PARAM

    def help(self, args):
        self.tl_help(args)

    def tl10_help(self, args):
        """
        Print TL10 help strings
        """
        serdes_eth_tl10.run_cmd(['-h'])
        log('\n---- or ----\n')
        serdes_pcie_sierra.run_cmd(['-h'])
        serdes_mgmt = self._get_serdes_mgmt()
        if serdes_mgmt is not None:
            log('\n---- or ----\n')
            serdes_mgmt.run_cmd(['-h'])

    def tl_help(self, args):
        """
        Print help strings
        """
        self.help_prbs(args)
        self.help_aapl(args)
        self.help_aapl_full(args)
        self.help_mapping(args)
        self.help_intr(args)
        self.help_tx_eq(args)

        self.help_pcie(args)
        self.help_gainshape(args)
        self.help_laneswap(args)
        self.help_pcie_swap(args)
        self.help_sbm(args)

    def help_aapl(self, args):
        log("Usage:: \n" + \
              "  diagtest serdes eth <devport> <lane>\"<cmd>\"  - execute AAPL command\n" \
              "  <devport>    - devport number (use 'all' for all devports)\n" \
              "  <lane>       - lane number\n" \
              "  <cmd>        - pre-canned AAPL commands\n"\
              "                 try \"aapl -help\" for list of commands\n")

    def help_aapl_full(self, args):
        log("Usage:: \n" + \
              "  diagtest serdes aapl-full \"<cmd>\"  - execute AAPL command\n" \
              "  <cmd>        - pre-canned AAPL commands\n"\
              "                 try \"aapl -help\" for list of commands\n")

    def help_mapping(self, args):
        log("Usage:: \n" + \
              "  diagtest serdes mapping <devport> - print serdes mapping info\n" \
              "  <devport>    - devport number (use 'all' for all devports)\n")

    def help_intr(self, args):
        log("Usage:: \n" + \
              "  diagtest serdes intr <devport> <lane> <intr_code> <intr_data> - Issue interrupt to serdes\n" \
              "  <devport>    - devport number (use 'all' for all devports)\n" \
              "  <lane>       - lane number\n" \
              "  <intr_code>  - hex interrupt code\n" \
              "  <intr_data>  - hex interrupt data\n")
    def help_tx_eq(self, args):
        log("Usage:: \n" + \
              "  diagtest serdes tx-eq <devport> <lane> - get serdes tx-eq\n" \
              "  <devport>    - devport number\n" \
              "  <lane>       - lane mask\n\n" \
              "  Note: The attenuation value read back may differ by +/- 3\n" \
              "        depending on the combination of the Tx EQ settings \n")

    def help_gainshape(self, args):
        log("Usage:: \n" + \
              "  diagtest serdes gainshape1 <devport> - get serdes Rx CTLE gainshape\n" \
              "  diagtest serdes gainshape2 <devport> - get serdes Rx CTLE gainshape\n" \
              "  diagtest serdes gainshape1 <devport> <lane> <gainshape> - set serdes CTLE gainshape\n" \
              "  diagtest serdes gainshape2 <devport> <lane> <gainshape> - set serdes CTLE gainshape\n" \
              "  <devport>    - devport number\n" \
              "  <lane>       - lane mask\n" \
              "  <gainshape>       - CTLE gainshape value to set\n" )

    def help_laneswap(self, args):
        log("Usage:: \n" + \
              "  diagtest serdes laneswap <isg-num> <value> - set serdes lane swap\n" \
              "  <isg-num>    - ISG number\n" \
              "  <value>      - Value as string\n")



    def help_pcie(self, args):
        log("Usage:: \n" + \
              "  diagtest serdes pcie <sbus-addr> <aapl cmd> - Run AAPL commands against the PCIe serdes\n" \
              "  <sbus-addr>  - SBus addr of the PCIe serdes lanes (6, 8, 10, 12)\n" \
              "  <cmd>        - pre-canned AAPL commands\n"\
              "                 try \"aapl -help\" for list of commands\n")

    def help_sbm(self, args):
        log("Usage:: \n" + \
              "  diagtest serdes sbm <sbus-addr> <aapl cmd> - Run AAPL commands against the PCIe serdes\n" \
              "  <sbus-addr>  - SBus addr of the SBus master (0xfd or 1:0xfd)\n" \
              "  <cmd>        - pre-canned AAPL commands\n"\
              "                 Ex. \"aapl sbm -int 0x2c 0x0\" \n")




    def _get_prbs_poly(self, poly_string):
        ''' Map the PRBS polynomial string input from
            the user to the corresponding enum
        '''
        if poly_string == 'prbs7':
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS7
        if poly_string == 'prbs9':
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS9
        if poly_string == 'prbs11':
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS11
        if poly_string == 'prbs13':
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS13
        if poly_string == 'prbs15':
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS15
        if poly_string == 'prbs23':
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS23
        if poly_string == 'prbs31':
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS31

        return None

    def _get_prbs_rate(self, rate_string):
        ''' Map the PRBS rate string input from
            the user to the corresponding enum
        '''
        if rate_string == '10g':
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_10_3125GBS
        if rate_string == '25g':
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_25_78125GBS
        if rate_string == '26g':
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_26_5625GBS
        if rate_string == '27g':
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_27_1875GBS
        if rate_string == '28g':
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_28_125GBS
        if rate_string == '51g':
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_51_5625GBS
        if rate_string == '53g':
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_53_125GBS
        if rate_string == '54g':
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_54_375GBS
        if rate_string == '56g':
            return ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_56_25GBS

        return None

    def _prbs_tx_stop(self, tx_port, lane_mask):
        """
        Clean up PRBS setup

        """
        node_id = self.cli.node_id
        attr_count = 4
        attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

        attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LANE_MASK
        attr_list_p[0].value.u32 = lane_mask

        attr_list_p[1].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_TX_RATE
        attr_list_p[1].value.u32 = ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_NOTCONFIGURED

        attr_list_p[2].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_GENERATOR_POLY
        attr_list_p[2].value.u32 = ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_NOTCONFIGURED

        attr_list_p[3].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_GENERATOR
        attr_list_p[3].value.u32 = 0

        rc = ifcs_ctypes.ifcs_devport_attr_set(node_id, tx_port,
                                   attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));

        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("Failed to stop Tx PRBS")

        return rc

    def _prbs_rx_stop(self, rx_port, lane_mask):
        """
        Clean up PRBS setup

        """
        node_id = self.cli.node_id

        # Stop PRBS Comparator/checker
        attr_count = 5
        attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

        attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LANE_MASK
        attr_list_p[0].value.u32 = lane_mask

        attr_list_p[1].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_RX_RATE
        attr_list_p[1].value.u32 = ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_NOTCONFIGURED

        attr_list_p[2].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_CHECKER_POLY
        attr_list_p[2].value.u32 = ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_NOTCONFIGURED

        attr_list_p[3].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_CHECKER
        attr_list_p[3].value.u32 = 0

        attr_list_p[4].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_COMPARATOR
        attr_list_p[4].value.u32 = 0

        rc = ifcs_ctypes.ifcs_devport_attr_set(node_id, rx_port,
                                   attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));

        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("Failed to stop Rx PRBS")

        return rc

    def _getAlldevport(self):
        def myCallback(node_id, arg, attr_count, attr_list, user_data):
            devport = arg
            devport_list.append(devport)

        devport_list = []

        callback_type = CFUNCTYPE(
            ifcs_ctypes.UNCHECKED(None),
            ifcs_ctypes.ifcs_node_id_t,
            ifcs_ctypes.ifcs_devport_t,
            c_uint32,
            POINTER(ifcs_ctypes.ifcs_attr_t),
            POINTER(None))
        callback = callback_type(myCallback)

        try:
            attr = ifcs_ctypes.ifcs_attr_t()
            ifcs_ctypes.ifcs_attr_t_init(pointer(attr))
            ifcs_ctypes.ifcs_attr_t_id_set(pointer(attr), ifcs_ctypes.IFCS_DEVPORT_ATTR_TYPE)
            ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_DEVPORT_TYPE_ETH)
            rc = ifcs_ctypes.ifcs_devport_get_all(self.cli.node_id, 1, pointer(attr), compat_funcPointer(callback, ifcs_ctypes.ifcs_devport_user_cb_t), None, None)
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Failed to get all eth devport rc: %d" %(rc))
        except Exception as e:
            log("Failed to get all eth devport rc: %d" %(rc))
            raise e

        return sorted(devport_list)

    def _parse_mode_cmd_args(self, cmd_args):
        """
        Parse the mode-en command args
        """
        node_id = self.cli.node_id
        check_failed = False
        devport_obj = Devport(self.cli)

        try:
            self.mode_enable = int(cmd_args[0])
        except Exception as ex:
            check_failed = True
            return check_failed

        for dp in self.port_list:
            devport_obj.setPrbsModeEnable(dp, self.mode_enable)

        time.sleep(2)
        log("PRBS mode-en set to %d" % (self.mode_enable))
        return check_failed

    def _parse_clear_cmd_args(self):
        """
        Parse the clear command args
        """
        node_id = self.cli.node_id
        check_failed = False
        devport_obj = Devport(self.cli)

        # Set PRBS_SYNC to FALSE
        for dp in self.port_list:
            devport_obj.setPrbsSync(dp, ifcs_ctypes.IFCS_BOOL_FALSE)

        time.sleep(2)

        # Clear all user set attrs
        for dp in self.port_list:
            devport_obj.setPrbsSet(dp, ifcs_ctypes.IFCS_DEVPORT_PRBS_MODE_NOTCONFIGURED)
            devport_obj.setPrbsGeneratorPoly(dp, ifcs_ctypes.IFCS_DEVPORT_PRBS_MODE_NOTCONFIGURED)
            devport_obj.setPrbsCheckerPoly(dp, ifcs_ctypes.IFCS_DEVPORT_PRBS_MODE_NOTCONFIGURED)
            devport_obj.setPrbsErrCountLimit(dp, 0)
            devport_obj.setPrbsCompareTime(dp, 0)
            devport_obj.setPrbsSet(dp, ifcs_ctypes.IFCS_DEVPORT_PRBS_MODE_NOTCONFIGURED)

        log("PRBS config cleared")
        return check_failed

    def _get_sync_status_str(self, sync_status):
        """
        Convert the sync status to str
        """

        if sync_status == 0:
            return "NOTCONFIGURED"
        elif sync_status == 1:
            return "LINK_DOWN"
        elif sync_status == 2:
            return "SYNC_IN_PROGRESS"
        elif sync_status == 3:
            return "SYNC"
        elif sync_status == 4:
            return "NO_SYNC"
        elif sync_status == 5:
            return "LINK_DOWN_SYNC"
        elif sync_status == 6:
            return "LINK_DOWN_NO_SYNC"

    def _parse_get_cmd_args(self):
        """
        Parse the get command args
        """
        node_id = self.cli.node_id
        check_failed = False

        devport_obj = Devport(self.cli)

        prbs_table = PrintTable()
        prbs_table.add_row(['Devport', 'Lane','ISG', 'Serdes#', 'Polynomial','Err Diff', 'Sync Status'])
        # Get the error count, BER and sync status
        for dp in self.port_list:
            devport_info = self._get_devport_info(dp)
            num_lanes   = devport_obj.getNumLanes(dp)
            prbs_poly   = devport_obj.enum_to_str('prbs_checker_poly', devport_obj.getPrbsGeneratorPoly(dp))
            err_count   = devport_obj.getPrbsErrCount(dp)
            sync_status = devport_obj.getPrbsSyncStatus(dp)

            for i in range(num_lanes):
                # Get the err diff and BER
                ring = devport_info[i][4]
                if ring == 0:
                    ring = ""
                sbus_addr = devport_info[i][5][2:]
                key= "%s:%s" %(ring, sbus_addr)

                if len(err_count) == 0:
                    error_count = 'N/A'
                else:
                    error_count = err_count[i]

                if len(sync_status) == 0:
                    sync = 'N/A'
                else:
                    sync = self._get_sync_status_str(sync_status[i])

                prbs_table.add_row([dp, i, devport_info[i][2], devport_info[i][3], prbs_poly, error_count, sync])

        log("\n")
        prbs_table.print_table()
        prbs_table.reset_table()

        return check_failed

    def _parse_sync_cmd_args(self):
        """
        Parse the sync command args
        """
        node_id = self.cli.node_id
        check_failed = False

        devport_obj = Devport(self.cli)

        max_comp_time = 0
        #Set the SYNC attr to True
        for dp in self.port_list:
            devport_obj.setPrbsSync(dp, ifcs_ctypes.IFCS_BOOL_TRUE)

        """
        # Wait for the compare time limit
        log("Waiting for user specified compare time ...")
        # Allow for extra time for PRBS to finish
        time.sleep((max_comp_time + 1))

        # Get the results
        for dp in self.port_list:

            devport_info = self._get_devport_info(dp)
            num_lanes   = devport_obj.getNumLanes(dp)
            #prbs_rate   = devport_obj.enum_to_str('prbs_rx_rate', devport_obj.getPrbsTxRate(dp))
            prbs_poly   = devport_obj.enum_to_str('prbs_checker_poly', devport_obj.getPrbsGeneratorPoly(dp))
            err_count   = devport_obj.getPrbsErrCount(dp)
            ber         = devport_obj.getPrbsBer(dp)
            sync_status = devport_obj.getPrbsSyncStatus(dp)

            for i in range(num_lanes):
                # Get the err diff and BER
                ring = devport_info[i][4]
                if ring == 0:
                    ring = ""
                sbus_addr = devport_info[i][5][2:]
                key= "%s:%s" %(ring, sbus_addr)

                if len(err_count) == 0:
                    error_count = 'N/A'
                else:
                    error_count = err_count[i]
                if len(ber) == 0:
                    ber_count = 'N/A'
                else:
                    ber_count = ber[i]
                if len(sync_status) == 0:
                    sync = 'N/A'
                else:
                    #sync_status_str = devport_obj.enum_to_str('prbs_sync_status', sync_status[i])
                    sync = sync_status[i]

                #prbs_sync_table.add_row([dp, i, devport_info[i][2], devport_info[i][3], prbs_rate, prbs_poly, error_count, ber_count, sync])
                prbs_sync_table.add_row([dp, i, devport_info[i][2], devport_info[i][3], prbs_poly, error_count, ber_count, sync])

        log("\n")
        prbs_sync_table.print_table()
        prbs_sync_table.reset_table()
        """
        return check_failed

    def _parse_set_cmd_args(self, cmd_args):
        """
        Parse the set command args
        """
        node_id = self.cli.node_id
        check_failed = False

        devport_obj = Devport(self.cli)

        try:
            set_enable = int(cmd_args[0])
            polynomial = self._get_prbs_poly(cmd_args[1])
            err_limit = int(cmd_args[2])
            #ber_limit = float(cmd_args[3])
            comp_time = int(cmd_args[3])
        except Exception as ex:
            check_failed = True
            return check_failed

        #log("set cmd args parsed")

        # Set the following attrs
        #   PRBS generator polynomial
        #   PRBS checker polynomial
        #   PRBS error counter limit
        #   PRBS BER limit
        #   PRBS compare/dwell time
        #   PRBS start
        for dp in self.port_list:

            #log("devport: %d enable: %d polynomial: %s err_limit: %d ber_limit: %s compare_time: %d" %
            #        (dp, set_enable, polynomial, err_limit, ber_limit, comp_time))
            lane_mask   = devport_obj.getLaneMask(dp)

            attr_count = 5
            attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

            attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_GENERATOR_POLY
            attr_list_p[0].value.u32 = polynomial

            attr_list_p[1].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_CHECKER_POLY
            attr_list_p[1].value.u32 = polynomial

            attr_list_p[2].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_ERR_COUNT_LIMIT
            attr_list_p[2].value.u32 = err_limit

            attr_list_p[3].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_COMPARE_TIME
            attr_list_p[3].value.u32 = comp_time

            attr_list_p[4].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_SET
            attr_list_p[4].value.u32 = set_enable

            rc = ifcs_ctypes.ifcs_devport_attr_set(node_id, dp,
                                       attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));

            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("PRBS set command failed\n")
                check_failed = True
                return check_failed

        return check_failed


    def _parse_devport_arg(self, dp_arg):
        """
        Parse the devport param - single, range of ports
        """
        check_failed = False
        self.port_list = []
        devport_arg = []

        if dp_arg == 'all':
            self.port_list = self._getAlldevport()
        else:
            devport_arg = dp_arg.split(",")

        try:
            for dp in devport_arg:
                if '-' in dp:
                    dp_range = compat_listrange(int(dp.split('-')[0]), int(dp.split('-')[1]) + 1)
                    for i in dp_range:
                        self.port_list.append(i)
                else:
                    self.port_list.append(int(dp))

        except Exception as ex:
            check_failed = True

        return check_failed

    def _parse_prbs_sync_args(self, arg_list):
        """
        Parse PRBS sync command args
        """
        check_failed = False
        help_string = {'mode-en': self.help_prbs_mode_en,
                        'set':    self.help_prbs_set,
                        'sync':   self.help_prbs_sync,
                        'get':    self.help_prbs_get,
                        'clear':  self.help_prbs_clear,
                      }

        cmd = arg_list[3]
        # Check for valid args
        if cmd == 'mode-en':
            exp_arg_count = 2
        elif cmd == 'set':
            exp_arg_count = 5
        elif cmd == 'sync':
            exp_arg_count = 1
        elif cmd == 'get':
            exp_arg_count = 1
        elif cmd == 'clear':
            exp_arg_count = 1

        arg_list = arg_list[4:]
        if len(arg_list) != exp_arg_count:
            check_failed = True
            log_err("Incorrect params passed")
            help_string[cmd]()
            return check_failed

        # Parse devport arg
        check_failed = self._parse_devport_arg(arg_list[0])
        if check_failed == True:
            help_string[cmd]()
            return check_failed

        # Parse prbs set cmd args
        if cmd == 'mode-en':
            check_failed = self._parse_mode_cmd_args(arg_list[1:])
            if check_failed == True:
                self.help_prbs_mode_en()
                return check_failed

        # Parse prbs set cmd args
        if cmd == 'set':
            check_failed = self._parse_set_cmd_args(arg_list[1:])
            if check_failed == True:
                self.help_prbs_set()
                return check_failed

        # Parse sync cmd args
        if cmd == 'sync':
            check_failed = self._parse_sync_cmd_args()
            if check_failed == True:
                self.help_prbs_sync()
                return check_failed

        # Parse get cmd args
        if cmd == 'get':
            check_failed = self._parse_get_cmd_args()
            if check_failed == True:
                self.help_prbs_get()
                return check_failed

        # Parse clear cmd args
        if cmd == 'clear':
            check_failed = self._parse_clear_cmd_args()
            if check_failed == True:
                self.help_prbs_clear()
                return check_failed

        return check_failed
    def _save_dp_lane_mask(self):
        '''
        Save the original lane mask for all devports
        '''

        devport_obj = Devport(self.cli)
        self.dp_orig_lane_mask = {}

        for dp in self._getAlldevport():
            self.dp_orig_lane_mask[dp] = devport_obj.getLaneMask(dp)

    def _validate_user_input(self, args):
        '''
        Check for user test params passed
        '''
        devport_obj = Devport(self.cli)

        check_failed = False
        self.tx_serdes = 0
        self.rx_serdes = 0
        self.lpbk_mode = 0
        self.rx_stop = 0
        self.tx_stop = 0
        self.rx_stop = 0
        self.tx_port = []
        self.rx_port = []
        self.rx_fine_tune = ifcs_ctypes.IFCS_DEVPORT_SERDES_RX_EQ_FINE_TUNE_CONTINUOUS
        self.pcal_en = 0

        self.arg_list  = args.split()
        num_args = len(self.arg_list)

        # Save the original devport lane mask for all ports
        self._save_dp_lane_mask()

        if num_args < 4:
            log_err("Incorrect params passed to the test\n")
            self.help_prbs(args)
            self.help_prbs_mode_en()
            self.help_prbs_set()
            self.help_prbs_sync()
            self.help_prbs_get()
            self.help_prbs_clear()
            check_failed = True
            return check_failed

        # Tx or Rx ?
        if self.arg_list[3] == 'tx':
            self.tx_serdes = 1
            if self.arg_list[4] == 'stop':
                self.tx_stop = 1
                if self.arg_list[5] == 'all':
                    self.tx_port    = self._getAlldevport()
                else:
                    self.tx_port.append(int(self.arg_list[5]))

                if self.arg_list[6] == 'all':
                    self.tx_lane_mask   = 0xFF
                else:
                    self.tx_lane_mask   = int(self.arg_list[6], 16)
                return

        elif self.arg_list[3] == 'rx':
            self.rx_serdes = 1
            if self.arg_list[4] == 'stop':
                self.rx_stop = 1
                if self.arg_list[5] == 'all':
                    self.rx_port    = self._getAlldevport()
                else:
                    self.rx_port.append(int(self.arg_list[5]))

                if self.arg_list[6] == 'all':
                    self.rx_lane_mask   = 0xFF
                else:
                    self.rx_lane_mask   = int(self.arg_list[6], 16)

                return

        elif self.arg_list[3] in ['mode-en', 'set', 'sync',
                                  'get',     'clear']:

            self.sync_cmd = True
            check_failed = self._parse_prbs_sync_args(self.arg_list)
            if check_failed == True:
                return check_failed

            return

        else:
            log_err("Incorrect params \n")
            self.help_prbs(args)
            self.help_prbs_mode_en()
            self.help_prbs_set()
            self.help_prbs_sync()
            self.help_prbs_get()
            self.help_prbs_clear()
            check_failed = True
            return check_failed

        if self.tx_serdes == 1:

            if num_args < 8:
                log_err("Incorrect params passed to the test\n")
                self.help_prbs(args)
                check_failed = True
                return check_failed

            if self.arg_list[4] == 'all':
                self.tx_port    = self._getAlldevport()
            else:
                self.tx_port.append(int(self.arg_list[4]))

            if self.arg_list[5] == 'all':
                self.tx_lane_mask   = 0xFF
            else:
                self.tx_lane_mask   = int(self.arg_list[5], 16)

            self.prbs_tx_poly   = self._get_prbs_poly(self.arg_list[6])
            self.prbs_tx_rate   = self._get_prbs_rate(self.arg_list[7])

            for dp in self.tx_port:
                # Get lane mask for 'all' input
                if self.tx_lane_mask == 0xFF:
                    tx_lane_mask = devport_obj.getLaneMask(dp)
                else:
                    tx_lane_mask = self.tx_lane_mask

                # Loopback mode check
                if num_args > 8:
                    self.lpbk_mode = int(self.arg_list[8])
                    if (self.lpbk_mode != 0) and (self.lpbk_mode != 1):
                        log_err("Invalid lpbk mode param\n")
                        check_failed = True
                        self.help_prbs(args)
                        return check_failed

                    #log("Using internal loopback mode")
                    self.rx_port.append(dp)
                    self.rx_lane_mask = tx_lane_mask
                    self.prbs_rx_poly  = self.prbs_tx_poly
                    self.prbs_rx_rate  = self.prbs_tx_rate

                    if self.lpbk_mode == 1 and num_args != 10:
                        log_err("Missing delay param\n")
                        check_failed = True
                        self.help_prbs(args)
                        return check_failed

                    self.prbs_delay    = int(self.arg_list[9])
                else:
                    # Disable by default
                    self.lpbk_mode = 0

                if dp < 0:
                    log_err("Invalid tx port number param\n")
                    check_failed = True

                if self.tx_lane_mask < 0 or self.tx_lane_mask  > 0xFF:
                    log_err("Invalid tx lane mask param\n");
                    check_failed = True

                if self.prbs_tx_poly is None:
                    log_err("Invalid PRBS polynomial param\n")
                    check_failed = True

                if self.prbs_tx_rate is None:
                    log_err("Invalid PRBS rate param\n")
                    check_failed = True

        elif self.rx_serdes == 1:

            if num_args < 9:
                log_err("Incorrect params passed to the test\n")
                self.help_prbs(args)
                check_failed = True
                return check_failed

            if self.arg_list[4] == 'all':
                self.rx_port    = self._getAlldevport()
            else:
                self.rx_port.append(int(self.arg_list[4]))

            if self.arg_list[5] == 'all':
                self.rx_lane_mask   = 0xFF
            else:
                self.rx_lane_mask   = int(self.arg_list[5], 16)

            self.prbs_rx_poly  = self._get_prbs_poly(self.arg_list[6])
            self.prbs_rx_rate  = self._get_prbs_rate(self.arg_list[7])
            self.prbs_delay    = int(self.arg_list[8])

            if num_args == 10:
                self.pcal_en = int(self.arg_list[9])
                if self.pcal_en not in [0, 1]:
                    log_err("Incorrect params passed to the test\n")
                    self.help_prbs(args)
                    check_failed = True
                    return check_failed

            if self.pcal_en == 1:
                self.rx_fine_tune = ifcs_ctypes.IFCS_DEVPORT_SERDES_RX_EQ_FINE_TUNE_CONTINUOUS
            else:
                self.rx_fine_tune = ifcs_ctypes.IFCS_DEVPORT_SERDES_RX_EQ_FINE_TUNE_SINGLE


            devport_obj = Devport(self.cli)

            for dp in self.rx_port:
                # Get lane mask for 'all' input
                if self.rx_lane_mask == 0xFF:
                    rx_lane_mask = devport_obj.getLaneMask(dp)
                else:
                    rx_lane_mask = self.rx_lane_mask

                if dp < 0:
                    log_err("Invalid rx port number param\n")
                    check_failed = True

                if self.rx_lane_mask < 0 or self.rx_lane_mask  > 0xFF:
                    log_err("Invalid rx lane mask param\n");
                    check_failed = True

                if self.prbs_rx_poly is None:
                    log_err("Invalid PRBS polynomial param\n")
                    check_failed = True

                if self.prbs_rx_rate is None:
                    log_err("Invalid PRBS rate param\n")
                    check_failed = True

                if self.prbs_delay < 0:
                    log_err("Invalid delay param\n")
                    check_failed = True

        return check_failed

    def _disable_tx(self, dp):
        node_id = self.cli.node_id
        devport_obj = Devport(self.cli)

        # Disable the port
        devport_obj.setAdminState(dp, 0)

        # Reapply Tx eq settings if link training is enabled
        if devport_obj.getLinkTraining(dp) == 1:
            tx_eq_pre1 = devport_obj.getTxEqPre1(dp)
            devport_obj.setTxEqPre1(dp, str(tx_eq_pre1))


    def _setup_tx(self, dp, lane_mask):

        node_id = self.cli.node_id
        if self.lpbk_mode == 1:
            # Set internal loopbck mode if selected
            attr_count = 1
            attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

            #6 Set SerDes ILB
            attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_ILB
            attr_list_p[0].value.u32 = 1;

            rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, dp,
                            attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));

            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Failed to set up PRBS ILB")
                return rc

        #1  Set port ADMIN_STATE to DISABLE on Tx port
        attr_count = 4
        attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

        #2  Lane select bitmask - select the lanes to operate on
        attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LANE_MASK
        attr_list_p[0].value.u32 = lane_mask;

        #3  Set the Tx EQ parameters (optional)
        #   User sets the Tx EQ params prior to
        #   invoking the prbs command

        #4  Set Tx Rate and Tx PRBS polynomial
        attr_list_p[1].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_TX_RATE
        attr_list_p[1].value.u32 = self.prbs_tx_rate;

        attr_list_p[2].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_GENERATOR_POLY
        attr_list_p[2].value.u32 = self.prbs_tx_poly;

        #5  Tx PRBS Generator enable - start PRBS traffic
        attr_list_p[3].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_GENERATOR
        attr_list_p[3].value.u32 = 1;

        rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, dp,
                        attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));

        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("Failed to set up Tx PRBS")
            return rc

        # Restore the lane mask
        attr_count = 1
        attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

        attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LANE_MASK
        attr_list_p[0].value.u32 = self.dp_orig_lane_mask[dp]

        rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, dp,
                                    attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));

        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("Failed to enable comparator on devport %d" % dp)

        return rc

    def _pause_pcal(self, dp, lane_mask):
        """
        Pause the pcal if enabled
        """
        node_id = self.cli.node_id
        attr_count = 1
        attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

        # Disable the port
        attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE
        attr_list_p[0].value.u32 = 0

        rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, dp,
                                    attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));

        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("Failed to disable ADMIN STATE Rx port")
            return rc

        intr_code = 0xa
        intr_data = 0x0

        for i in range(8):
            if ((lane_mask >> i) & 0x1):
                #log("Pausing pCal for devport %d lane %d" %(dp, i))
                rsp_data = self._devport_serdes_intr(dp, i, intr_code, intr_data)
                #log("Devport %d lane %d DFE status, rsp_data 0x%x" % (dp, i, rsp_data))


    def _setup_rx(self, dp, lane_mask):
        '''
        Method to setup Rx serdes and run PRBS check
        '''
        node_id = self.cli.node_id

        attr_count = 4
        attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

        # Lane select bitmask - select the lanes to operate on
        attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LANE_MASK
        attr_list_p[0].value.u32 = lane_mask;

        #6  Set Rx Rate and Rx polynomial
        attr_list_p[1].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_RX_RATE
        attr_list_p[1].value.u32 = self.prbs_rx_rate;

        attr_list_p[2].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_CHECKER_POLY
        attr_list_p[2].value.u32 = self.prbs_rx_poly;

        #7  Enable Rx serdes
        attr_list_p[3].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_CHECKER
        attr_list_p[3].value.u32 = 1;

        rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, dp,
                        attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));

        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("Failed to set up Rx PRBS")

        return  rc

    def _set_tune_mode(self, dp, lane_mask):
        """
        """
        node_id = self.cli.node_id
        # Check for DFE status
        for i in range(8):
            if ((lane_mask >> i) & 0x1):
                start = time.time()
                retry_count = 150
                while True:
                    intr_code = 0x126
                    intr_data = 0xb00
                    rsp_data = self._devport_serdes_intr(dp, i, intr_code,
                                                         intr_data)
                    if rsp_data == 0x80:
                        end = time.time()
                        #log("Devport %d lane %d, DFE completion time: %d sec" % (dp, i, (end - start)))
                        break
                    else:
                       time.sleep(0.1)
                       #log("Devport %d lane %d DFE status, rsp_data 0x%x" % (dp, i, rsp_data))

                    if retry_count == 0:
                       end = time.time()
                       log("Devport %d lane %d DFE completion exceeded wait time, %d sec, rsp_data 0x%x" % (dp, i, (end - start), rsp_data))
                       break

                    retry_count = retry_count - 1

        device_type = ifcs_ctypes.im_nmgr_node_device_type_get(self.cli.node_id)
        if device_type != ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
            # Below attribute is not applicable
            return ifcs_ctypes.IFCS_CONFIG

        attr_count = 1
        attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

        # Set Rx fine tune mode
        attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_RX_EQ_FINE_TUNE
        attr_list_p[0].value.u32 = self.rx_fine_tune

        rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, dp,
                                    attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));

        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("Failed to enable comparator on devport %d" % dp)

        return  rc

    def _start_rx_compare(self, dp, lane_mask):
        '''
        Method to check Rx PRBS status
        '''
        node_id = self.cli.node_id

        attr_count = 2
        attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

        # Start comparator
        attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_COMPARATOR
        attr_list_p[0].value.u32 = 1

        attr_list_p[1].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LANE_MASK
        attr_list_p[1].value.u32 = lane_mask

        rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, dp,
                                    attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));

        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("Failed to enable comparator on devport %d" % dp)

        return  rc


    def _get_devport_info(self, devport):
        """
        Get the sbus ring and addr for the given devport
        """
        devport_obj = Devport(self.cli)

        # Get num lanes and start lane for each devport
        num_lanes = devport_obj.getNumLanes(devport)
        start_lane = devport_obj.getStartLane(devport)

        devport_info = []

        # For each lane, get serdes info
        for lane_num in range(num_lanes):
            serdes_info = ifcs_ctypes.im_serdes_info_t()
            rc = ifcs_ctypes.im_devport_get_serdes_info(self.cli.node_id, devport,
                                            lane_num, pointer(serdes_info))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                err_msg = "Error getting serdes info for devport %d, rc %d" %(devport, rc)
                log_err(err_msg)
                return rc
            # Fill the serdes info
            lane_info = []
            lane_info.append(devport)
            lane_info.append(lane_num)
            lane_info.append(devport_obj.enum_to_str('serdes_group', serdes_info.isg))
            lane_info.append(serdes_info.serdes_num)
            lane_info.append(serdes_info.ring)
            sbus_addr = "0x%x" % (serdes_info.sbus_addr)
            lane_info.append(sbus_addr)

            # Add the lane_info in to devport list
            devport_info.append(lane_info)

        return devport_info

    def _create_dict_errors(self, output):
        """
        Create a dictionary of error output with sbus addr as key
        """
        err_dict = {}

        for row in output:
            err_dict[row[0]] = []
            for col in row[0:8]:
                err_dict[row[0]].append(col)

        return err_dict


    def _check_rx(self, rx_port, lane_mask, prbs_delay):
        '''
        Method to check Rx PRBS status
        '''
        self.output = []
        def aapl_log_callback(node_id, buff):
            self.output.append([compat_bytesToStr(x) for x in buff.split()])

        callback_type = CFUNCTYPE(
            ifcs_ctypes.UNCHECKED(None),
            ifcs_ctypes.ifcs_node_id_t,
            c_char_p)
        callback = callback_type(aapl_log_callback)

        node_id = self.cli.node_id
        devport_obj = Devport(self.cli)

        # Check for all ports
        if self.arg_list[5] == 'all':
            sbus_addrs = " 0:ee,1:ee"
        else:
            devport = rx_port[0]
            devport_info = self._get_devport_info(devport)
            num_lanes = devport_obj.getNumLanes(devport)
            sbus_addrs = " "

            for i in range(num_lanes):
                if i != 0:
                    sbus_addrs = sbus_addrs + ","
                sbus_addrs = sbus_addrs + '%s:%s' % (devport_info[i][4], devport_info[i][5].split('0x')[1])

        devport = 1 # dummy
        lane = 0 # dummy

        log("Getting BER with dwell time of %d sec" % prbs_delay)

        # Build the AAPL cmd to retrieve the BER
        if self.pcal_en == 1:
            # With pcal, use aux counter
            """
            argc = 7
            arg_list = 'aapl serdes -addr %s -aux-start -timeout 20000' % (sbus_addrs)
            log(arg_list)

            argv = (c_char_p * argc)()
            arg_idx = 0
            for x in arg_list.split():
                argv[arg_idx] = compat_strToBytes(x)
                arg_idx += 1

            self.output = []
            rc = ifcs_ctypes.im_devport_serdes_aapl_cmd(node_id,
                                            devport, lane,
                                            argc, compat_pointer(argv, POINTER(c_char)), compat_funcPointer(callback, ifcs_ctypes.im_depvort_aapl_user_cb_t))

            if rc != ifcs_ctypes.IFCS_SUCCESS:
                err_msg = "ERR executing AAPL command, rc %d" % rc
                log_err(err_msg)
                return
            """
            # Run the BER command
            argc = 10
            arg_list = 'aapl serdes -addr %s -ber-aux -ber-dwell %d -aux-reset -timeout 20000' % (sbus_addrs, prbs_delay)
        else:
            # Run the BER command
            argc = 10
            arg_list = 'aapl serdes -addr %s -ber -ber-dwell %d -error-reset -timeout 20000' % (sbus_addrs, prbs_delay)

        # Get BER usign AAPL
        #log(arg_list)
        argv = (c_char_p * argc)()
        arg_idx = 0
        for x in arg_list.split():
            argv[arg_idx] = compat_strToBytes(x)
            arg_idx += 1

        self.output = []
        rc = ifcs_ctypes.im_devport_serdes_aapl_cmd(node_id,
                                        devport, lane,
                                        argc, compat_pointer(argv, POINTER(c_char)), compat_funcPointer(callback, ifcs_ctypes.im_depvort_aapl_user_cb_t))

        if rc != ifcs_ctypes.IFCS_SUCCESS:
            err_msg = "ERR executing AAPL command, rc %d" % rc
            log_err(err_msg)
            return  rc

        # Parse the AAPL cmd output
        # First line has header info, drop it
        self.output[0] = self.output[0][17:]

        error_info = self._create_dict_errors(self.output)

        for dp in rx_port:
            devport_info = self._get_devport_info(dp)
            num_lanes = devport_obj.getNumLanes(dp)
            for i in range(num_lanes):
                if ((lane_mask >> i) & 0x1):
                    # Get the err diff and BER
                    ring = devport_info[i][4]
                    if ring == 0:
                        ring = ""
                    sbus_addr = devport_info[i][5][2:]
                    key= "%s:%s" %(ring, sbus_addr)
                    err_diff = error_info[key][5]
                    ber = error_info[key][7]

                    self.prbs_table.add_row([dp, i, devport_info[i][2], self.prbs_rate, self.prbs_poly, err_diff, ber])

            # Reset the original lane mask for the port
            attr_count = 1
            attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

            attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LANE_MASK
            attr_list_p[0].value.u32 = self.dp_orig_lane_mask[dp];

            rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, dp,
                                        attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));

            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Failed to set Rx lane")

        return rc


    # ------------
    # test command
    # ------------
    def prbs(self, args):
        self.sync_cmd = False

        node_id = self.cli.node_id
        if ifcs_ctypes.im_nmgr_node_device_type_get(node_id) == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TL10:
            return serdes_comphy.prbs_tl10(self, args)

        if ifcs_ctypes.im_nmgr_node_device_type_get(node_id) != ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
            log("Command not valid for chip type!")
            return ifcs_ctypes.IFCS_INVAL

        self.prbs_table = PrintTable()
        self.prbs_table.add_row(['Devport', 'Lane', 'ISG', 'Rate', 'Polynomial','Err Diff', 'BER'])

        if self._validate_user_input(args) == True:
            return ifcs_ctypes.IFCS_INVAL

        # For sync command, return
        if self.sync_cmd == True:
            return

        devport_obj = Devport(self.cli)

        if self.tx_serdes == 1:
            # Tx serdes
            if self.tx_stop == 1:
                log("Stopping Tx PRBS")
                for dp in self.tx_port:
                    self._prbs_tx_stop(dp, self.dp_orig_lane_mask[dp])

                return

            log("Setting up Tx PRBS")
            # Disable all ports
            for dp in self.tx_port:
                self._disable_tx(dp)

            # Set up Tx PRBS
            for dp in self.tx_port:
                # Get lane mask for 'all' input
                if self.tx_lane_mask == 0xFF:
                    tx_lane_mask = devport_obj.getLaneMask(dp)
                else:
                    tx_lane_mask = self.tx_lane_mask

                self._setup_tx(dp, tx_lane_mask)

            log("Waiting for Tx setup to complete")
            time.sleep(2)

        if self.lpbk_mode == 1 or self.rx_serdes == 1:
            # Rx serdes
            if self.rx_stop == 1:
                log("Stopping Rx PRBS")
                for dp in self.rx_port:
                    self._prbs_rx_stop(dp, self.dp_orig_lane_mask[dp])

                return

            log("Setting up Rx PRBS")
            for dp in self.rx_port:
                # Get lane mask for 'all' input
                if self.rx_lane_mask == 0xFF:
                    rx_lane_mask = devport_obj.getLaneMask(dp)
                else:
                    rx_lane_mask = self.rx_lane_mask

                self._pause_pcal(dp, rx_lane_mask)

            # Wait for pcal pause to complete
            time.sleep(2)

            for dp in self.rx_port:
                # Get lane mask for 'all' input
                if self.rx_lane_mask == 0xFF:
                    rx_lane_mask = devport_obj.getLaneMask(dp)
                else:
                    rx_lane_mask = self.rx_lane_mask

                self._setup_rx(dp, rx_lane_mask)

            log("Starting Rx comparator")
            for dp in self.rx_port:
                # Get lane mask for 'all' input
                if self.rx_lane_mask == 0xFF:
                    rx_lane_mask = devport_obj.getLaneMask(dp)
                else:
                    rx_lane_mask = self.rx_lane_mask

                self._set_tune_mode(dp, rx_lane_mask)

            # Delay for pcal fine tune to complete
            time.sleep(2)

            for dp in self.rx_port:
                # Get lane mask for 'all' input
                if self.rx_lane_mask == 0xFF:
                    rx_lane_mask = devport_obj.getLaneMask(dp)
                else:
                    rx_lane_mask = self.rx_lane_mask

                self._start_rx_compare(dp, rx_lane_mask)


            self.prbs_poly = devport_obj.enum_to_str('prbs_checker_poly', self.prbs_rx_poly)
            self.prbs_rate = devport_obj.enum_to_str('prbs_rx_rate', self.prbs_rx_rate)

            log("Starting Rx checker")
            self._check_rx(self.rx_port, self.rx_lane_mask, self.prbs_delay)

            log("\n")
            self.prbs_table.print_table()
            self.prbs_table.reset_table()




    def tl_pcie(self, args):
        '''
        Method to swap the PCIe serdes firmware
        '''
        def remote_shell_callback(node_id, buff):
            log("%s" % compat_bytesToStr(buff))

        callback_type = CFUNCTYPE(
            ifcs_ctypes.UNCHECKED(None),
            ifcs_ctypes.ifcs_node_id_t,
            c_char_p)
        callback = callback_type(remote_shell_callback)

        node_id = self.cli.node_id
        if ifcs_ctypes.im_nmgr_node_device_type_get(node_id) != ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
            log("Command not valid for chip type!")
            return ifcs_ctypes.IFCS_INVAL

        arg_list = shlex.split(args)
        num_args = len(self.arg_list)

        if num_args < 5:
            log_err("Incorrect params passed to the test\n")
            self.help_pcie(args)
            return ifcs_ctypes.IFCS_INVAL

        sbus_addr = int(arg_list[3])
        devport = 0 # dummy
        lane = 0 #dummy

        # Extract the aapl command to pass
        # to Aapl lib
        argv = arg_list[4]

        # Append -addr <#> to the command
        addr_opt = " -addr 0:0x%x" % (sbus_addr)
        argv = argv + addr_opt
        arg_list[4] = argv
        argc = (len(shlex.split(argv)))
        argv = (c_char_p * argc)()
        arg_idx = 0
        for x in arg_list[4].split():
            argv[arg_idx] = compat_strToBytes(x)
            arg_idx += 1

        rc = ifcs_ctypes.im_devport_serdes_aapl_cmd(node_id,
                                        devport, lane,
                                        argc, compat_pointer(argv, POINTER(c_char)), compat_funcPointer(callback, ifcs_ctypes.im_depvort_aapl_user_cb_t))

        if rc != ifcs_ctypes.IFCS_SUCCESS:
            err_msg = "ERR executing AAPL command, rc %d" % rc
            log_err(err_msg)

        return rc

    def sbm(self, args):
        '''
        Access SBus master
        '''
        def remote_shell_callback(node_id, buff):
            log("%s" % compat_bytesToStr(buff))

        callback_type = CFUNCTYPE(
            ifcs_ctypes.UNCHECKED(None),
            ifcs_ctypes.ifcs_node_id_t,
            c_char_p)
        callback = callback_type(remote_shell_callback)

        node_id = self.cli.node_id
        if ifcs_ctypes.im_nmgr_node_device_type_get(node_id) != ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
            log("Command not valid for chip type!")
            return ifcs_ctypes.IFCS_INVAL

        arg_list = shlex.split(args)
        num_args = len(self.arg_list)

        if num_args < 5:
            log_err("Incorrect params passed to the test\n")
            self.help_sbm(args)
            return ifcs_ctypes.IFCS_INVAL

        sbus_addr = arg_list[3]
        devport = 0 # dummy
        lane = 0 #dummy

        # Extract the aapl command to pass
        # to Aapl lib
        argv = arg_list[4]

        # Append -addr <#> to the command
        addr_opt = " -addr %s" % (sbus_addr)
        argv = argv + addr_opt
        arg_list[4] = argv
        argc = (len(shlex.split(argv)))
        argv = (c_char_p * argc)()
        arg_idx = 0
        for x in arg_list[4].split():
            argv[arg_idx] = compat_strToBytes(x)
            arg_idx += 1

        rc = ifcs_ctypes.im_devport_serdes_aapl_cmd(node_id,
                                                    devport, lane,
                                                    argc, compat_pointer(argv, POINTER(c_char)), compat_funcPointer(callback, ifcs_ctypes.im_depvort_aapl_user_cb_t))

        if rc != ifcs_ctypes.IFCS_SUCCESS:
            err_msg = "ERR executing AAPL command, rc %d" % rc
            log_err(err_msg)

        return rc


    def help_prbs(self, args):
        log("Usage:: \n" + \
              "  diagtest serdes prbs tx <devport> <lane-mask> <poly> <rate> <lpbk> <delay>\n" \
              " <devport>   - tx devport number or 'all' \n" \
              " <lane-mask> - tx devport lane number (0x0 - 0xFF, all)\n" \
              " <poly>          - PRBS polynomial\n" \
              "                    prbs7\n" \
              "                    prbs9\n" \
              "                    prbs11\n" \
              "                    prbs13\n" \
              "                    prbs15\n" \
              "                    prbs23\n" \
              "                    prbs31\n" \
              " <rate>          - PRBS rate\n" \
              "                    10g (10.3125)\n" \
              "                    25g (25.78125)\n" \
              "                    26g (26.5625)\n" \
              "                    27g (27.1875)\n" \
              "                    28g (28.125)\n" \
              "                    51g (51.5625)\n" \
              "                    53g (53.125)\n" \
              "                    54g (54.375)\n" \
              "                    56g (56.25)\n" \
              " ----- Optional params -----\n"\
              " <lpbk>          - Loopback(local/internal) mode\n" \
              "                     - 1: Enable\n" \
              "                     - 0: Disable\n\n" \
              " <delay>         - Time (in sec) to run the PRBS, required if loopback mode is used\n" \
              "\n"\
              "  diagtest serdes prbs rx <devport> <lane-mask> <poly> <rate> <delay> <rx-pcal>\n" \
              " <devport>   - tx devport number or all\n" \
              " <lane-mask> - tx devport lane number (0x0 - 0xFF, all)\n" \
              " <poly>          - PRBS polynomial\n" \
              "                    prbs7\n" \
              "                    prbs9\n" \
              "                    prbs11\n" \
              "                    prbs13\n" \
              "                    prbs15\n" \
              "                    prbs23\n" \
              "                    prbs31\n" \
              " <rate>          - PRBS rate\n" \
              "                    10g (10.3125)\n" \
              "                    25g (25.78125)\n" \
              "                    26g (26.5625)\n" \
              "                    27g (27.1875)\n" \
              "                    28g (28.125)\n" \
              "                    51g (51.5625)\n" \
              "                    53g (53.125)\n" \
              "                    54g (54.375)\n" \
              "                    56g (56.25)\n"\
              " <delay>         - Time (in sec) to run the PRBS\n" \
              " <rx-pcal>       - Enable Rx pCal (optional param)\n" \
              "                 - 1: Continuous\n" \
              "                 - 0: Single\n" \
              "\n"\
              "  diagtest serdes prbs tx stop <devport> <lane-mask>\n" \
              " <devport>   - tx devport number or all \n" \
              " <lane-mask> - tx devport lane number (0x0 - 0xFF, all)\n" \
              "\n"\
              "  diagtest serdes prbs rx stop <devport> <lane-mask>\n" \
              " <devport>   - tx devport number or all\n" \
              " <lane-mask> - tx devport lane number (0x0 - 0xFF, all)\n")



    def help_prbs_mode_en(self):
        log("Usage:: \n" + \
              "  diagtest serdes prbs mode-en <devport> <enable>\n" \
              " <devport>   - devport,range of devports or 'all' \n" \
              "               e.g. 1,2,3,4,16-20,30  \n" \
              " <enable>    - 1: enable PRBS mode  \n" \
              "               0: disable PRBS mode  \n" )

    def help_prbs_set(self):
        log("Usage:: \n" + \
              "  diagtest serdes prbs set <devport> <enable-mode> <poly> <err-counter-limit> <compare-time>\n" \
              " <devport>           - devport,range of devports or 'all' \n" \
              "                         e.g. 1,2,3,4,16-20,30  \n" \
              " <enable-mode>       - 1: enable PRBS mode  \n" \
              " <poly>              - PRBS polynomial\n" \
              "                         prbs7\n" \
              "                         prbs9\n" \
              "                         prbs11\n" \
              "                         prbs13\n" \
              "                         prbs15\n" \
              "                         prbs23\n" \
              "                         prbs31\n" \
              " <err-counter-limit> - Number of errors to use for sync status determination\n" \
              " <compare-time>      - Time (in milli sec) to compute the BER and capture errors\n" )

    def help_prbs_sync(self):
        log("Usage:: \n" + \
              "  diagtest serdes prbs sync <devport> \n" \
              " <devport>   - devport,range of devports or 'all' \n" \
              "               e.g. 1,2,3,4,16-20,30  \n")

    def help_prbs_get(self):
        log("Usage:: \n" + \
              "  diagtest serdes prbs get <devport> \n" \
              " <devport>   - devport,range of devports or 'all' \n" \
              "               e.g. 1,2,3,4,16-20,30  \n" )

    def help_prbs_clear(self):
        log("Usage:: \n" + \
              "  diagtest serdes prbs clear <devport> \n" \
              " <devport>   - devport,range of devports or 'all' \n" \
              "               e.g. 1,2,3,4,16-20,30  \n" )
