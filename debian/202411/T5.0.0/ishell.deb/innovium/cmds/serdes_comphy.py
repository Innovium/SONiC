#-------------------------------------------------------------------------------
# Copyright (c) (2023) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import shlex
import argparse
import itertools
import time
import json
import sys
from utils.compat_util import *
from verbosity import *
from ctypes import *
from ifcs_cmds.devport import Devport as Devport
from print_table import PrintTable

ifcs_ctypes = sys.modules['ifcs_ctypes']


def get_devport_info(self, devport):
    """
    Get the sbus ring and addr for the given devport
    """
    devport_obj = Devport(self.cli)

    # Get num lanes and start lane for each devport
    num_lanes = devport_obj.getNumLanes(devport)
    start_lane = devport_obj.getStartLane(devport)

    devport_info = []

    # For each lane, get serdes info
    for lane_num in range(num_lanes):
        serdes_info = ifcs_ctypes.im_serdes_info_t()
        rc = ifcs_ctypes.im_devport_get_serdes_info(self.cli.node_id, devport,
                                        lane_num, pointer(serdes_info))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            err_msg = "Error getting serdes info for devport %d, rc %d" %(devport, rc)
            log_err(err_msg)
            return
        # Fill the serdes info
        lane_info = []
        lane_info.append(devport)
        lane_info.append(lane_num)
        lane_info.append(devport_obj.enum_to_str('serdes_group', serdes_info.isg))
        lane_info.append(serdes_info.serdes_num)
        lane_info.append(serdes_info.ring)
        sbus_addr = "0x%x" % (serdes_info.sbus_addr)
        lane_info.append(sbus_addr)

        # Add the lane_info in to devport list
        devport_info.append(lane_info)

    return devport_info

def save_dp_lane_mask(self):
    '''
    Save the original lane mask for all devports
    '''

    devport_obj = Devport(self.cli)
    self.dp_orig_lane_mask = {}

    for dp in getAlldevport(self):
        self.dp_orig_lane_mask[dp] = devport_obj.getLaneMask(dp)

def getAlldevport(self):
    def myCallback(node_id, arg, attr_count, attr_list, user_data):
        devport = arg
        attr = attr_list[ifcs_ctypes.IFCS_DEVPORT_ATTR_TYPE]
        assert attr.id == ifcs_ctypes.IFCS_DEVPORT_ATTR_TYPE
        if (attr.value.u32 == ifcs_ctypes.IFCS_DEVPORT_TYPE_ETH or
            attr.value.u32 == ifcs_ctypes.IFCS_DEVPORT_TYPE_AUX):
            devport_list.append(devport)

    devport_list = []

    callback_type = CFUNCTYPE(
        ifcs_ctypes.UNCHECKED(None),
        ifcs_ctypes.ifcs_node_id_t,
        ifcs_ctypes.ifcs_devport_t,
        c_uint32,
        POINTER(ifcs_ctypes.ifcs_attr_t),
        POINTER(None))
    callback = callback_type(myCallback)

    try:
        rc = ifcs_ctypes.ifcs_devport_get_all(self.cli.node_id, 0, None, compat_funcPointer(callback, ifcs_ctypes.ifcs_devport_user_cb_t), None, None)
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("Failed to get all eth devport rc: %d" %(rc))
    except Exception as e:
        log("Failed to get all eth devport rc: %d" %(rc))
        raise e

    return sorted(devport_list)

def disable_tx(self, dp):
    node_id = self.cli.node_id
    devport_obj = Devport(self.cli)

    # Disable the port
    devport_obj.setAdminState(dp, 0)

def disable_rx(self, dp):
    node_id = self.cli.node_id
    devport_obj = Devport(self.cli)

    if devport_obj.getAdminState(dp) == 1:
        # Disable the port
        devport_obj.setAdminState(dp, 0)

def setup_tx(self, dp, lane_mask):

    node_id = self.cli.node_id
    if self.lpbk_mode == 1:
        # Set internal loopbck mode if selected
        attr_count = 1
        attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

        #6 Set SerDes ILB
        attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_ILB
        attr_list_p[0].value.u32 = 1;

        rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, dp,
                        attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));

        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("Failed to set up PRBS ILB")
            return

    #1  Set port ADMIN_STATE to DISABLE on Tx port
    attr_count = 4
    attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

    #2  Lane select bitmask - select the lanes to operate on
    attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LANE_MASK
    attr_list_p[0].value.u32 = lane_mask;

    #3  Set the Tx EQ parameters (optional)
    #   User sets the Tx EQ params prior to
    #   invoking the prbs command

    #4  Set Tx Rate and Tx PRBS polynomial
    attr_list_p[1].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_TX_RATE
    attr_list_p[1].value.u32 = self.prbs_tx_rate;

    attr_list_p[2].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_GENERATOR_POLY
    attr_list_p[2].value.u32 = self.prbs_tx_poly;

    #5  Tx PRBS Generator enable - start PRBS traffic
    attr_list_p[3].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_GENERATOR
    attr_list_p[3].value.u32 = 1;

    rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, dp,
                   attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));

    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log("Failed to set up Tx PRBS")
        return

    # Restore the lane mask
    attr_count = 1
    attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

    attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LANE_MASK
    attr_list_p[0].value.u32 = self.dp_orig_lane_mask[dp]

    rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, dp,
                                attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));

    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log("Failed to enable comparator on devport %d" % dp)
        return

    return

def setup_rx(self, dp, lane_mask):
    '''
    Method to setup Rx serdes and run PRBS check
    '''
    node_id = self.cli.node_id

    attr_count = 4
    attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

    # Lane select bitmask - select the lanes to operate on
    attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LANE_MASK
    attr_list_p[0].value.u32 = lane_mask;

    #6  Set Rx Rate and Rx polynomial
    attr_list_p[1].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_RX_RATE
    attr_list_p[1].value.u32 = self.prbs_rx_rate;

    attr_list_p[2].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_CHECKER_POLY
    attr_list_p[2].value.u32 = self.prbs_rx_poly;

    #7  Enable Rx serdes
    attr_list_p[3].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_CHECKER
    attr_list_p[3].value.u32 = 1;

    rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, dp,
                    attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));

    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log("Failed to set up Rx PRBS")
        return

def prbs_tx_stop(self, tx_port, lane_mask):
    """
    Clean up PRBS setup

    """
    node_id = self.cli.node_id
    attr_count = 4
    attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

    attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LANE_MASK
    attr_list_p[0].value.u32 = lane_mask

    attr_list_p[1].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_TX_RATE
    attr_list_p[1].value.u32 = ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_NOTCONFIGURED

    attr_list_p[2].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_GENERATOR_POLY
    attr_list_p[2].value.u32 = ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_NOTCONFIGURED

    attr_list_p[3].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_GENERATOR
    attr_list_p[3].value.u32 = 0

    rc = ifcs_ctypes.ifcs_devport_attr_set(node_id, tx_port,
                               attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));

    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log("Failed to stop Tx PRBS")

    return

def prbs_rx_stop(self, rx_port, lane_mask):
    """
    Clean up PRBS setup

    """
    node_id = self.cli.node_id

    # Stop PRBS Comparator/checker
    attr_count = 5
    attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

    attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LANE_MASK
    attr_list_p[0].value.u32 = lane_mask

    attr_list_p[1].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_RX_RATE
    attr_list_p[1].value.u32 = ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_NOTCONFIGURED

    attr_list_p[2].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_CHECKER_POLY
    attr_list_p[2].value.u32 = ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_NOTCONFIGURED

    attr_list_p[3].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_CHECKER
    attr_list_p[3].value.u32 = 0

    attr_list_p[4].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_COMPARATOR
    attr_list_p[4].value.u32 = 0

    rc = ifcs_ctypes.ifcs_devport_attr_set(node_id, rx_port,
                               attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));

    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log("Failed to stop Rx PRBS")
        return
    return


def start_rx_compare(self, dp, lane_mask):
    '''
    Method to check Rx PRBS status
    '''
    node_id = self.cli.node_id

    attr_count = 2
    attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

    # Start comparator
    attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_COMPARATOR
    attr_list_p[0].value.u32 = 1

    attr_list_p[1].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LANE_MASK
    attr_list_p[1].value.u32 = lane_mask

    rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, dp,
                                attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));

    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log("Failed to enable comparator on devport %d" % dp)
        return

def stop_rx_compare(self, dp, lane_mask):
    '''
    Method to stop Rx PRBS Test
    '''
    node_id = self.cli.node_id

    attr_count = 2
    attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

    # Stop comparator
    attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_COMPARATOR
    attr_list_p[0].value.u32 = 0

    attr_list_p[1].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LANE_MASK
    attr_list_p[1].value.u32 = lane_mask

    rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, dp,
                                attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));

    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log("Failed to stop comparator on devport %d" % dp)
        return

def parse_mode_cmd_args(self, cmd_args):
    """
    Parse the mode-en command args
    """
    node_id = self.cli.node_id
    check_failed = False
    devport_obj = Devport(self.cli)

    try:
        self.mode_enable = int(cmd_args[0])
    except Exception as ex:
        check_failed = True
        return check_failed

    for dp in self.port_list:
        devport_obj.setPrbsModeEnable(dp, self.mode_enable)

    time.sleep(2)
    log("PRBS mode-en set to %d" % (self.mode_enable))
    return check_failed

def parse_clear_cmd_args(self):
    """
    Parse the clear command args
    """
    node_id = self.cli.node_id
    check_failed = False
    devport_obj = Devport(self.cli)

    # Set PRBS_SYNC to FALSE
    for dp in self.port_list:
        devport_obj.setPrbsSync(dp, ifcs_ctypes.IFCS_BOOL_FALSE)

    time.sleep(2)
    down_port_list = []
    # Clear all user set attrs
    for dp in self.port_list:
        devport_obj.setPrbsGeneratorPoly(dp, ifcs_ctypes.IFCS_DEVPORT_PRBS_MODE_NOTCONFIGURED)
        devport_obj.setPrbsCheckerPoly(dp, ifcs_ctypes.IFCS_DEVPORT_PRBS_MODE_NOTCONFIGURED)
        devport_obj.setPrbsErrCount2Limit(dp, 0)
        devport_obj.setPrbsCompareTime(dp, 0)
        devport_obj.setPrbsSet(dp, ifcs_ctypes.IFCS_DEVPORT_PRBS_MODE_NOTCONFIGURED)
    for dp in self.port_list:
        if devport_obj.getAdminState(dp) == 0:
            devport_obj.setAdminState(dp, 1)
            down_port_list.append(dp)
    for dp in down_port_list:
        devport_obj.setAdminState(dp, 0)
    log("PRBS config cleared")
    return check_failed

def get_sync_status_str(self, sync_status):
    """
    Convert the sync status to str
    """

    if sync_status == 0:
        return "NOTCONFIGURED"
    elif sync_status == 1:
        return "LINK_DOWN"
    elif sync_status == 2:
        return "SYNC_IN_PROGRESS"
    elif sync_status == 3:
        return "SYNC"
    elif sync_status == 4:
        return "NO_SYNC"
    elif sync_status == 5:
        return "LINK_DOWN_SYNC"
    elif sync_status == 6:
        return "LINK_DOWN_NO_SYNC"

def parse_get_cmd_args(self):
    """
    Parse the get command args
    """
    node_id = self.cli.node_id
    check_failed = False

    devport_obj = Devport(self.cli)

    prbs_table = PrintTable()
    prbs_table.add_row(['Devport', 'Lane','ISG', 'Serdes#', 'Polynomial','Err Diff', 'Sync Status'])
    # Get the error count, BER and sync status
    for dp in self.port_list:
        devport_info = get_devport_info(self, dp)
        num_lanes   = devport_obj.getNumLanes(dp)
        prbs_poly   = devport_obj.enum_to_str('prbs_checker_poly', devport_obj.getPrbsGeneratorPoly(dp))
        err_count   = devport_obj.getPrbsErrCount2(dp)
        sync_status = devport_obj.getPrbsSyncStatus(dp)
        prbs_lock   = devport_obj.getPrbsLock(dp)

        for i in range(num_lanes):
            # Get the err diff and BER
            ring = devport_info[i][4]
            if ring == 0:
                ring = ""
            sbus_addr = devport_info[i][5][2:]
            key= "%s:%s" %(ring, sbus_addr)

            if prbs_poly == 'NOTCONFIGURED':
                error_count = 'N/A'
            else:
                error_count = err_count[i]

            if len(sync_status) == 0:
                sync = 'N/A'
            elif prbs_poly == 'NOTCONFIGURED':
                sync = 'N/A'
            else:
                sync = get_sync_status_str(self, sync_status[i])

            if((prbs_lock[i] == 0) and (sync != 'SYNC_IN_PROGRESS') and (prbs_poly != 'NOTCONFIGURED')):
                error_count = 'NO LOCK'
                sync = 'N/A'

            prbs_table.add_row([dp, i, devport_info[i][2], devport_info[i][3], prbs_poly, error_count, sync])

    log("\n")
    prbs_table.print_table()
    prbs_table.reset_table()

    return check_failed

def parse_sync_cmd_args(self):
    """
    Parse the sync command args
    """
    node_id = self.cli.node_id
    check_failed = False

    devport_obj = Devport(self.cli)

    #Set the SYNC attr to True
    for dp in self.port_list:
        devport_obj.setPrbsSync(dp, ifcs_ctypes.IFCS_BOOL_TRUE)

    time.sleep(2)
    log("prbs sync cmd called\n")
    return check_failed

def parse_set_cmd_args(self, cmd_args):
    """
    Parse the set command args
    """
    node_id = self.cli.node_id
    check_failed = False

    devport_obj = Devport(self.cli)

    try:
        set_enable = int(cmd_args[0])
        polynomial = get_prbs_poly(self, cmd_args[1])
        err_limit = int(cmd_args[2])
        #ber_limit = float(cmd_args[3])
        comp_time = int(cmd_args[3])
    except Exception as ex:
        check_failed = True
        return check_failed
    #log("set cmd args parsed")

    # Set the following attrs
    #   PRBS generator polynomial
    #   PRBS checker polynomial
    #   PRBS error counter limit
    #   PRBS BER limit
    #   PRBS compare/dwell time
    #   PRBS start
    for dp in self.port_list:

        #log("devport: %d enable: %d polynomial: %s err_limit: %d ber_limit: %s compare_time: %d" %
        #        (dp, set_enable, polynomial, err_limit, ber_limit, comp_time))
        lane_mask   = devport_obj.getLaneMask(dp)

        attr_count = 5
        attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

        attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_GENERATOR_POLY
        attr_list_p[0].value.u32 = polynomial

        attr_list_p[1].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_CHECKER_POLY
        attr_list_p[1].value.u32 = polynomial

        attr_list_p[2].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_ERR_COUNT2_LIMIT
        attr_list_p[2].value.u32 = err_limit

        attr_list_p[3].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_COMPARE_TIME
        attr_list_p[3].value.u32 = comp_time

        attr_list_p[4].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_SET
        attr_list_p[4].value.u32 = set_enable

        rc = ifcs_ctypes.ifcs_devport_attr_set(node_id, dp,
                                    attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));

        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("PRBS set command failed\n")
            check_failed = True
            return check_failed

    time.sleep(2)
    log("PRBS set command called\n")
    return check_failed


def parse_devport_arg(self, dp_arg):
    """
    Parse the devport param - single, range of ports
    """
    check_failed = False
    self.port_list = []
    devport_arg = []

    if dp_arg == 'all':
        self.port_list = self._getAlldevport()
    else:
        devport_arg = dp_arg.split(",")

    try:
        for dp in devport_arg:
            if '-' in dp:
                dp_range = compat_listrange(int(dp.split('-')[0]), int(dp.split('-')[1]) + 1)
                for i in dp_range:
                    self.port_list.append(i)
            else:
                self.port_list.append(int(dp))

    except Exception as ex:
        check_failed = True

    return check_failed

def parse_prbs_sync_args(self, arg_list):
    """
    Parse PRBS sync command args
    """
    check_failed = False
    help_string = {'mode-en': self.help_prbs_mode_en,
                    'set':    self.help_prbs_set,
                    'sync':   self.help_prbs_sync,
                    'get':    self.help_prbs_get,
                    'clear':  self.help_prbs_clear,
                    }

    cmd = arg_list[3]
    # Check for valid args
    if cmd == 'mode-en':
        exp_arg_count = 2
    elif cmd == 'set':
        exp_arg_count = 5
    elif cmd == 'sync':
        exp_arg_count = 1
    elif cmd == 'get':
        exp_arg_count = 1
    elif cmd == 'clear':
        exp_arg_count = 1

    arg_list = arg_list[4:]
    if len(arg_list) != exp_arg_count:
        check_failed = True
        log_err("Incorrect params passed")
        help_string[cmd]()
        return check_failed

    # Parse devport arg
    check_failed = parse_devport_arg(self, arg_list[0])
    if check_failed == True:
        help_string[cmd]()
        return check_failed

    # Parse prbs set cmd args
    if cmd == 'mode-en':
        check_failed = parse_mode_cmd_args(self, arg_list[1:])
        if check_failed == True:
            self.help_prbs_mode_en()
            return check_failed

    # Parse prbs set cmd args
    if cmd == 'set':
        check_failed = parse_set_cmd_args(self, arg_list[1:])
        if check_failed == True:
            self.help_prbs_set()
            return check_failed

    # Parse sync cmd args
    if cmd == 'sync':
        check_failed = parse_sync_cmd_args(self)
        if check_failed == True:
            self.help_prbs_sync()
            return check_failed

    # Parse get cmd args
    if cmd == 'get':
        check_failed = parse_get_cmd_args(self)
        if check_failed == True:
            self.help_prbs_get()
            return check_failed

    # Parse clear cmd args
    if cmd == 'clear':
        check_failed = parse_clear_cmd_args(self)
        if check_failed == True:
            self.help_prbs_clear()
            return check_failed

    return check_failed

def run_cmd(self, args):
        self.arg_list = shlex.split(args)
        try:
            rc = self.sub_cmds[self.arg_list[2]](args)
            return rc
        except (KeyError):
            log("ERR: Invalid command, list of valid commands...")
            self.sub_cmds['help'](args)
            return ifcs_ctypes.IFCS_PARAM
        except Exception as ex:
            self.cli.error()
            self.sub_cmds['help'](args)

def validate_user_input(self, args):
        '''
        Check for user test params passed
        '''
        devport_obj = Devport(self.cli)

        check_failed = False
        self.tx_serdes = 0
        self.rx_serdes = 0
        self.lpbk_mode = 0
        self.rx_stop = 0
        self.tx_stop = 0
        self.rx_stop = 0
        self.tx_port = []
        self.rx_port = []

        self.arg_list  = args.split()
        num_args = len(self.arg_list)

        # Save the original devport lane mask for all ports
        save_dp_lane_mask(self)

        if num_args < 4:
            log_err("Incorrect params passed to the test\n")
            help_prbs_comphy(self, args)
            help_prbs_mode_en(self, args)
            help_prbs_set(self, args)
            help_prbs_sync(self, args)
            help_prbs_get(self, args)
            help_prbs_clear(self, args)
            check_failed = True
            return check_failed

        # Tx or Rx ?
        if self.arg_list[3] == 'tx':
            self.tx_serdes = 1
            if self.arg_list[4] == 'stop':
                self.tx_stop = 1
                if self.arg_list[5] == 'all':
                    self.tx_port    = self._getAlldevport()
                else:
                    self.tx_port.append(int(self.arg_list[5]))

                if self.arg_list[6] == 'all':
                    self.tx_lane_mask   = 0xFF
                else:
                    self.tx_lane_mask   = int(self.arg_list[6], 16)
                return

        elif self.arg_list[3] == 'rx':
            self.rx_serdes = 1
            if self.arg_list[4] == 'stop':
                self.rx_stop = 1
                if self.arg_list[5] == 'all':
                    self.rx_port    = self._getAlldevport()
                else:
                    self.rx_port.append(int(self.arg_list[5]))

                if self.arg_list[6] == 'all':
                    self.rx_lane_mask   = 0xFF
                else:
                    self.rx_lane_mask   = int(self.arg_list[6], 16)

                return

        elif self.arg_list[3] in ['mode-en', 'set', 'sync',
                                  'get',     'clear']:

            self.sync_cmd = True
            check_failed = parse_prbs_sync_args(self, self.arg_list)
            if check_failed == True:
                return check_failed

            return

        else:
            log_err("Incorrect params \n")
            help_prbs_comphy(self, args)
            help_prbs_clear()
            check_failed = True
            return check_failed

        if self.tx_serdes == 1:

            if num_args < 8:
                log_err("Incorrect params passed to the test\n")
                help_prbs_comphy(self, args)
                check_failed = True
                return check_failed

            if self.arg_list[4] == 'all':
                self.tx_port    = self._getAlldevport()
            else:
                self.tx_port.append(int(self.arg_list[4]))

            if self.arg_list[5] == 'all':
                self.tx_lane_mask   = 0xFF
            else:
                self.tx_lane_mask   = int(self.arg_list[5], 16)

            self.prbs_tx_poly   = get_prbs_poly(self, self.arg_list[6])
            self.prbs_tx_rate   = get_prbs_rate(self, self.arg_list[7])

            for dp in self.tx_port:
                # Get lane mask for 'all' input
                if self.tx_lane_mask == 0xFF:
                    tx_lane_mask = devport_obj.getLaneMask(dp)
                else:
                    tx_lane_mask = self.tx_lane_mask

                # Loopback mode check
                if num_args > 8:
                    self.lpbk_mode = int(self.arg_list[8])
                    if (self.lpbk_mode != 0) and (self.lpbk_mode != 1):
                        log_err("Invalid lpbk mode param\n")
                        check_failed = True
                        help_prbs_comphy(self, args)
                        return check_failed

                    #log("Using internal loopback mode")
                    self.rx_port.append(dp)
                    self.rx_lane_mask = tx_lane_mask
                    self.prbs_rx_poly  = self.prbs_tx_poly
                    self.prbs_rx_rate  = self.prbs_tx_rate

                    if self.lpbk_mode == 1 and num_args != 10:
                        log_err("Missing delay param\n")
                        check_failed = True
                        help_prbs_comphy(self, args)
                        return check_failed

                    self.prbs_delay    = int(self.arg_list[9])
                else:
                    # Disable by default
                    self.lpbk_mode = 0

                if dp < 0:
                    log_err("Invalid tx port number param\n")
                    check_failed = True

                if self.tx_lane_mask < 0 or self.tx_lane_mask  > 0xFF:
                    log_err("Invalid tx lane mask param\n");
                    check_failed = True

                if self.prbs_tx_poly is None:
                    log_err("Invalid PRBS polynomial param\n")
                    check_failed = True

                if self.prbs_tx_rate is None:
                    log_err("Invalid PRBS rate param\n")
                    check_failed = True

        elif self.rx_serdes == 1:

            if num_args < 9:
                log_err("Incorrect params passed to the test\n")
                help_prbs_comphy(self, args)
                check_failed = True
                return check_failed

            if self.arg_list[4] == 'all':
                self.rx_port    = self._getAlldevport()
            else:
                self.rx_port.append(int(self.arg_list[4]))

            if self.arg_list[5] == 'all':
                self.rx_lane_mask   = 0xFF
            else:
                self.rx_lane_mask   = int(self.arg_list[5], 16)

            self.prbs_rx_poly  = get_prbs_poly(self, self.arg_list[6])
            self.prbs_rx_rate  = get_prbs_rate(self, self.arg_list[7])
            self.prbs_delay    = int(self.arg_list[8])


            for dp in self.rx_port:
                # Get lane mask for 'all' input
                if self.rx_lane_mask == 0xFF:
                    rx_lane_mask = devport_obj.getLaneMask(dp)
                else:
                    rx_lane_mask = self.rx_lane_mask

                if dp < 0:
                    log_err("Invalid rx port number param\n")
                    check_failed = True

                if self.rx_lane_mask < 0 or self.rx_lane_mask  > 0xFF:
                    log_err("Invalid rx lane mask param\n");
                    check_failed = True

                if self.prbs_rx_poly is None:
                    log_err("Invalid PRBS polynomial param\n")
                    check_failed = True

                if self.prbs_rx_rate is None:
                    log_err("Invalid PRBS rate param\n")
                    check_failed = True

                if self.prbs_delay < 0:
                    log_err("Invalid delay param\n")
                    check_failed = True

        return check_failed

# ------------
# test command
# ------------
def prbs_tl10(self, args):

    node_id = self.cli.node_id
    if ifcs_ctypes.im_nmgr_node_device_type_get(node_id) != ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TL10:
        log("Command not valid for chip type!")
        return ifcs_ctypes.IFCS_INVAL

    self.prbs_table = PrintTable()
    self.prbs_table.add_row(['Devport', 'Lane', 'ISG', 'Rate', 'Polynomial','Err Diff', 'BER'])

    if validate_user_input(self, args) == True:
        return ifcs_ctypes.IFCS_INVAL

    # For sync command, return
    if self.sync_cmd == True:
        return ifcs_ctypes.IFCS_SUCCESS

    devport_obj = Devport(self.cli)

    if self.tx_serdes == 1:
        # Tx serdes
        if self.tx_stop == 1:
            log("Stopping Tx PRBS")
            for dp in self.tx_port:
                prbs_tx_stop(self, dp, self.dp_orig_lane_mask[dp])
            #Devport down and up for ports fail to link up after prbs stop
            for dp in self.tx_port:
                devport_obj.setAdminState(dp, 1)
            for dp in self.tx_port:
                devport_obj.setAdminState(dp, 0)

            return

        log("Setting up Tx PRBS")
        # Disable all ports
        for dp in self.tx_port:
            disable_tx(self, dp)

        # Set up Tx PRBS
        for dp in self.tx_port:
            # Get lane mask for 'all' input
            if self.tx_lane_mask == 0xFF:
                tx_lane_mask = devport_obj.getLaneMask(dp)
            else:
                tx_lane_mask = self.tx_lane_mask

            setup_tx(self, dp, tx_lane_mask)

        log("Waiting for Tx setup to complete")
        time.sleep(2)

    if self.lpbk_mode == 1 or self.rx_serdes == 1:
        # Rx serdes
        if self.rx_stop == 1:
            log("Stopping Rx PRBS")
            for dp in self.rx_port:
                prbs_rx_stop(self, dp, self.dp_orig_lane_mask[dp])
            #Devport down and up for ports fail to link up after prbs stop
            for dp in self.rx_port:
                devport_obj.setAdminState(dp, 1)
            for dp in self.rx_port:
                devport_obj.setAdminState(dp, 0)

            return

        log("Setting up Rx PRBS")
        # Disable all ports
        for dp in self.rx_port:
            disable_rx(self, dp)

        for dp in self.rx_port:
            # Get lane mask for 'all' input
            if self.rx_lane_mask == 0xFF:
                rx_lane_mask = devport_obj.getLaneMask(dp)
            else:
                rx_lane_mask = self.rx_lane_mask

        for dp in self.rx_port:
            # Get lane mask for 'all' input
            if self.rx_lane_mask == 0xFF:
                rx_lane_mask = devport_obj.getLaneMask(dp)
            else:
                rx_lane_mask = self.rx_lane_mask

            setup_rx(self, dp, rx_lane_mask)

        log("Starting Rx comparator")
        for dp in self.rx_port:
            # Get lane mask for 'all' input
            if self.rx_lane_mask == 0xFF:
                rx_lane_mask = devport_obj.getLaneMask(dp)
            else:
                rx_lane_mask = self.rx_lane_mask

        for dp in self.rx_port:
            # Get lane mask for 'all' input
            if self.rx_lane_mask == 0xFF:
                rx_lane_mask = devport_obj.getLaneMask(dp)
            else:
                rx_lane_mask = self.rx_lane_mask

            start_rx_compare(self, dp, rx_lane_mask)

        if all([self.prbs_rx_rate >= ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_3_125GBS,
                self.prbs_rx_rate <= ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_28_125GBS]):
            time.sleep(1)
        elif all([self.prbs_rx_rate >= ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_51_5625GBS,
                  self.prbs_rx_rate <= ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_56_25GBS]):
            time.sleep(4)
        else:
            time.sleep(12)

        time.sleep(self.prbs_delay)

        for dp in self.rx_port:
            # Get lane mask for 'all' input
            if self.rx_lane_mask == 0xFF:
                rx_lane_mask = devport_obj.getLaneMask(dp)
            else:
                rx_lane_mask = self.rx_lane_mask

            stop_rx_compare(self, dp, rx_lane_mask)

        self.prbs_poly = devport_obj.enum_to_str('prbs_checker_poly', self.prbs_rx_poly)
        self.prbs_rate = devport_obj.enum_to_str('prbs_rx_rate', self.prbs_rx_rate)

        log("Starting Rx checker")
        check_rx(self, self.rx_port, self.rx_lane_mask, self.prbs_delay)

        log("\n")
        self.prbs_table.print_table()
        self.prbs_table.reset_table()

def check_rx(self, rx_port, lane_mask, prbs_delay):
        '''
        Method to check Rx PRBS status
        '''
        node_id = self.cli.node_id
        devport_obj = Devport(self.cli)

        devport = rx_port[0]
        devport_info = get_devport_info(self, devport)
        num_lanes = devport_obj.getNumLanes(devport)

        devport = 1 # dummy
        lane = 0 # dummy

        for dp in rx_port:
            prbs_err_count = devport_obj.getPrbsErrCount2(dp)
            devport_info = get_devport_info(self, dp)
            num_lanes    = devport_obj.getNumLanes(dp)
            prbs_ber     = devport_obj.getPrbsBer2(dp)
            prbs_lock    = devport_obj.getPrbsLock(dp)
            for i in range(num_lanes):
                if ((lane_mask >> i) & 0x1):
                    # Get the err diff and BER
                    if prbs_lock[i] == 0:
                        err_diff = 'NO LOCK'
                    else:
                        err_diff = prbs_err_count[i]

                    if prbs_lock[i] == 0:
                       ber = 'N/A'
                    else:
                       ber = prbs_ber[i]

                    self.prbs_table.add_row([dp, i, devport_info[i][2], self.prbs_rate, self.prbs_poly, err_diff, ber])

            # Reset the original lane mask for the port
            attr_count = 1
            attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

            attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LANE_MASK
            attr_list_p[0].value.u32 = self.dp_orig_lane_mask[dp]

            rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, dp,
                                    attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));

            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Failed to enable comparator on devport %d" % dp)
                return rc
        return

def help_prbs_comphy(self, args):
        log("Usage:: \n" + \
              "  diagtest serdes prbs tx <devport> <lane-mask> <poly> <rate> <lpbk> <delay>\n" \
              " <devport>   - tx devport number or 'all' \n" \
              " <lane-mask> - tx devport lane number (0x0 - 0xFF, all)\n" \
              " <poly>          - PRBS polynomial\n" \
              "                    prbs7\n" \
              "                    prbs9\n" \
              "                    prbs11\n" \
              "                    prbs13\n" \
              "                    prbs15\n" \
              "                    prbs23\n" \
              "                    prbs31\n" \
              "                    prbs32\n" \
              " <rate>          - PRBS rate\n" \
              "                    10g (10.3125)\n" \
              "                    25g (25.78125)\n" \
              "                    26g (26.5625)\n" \
              "                    27g (27.1875)\n" \
              "                    28g (28.125)\n" \
              "                    51g (51.5625)\n" \
              "                    53g (53.125)\n" \
              "                    54g (54.375)\n" \
              "                    56g (56.25)\n" \
              "                    106g (106.25)\n" \
              "                    112g (112.50)\n" \
              " ----- Optional params -----\n"\
              " <lpbk>          - Loopback(local/internal) mode\n" \
              "                     - 1: Enable\n" \
              "                     - 0: Disable\n\n" \
              " <delay>         - Time (in sec) to run the PRBS, required if loopback mode is used\n" \
              "\n"\
              "  diagtest serdes prbs rx <devport> <lane-mask> <poly> <rate> <delay> <rx-pcal>\n" \
              " <devport>   - tx devport number or all\n" \
              " <lane-mask> - tx devport lane number (0x0 - 0xFF, all)\n" \
              " <poly>          - PRBS polynomial\n" \
              "                    prbs7\n" \
              "                    prbs9\n" \
              "                    prbs11\n" \
              "                    prbs13\n" \
              "                    prbs15\n" \
              "                    prbs23\n" \
              "                    prbs31\n" \
              "                    prbs32\n" \
              " <rate>          - PRBS rate\n" \
              "                    10g (10.3125)\n" \
              "                    25g (25.78125)\n" \
              "                    26g (26.5625)\n" \
              "                    27g (27.1875)\n" \
              "                    28g (28.125)\n" \
              "                    51g (51.5625)\n" \
              "                    53g (53.125)\n" \
              "                    54g (54.375)\n" \
              "                    56g (56.25)\n"\
              "                    106g (106.25)\n" \
              "                    112g (112.50)\n" \
              " <delay>         - Time (in sec) to run the PRBS\n" \
              "\n"\
              "  diagtest serdes prbs tx stop <devport> <lane-mask>\n" \
              " <devport>   - tx devport number or all \n" \
              " <lane-mask> - tx devport lane number (0x0 - 0xFF, all)\n" \
              "\n"\
              "  diagtest serdes prbs rx stop <devport> <lane-mask>\n" \
              " <devport>   - tx devport number or all\n" \
              " <lane-mask> - tx devport lane number (0x0 - 0xFF, all)\n")


def help_prbs_mode_en(self):
    log("Usage:: \n" + \
          "  diagtest serdes prbs mode-en <devport> <enable>\n" \
          " <devport>   - devport,range of devports or 'all' \n" \
          "               e.g. 1,2,3,4,16-20,30  \n" \
          " <enable>    - 1: enable PRBS mode  \n" \
          "               0: disable PRBS mode  \n" )

def help_prbs_set(self):
    log("Usage:: \n" + \
          "  diagtest serdes prbs set <devport> <enable-mode> <poly> <err-counter-limit> <compare-time>\n" \
          " <devport>           - devport,range of devports or 'all' \n" \
          "                         e.g. 1,2,3,4,16-20,30  \n" \
          " <enable-mode>       - 1: enable PRBS mode  \n" \
          " <poly>              - PRBS polynomial\n" \
          "                         prbs7\n" \
          "                         prbs9\n" \
          "                         prbs11\n" \
          "                         prbs13\n" \
          "                         prbs15\n" \
          "                         prbs23\n" \
          "                         prbs31\n" \
          " <err-counter-limit> - Number of errors to use for sync status determination\n" \
          " <compare-time>      - Time (in milli sec) to compute the BER and capture errors\n" )

def help_prbs_sync(self):
    log("Usage:: \n" + \
          "  diagtest serdes prbs sync <devport> \n" \
          " <devport>   - devport,range of devports or 'all' \n" \
          "               e.g. 1,2,3,4,16-20,30  \n")

def help_prbs_get(self):
    log("Usage:: \n" + \
          "  diagtest serdes prbs get <devport> \n" \
          " <devport>   - devport,range of devports or 'all' \n" \
          "               e.g. 1,2,3,4,16-20,30  \n" )


def help_prbs_clear(self):
    log("Usage:: \n" + \
          "  diagtest serdes prbs clear <devport> \n" \
          " <devport>   - devport,range of devports or 'all' \n" \
          "               e.g. 1,2,3,4,16-20,30  \n" )

def get_prbs_poly(self, poly_string):
    ''' Map the PRBS polynomial string input from
        the user to the corresponding enum
    '''
    if poly_string == 'ssprq':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_SSPRQ
    if poly_string == 'jitter_k28p5':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_JITTER_K28P5
    if poly_string == 'jitter_1t':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_JITTER_1T
    if poly_string == 'jitter_2t':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_JITTER_2T
    if poly_string == 'jitter_4t':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_JITTER_4T
    if poly_string == 'jitter_5t':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_JITTER_5T
    if poly_string == 'jitter_8t':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_JITTER_8T
    if poly_string == 'jitter_10t':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_JITTER_10T
    if poly_string == 'prbs7':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS7
    if poly_string == 'prbs9':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS9
    if poly_string == 'prbs11':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS11
    if poly_string == 'prbs13':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS13
    if poly_string == 'prbs15':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS15
    if poly_string == 'prbs16':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS16
    if poly_string == 'prbs23':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS23
    if poly_string == 'prbs31':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS31
    if poly_string == 'prbs32':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS32

    return

def get_prbs_rate(self, rate_string):
    ''' Map the PRBS rate string input from
        the user to the corresponding enum
    '''
    if rate_string == '3g':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_3_125GBS
    if rate_string == '10g':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_10_3125GBS
    if rate_string == '25g':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_25_78125GBS
    if rate_string == '26g':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_26_5625GBS
    if rate_string == '27g':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_27_1875GBS
    if rate_string == '28g':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_28_125GBS
    if rate_string == '51g':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_51_5625GBS
    if rate_string == '53g':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_53_125GBS
    if rate_string == '54g':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_54_375GBS
    if rate_string == '56g':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_56_25GBS
    if rate_string == '106g':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_106_25GBS
    if rate_string == '112g':
        return ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_112_5GBS

    return
